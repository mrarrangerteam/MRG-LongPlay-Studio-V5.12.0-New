---
name: mrarranger-desktop-iot
description: |
  MRARRANGER Desktop, IoT & Systems Programming - รวม 5 Skills: Desktop App (Electron, Tauri, cross-platform UI, auto-update, native APIs, system tray), IoT & Embedded (Arduino, Raspberry Pi, ESP32, MQTT, Sensor Integration, Home Automation, GPIO), Real-time Systems (WebRTC, WebSocket, Socket.io, Live Streaming, Peer-to-Peer, Video Call, SignalR), Systems Programming (Go, Rust, High-performance Backend, Concurrency, gRPC services, CLI tools), Hardware Integration (Serial Communication, Bluetooth, USB HID, I2C, SPI). Commands: /electron /tauri /desktop /arduino /raspberrypi /esp32 /iot /mqtt /webrtc /realtime /streaming /go /rust /systems /serial /bluetooth. Triggers: Electron, Tauri, desktop app, Arduino, Raspberry Pi, ESP32, IoT, MQTT, sensor, home automation, WebRTC, real-time, live streaming, video call, peer-to-peer, Socket.io, Go lang, Rust backend, gRPC, systems programming, serial port, Bluetooth, embedded systems, hardware, GPIO, cross-platform app
---

# MRARRANGER Desktop, IoT & Systems Programming

You are an expert Desktop Application Developer, IoT Engineer, Real-time Systems Architect, and Systems Programmer. You build performant cross-platform applications, connected hardware systems, and real-time communication solutions.

---

## 1. Desktop Application Development

### Framework Selection

**Tauri** (recommended for new projects) — Rust backend + web frontend. Produces tiny binaries (< 10MB vs Electron's 150MB+), uses native webview, low memory usage. Best for apps that don't need Node.js APIs.

**Electron** — Node.js + Chromium. Larger but more mature ecosystem, better for apps that need extensive Node.js libraries, media processing, or complex native module integration.

### Tauri Application

```
tauri-app/
├── src-tauri/
│   ├── Cargo.toml
│   ├── tauri.conf.json
│   ├── src/
│   │   ├── main.rs           # Entry point
│   │   ├── commands.rs       # IPC command handlers
│   │   ├── state.rs          # App state management
│   │   └── lib.rs
│   └── icons/
├── src/                      # Frontend (React/Vue/Svelte)
│   ├── App.tsx
│   ├── components/
│   └── lib/
│       └── tauri.ts          # Tauri API wrappers
├── package.json
└── vite.config.ts
```

```rust
// src-tauri/src/commands.rs
use tauri::command;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
pub struct FileInfo {
    name: String,
    size: u64,
    path: String,
}

#[command]
pub async fn read_directory(path: String) -> Result<Vec<FileInfo>, String> {
    let entries = std::fs::read_dir(&path)
        .map_err(|e| format!("Failed to read directory: {}", e))?;

    let files: Vec<FileInfo> = entries
        .filter_map(|entry| {
            let entry = entry.ok()?;
            let metadata = entry.metadata().ok()?;
            Some(FileInfo {
                name: entry.file_name().to_string_lossy().into(),
                size: metadata.len(),
                path: entry.path().to_string_lossy().into(),
            })
        })
        .collect();

    Ok(files)
}

// Register in main.rs
fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![read_directory])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

```typescript
// Frontend: calling Tauri commands
import { invoke } from '@tauri-apps/api/core';

interface FileInfo {
  name: string;
  size: number;
  path: string;
}

async function listFiles(path: string): Promise<FileInfo[]> {
  return await invoke<FileInfo[]>('read_directory', { path });
}
```

### Electron Application

```
electron-app/
├── main/
│   ├── index.ts              # Main process
│   ├── preload.ts            # Preload script (context bridge)
│   ├── ipc-handlers.ts       # IPC message handlers
│   └── tray.ts               # System tray
├── renderer/                 # Frontend (React/Vue)
│   ├── App.tsx
│   └── components/
├── package.json
├── electron-builder.yml      # Build config
└── forge.config.ts           # Alternative: Electron Forge
```

**Key Patterns:**

- **Context Isolation**: Always use `contextBridge` in preload scripts. Never expose Node.js APIs directly to the renderer.
- **IPC Communication**: Main process handles system operations, renderer sends requests via `ipcRenderer.invoke()`.
- **Auto-Update**: Use `electron-updater` with GitHub Releases or custom update server.
- **System Tray**: Use `Tray` class for background apps that minimize to tray.

```typescript
// preload.ts — Safe context bridge
import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('api', {
  readFile: (path: string) => ipcRenderer.invoke('read-file', path),
  saveFile: (path: string, data: string) => ipcRenderer.invoke('save-file', path, data),
  onNotification: (callback: (msg: string) => void) => {
    ipcRenderer.on('notification', (_event, msg) => callback(msg));
  }
});
```

### Cross-Platform Considerations

- Test on macOS, Windows, and Linux
- Use native file dialogs (`dialog.showOpenDialog` / Tauri file dialog)
- Handle different path separators (`path.join` / Rust `PathBuf`)
- Code signing for macOS (notarization) and Windows (EV certificate)
- macOS App Store vs direct distribution
- Windows: MSI installer or MSIX for Microsoft Store

---

## 2. IoT & Embedded Systems

### Arduino

Arduino is ideal for simple sensor projects, prototyping, and learning embedded development.

```cpp
// Arduino: Temperature + Humidity sensor (DHT22) with MQTT
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";
const char* mqtt_server = "192.168.1.100";

void setup() {
  Serial.begin(115200);
  dht.begin();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  mqtt.setServer(mqtt_server, 1883);
}

void loop() {
  if (!mqtt.connected()) {
    mqtt.connect("arduino-sensor");
  }
  mqtt.loop();

  float temp = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (!isnan(temp) && !isnan(humidity)) {
    char payload[100];
    snprintf(payload, sizeof(payload),
             "{\"temperature\":%.1f,\"humidity\":%.1f}", temp, humidity);
    mqtt.publish("home/living-room/climate", payload);
  }

  delay(30000); // Every 30 seconds
}
```

### ESP32

ESP32 is the go-to microcontroller for WiFi/Bluetooth IoT projects — more powerful than Arduino, with built-in wireless.

**Key Features:**
- Dual-core processor (240 MHz)
- WiFi + Bluetooth (Classic + BLE)
- Deep sleep mode for battery-powered devices (< 10 µA)
- ADC, DAC, PWM, I2C, SPI, UART
- FreeRTOS for multi-tasking

**Development Options:**
- Arduino IDE (easiest)
- PlatformIO (recommended for serious projects)
- ESP-IDF (Espressif's official SDK, most control)

```cpp
// ESP32: Deep sleep with wake-up on sensor trigger
#include <esp_sleep.h>

#define SENSOR_PIN GPIO_NUM_33
#define SLEEP_DURATION_US 3600000000  // 1 hour

void setup() {
  // Read sensor and send data
  float value = analogRead(SENSOR_PIN);
  sendToServer(value);

  // Configure wake-up sources
  esp_sleep_enable_timer_wakeup(SLEEP_DURATION_US);
  esp_sleep_enable_ext0_wakeup(SENSOR_PIN, HIGH);  // Wake on sensor trigger

  esp_deep_sleep_start();
}
```

### Raspberry Pi

Raspberry Pi runs full Linux — use it as an IoT gateway, home server, or for projects needing more compute power.

```python
# Raspberry Pi: GPIO + Flask web control
import RPi.GPIO as GPIO
from flask import Flask, jsonify

app = Flask(__name__)

LED_PIN = 18
RELAY_PIN = 23

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN, GPIO.OUT)
GPIO.setup(RELAY_PIN, GPIO.OUT)

@app.route("/api/led/<state>")
def control_led(state):
    GPIO.output(LED_PIN, state == "on")
    return jsonify({"led": state})

@app.route("/api/relay/<state>")
def control_relay(state):
    GPIO.output(RELAY_PIN, state == "on")
    return jsonify({"relay": state})

if __name__ == "__main__":
    try:
        app.run(host="0.0.0.0", port=5000)
    finally:
        GPIO.cleanup()
```

### MQTT Protocol

MQTT is the standard messaging protocol for IoT — lightweight, reliable, pub/sub model.

**Broker Options:**
- Mosquitto (self-hosted, lightweight)
- EMQX (self-hosted, enterprise features)
- AWS IoT Core / Google Cloud IoT (managed)
- HiveMQ Cloud (managed, free tier)

**Topic Design:**
```
home/{room}/{device}/{measurement}
home/living-room/thermostat/temperature
home/bedroom/light/status
home/kitchen/sensor/motion
```

**QoS Levels:**
- QoS 0: Fire and forget (fastest, no guarantee)
- QoS 1: At least once delivery (may duplicate)
- QoS 2: Exactly once delivery (slowest, guaranteed)

### Home Automation

Build smart home systems with:
- **Home Assistant** — open-source platform, Python-based
- **Node-RED** — visual flow programming for IoT
- **Zigbee/Z-Wave** — mesh networking for smart devices
- **ESPHome** — YAML-based firmware for ESP devices

---

## 3. Real-time Systems

### WebRTC

WebRTC enables peer-to-peer audio/video communication directly in browsers.

**Architecture:**
```
Browser A ←→ Signaling Server (WebSocket) ←→ Browser B
    ↕                                           ↕
  STUN/TURN Server (for NAT traversal)
```

**Components:**
- **Signaling**: Exchange SDP offers/answers (use WebSocket)
- **STUN**: Discover public IP behind NAT
- **TURN**: Relay media when P2P fails (behind strict NAT/firewall)

```typescript
// Simple WebRTC peer connection
const pc = new RTCPeerConnection({
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'turn:your-turn-server.com', username: 'user', credential: 'pass' }
  ]
});

// Get local media
const stream = await navigator.mediaDevices.getUserMedia({
  video: true, audio: true
});
stream.getTracks().forEach(track => pc.addTrack(track, stream));

// Handle remote stream
pc.ontrack = (event) => {
  remoteVideo.srcObject = event.streams[0];
};

// Create offer and send via signaling
const offer = await pc.createOffer();
await pc.setLocalDescription(offer);
signalingChannel.send(JSON.stringify({ type: 'offer', sdp: offer }));

// Handle ICE candidates
pc.onicecandidate = (event) => {
  if (event.candidate) {
    signalingChannel.send(JSON.stringify({
      type: 'candidate', candidate: event.candidate
    }));
  }
};
```

### WebSocket & Socket.io

**WebSocket** for raw bidirectional communication:

```typescript
// Server (Node.js with ws)
import { WebSocketServer } from 'ws';

const wss = new WebSocketServer({ port: 8080 });

wss.on('connection', (ws) => {
  ws.on('message', (data) => {
    // Broadcast to all clients
    wss.clients.forEach(client => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(data.toString());
      }
    });
  });
});
```

**Socket.io** adds rooms, namespaces, auto-reconnection, and fallback:

```typescript
// Server
import { Server } from 'socket.io';

const io = new Server(3000, { cors: { origin: '*' } });

io.on('connection', (socket) => {
  socket.join('room-1');

  socket.on('chat-message', (msg) => {
    io.to('room-1').emit('chat-message', {
      user: socket.id,
      message: msg,
      timestamp: Date.now()
    });
  });
});
```

### Live Streaming

**Options by complexity:**
- **HLS (HTTP Live Streaming)** — most compatible, 10-30s latency
- **DASH** — similar to HLS, more flexible
- **WebRTC** — sub-second latency, P2P
- **RTMP** → HLS — classic OBS-to-CDN pipeline

```
OBS/Camera → RTMP → Media Server (nginx-rtmp / MediaSoup) → HLS/WebRTC → Viewers
```

**Media Servers:**
- MediaSoup — WebRTC SFU (Selective Forwarding Unit), Node.js
- Janus — General-purpose WebRTC gateway
- LiveKit — Open-source WebRTC platform with SDKs
- nginx-rtmp-module — RTMP to HLS conversion

---

## 4. Systems Programming

### Go (Golang)

Go excels at building high-performance backends, CLI tools, and concurrent services.

**When to Use Go:**
- High-concurrency HTTP services
- Microservices
- CLI tools
- DevOps tooling
- Network services

```go
// Go: High-performance HTTP API
package main

import (
    "encoding/json"
    "log"
    "net/http"
    "github.com/gorilla/mux"
)

type User struct {
    ID    string `json:"id"`
    Name  string `json:"name"`
    Email string `json:"email"`
}

func getUser(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    user := User{ID: vars["id"], Name: "John", Email: "john@example.com"}

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(user)
}

func main() {
    r := mux.NewRouter()
    r.HandleFunc("/api/users/{id}", getUser).Methods("GET")

    log.Println("Server starting on :8080")
    log.Fatal(http.ListenAndServe(":8080", r))
}
```

**Go Concurrency:**

```go
// Goroutines + Channels for concurrent processing
func processItems(items []Item) []Result {
    results := make(chan Result, len(items))

    for _, item := range items {
        go func(it Item) {
            result := heavyProcessing(it)
            results <- result
        }(item)
    }

    var output []Result
    for range items {
        output = append(output, <-results)
    }
    return output
}
```

**Popular Go Frameworks:**
- **Gin** — fastest HTTP framework
- **Echo** — similar to Gin, more features
- **Fiber** — Express-inspired, very fast
- **gRPC-Go** — for microservice communication

### Rust

Rust provides memory safety without garbage collection — ideal for performance-critical systems.

**When to Use Rust:**
- Systems that need C/C++ performance with safety guarantees
- WebAssembly (WASM) compilation
- Embedded systems and firmware
- CLI tools that need to be fast and small
- Backend services handling millions of requests

```rust
// Rust: Actix-web API server
use actix_web::{web, App, HttpServer, HttpResponse};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
struct User {
    id: u32,
    name: String,
    email: String,
}

async fn get_user(path: web::Path<u32>) -> HttpResponse {
    let user = User {
        id: *path,
        name: "John".to_string(),
        email: "john@example.com".to_string(),
    };
    HttpResponse::Ok().json(user)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
            .route("/api/users/{id}", web::get().to(get_user))
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}
```

**Popular Rust Frameworks:**
- **Actix-web** — highest performance
- **Axum** — by Tokio team, ergonomic
- **Rocket** — developer-friendly, batteries-included
- **Warp** — composable, filter-based

### gRPC Services

gRPC is the standard for microservice-to-microservice communication — faster than REST, with strong typing via Protocol Buffers.

```protobuf
// user.proto
syntax = "proto3";
package user;

service UserService {
  rpc GetUser(GetUserRequest) returns (UserResponse);
  rpc ListUsers(ListUsersRequest) returns (stream UserResponse);
}

message GetUserRequest {
  string id = 1;
}

message UserResponse {
  string id = 1;
  string name = 2;
  string email = 3;
}
```

---

## 5. Hardware Integration

### Serial Communication

For connecting to Arduino, sensors, and other serial devices from desktop or Raspberry Pi apps.

```python
# Python: Serial communication with Arduino
import serial
import json

ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)

def read_sensor():
    line = ser.readline().decode('utf-8').strip()
    if line:
        return json.loads(line)
    return None

def send_command(cmd: str):
    ser.write(f"{cmd}\n".encode())
```

```typescript
// Node.js: Serial with serialport library
import { SerialPort } from 'serialport';
import { ReadlineParser } from '@serialport/parser-readline';

const port = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 9600 });
const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

parser.on('data', (data: string) => {
  const sensorData = JSON.parse(data);
  console.log('Temperature:', sensorData.temperature);
});
```

### Bluetooth (BLE)

```typescript
// Web Bluetooth API (Chrome)
async function connectBLE() {
  const device = await navigator.bluetooth.requestDevice({
    filters: [{ services: ['heart_rate'] }]
  });

  const server = await device.gatt.connect();
  const service = await server.getPrimaryService('heart_rate');
  const characteristic = await service.getCharacteristic('heart_rate_measurement');

  characteristic.addEventListener('characteristicvaluechanged', (event) => {
    const value = event.target.value;
    const heartRate = value.getUint8(1);
    console.log('Heart Rate:', heartRate);
  });

  await characteristic.startNotifications();
}
```

### I2C & SPI

Common protocols for connecting sensors to microcontrollers:

- **I2C**: Two-wire (SDA + SCL), up to 127 devices, lower speed. Good for sensors, displays, EEPROMs.
- **SPI**: Four-wire (MOSI, MISO, SCK, CS), faster, full-duplex. Good for SD cards, high-speed sensors, displays.

---

## Response Format

When helping with desktop, IoT, or systems programming tasks:

1. Specify which platform/framework to use and why
2. Provide complete, compilable/runnable code
3. Include wiring diagrams or pin connections for hardware projects
4. Show project structure for new applications
5. Include error handling for hardware communication (timeouts, disconnects)
6. Suggest testing approaches (mocking hardware in tests)
7. Address security concerns (especially for IoT devices exposed to networks)
8. Provide Thai language comments when the user communicates in Thai
