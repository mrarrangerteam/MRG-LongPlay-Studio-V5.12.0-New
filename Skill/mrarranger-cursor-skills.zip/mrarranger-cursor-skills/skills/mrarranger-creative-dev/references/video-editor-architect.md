---
name: video-editor-architect
description: >-
  Expert guidance for building video editing software like CapCut, DaVinci Resolve,
  Premiere Pro, or browser-based editors. Use when building a video editor, designing
  timeline engines, implementing effects/transitions/filters, video rendering pipelines,
  FFmpeg integration, GPU compositing, text/subtitle overlays, export pipelines,
  audio-video sync, keyframe animation, or color grading/LUT systems. Trigger on
  "video editor", "NLE", "timeline", "video effects", "CapCut clone", "video cutting
  app", "short video maker", "reel maker", "video template system", or any app
  involving editing, compositing, or exporting video. Covers desktop (C++/Rust/Electron),
  web (WebCodecs/WebGL), and mobile. Not for simple video players or streaming servers.
---

# Video Editor Architect

You are a specialist skill for **designing and building video editing applications**.
Your job is to reason like a principal engineer at a video tools company who
understands the full pipeline — from media decoding through timeline editing
to final export.

## What this skill covers

- **Timeline Engine** — non-linear editing timeline, multi-track compositing, clip management, trimming, splitting, ripple/roll/slip/slide edits.
- **Media Pipeline** — decode (FFmpeg/libav, VideoToolbox, MediaCodec), frame caching, thumbnail generation, proxy workflows.
- **Rendering Engine** — GPU compositing (OpenGL/Vulkan/Metal/WebGL), blend modes, transforms, text rendering, effect stacking.
- **Effects & Transitions** — video filters, color grading, LUTs, transitions (dissolve, wipe, zoom), keyframe animation.
- **Text & Overlays** — text rendering, animated captions, subtitles (SRT/ASS), stickers, watermarks, templates.
- **Audio in Video** — audio waveform display, basic audio editing, audio-video sync, ducking, background music.
- **Export Pipeline** — encoding (H.264/H.265/VP9/AV1/ProRes), hardware acceleration (NVENC/QSV/VideoToolbox), format containers (MP4/MOV/WebM).
- **Project Management** — save/load, undo/redo, autosave, asset management.
- **Template System** — reusable video templates, dynamic text/media replacement (like CapCut templates).

## What this skill is NOT for

- Audio-only editing / DAW features (use `daw-engine-architect`)
- Live video streaming / broadcasting
- Video conferencing / WebRTC
- Simple video playback applications
- 3D animation / VFX compositing (Blender/After Effects level)

## Core architecture

### System Overview

```
┌──────────────────────────────────────────────────────┐
│                    UI Layer                           │
│  Timeline │ Preview │ Media Browser │ Inspector       │
├──────────────────────────────────────────────────────┤
│                 Editor Controller                     │
│  Commands │ Undo/Redo │ Selection │ Clipboard         │
├──────────────────────────────────────────────────────┤
│                  Composition Model                    │
│  Tracks │ Clips │ Effects │ Transitions │ Keyframes   │
├──────────────────────────────────────────────────────┤
│               Rendering Pipeline                      │
│  Frame Cache │ Compositor │ Effect Stack │ Text Engine │
├──────────────────────────────────────────────────────┤
│                  Media Engine                         │
│  Decoders │ Encoders │ Thumbnail Gen │ Proxy Gen      │
├──────────────────────────────────────────────────────┤
│               Platform / Hardware                     │
│  GPU (OpenGL/Vulkan/Metal) │ HW Codecs │ File I/O    │
└──────────────────────────────────────────────────────┘
```

### Thread Architecture

```
UI Thread (main)
├── Handle user interaction
├── Render timeline, controls, inspector
└── Send edit commands to controller

Preview Thread
├── Decode frames for current playhead position
├── Composite layers at playhead
└── Push rendered frames to preview display

Decode Thread Pool (2-4 threads)
├── Decode video frames from source files
├── Maintain frame cache (LRU)
└── Pre-decode ahead of playhead

Thumbnail Thread
├── Generate thumbnails for timeline display
└── Build thumbnail strips at multiple zoom levels

Export Thread
├── Sequential frame rendering
├── Encode to target format
└── Mux audio + video into container
```

## Timeline Engine

### Data Model

```
Project {
    composition: Composition,
    media_pool: MediaPool,
    settings: ProjectSettings,
    undo_stack: UndoStack,
}

Composition {
    tracks: Vec<Track>,
    duration: TimeCode,
    frame_rate: FrameRate,    // 24, 25, 29.97, 30, 60
    resolution: Resolution,   // 1920×1080, 3840×2160
}

Track {
    id: TrackId,
    kind: TrackKind,          // Video, Audio, Text, Effect
    clips: Vec<Clip>,
    visible: bool,
    locked: bool,
    blend_mode: BlendMode,
    opacity: f32,
}

Clip {
    id: ClipId,
    media_ref: MediaRef,           // reference to source media
    timeline_start: TimeCode,       // position on timeline
    timeline_duration: TimeCode,    // visible duration
    source_in: TimeCode,           // start point in source
    source_out: TimeCode,          // end point in source
    speed: f64,                    // 1.0 = normal, 2.0 = 2x
    effects: Vec<Effect>,
    transitions: (Option<Transition>, Option<Transition>),  // in, out
    opacity_keyframes: KeyframeTrack<f32>,
    transform_keyframes: KeyframeTrack<Transform2D>,
}
```

### Time Representation

```
TimeCode {
    frames: i64,  // absolute frame count from timeline start
}

// Conversion utilities
impl TimeCode {
    fn from_seconds(seconds: f64, fps: f64) -> Self;
    fn to_seconds(&self, fps: f64) -> f64;
    fn to_smpte(&self, fps: f64) -> String;  // "01:23:45:12"
    fn from_samples(samples: i64, sample_rate: u32, fps: f64) -> Self;
}
```

### Edit Operations

```
// Trim: change in/out points without moving clip
fn trim_clip_start(clip: &mut Clip, new_start: TimeCode);
fn trim_clip_end(clip: &mut Clip, new_end: TimeCode);

// Split: divide clip into two at playhead
fn split_clip(clip: Clip, at: TimeCode) -> (Clip, Clip);

// Ripple: move all subsequent clips when inserting/deleting
fn ripple_insert(track: &mut Track, at: TimeCode, duration: TimeCode);
fn ripple_delete(track: &mut Track, range: TimeRange);

// Slip: change source in/out without moving timeline position
fn slip_clip(clip: &mut Clip, offset: TimeCode);

// Slide: move clip position without changing source in/out
fn slide_clip(clip: &mut Clip, new_position: TimeCode);
```

## Media Pipeline

### Decoding Strategy

```
FFmpeg-based decoder:
1. Open file with avformat_open_input()
2. Find video/audio streams
3. Create codec contexts (avcodec)
4. Seek to target frame (av_seek_frame)
5. Decode frames (avcodec_send_packet / avcodec_receive_frame)
6. Convert pixel format (sws_scale) → RGB/RGBA for GPU upload
7. Cache decoded frame

Hardware-accelerated decoding:
- macOS: VideoToolbox (built into FFmpeg)
- Windows: DXVA2 / D3D11VA / CUDA
- Linux: VAAPI / VDPAU
- Web: WebCodecs API
```

### Frame Cache

```
FrameCache {
    cache: LRUCache<(MediaId, FrameNumber), DecodedFrame>,
    max_memory: usize,  // e.g., 2GB
    
    // Pre-decode strategy
    prefetch_ahead: i32,   // frames ahead of playhead to pre-decode
    prefetch_behind: i32,  // frames behind (for reverse playback)
}

// Priority: current frame > nearby frames > thumbnail frames
```

### Thumbnail Generation

```
ThumbnailStrip {
    media_id: MediaId,
    frames: Vec<SmallImage>,      // e.g., 160×90 px
    interval: TimeCode,           // one thumbnail every N frames
    
    // Multi-resolution for zoom levels
    levels: Vec<ThumbnailLevel>,  // coarse → fine
}

// Generate in background thread
// Cache to disk for fast reload
```

### Proxy Workflow
For high-res media (4K+), generate lower-res proxies for smooth editing:

```
Original: 3840×2160 ProRes → Proxy: 960×540 H.264
Edit using proxy → Export using original
```

## Rendering Pipeline

### Frame Compositing (per frame)

```
For each frame at time T:
1. Collect visible clips at time T (across all tracks)
2. For each clip (bottom to top):
   a. Decode source frame at clip's source time
   b. Apply clip effects (filters, color grading)
   c. Apply transform (position, scale, rotation, keyframed)
   d. Apply opacity (keyframed)
   e. Apply transition (if overlapping with adjacent clip)
3. Composite all layers using blend modes
4. Apply track-level effects
5. Render text/subtitle overlays
6. Output final frame
```

### GPU Compositing

```
OpenGL/WebGL approach:
- Upload decoded frames as textures
- Each clip = textured quad with transform matrix
- Effects = fragment shaders
- Blend modes = custom blend equations or shader-based
- Text = pre-rendered texture atlas or SDF rendering
- Final composite = render to framebuffer → read back or display

Key shaders:
- Color correction (brightness, contrast, saturation, hue)
- LUT application (3D lookup texture)
- Blur (gaussian, motion, radial)
- Chroma key (green screen removal)
- Transform (affine + perspective)
- Blend modes (multiply, screen, overlay, etc.)
```

## Effects System

### Effect Architecture

```
Effect {
    id: EffectId,
    effect_type: EffectType,
    parameters: Vec<EffectParameter>,
    enabled: bool,
    keyframes: HashMap<ParamId, KeyframeTrack>,
}

EffectParameter {
    id: ParamId,
    name: String,
    value: ParameterValue,
    default: ParameterValue,
    range: ParameterRange,
}

enum EffectType {
    // Color
    BrightnessContrast,
    HueSaturation,
    ColorBalance,
    LUT3D,
    Curves,
    
    // Blur/Sharpen
    GaussianBlur,
    MotionBlur,
    Sharpen,
    
    // Distortion
    ChromaKey,
    Transform,
    Crop,
    LensDistortion,
    
    // Stylize
    Vignette,
    FilmGrain,
    Glitch,
    Pixelate,
    
    // Time
    SpeedRamp,
    Freeze,
    Reverse,
}
```

### Keyframe Animation

```
KeyframeTrack<T> {
    keyframes: Vec<Keyframe<T>>,
}

Keyframe<T> {
    time: TimeCode,
    value: T,
    interpolation: Interpolation,
    ease_in: EaseHandle,   // bezier control point
    ease_out: EaseHandle,
}

enum Interpolation {
    Linear,
    EaseIn,
    EaseOut,
    EaseInOut,
    Bezier(f32, f32, f32, f32),  // cubic bezier
    Step,                         // hold until next keyframe
}

// Evaluate at time T
fn evaluate<T: Lerp>(track: &KeyframeTrack<T>, time: TimeCode) -> T {
    let (prev, next) = find_surrounding_keyframes(track, time);
    let t = normalized_time(prev.time, next.time, time);
    let eased_t = apply_easing(t, prev.ease_out, next.ease_in);
    lerp(prev.value, next.value, eased_t)
}
```

### Transition System

```
Transition {
    kind: TransitionKind,
    duration: TimeCode,
    parameters: HashMap<String, f32>,
}

enum TransitionKind {
    Dissolve,         // crossfade
    Wipe(Direction),  // left, right, up, down, diagonal
    Zoom,             // zoom in/out
    Slide(Direction), // push
    Blur,             // blur transition
    Custom(ShaderId), // custom shader
}

// Rendering a transition between clip A and clip B:
fn render_transition(frame_a: &Frame, frame_b: &Frame, 
                     transition: &Transition, progress: f32) -> Frame {
    // progress: 0.0 = full A, 1.0 = full B
    match transition.kind {
        Dissolve => blend(frame_a, frame_b, progress),
        Wipe(dir) => wipe_shader(frame_a, frame_b, dir, progress),
        // ...
    }
}
```

## Text & Subtitle Engine

### Text Overlay

```
TextOverlay {
    content: String,
    font: FontSpec,
    position: Position2D,     // keyframeable
    alignment: TextAlignment,
    color: Color,
    outline: Option<OutlineSpec>,
    shadow: Option<ShadowSpec>,
    background: Option<BackgroundSpec>,
    animation: Option<TextAnimation>,
    time_range: TimeRange,
}

enum TextAnimation {
    TypeWriter { speed: f32 },
    FadeIn { duration: TimeCode },
    SlideIn { direction: Direction, duration: TimeCode },
    PopIn { scale: f32, duration: TimeCode },
    Karaoke { word_timestamps: Vec<TimeCode> },
}
```

### Subtitle Support
Parse SRT, VTT, ASS formats → render as timed text overlays.
Support auto-captioning via speech-to-text integration.

## Export Pipeline

### Export Process

```
1. User selects export settings (format, resolution, bitrate, codec)
2. Create encoder context (FFmpeg: avcodec_open2)
3. For each frame (0 to total_frames):
   a. Render composited frame at full resolution
   b. Convert to encoder pixel format (usually YUV420)
   c. Encode frame (avcodec_send_frame / avcodec_receive_packet)
   d. Write packet to muxer (av_interleaved_write_frame)
   e. Report progress (frame / total_frames)
4. Flush encoder
5. Write trailer (av_write_trailer)
6. Close file
```

### Hardware-Accelerated Encoding

```
NVENC (NVIDIA):     H.264, H.265        // fastest
QSV (Intel):        H.264, H.265, AV1   
VideoToolbox (Mac): H.264, H.265, ProRes
AMF (AMD):          H.264, H.265, AV1
```

### Common Export Presets

```
Social Media:
- TikTok/Reels: 1080×1920, H.264, 30fps, 10-15 Mbps
- YouTube: 1920×1080 or 3840×2160, H.264/H.265, 30/60fps
- Twitter/X: 1280×720, H.264, 30fps, 5 Mbps

Professional:
- ProRes 422: for editing interchange
- DNxHR: Avid ecosystem
- H.265 10-bit: high quality delivery

Web:
- WebM VP9: good compression, browser-native
- MP4 H.264: maximum compatibility
```

## Technology Choices

### Desktop: C++ / Rust + FFmpeg
Best for: Professional-grade editor (DaVinci Resolve level)
Stack: C++/Rust core, FFmpeg for codecs, OpenGL/Vulkan/Metal for GPU, Qt/custom for UI

### Desktop: Electron + Native Module
Best for: CapCut desktop style
Stack: Electron UI, native Node addon for FFmpeg/GPU, Canvas/WebGL for preview

### Web: Browser-Based
Best for: Online editor (Kapwing, Clipchamp style)
Stack: WebCodecs for decode/encode, WebGL for compositing, Canvas for UI, WebAssembly for performance-critical code

Key Web APIs:
- `VideoDecoder` / `VideoEncoder` (WebCodecs)
- `WebGL2` / `WebGPU` for GPU compositing
- `OffscreenCanvas` for worker-thread rendering
- `SharedArrayBuffer` for zero-copy frame passing
- `File System Access API` for local file read/write

### Mobile: Native
- iOS: AVFoundation + Metal + Core Image
- Android: MediaCodec + OpenGL ES / Vulkan + RenderScript

## Template System (CapCut-style)

```
Template {
    id: TemplateId,
    name: String,
    preview_url: String,
    composition: Composition,     // full timeline structure
    placeholders: Vec<Placeholder>,
}

Placeholder {
    id: PlaceholderId,
    kind: PlaceholderKind,  // Video, Image, Text
    clip_id: ClipId,        // which clip in the composition
    label: String,          // "Your photo here"
    constraints: PlaceholderConstraints,
}

// User fills in placeholders → generates personalized video
fn apply_template(template: &Template, user_media: &HashMap<PlaceholderId, Media>) -> Composition {
    let mut comp = template.composition.clone();
    for (placeholder_id, media) in user_media {
        replace_placeholder(&mut comp, placeholder_id, media);
    }
    comp
}
```

## Common pitfalls

1. **Decoding on the UI thread** → frozen interface during scrubbing
2. **No frame cache** → re-decoding every frame on timeline scrub
3. **Ignoring audio-video sync** → audio drifts from video over time
4. **Fixed frame rate assumption** → variable frame rate sources break everything
5. **No proxy workflow** → 4K editing unusable without powerful hardware
6. **Pixel format confusion** → RGB vs YUV conversion errors cause color shift
7. **Not handling seek accurately** → seeking to keyframes only, not exact frames
8. **Export without hardware encoding** → 10× slower than necessary

## Default workflow

### Step 1 — Define scope
- Platform: desktop, web, mobile, or cross-platform?
- Target user: casual (CapCut-like) or professional (Premiere-like)?
- Key features for MVP?
- Template system needed?

### Step 2 — Choose the media stack
- Decoder: FFmpeg (desktop), WebCodecs (web), platform codecs (mobile)
- GPU: OpenGL/Vulkan/Metal (desktop), WebGL/WebGPU (web)
- Encoder: FFmpeg + hardware acceleration

### Step 3 — Build incrementally
1. Load and display a single video file
2. Basic timeline (place clips, play sequentially)
3. Trim and split clips
4. Multi-track compositing (picture-in-picture)
5. Text overlays
6. Effects and filters
7. Transitions
8. Keyframe animation
9. Audio editing (volume, basic effects)
10. Export pipeline
11. Undo/redo
12. Project save/load
13. Template system

### Step 4 — Optimize
- Frame cache tuning
- GPU shader optimization
- Proxy generation
- Thumbnail pre-generation
- Export speed (hardware encoding)

## Response style

1. **Goal** — What the user wants to build
2. **Architecture** — System diagram with components
3. **Data Model** — Timeline, clips, effects, keyframes
4. **Pipeline** — Decode → compose → render → encode flow
5. **Implementation** — Code patterns and library usage
6. **Pitfalls** — Common mistakes and how to avoid them
7. **Build Order** — What to implement first

## Additional resources

Load these only when relevant:
- [resources/ffmpeg-integration.md](resources/ffmpeg-integration.md) — FFmpeg API usage, codec setup, seek strategies, hardware acceleration.
- [resources/gpu-compositing.md](resources/gpu-compositing.md) — Shader patterns for effects, transitions, blend modes, text rendering.
- [resources/web-video-editor.md](resources/web-video-editor.md) — WebCodecs, WebGL compositing, browser-based editor architecture.

## Final rule

Video editing software must feel responsive above all else.
Users judge quality by how smooth the timeline scrubs, how fast the preview
updates, and how quick the export finishes. Optimize for perceived performance:
show something fast (even if approximate), then refine in the background.
Never let the user wait staring at a frozen screen.
