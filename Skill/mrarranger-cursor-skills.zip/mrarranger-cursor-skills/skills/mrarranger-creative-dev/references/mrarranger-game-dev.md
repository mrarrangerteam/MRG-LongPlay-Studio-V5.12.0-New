---
name: mrarranger-game-dev
description: |
  MRARRANGER Game Development - ระบบสร้างเกมครบวงจร ครอบคลุมทุก Engine (Unity, Godot, Phaser, Unreal, Bevy)
  Game Design Patterns, Physics, AI, Audio, Multiplayer, Monetization, Publishing
  ใช้เมื่อ: (1) สร้างเกม 2D/3D (2) เลือก Game Engine (3) ออกแบบ Game Design (4) เขียน Game Logic
  (5) ทำ Physics/Collision (6) สร้าง Game AI (7) ทำ Multiplayer (8) Publish เกมขึ้น Store
  (9) Monetization (10) Performance Optimization
  Commands: /game, /phaser, /godot, /unity, /gamedesign, /physics-game, /multiplayer, /publish-game
---

# MRARRANGER Game Development

ระบบสร้างเกมครบวงจร - ทุก Engine, ทุก Platform, ทุก Genre

## Quick Commands

```
/game [type]         → สร้างเกมทั่วไป (ระบุ genre)
/phaser [task]       → Phaser.js (web games)
/godot [task]        → Godot engine (indie games)
/unity [task]        → Unity C# scripting
/gamedesign [type]   → Game design patterns & theory
/physics-game        → Physics, collision, math
/multiplayer [type]  → Networking & real-time
/publish-game [platform] → Distribution & publishing
```

## Reference Files (อ่านเพิ่มเติม)

```
references/engines-and-implementation.md  → Unity scripting, Game Math, Physics, Game AI,
                                           Audio, UI/HUD, Multiplayer, Monetization,
                                           Publishing, Performance Optimization
                                           (ตัวอย่างโค้ดเต็ม C#, GDScript, JavaScript)
```

---

## Game Engines Overview

### เลือก Engine ตาม Project
```
PROJECT TYPE              → ENGINE           → LANGUAGE
Web game / itch.io        → Phaser.js        → JavaScript/TypeScript
Indie 2D/3D              → Godot             → GDScript / C#
Mobile / AAA / VR/AR     → Unity             → C#
High-end 3D / AAA        → Unreal Engine     → C++ / Blueprints
Performance-critical     → Bevy              → Rust
```

### Engine Quick Comparison
```
                Phaser    Godot     Unity       Unreal      Bevy
Cost            Free      Free      Free*       Free*       Free
2D              ★★★★★    ★★★★★    ★★★★       ★★★        ★★★★
3D              ★★        ★★★      ★★★★★     ★★★★★      ★★★★
Learning        ★★★★★    ★★★★     ★★★        ★★          ★★
Ecosystem       ★★★       ★★★      ★★★★★     ★★★★★      ★★
Mobile          ★★★       ★★★★     ★★★★★     ★★★★       ★★
* Revenue share applies for large studios
```

---

## Game Design Patterns

### Game Loop
```
while (gameRunning) {
  HandleInput();        // Process user input
  Update(deltaTime);    // Update game state
  Render();             // Draw to screen
}
```

### Component-Entity System (ECS)
```
Entity = GameObject / Node (แค่ ID)
Component = Data (Position, Health, Sprite)
System = Logic (Movement, Rendering, Physics)

ข้อดี: ยืดหยุ่น, reusable, ไม่ต้อง deep inheritance
ใช้ใน: Unity ECS, Bevy, Godot nodes
```

### State Machine Pattern
```csharp
enum PlayerState { Idle, Running, Jumping, Falling, Attacking }

void Update() {
  switch (currentState) {
    case PlayerState.Idle:
      if (moveInput != 0) currentState = PlayerState.Running;
      if (jumpPressed) currentState = PlayerState.Jumping;
      break;
    case PlayerState.Running:
      if (moveInput == 0) currentState = PlayerState.Idle;
      if (jumpPressed) currentState = PlayerState.Jumping;
      break;
    case PlayerState.Jumping:
      if (velocity.y < 0) currentState = PlayerState.Falling;
      break;
  }
}
```

### Observer Pattern (Events)
```csharp
// ใช้สำหรับ: damage, pickups, level complete, achievements
public delegate void OnPlayerDamaged(int damage);
public static event OnPlayerDamaged PlayerDamaged;

// Trigger
PlayerDamaged?.Invoke(10);

// Subscribe
OnEnable() => PlayerDamaged += HandleDamage;
OnDisable() => PlayerDamaged -= HandleDamage;
```

### Command Pattern (Input & Undo/Redo)
```csharp
public interface ICommand {
  void Execute();
  void Undo();
}

// ใช้สำหรับ: replay system, undo moves, input rebinding
Stack<ICommand> history = new();
void ExecuteCommand(ICommand cmd) {
  cmd.Execute();
  history.Push(cmd);
}
void UndoLast() {
  if (history.Count > 0) history.Pop().Undo();
}
```

### Object Pool Pattern
```csharp
// ใช้สำหรับ: bullets, particles, enemies ที่ spawn/despawn บ่อย
public class ObjectPool<T> where T : MonoBehaviour {
  private Stack<T> pool = new();
  public T Get() => pool.Count > 0 ? pool.Pop() : Instantiate(prefab);
  public void Return(T obj) { obj.gameObject.SetActive(false); pool.Push(obj); }
}
```

---

## Phaser.js (Web Games)

### Basic Game Setup
```javascript
const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  physics: {
    default: 'arcade',
    arcade: { gravity: { y: 300 }, debug: false }
  },
  scene: { preload, create, update }
};

function preload() {
  this.load.image('player', 'assets/player.png');
  this.load.spritesheet('coins', 'assets/coins.png', { frameWidth: 32, frameHeight: 32 });
}

function create() {
  this.player = this.physics.add.sprite(100, 300, 'player');
  this.player.setCollideWorldBounds(true);
  this.cursors = this.input.keyboard.createCursorKeys();

  // Coin group
  this.coins = this.physics.add.group({
    key: 'coins', repeat: 11, setXY: { x: 12, y: 0, stepX: 70 }
  });

  // Collision
  this.physics.add.overlap(this.player, this.coins, collectCoin, null, this);
}

function update() {
  if (this.cursors.left.isDown) this.player.setVelocityX(-160);
  else if (this.cursors.right.isDown) this.player.setVelocityX(160);
  else this.player.setVelocityX(0);

  if (this.cursors.up.isDown && this.player.body.touching.down)
    this.player.setVelocityY(-330);
}
```

### Scene Management
```javascript
class MenuScene extends Phaser.Scene {
  constructor() { super('MenuScene'); }
  create() {
    this.add.text(400, 300, 'PLAY', { fontSize: '48px' })
      .setOrigin(0.5).setInteractive()
      .on('pointerdown', () => this.scene.start('GameScene'));
  }
}

class GameScene extends Phaser.Scene {
  constructor() { super('GameScene'); }
  create() { /* game logic */ }
  update() { /* game loop */ }
}
```

---

## Godot (Indie Games)

### Scene & Nodes
```
Player (CharacterBody2D)
  ├── Sprite2D
  ├── CollisionShape2D
  ├── AnimationPlayer
  └── Camera2D
```

### Player Movement (GDScript)
```gdscript
extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

func _physics_process(delta):
  if not is_on_floor():
    velocity += get_gravity() * delta

  if Input.is_action_just_pressed("jump") and is_on_floor():
    velocity.y = JUMP_VELOCITY

  var direction = Input.get_axis("move_left", "move_right")
  velocity.x = direction * SPEED if direction else move_toward(velocity.x, 0, SPEED)
  move_and_slide()
```

### Signals (Event System)
```gdscript
# Define signal
signal health_changed(new_health)
signal player_died

# Emit
func take_damage(amount):
  health -= amount
  health_changed.emit(health)
  if health <= 0:
    player_died.emit()

# Connect
func _ready():
  player.health_changed.connect(_on_health_changed)

func _on_health_changed(new_health):
  health_bar.value = new_health
```

### Autoload (Global Singleton)
```gdscript
# GameManager.gd → Project > Project Settings > Autoload
extends Node

var score = 0
var level = 1

func _ready():
  add_to_group("game_manager")

# Access from anywhere: GameManager.score += 10
```

---

## Game Math Essentials

### Vectors & Movement
```
Direction = (Target - Current).normalized()
Movement = Direction × Speed × DeltaTime
Distance = |Target - Current|
```

### Lerp (Smooth Interpolation)
```csharp
// t goes from 0 to 1
Vector3 pos = Vector3.Lerp(startPos, endPos, t);

// Ease in/out: t = t * t * (3 - 2 * t)  (smoothstep)
// Ease in:     t = t * t
// Ease out:    t = 1 - (1 - t) * (1 - t)
```

### Collision Detection
```
Circle vs Circle: distance(A, B) < radiusA + radiusB
AABB vs AABB:     !(A.right < B.left || A.left > B.right ||
                    A.bottom < B.top || A.top > B.bottom)
Point in Circle:  distance(P, center) < radius
```

### A* Pathfinding (Concept)
```
1. Start node → Open Set
2. Loop:
   a. Pick node with lowest f = g + h (g=cost, h=heuristic)
   b. If goal → reconstruct path
   c. For each neighbor:
      - Calculate tentative g score
      - If better than known → update and add to Open Set
```

---

## Publishing Checklist

### Web (itch.io)
```
□ Build for Web (HTML5/WebGL)
□ Test in browser (Chrome, Firefox, Safari)
□ Compress assets (< 20MB ideal)
□ Create itch.io page with screenshots
□ Upload ZIP → Set to HTML embed
□ Configure controls description
```

### Steam
```
□ Register Steamworks developer ($100)
□ Create app ID & store page
□ Build for Windows/Mac/Linux
□ Steam achievements & cloud saves
□ Playtest & QA
□ Submit for review (2-5 business days)
```

### Mobile (iOS/Android)
```
□ Adapt controls for touch
□ Test on multiple screen sizes
□ App icons & screenshots (all sizes)
□ Privacy policy URL
□ Age rating (IARC)
□ iOS: Xcode → App Store Connect → Apple Review
□ Android: Gradle → Play Console → 24h review
```

---

## Performance Quick Reference

```
OPTIMIZATION                    IMPACT    EFFORT
Sprite atlases (texture pack)   ★★★★★    ★★
Object pooling                  ★★★★★    ★★★
Frustum culling                 ★★★★     ★★
LOD (Level of Detail)           ★★★★     ★★★
Reduce draw calls               ★★★★     ★★
Limit active lights              ★★★      ★
Audio compression               ★★★      ★
Lazy load distant scenes        ★★★      ★★
Profile FIRST, optimize SECOND  ∞         ★
```

> ดูตัวอย่างโค้ดเต็ม (Unity, Godot, Phaser) ใน `references/engines-and-implementation.md`
