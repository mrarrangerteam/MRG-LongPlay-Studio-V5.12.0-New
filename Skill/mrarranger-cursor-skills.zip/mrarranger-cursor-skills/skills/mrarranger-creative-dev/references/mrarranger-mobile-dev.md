---
name: mrarranger-mobile-dev
description: "Mobile Development Master Guide - React Native, Flutter, Swift, Kotlin, Cross-platform strategies, Performance, Security, Testing"
author: "mrarranger"
version: "1.0.0"
category: "Mobile Development"
---

# 📱 mrarranger-mobile-dev: Mobile Development Master Guide

> **คำแนะนำ**: Comprehensive mobile development skill covering iOS, Android, and cross-platform frameworks with production-ready patterns



## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations, advanced patterns, and in-depth examples, see:
- **advanced-mobile.md**: Advanced Mobile Development

These files contain:
- Detailed code examples & implementation patterns
- Advanced techniques & optimization strategies
- Integration examples & real-world use cases
- Edge cases & troubleshooting guides


## Quick Commands

- `/mobile` - General mobile development questions
- `/rn` - React Native with Expo/Bare workflow
- `/flutter` - Flutter and Dart development
- `/ios` - Swift/SwiftUI native iOS
- `/android` - Kotlin/Jetpack Compose native Android
- `/publish` - App Store/Play Store submission guide
- `/security` - Mobile security patterns and best practices
- `/perf` - Performance optimization techniques

---

## 1️⃣ React Native Development Guide

### Setup & Navigation

**Expo vs Bare Workflow**:
- **Expo**: Managed service, quick development, limited native access
- **Bare**: Full control, custom native modules, complex setup

```typescript
// Expo project setup
npx create-expo-app MyApp
npx expo install expo-router
npx expo install react-native-safe-area-context react-native-screens

// Tab navigation with Expo Router (App.tsx)
import { Tabs } from 'expo-router';

export default function TabsLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
```

### Native Modules Integration

```typescript
// Accessing native iOS/Android features
import { NativeModules } from 'react-native';

const BiometricAuth = NativeModules.BiometricModule;

export async function authenticateWithBiometric() {
  try {
    const result = await BiometricAuth.authenticate();
    return result.isAuthenticated;
  } catch (error) {
    console.error('Biometric auth failed:', error);
  }
}
```

---

## 2️⃣ Flutter Development Guide

### Project Structure & Widgets

```dart
// lib/main.dart - Entry point
import 'package:flutter/material.dart';
import 'package:riverpod_flutter/riverpod_flutter.dart';

void main() {
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

// State management with Riverpod
final userProvider = FutureProvider<User>((ref) async {
  return await fetchUserData();
});

class HomeScreen extends ConsumerWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(userProvider);

    return userAsync.when(
      data: (user) => Text('Hello, ${user.name}'),
      loading: () => const CircularProgressIndicator(),
      error: (err, stack) => Text('Error: $err'),
    );
  }
}
```

### Navigation Pattern (go_router)

```dart
import 'package:go_router/go_router.dart';

final router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(),
      routes: [
        GoRoute(
          path: 'detail/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return DetailScreen(id: id);
          },
        ),
      ],
    ),
  ],
);
```

---

## 3️⃣ iOS Native Development (Swift/SwiftUI)

### SwiftUI View & State Management

```swift
import SwiftUI

@main
struct MyApp: App {
  @StateObject private var viewModel = AuthViewModel()

  var body: some Scene {
    WindowGroup {
      if viewModel.isLoggedIn {
        MainTabView()
      } else {
        LoginView(viewModel: viewModel)
      }
    }
  }
}

// MVVM pattern
class AuthViewModel: ObservableObject {
  @Published var isLoggedIn = false
  @Published var errorMessage: String?

  func login(email: String, password: String) async {
    do {
      let token = try await AuthService.login(email, password)
      DispatchQueue.main.async {
        self.isLoggedIn = true
      }
    } catch {
      DispatchQueue.main.async {
        self.errorMessage = error.localizedDescription
      }
    }
  }
}

// SwiftUI View
struct LoginView: View {
  @ObservedObject var viewModel: AuthViewModel
  @State private var email = ""
  @State private var password = ""

  var body: some View {
    VStack(spacing: 16) {
      TextField("Email", text: $email)
        .textInputAutocapitalization(.never)
      SecureField("Password", text: $password)

      Button(action: {
        Task {
          await viewModel.login(email: email, password: password)
        }
      }) {
        Text("Login")
          .frame(maxWidth: .infinity)
          .padding()
          .background(Color.blue)
          .foregroundColor(.white)
          .cornerRadius(8)
      }

      if let error = viewModel.errorMessage {
        Text(error).foregroundColor(.red)
      }
    }
    .padding()
  }
}
```

---

## 4️⃣ Android Native Development (Kotlin/Jetpack Compose)

### Jetpack Compose UI

```kotlin
// MainActivity.kt
class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      MyAppTheme {
        MyApp()
      }
    }
  }
}

// Main composable
@Composable
fun MyApp() {
  val navController = rememberNavController()
  NavHost(navController = navController, startDestination = "home") {
    composable("home") { HomeScreen(navController) }
    composable("detail/{id}") { backStackEntry ->
      val id = backStackEntry.arguments?.getString("id")
      DetailScreen(id = id, navController = navController)
    }
  }
}

// ViewModel with Jetpack Compose
class LoginViewModel : ViewModel() {
  private val _uiState = MutableStateFlow(LoginUiState())
  val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

  fun login(email: String, password: String) {
    viewModelScope.launch {
      try {
        val token = authRepository.login(email, password)
        _uiState.update { it.copy(isLoggedIn = true) }
      } catch (e: Exception) {
        _uiState.update { it.copy(error = e.message) }
      }
    }
  }
}

@Composable
fun LoginScreen(viewModel: LoginViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsState()
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }

  Column(modifier = Modifier.padding(16.dp)) {
    TextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
    TextField(value = password, onValueChange = { password = it }, label = { Text("Password") })

    Button(onClick = { viewModel.login(email, password) }) {
      Text("Login")
    }

    if (uiState.error != null) {
      Text(uiState.error!!, color = Color.Red)
    }
  }
}

data class LoginUiState(val isLoggedIn: Boolean = false, val error: String? = null)
```

---

## 5️⃣ Cross-Platform Strategy Guide

| Framework | Best For | Native Access | Learning Curve |
|-----------|----------|----------------|-----------------|
| **React Native** | Quick MVP, shared JS team | Good (Modules) | Medium |
| **Flutter** | Performance, UI consistency | Excellent | Medium-High |
| **Swift/Kotlin** | Premium app, native features | Perfect | High |
| **Hybrid** | Simple apps, minimal native | Limited | Low |

**Decision Tree**:
- ✅ Want shared codebase? → React Native or Flutter
- ✅ Need custom UI polish? → Flutter (better rendering)
- ✅ Have JS engineers? → React Native
- ✅ Need maximum performance? → Swift/Kotlin native
- ✅ Using native SDKs heavily? → Swift/Kotlin

---


## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations and advanced patterns, see:

- **advanced-mobile.md**: Advanced techniques and detailed examples

