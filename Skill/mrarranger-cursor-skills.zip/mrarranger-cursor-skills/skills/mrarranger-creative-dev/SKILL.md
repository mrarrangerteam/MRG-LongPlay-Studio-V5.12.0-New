---
name: mrarranger-creative-dev
description: "MRARRANGER Creative Dev - รวม 5 Skills: Mobile Dev (React Native, Flutter, iOS, Android, App Store), Game Dev (Unity, Godot, Unreal, Phaser, Game Design, Physics), Audio Plugin (VST3, AU, CLAP, JUCE, Synth, Effects, DSP), DAW Engine (Digital Audio Workstation, Audio Graph, Mixer, Timeline, MIDI), Video Editor (NLE, Timeline Engine, FFmpeg, WebCodecs, Effects, Rendering). Commands: /mobile /flutter /react-native /game /unity /godot /vst /plugin /daw /audio-engine /video-editor /timeline"
---

# mrarranger-creative-dev - Combined Skill

> Auto-routing: วิเคราะห์ request แล้วโหลด reference ที่เกี่ยวข้อง

## HOW TO USE
1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง
3. โหลด reference file ที่ตรงกับ request
4. Execute ตาม instructions ใน reference

## SKILL ROUTING TABLE

| Skill | Reference File |
|-------|---------------|
| mrarranger-mobile-dev | references/mrarranger-mobile-dev.md |
| mrarranger-game-dev | references/mrarranger-game-dev.md |
| audio-plugin-developer | references/audio-plugin-developer.md |
| daw-engine-architect | references/daw-engine-architect.md |
| video-editor-architect | references/video-editor-architect.md |

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ skill ไหนจาก routing table
2. ใช้ `view` tool อ่าน reference file ที่เกี่ยวข้อง
3. ทำตาม instructions ใน reference file นั้นอย่างเคร่งครัด
4. ถ้าเกี่ยวข้องหลาย skills ให้อ่านทุก reference ที่เกี่ยวข้อง
