---
name: mrarranger-dev-tools
description: "MRARRANGER Dev Tools - 9 Skills: Code Master (Clean Code, SOLID), Debug Master (Error Handling, Profiling), CLI Tools (Shell, Automation), MCP Builder (Tool Creation), Technical Docs (API Docs, README), Agent Browser (Web Scraping), Superpowers (Advanced Claude), Vibe Code Guardian (Security Audit, 15-Team Review), Code Review Graph (Knowledge Graph PR Review, Blast Radius, OWASP, Delta Review). Commands: /code /debug /cli /mcp /docs /browse /superpower /guard /review-pr /review-delta /build-graph /blast /security-review /review-arch /review-perf /review-test. Triggers: code review, PR review, pull request, blast radius, knowledge graph, security review, OWASP, test coverage, architecture review, delta review, impact analysis, code quality, refactoring, debugging, MCP, vibe code, guardian audit"
---

# mrarranger-dev-tools - Combined Skill (v2.0)

> Auto-routing: วิเคราะห์ request แล้วโหลด reference ที่เกี่ยวข้อง
> v2.0: +Code Review Graph System (replaces review-pr, review-delta, build-graph)

## HOW TO USE
1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง
3. โหลด reference file ที่ตรงกับ request
4. Execute ตาม instructions ใน reference

## SKILL ROUTING TABLE

| Skill | Commands | Reference File |
|-------|----------|---------------|
| Code Master | /code | references/mrarranger-code-master.md |
| Debug Master | /debug | references/mrarranger-debug-master.md |
| CLI Tools | /cli | references/mrarranger-cli-tools.md |
| MCP Builder | /mcp | references/mrarranger-mcp-builder.md |
| Technical Docs | /docs | references/mrarranger-technical-docs.md |
| Agent Browser | /browse /scrape | references/mrarranger-agent-browser.md |
| Superpowers | /superpower | references/mrarranger-superpowers.md |
| Vibe Code Guardian | /guard /review | references/vibe-code-guardian.md |
| **Code Review Graph** | **/review-pr /review-delta /build-graph /blast /security-review /review-arch /review-perf /review-test** | **references/code-review-graph.md** |

## QUICK COMMAND REFERENCE

```
/review-pr [PR#]      — Full PR review with knowledge graph context
/review-delta          — Token-efficient delta review (last commit only)
/build-graph [full]    — Build/update semantic knowledge graph
/blast [file/func]     — Blast radius impact analysis
/security-review       — OWASP Top 10 + AI security checklist
/review-arch           — Architecture & dependency health review
/review-perf           — Performance review (N+1, memory, bottlenecks)
/review-test           — Test coverage gap analysis
/guard                 — Full Vibe Code Guardian audit (15-team)
/code                  — Clean code, refactoring, patterns
/debug                 — Debugging, error handling, profiling
/cli                   — Shell scripts, CLI apps, automation
/mcp                   — MCP server/tool creation
/docs                  — API docs, README, changelog
/browse                — Web scraping, automation
/superpower            — Advanced Claude techniques
```

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ skill ไหนจาก routing table
2. ใช้ `view` tool อ่าน reference file ที่เกี่ยวข้อง
3. ทำตาม instructions ใน reference file นั้นอย่างเคร่งครัด
4. ถ้าเกี่ยวข้องหลาย skills ให้อ่านทุก reference ที่เกี่ยวข้อง

## COMBO PATTERNS

| ใช้งาน | โหลด References |
|--------|----------------|
| Full audit + PR review | vibe-code-guardian.md + code-review-graph.md |
| Security-focused review | code-review-graph.md (Section 5) + team-security.md |
| Refactoring with tests | mrarranger-code-master.md + code-review-graph.md (Section 7) |
| Debug + blast radius | mrarranger-debug-master.md + code-review-graph.md (Section 4) |
