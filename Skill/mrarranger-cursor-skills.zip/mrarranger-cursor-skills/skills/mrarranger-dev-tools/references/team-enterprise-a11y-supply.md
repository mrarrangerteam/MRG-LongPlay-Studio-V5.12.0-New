# Team 14: Enterprise Compliance Team

## บทบาท
Enterprise Compliance Specialist — SOC 2, ISO 27001, NIST CSF 2.0, Bug Bounty

## ทำไมทีมนี้สำคัญ (แยกจาก Compliance Team เดิมที่ดู GDPR/PDPA/PCI)
- 83% ของ enterprise buyers ต้องการ SOC 2
- SOC 2 certified startups ปิด deals เร็วขึ้น 35%
- ISO 27001 adoption พุ่งถึง 81% ใน 2025
- NIST CSF 2.0 เพิ่ม Govern function สำหรับ AI governance

## Checklist

### 1. SOC 2 Readiness
**Trust Service Criteria (Security = บังคับ):**
- MFA everywhere
- RBAC + regular access reviews
- AES-256 encryption at rest
- TLS 1.2+ in transit
- Change management with documented approvals
- Continuous monitoring via SIEM
- Incident response plan documented
- Vendor management program
- Employee security training

**Vibe-Coded Specific Gaps:**
- Missing change management documentation สำหรับ AI-generated code
- No human code review trail
- Absent System Description สำหรับ AI architectures
- Cost: $20K-$50K with automation (Vanta, Drata, Secureframe)

### 2. ISO 27001:2022
- 93 Annex A controls (organizational, people, physical, technological)
- Control A.8.25: Secure Development Lifecycle — ต้องมี human review ของ AI code
- Fulfills ~84% of GDPR controls
- Global recognition (especially Europe/APAC)

### 3. NIST CSF 2.0 (ก.พ. 2024)
6 Core Functions:
- **Govern** (ใหม่): AI tool governance, acceptable AI practices, risk strategy
- **Identify**: Asset management, risk assessment
- **Protect**: Access control, training, data security
- **Detect**: Continuous monitoring, anomaly detection
- **Respond**: Incident response, communications
- **Recover**: Recovery planning, improvements

### 4. Bug Bounty Program
- AI-specific scope: MCP servers, AI chatbot, AI-generated API endpoints
- Reward structure: $100 (P4) → $5K-$10K (P1 Critical)
- Platforms: HackerOne, Bugcrowd, Intigriti (EU data sovereignty)
- security.txt file (RFC 9116)
- Vulnerability Disclosure Policy published
- PGP-encrypted reporting channel

### 5. SBOM & License Compliance
- Software Bill of Materials สำหรับทุก dependency
- License compatibility check (GPLv3 ใน commercial SaaS = ปัญหา)
- AI อาจ mix incompatible licenses โดยไม่รู้ตัว
- Code provenance tracking (label AI-generated code ใน PRs)

---

# Team 15: Accessibility, i18n & Supply Chain Team

## บทบาท
Accessibility/i18n Specialist — WCAG compliance, Unicode security, feature flags, supply chain

## ทำไมทีมนี้สำคัญ
- European Accessibility Act บังคับใช้ มิ.ย. 2025
- AI-generated UIs สร้าง decorative divs แทน semantic HTML
- Homoglyph attacks เกิด 31,000 ครั้ง/วัน
- Angular i18n XSS vulnerability: translation files ฉีด JavaScript ได้

## Checklist

### 1. Accessibility (WCAG 2.1 Level AA)
- Semantic HTML (header, nav, main, article — ไม่ใช่ div ทั้งหมด)
- Alt text ทุก image
- Form labels ทุก input
- Color contrast 4.5:1 สำหรับ text
- Keyboard navigation ทำงานครบ
- Focus indicators visible
- Screen reader tested (VoiceOver, NVDA)
- Skip navigation links
- ARIA attributes ถูกต้อง (ไม่ overuse)
- Error messages accessible

### 2. Internationalization Security
- Unicode normalization (NFC) on all inputs
- Homoglyph detection สำหรับ identifiers (usernames, URLs)
- RTL/bidirectional character stripping
- Trojan Source attack detection (mixed-script ใน source code)
- Translation files validated (ไม่มี script injection)

### 3. Feature Flags & Gradual Rollout
- Kill switch flags สำหรับ critical features
- Gradual rollout strategies documented
- Flags integrate กับ observability สำหรับ automatic rollback
- Temporary flags มี expiry dates
- Tools: LaunchDarkly, Unleash, Flagsmith, OpenFeature (CNCF)

### 4. Supply Chain Security
- SBOM (Software Bill of Materials) generated
- Dependency lock files committed (package-lock.json, yarn.lock)
- npm audit / Snyk ใน CI/CD pipeline
- AI plugin/skill vetting (5.2% แสดง malicious patterns)
- MCP server inventory + security audit
- ตรวจ typosquatting packages
- Pin dependency versions (ไม่ใช้ ^latest)

### 5. WebSocket Security (ถ้ามี real-time features)
- wss:// only (never ws://)
- Token-based auth during handshake
- Origin header validation against allowlist
- Per-message authorization
- Message schema validation
- Rate limiting per connection
- Session-to-connection mapping สำหรับ logout
