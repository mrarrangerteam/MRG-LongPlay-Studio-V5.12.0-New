---
name: mrarranger-superpowers
description: |
  MRARRANGER Superpowers - ระบบ Autonomous Agent Development ครบวงจร (Inspired by Obra Superpowers)
  รวม Brainstorming → Planning → TDD → Systematic Debugging → Code Review → Subagent Development → Verification
  เป็น Framework ที่ทำให้ Claude ทำงานเป็นระบบ autonomous ได้หลายชั่วโมงโดยไม่หลุด plan
  ใช้เมื่อ: (1) ต้องการทำงานแบบ autonomous หลายขั้นตอน (2) วางแผนงานซับซ้อน (3) เขียนโค้ดแบบ TDD
  (4) Debug อย่างเป็นระบบ (5) ทำ Code Review (6) สร้าง Subagent (7) Verify ก่อนส่งงาน
  (8) ต้องการให้ Claude คิด วางแผน แล้วทำงานเองจนจบ
  Commands: /superpower [task], /plan [goal], /tdd [feature], /debug [issue], /review [code], /subagent [task], /verify [output]
---

# MRARRANGER Superpowers System

ระบบนี้ทำให้ Claude ทำงานแบบ Autonomous Agent ได้อย่างมีระบบ ครอบคลุมตั้งแต่คิด วางแผน เขียน ทดสอบ จนส่งมอบ

## Quick Commands

```
/superpower [task]      → Full autonomous workflow (คิด→วางแผน→ทำ→ทดสอบ→ส่งมอบ)
/plan [goal]            → สร้าง structured plan
/tdd [feature]          → เขียน test ก่อน แล้วค่อย implement
/debug [issue]          → วิเคราะห์และแก้ bug อย่างเป็นระบบ
/review [code]          → Code review ระดับ Senior Engineer
/subagent [task]        → สร้าง subagent เฉพาะทาง
/verify [output]        → ตรวจสอบ output ก่อนส่งมอบ
/brainstorm [topic]     → Structured brainstorming
```

---

## Core Philosophy

### The Superpowers Chain
งานทุกชิ้นที่ซับซ้อนต้องผ่าน chain นี้:

```
BRAINSTORM → PLAN → IMPLEMENT (TDD) → DEBUG → REVIEW → VERIFY → DELIVER
```

แต่ละขั้นตอนมีกฎชัดเจน ไม่ข้ามขั้น ไม่ลัดทาง

### Key Principles
1. **Think before you code** - ห้ามเริ่ม implement ก่อน plan เสร็จ
2. **Test before you write** - เขียน test ก่อนเขียน code (TDD)
3. **Debug systematically** - อย่าเดา ให้หา root cause จริง
4. **Verify before delivery** - ตรวจสอบทุกอย่างก่อนส่งมอบ
5. **Document as you go** - บันทึกทุก decision ที่สำคัญ

---

## 1. Brainstorming Module

เมื่อได้รับโจทย์ใหม่ ให้เริ่มด้วย structured brainstorming:

### Process
```
1. RESTATE: เขียนโจทย์ใหม่ด้วยคำพูดตัวเอง ยืนยันกับ user
2. EXPLORE: หา 3-5 approaches ที่เป็นไปได้
3. EVALUATE: วิเคราะห์ pros/cons ของแต่ละ approach
4. SELECT: เลือก approach ที่ดีที่สุด พร้อมเหตุผล
5. VALIDATE: ยืนยันกับ user ก่อนไปขั้นต่อไป
```

### Brainstorm Template
```markdown
## Brainstorm: [Topic]

### Problem Statement
[restate ปัญหาด้วยคำพูดตัวเอง]

### Approaches
| # | Approach | Pros | Cons | Effort | Risk |
|---|----------|------|------|--------|------|
| 1 | ... | ... | ... | Low/Med/High | Low/Med/High |
| 2 | ... | ... | ... | ... | ... |
| 3 | ... | ... | ... | ... | ... |

### Recommendation
เลือก Approach #X เพราะ [เหตุผล]

### Open Questions
- [สิ่งที่ต้องตรวจสอบก่อน implement]
```

---

## 2. Writing Plans Module

แปลง brainstorm ที่ผ่านแล้วเป็น actionable plan:

### Plan Structure
```markdown
## Plan: [Feature/Task Name]

### Objective
[1 ประโยค บอกว่าจะทำอะไร ทำไม]

### Success Criteria
- [ ] [criteria 1 - ต้อง measurable]
- [ ] [criteria 2]
- [ ] [criteria 3]

### Steps
1. **[Step Name]** (est: Xm)
   - สิ่งที่ต้องทำ
   - Expected output
   - Dependencies: [none / step X]

2. **[Step Name]** (est: Xm)
   ...

### Risk Assessment
- Risk: [อะไร] → Mitigation: [ทำอย่างไร]

### Estimated Total Time: X minutes
```

### Plan Rules
- ทุก step ต้อง actionable (เริ่มด้วย verb)
- ทุก step ต้องมี expected output ที่ชัดเจน
- estimate เวลาแต่ละ step
- ระบุ dependencies ระหว่าง steps
- ถ้า plan เกิน 10 steps → แตกเป็น sub-plans

---

## 3. Test-Driven Development (TDD) Module

### TDD Cycle: Red → Green → Refactor

```
1. RED: เขียน test ที่ fail (เพราะยังไม่มี implementation)
2. GREEN: เขียน code ให้ test ผ่าน (minimal code เท่าที่จำเป็น)
3. REFACTOR: ปรับปรุง code โดยไม่ให้ test fail
```

### TDD Rules
- ห้ามเขียน production code ก่อนมี failing test
- เขียน test ทีละ 1 case (ไม่ใช่เขียนทุก test แล้วค่อย implement)
- แต่ละ test ต้อง test แค่ 1 behavior
- Test ต้อง readable - อ่านแล้วรู้ว่า test อะไร

### Test Template
```javascript
describe('[Feature/Module]', () => {
  describe('[Method/Behavior]', () => {
    it('should [expected behavior] when [condition]', () => {
      // Arrange - ตั้งค่า
      // Act - ทำ
      // Assert - ตรวจสอบ
    });

    it('should [handle edge case]', () => {
      // ...
    });
  });
});
```

### What to Test
```
ALWAYS test:
- Happy path (input ปกติ)
- Edge cases (empty, null, boundary values)
- Error cases (invalid input, network failure)
- Integration points (ต่อกับ external systems)

SKIP testing:
- Third-party library internals
- Simple getters/setters
- Framework behavior
```

---

## 4. Systematic Debugging Module

เมื่อเจอ bug ห้ามเดา ให้ทำตามระบบ:

### Debug Process: ISOLATE → REPRODUCE → DIAGNOSE → FIX → VERIFY

```
1. ISOLATE
   - บันทึก symptoms: อะไรผิด? เมื่อไหร่? ที่ไหน?
   - Error messages / stack traces
   - ระบุขอบเขต: component ไหน? function ไหน?

2. REPRODUCE
   - หา minimal reproduction steps
   - ทำซ้ำได้ทุกครั้งไหม?
   - เกิดเฉพาะ condition ไหน?

3. DIAGNOSE
   - สร้าง hypotheses (อย่างน้อย 2 ข้อ)
   - ทดสอบแต่ละ hypothesis
   - Binary search: ตัดครึ่งพื้นที่ที่เป็นไปได้
   - ดู logs, add logging ถ้าจำเป็น
   - CHECK: dependencies, config, data, state, timing

4. FIX
   - แก้ root cause ไม่ใช่ symptoms
   - เขียน test ที่ reproduce bug ก่อนแก้
   - Fix ให้ minimal - อย่าแก้ของอื่นไปด้วย

5. VERIFY
   - Run test ที่เขียนไว้ - ต้อง pass
   - Run existing tests - ต้องไม่ break
   - Test edge cases ที่เกี่ยวข้อง
   - ยืนยันว่า root cause ถูกแก้จริง
```

### Debug Decision Tree
```
Error เกิดขึ้น
├── มี error message? → อ่าน message ให้ละเอียด (มักบอกอยู่แล้ว)
├── ไม่มี error? → Add logging at boundaries
├── Works sometimes? → Race condition / timing / state
├── Works locally not in prod? → Environment diff / config
└── Worked before? → Check git diff since last working
```

---

## 5. Code Review Module

### Review Checklist (ใช้ทุกครั้งก่อนส่ง code)

```
## Correctness
- [ ] Logic ถูกต้องตาม requirements
- [ ] Edge cases ถูก handle
- [ ] Error handling ครบถ้วน
- [ ] No off-by-one errors

## Security
- [ ] Input validation ทุก user input
- [ ] No SQL injection / XSS / CSRF vulnerabilities
- [ ] Sensitive data ไม่ถูก log / expose
- [ ] Auth/authorization checks ถูกต้อง

## Performance
- [ ] No N+1 queries
- [ ] No unnecessary re-renders (React)
- [ ] Big O complexity เหมาะสม
- [ ] No memory leaks

## Maintainability
- [ ] Code อ่านง่าย ชื่อตัวแปรสื่อความหมาย
- [ ] Functions ไม่ยาวเกินไป (<50 lines ideal)
- [ ] DRY - ไม่ duplicate logic
- [ ] Comments อธิบาย "ทำไม" ไม่ใช่ "ทำอะไร"

## Testing
- [ ] Tests ครอบคลุม happy path
- [ ] Tests ครอบคลุม edge cases
- [ ] Tests ครอบคลุม error cases
- [ ] Test names อธิบาย behavior
```

### Review Output Format
```markdown
## Code Review: [File/PR Name]

### Summary
[1-2 ประโยคสรุปภาพรวม]

### Issues Found
🔴 **Critical** - [description] (line X)
🟡 **Warning** - [description] (line X)
🔵 **Suggestion** - [description] (line X)

### Good Practices Noticed
✅ [สิ่งที่ทำได้ดี]

### Action Items
- [ ] Fix: [critical issue]
- [ ] Consider: [suggestion]
```

---

## 6. Subagent-Driven Development Module

เมื่องานซับซ้อนเกินกว่าจะทำคนเดียว ให้แตก task เป็น subagents:

### When to Use Subagents
- งานที่ parallelize ได้ (เช่น research + code + docs พร้อมกัน)
- งานที่ต้องการ specialized context (เช่น frontend vs backend)
- งานที่ต้อง isolated execution (test ที่อาจ affect state)

### Subagent Design Pattern
```
ORCHESTRATOR (Main Agent)
├── RESEARCHER: ค้นคว้าข้อมูลที่จำเป็น
├── IMPLEMENTER: เขียน code ตาม plan
├── TESTER: เขียนและรัน tests
├── REVIEWER: ตรวจสอบ code quality
└── DOCUMENTER: เขียน documentation
```

### Subagent Prompt Template
```
คุณเป็น [ROLE] subagent
Task: [specific task description]
Context: [relevant context from orchestrator]
Input: [files/data ที่ต้องใช้]
Output: บันทึกผลที่ [path]
Constraints: [limitations/rules]
```

### Orchestrator Rules
- แตก tasks ให้ independent จากกัน มากที่สุด
- ให้ context เท่าที่จำเป็น ไม่ dump ทุกอย่าง
- รวม results แล้ว verify ก่อนส่งต่อ
- Handle failures: ถ้า subagent fail ให้ retry หรือ fallback

---

## 7. Verification Before Completion Module

ก่อนส่งมอบงานทุกชิ้น ต้องผ่าน verification:

### Verification Checklist
```
## Pre-Delivery Verification

### Functional
- [ ] ทำตาม requirements ครบทุกข้อ
- [ ] ทุก test pass
- [ ] Manual smoke test ผ่าน
- [ ] Edge cases ถูก handle

### Quality
- [ ] Code review ผ่าน (ใช้ checklist ข้างบน)
- [ ] No console.log / debug code ค้างอยู่
- [ ] Error messages user-friendly
- [ ] Performance acceptable

### Documentation
- [ ] README / usage instructions updated
- [ ] API documentation ถูกต้อง
- [ ] Comments อธิบาย complex logic
- [ ] CHANGELOG updated (if applicable)

### Final Check
- [ ] git status clean
- [ ] Build passes
- [ ] Demo/walkthrough พร้อม
```

### Verification Process
```
1. Run all tests → ต้อง 100% pass
2. Run linter → ต้อง 0 errors (warnings OK ถ้ามีเหตุผล)
3. Build → ต้อง success
4. Manual test → ทำตาม user story ทีละ step
5. Review own code → อ่าน diff ทั้งหมดอีกครั้ง
6. ถ้าผ่านทุกข้อ → ส่งมอบ
7. ถ้าไม่ผ่าน → กลับไปแก้ แล้ว verify ใหม่
```

---

## Full Autonomous Workflow (/superpower)

เมื่อ user สั่ง /superpower [task] ให้ทำงานตาม chain ทั้งหมด:

```
1. 📋 BRAINSTORM
   - เข้าใจโจทย์ สำรวจ approaches
   - ยืนยันกับ user

2. 📝 PLAN
   - สร้าง structured plan
   - estimate เวลา ระบุ dependencies

3. 🔴 TDD - RED
   - เขียน tests ที่ fail

4. 🟢 TDD - GREEN
   - Implement ให้ tests ผ่าน

5. 🔄 REFACTOR
   - ปรับปรุง code quality

6. 🐛 DEBUG (ถ้ามีปัญหา)
   - Systematic debugging

7. 👀 REVIEW
   - Self code review

8. ✅ VERIFY
   - Verification checklist

9. 📦 DELIVER
   - ส่งมอบพร้อม summary
```

### Autonomous Rules
- ถ้าติดปัญหา > 3 ครั้ง กับ issue เดิม → ถาม user
- ถ้า plan เปลี่ยนมาก → ยืนยัน user ก่อน
- ทุก major decision → บันทึกไว้ใน decision log
- ทุก 5 steps → สรุป progress ให้ user รู้
