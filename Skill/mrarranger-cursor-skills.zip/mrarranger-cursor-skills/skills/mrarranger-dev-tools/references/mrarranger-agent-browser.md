---
name: mrarranger-agent-browser
description: |
  MRARRANGER Agent Browser - ระบบ Browser Automation ขั้นสูงสำหรับ AI Agent
  รวม Web Scraping, Form Filling, Login Automation, Data Extraction, Screenshot Analysis
  ให้ Claude navigate เว็บอัตโนมัติ ทำงาน research, extract ข้อมูล, กรอก forms ได้เอง
  ใช้เมื่อ: (1) ต้องการดึงข้อมูลจากเว็บ (2) กรอก form อัตโนมัติ (3) Login เข้าระบบ
  (4) Screenshot แล้ววิเคราะห์ (5) Monitor เว็บ (6) Web scraping (7) Compare ราคา/ข้อมูล
  (8) Research จากหลายเว็บพร้อมกัน (9) ทำ browser tasks อะไรก็ได้
  Commands: /browse [url], /scrape [target], /form [action], /monitor [url], /extract [data], /compare [urls]
---

# MRARRANGER Agent Browser

ระบบให้ Claude ทำงานกับ web browser อย่างมีประสิทธิภาพ ทั้ง scraping, form filling, monitoring

## Quick Commands

```
/browse [url]           → Navigate and analyze page
/scrape [target]        → Extract structured data
/form [action]          → Fill and submit forms
/monitor [url]          → Monitor for changes
/extract [data-type]    → Extract specific data (tables, links, images)
/compare [urls]         → Compare content across URLs
/screenshot [url]       → Capture and analyze
/login [service]        → Automated login flow
```

---

## Browser Automation Strategy

### Approach Selection
```
TASK TYPE                    → BEST APPROACH
Simple text extraction       → WebFetch (fastest)
Complex interaction needed   → Claude in Chrome / Playwright
JavaScript-rendered content  → Headless browser
Data behind login            → Playwright with auth
Multiple pages/pagination    → Scripted crawl
Real-time monitoring         → Screenshot + diff
```

### Tool Priority
```
1. WebFetch / WebSearch     → ใช้ก่อนเสมอ (เร็วที่สุด)
2. Claude in Chrome MCP     → ใช้เมื่อต้อง interact กับ page
3. Playwright script        → ใช้เมื่อต้อง automate หลาย steps
4. Puppeteer                → Alternative ถ้า Playwright ไม่ available
```

---

## Web Scraping Patterns

### Structured Data Extraction
```python
# Pattern: Extract table data
def extract_table(page_content):
    """
    1. Find table element
    2. Extract headers
    3. Extract rows
    4. Return structured JSON/CSV
    """
    # Use CSS selectors or XPath
    headers = page.query_selector_all("table th")
    rows = page.query_selector_all("table tr")
    return {
        "headers": [h.text_content() for h in headers],
        "rows": [[cell.text_content() for cell in row.query_selector_all("td")] for row in rows]
    }
```

### Multi-Page Scraping
```python
# Pattern: Pagination handling
async def scrape_all_pages(base_url):
    all_data = []
    page_num = 1

    while True:
        url = f"{base_url}?page={page_num}"
        data = await scrape_page(url)

        if not data:  # No more results
            break

        all_data.extend(data)
        page_num += 1

        # Rate limiting - อย่าทำเร็วเกินไป
        await asyncio.sleep(1)

    return all_data
```

### Data Cleaning Pipeline
```
RAW HTML → Parse → Clean → Normalize → Validate → Output

1. Parse: ดึง text จาก HTML elements
2. Clean: ลบ whitespace, special chars ที่ไม่ต้องการ
3. Normalize: แปลง format (dates, numbers, currencies)
4. Validate: ตรวจสอบว่า data สมบูรณ์
5. Output: JSON, CSV, หรือ structured format
```

---

## Form Automation

### Form Fill Strategy
```
1. IDENTIFY: หา form elements ทั้งหมด (input, select, textarea, checkbox)
2. MAP: จับคู่ data กับ fields
3. FILL: กรอกข้อมูลตาม mapping
4. VALIDATE: ตรวจสอบว่ากรอกถูกต้อง
5. SUBMIT: กด submit
6. VERIFY: ตรวจสอบ success/error response
```

### Common Form Patterns
```javascript
// Text input
await page.fill('input[name="email"]', 'user@example.com');

// Dropdown
await page.selectOption('select[name="country"]', 'TH');

// Checkbox
await page.check('input[type="checkbox"][name="agree"]');

// Radio
await page.click('input[type="radio"][value="option1"]');

// File upload
await page.setInputFiles('input[type="file"]', '/path/to/file.pdf');

// Date picker
await page.fill('input[type="date"]', '2026-03-15');

// Wait for dynamic content
await page.waitForSelector('.success-message', { timeout: 10000 });
```

---

## Screenshot Analysis

### When to Use Screenshots
```
- Page ที่ render ด้วย JavaScript (WebFetch ได้แค่ HTML)
- ต้องการเห็น visual layout
- Verify ว่า form ถูกกรอกถูกต้อง
- Monitor visual changes
- Debug: "เว็บเป็นยังไง?"
```

### Analysis Workflow
```
1. Take screenshot (full page or viewport)
2. Analyze with Claude Vision:
   - Layout structure
   - Text content
   - Interactive elements
   - Error messages
   - Visual anomalies
3. Decide next action based on analysis
```

---

## Login & Authentication Automation

### Login Flow
```
1. Navigate to login page
2. Fill credentials (จาก environment variables ไม่ hardcode)
3. Handle 2FA/CAPTCHA (ให้ user ช่วย)
4. Verify login success
5. Store session/cookies for reuse
```

### Security Rules
```
ALWAYS:
- ใช้ environment variables สำหรับ credentials
- ถาม user ก่อน login
- Handle CAPTCHA/2FA โดยให้ user ช่วย
- Clear credentials หลังใช้เสร็จ

NEVER:
- Hardcode passwords ในโค้ด
- Store credentials ใน plain text
- Bypass security measures
- Login โดย user ไม่รู้
```

---

## Monitoring & Change Detection

### Monitor Pattern
```python
async def monitor_page(url, interval_minutes=5):
    """
    1. Take initial snapshot
    2. Wait interval
    3. Take new snapshot
    4. Compare (text diff / visual diff)
    5. Alert if significant change
    6. Repeat
    """
    previous = await get_page_content(url)

    while True:
        await asyncio.sleep(interval_minutes * 60)
        current = await get_page_content(url)

        changes = compare_content(previous, current)
        if changes.is_significant:
            notify_user(changes)

        previous = current
```

### Change Types to Monitor
```
- Price changes (e-commerce)
- Stock availability
- Content updates (news, blog)
- Error/downtime detection
- New listings (jobs, properties)
- Competitor changes
```

---

## Best Practices

### Rate Limiting & Ethics
```
DO:
- Respect robots.txt
- Add delays between requests (1-3 sec)
- Use reasonable User-Agent string
- Cache results to minimize requests
- Handle 429 (Too Many Requests) gracefully

DON'T:
- Hammer servers with rapid requests
- Bypass CAPTCHA programmatically
- Scrape personal/private data
- Violate Terms of Service
- Pretend to be a real browser when it matters
```

### Error Recovery
```
NETWORK ERROR → Retry 3 times with exponential backoff
TIMEOUT → Increase timeout, try again
404 → URL might have changed, try search
CAPTCHA → Ask user for help
LOGIN EXPIRED → Re-authenticate
BLOCKED → Change approach or ask user
```

### Output Format
ผลลัพธ์จาก browser automation ควรอยู่ใน structured format:

```json
{
  "source_url": "https://example.com/products",
  "scraped_at": "2026-03-15T10:30:00Z",
  "items_count": 25,
  "data": [
    {
      "name": "Product A",
      "price": 1990,
      "currency": "THB",
      "url": "https://example.com/products/a",
      "in_stock": true
    }
  ],
  "metadata": {
    "total_pages": 5,
    "current_page": 1,
    "has_more": true
  }
}
```
