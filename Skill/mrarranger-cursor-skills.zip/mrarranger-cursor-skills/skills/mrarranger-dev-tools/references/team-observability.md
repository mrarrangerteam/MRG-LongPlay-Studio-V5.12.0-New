# Team 10: Observability & Incident Response Team

## บทบาท
SRE / Observability Engineer — monitoring, alerting, disaster recovery, incident response

## ทำไมทีมนี้สำคัญ
- Cloud disruptions cost $5,600/minute (Gartner)
- Vibe-coded apps ไม่เคยมี monitoring, alerting, หรือ incident response plan
- ทีมที่มี documented runbooks แก้ incident เร็วขึ้น 30-50%

## Checklist

### 1. Observability 3 Pillars (OpenTelemetry Standard)
- **Logging**: Structured JSON, ไม่มี PII, log levels (ERROR/WARN/INFO/DEBUG)
- **Metrics**: Latency, error rate, throughput, saturation (RED/USE method)
- **Tracing**: Distributed tracing across services, trace ID propagation
- AI-specific: Token usage, inference latency, cost per request

### 2. Alerting
- SLO-based alerting (ไม่ alert ทุกเรื่อง — ลด alert fatigue)
- P1: Service down → PagerDuty/OpsGenie → response 5 นาที
- P2: Performance degraded → Slack → response 30 นาที
- P3: Warning → ticket → response 4 ชั่วโมง
- Synthetic monitoring จากหลาย regions

### 3. Disaster Recovery
- RTO/RPO กำหนดสำหรับทุก critical service
- Automated backups ตาม 3-2-1 rule (3 copies, 2 media, 1 offsite)
- Restore testing ทุกเดือน
- DR drills: Quarterly (tabletop), Semi-annual (live failover)

### 4. Incident Response Runbooks
- Runbooks สำหรับ top 10 incident types
- Roles: Incident Manager, Tech Lead, Communications Lead
- Post-mortem template (blameless)
- Escalation matrix
- Status page (Statuspage.io, Instatus, Cachet)

### 5. Error Tracking
- Sentry/Bugsnag setup พร้อม PII scrubbing
- send_default_pii = False
- before_send hook strip sensitive data
- Source maps uploaded securely (ไม่ public)

### Tools
- OpenTelemetry (CNCF standard)
- LGTM Stack: Loki, Grafana, Tempo, Mimir (open-source)
- Sentry (error tracking, free tier)
- UptimeRobot/Better Uptime (uptime monitoring)
- PagerDuty/OpsGenie (on-call)
