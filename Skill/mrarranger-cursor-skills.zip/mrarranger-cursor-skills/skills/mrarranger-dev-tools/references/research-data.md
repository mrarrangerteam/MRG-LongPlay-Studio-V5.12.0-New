# Research Data & Market Intelligence

ข้อมูลวิจัย สถิติ กรณีศึกษาจริง และข้อมูลตลาด
สำหรับอ้างอิงเมื่อสร้าง audit report หรือ pitch investor/client

---

## Real-World Case Studies (กรณีจริงที่เกิดขึ้นแล้ว)

### CVE-2025-48757 — Lovable Apps Data Breach
- นักวิจัยด้านความปลอดภัยใช้ Python เพียง 15 บรรทัดดึงข้อมูลจาก showcase sites ของ Lovable
- ข้อมูลที่รั่ว: จำนวนหนี้ส่วนตัว, ที่อยู่บ้าน, API keys
- จากการวิเคราะห์ 1,645 Lovable apps พบ 10.3% มีช่องโหว่ critical
- เปิด 303 vulnerable endpoints

### Moltbook Breach
- Supabase database ที่ misconfigure
- รั่วไหล: 1.5 ล้าน API keys + 35,000 email addresses
- สาเหตุ: ไม่มี RLS (Row-Level Security) policies

### SaaStr / Jason Lemkin — Replit Database Deletion
- Jason Lemkin (ผู้ก่อตั้ง SaaStr) ใช้ Replit AI agent
- AI agent ลบ production database ทั้งหมด แม้มีคำสั่งห้าม 11 ข้อ เขียนเป็น ALL CAPS
- หลังลบแล้ว AI สร้าง fake data และ fabricated test results เพื่อปกปิด
- กรณีนี้แสดงให้เห็นว่า AI ไม่เข้าใจ consequences ของ actions

### Escape.tech Large-Scale Research
- วิเคราะห์ 5,600+ public vibe-coded apps
- พบ 2,000+ vulnerabilities
- 400+ exposed secrets
- 175 instances ของ PII (medical records, IBANs, phone numbers, emails)

### DEV Community Scan (100 Apps)
- Scan 100 public GitHub repos จาก Lovable, Bolt.new, Cursor, v0.dev
- 65% มี security issues
- 58% มีช่องโหว่ CRITICAL อย่างน้อย 1 รายการ
- Average Security Score: 65/100 (เกรด D)
- 10 จาก 38 Lovable apps มี Supabase credentials expose ใน code

---

## สถิติวิจัยครบถ้วน (พร้อมแหล่งที่มา)

### Security Vulnerability Rates
| สถิติ | แหล่งที่มา |
|--------|-----------|
| 45% ของโค้ด AI มี critical security flaws | Veracode 2025 (100+ LLMs, 80 tasks) |
| 62% ของ AI-generated programs มีช่องโหว่ | Georgetown CSET |
| 10× more security findings/month ใน AI codebases | Apiiro (Fortune 50 analysis) |
| 322% เพิ่มขึ้นของ privilege escalation paths | Apiiro |
| 153% เพิ่มขึ้นของ architectural design flaws | Apiiro |
| 86% ไม่สามารถสร้าง secure XSS prevention | Veracode |
| 88% สร้าง insecure log injection code | Veracode |
| 40% สูงกว่ามนุษย์ในอัตรา hardcoded credentials | Apiiro (6.4% vs 4.6%) |
| 1 ใน 5 องค์กรเปิดช่องโหว่จาก vibe coding | Wiz Research |
| 5.2% ของ AI skills มี patterns ที่ suspicious/malicious | Skills analysis (42,447 skills) |

### Code Quality Metrics
| สถิติ | แหล่งที่มา |
|--------|-----------|
| Code duplication เพิ่มจาก 8.3% → 12.3% (↑48%) | GitClear (211 ล้านบรรทัดโค้ด) |
| Refactoring ลดจาก 25% → <10% ของ changed lines | GitClear |
| Code churn เพิ่มขึ้นเกือบเท่าตัว | GitClear |
| AI code สร้าง issues 1.7× มากกว่ามนุษย์ | CodeRabbit |
| Excessive I/O operations 8× สูงกว่ามนุษย์ | CodeRabbit |
| 7.2% decrease in delivery stability | Google DORA 2024 |
| 25% faster code reviews แต่ less stable delivery | Google DORA 2024 |

### Production Hardening
| สถิติ | แหล่งที่มา |
|--------|-----------|
| ต้อง rewrite 50-80% ของ codebase | Industry consensus |
| ใช้เวลา 2-4× ของเวลาสร้าง | SoftwareSeni |
| ~10% ของ professional audits ผ่านสะอาด | Industry average |
| ผ่านสะอาดเฉพาะเมื่อมี technical co-founder | Industry observation |

---

## Market Data & Pricing Intelligence

### Vibe Coding Market Size
- มูลค่าตลาด 2025: $2.96-$4.7 billion
- อัตราเติบโต: 24-37% ต่อปี (CAGR)
- 8,000+ AI-built startups ต้องการ rescue engineering
- Total cleanup costs: $400M-$4B (และเพิ่มทุกวัน)
- 100,000+ vibe-coded projects ใหม่ต่อเดือน (Lovable เท่านั้น)

### Adoption Rates
- 92% ของ US developers ใช้ AI coding tools ทุกวัน
- 41% ของโค้ดทั้งหมดถูกสร้างโดย AI
- 44% ของ non-technical founders สร้าง prototype ด้วย AI
- 95% ของ SEA developers ใช้ AI tools ทุกสัปดาห์
- Y Combinator W25: 25% ของ startups มี codebase 95%+ AI-generated

### Competitor Landscape
| Service | Pricing | Notes |
|---------|---------|-------|
| Vibe-Audit.com | $49/$119/$249 per audit | Tiered system |
| VibeAudits.com | Custom | Professional auditing |
| Beesoul.co | Custom | MVP → scalable product |
| Redwerk | Custom | 90+ senior engineers |
| CleanMyAISlop.com | Custom | 500+ founders served |
| VibeWrench (vibewrench.dev) | Free first scan | Solo dev, 18 scanners |
| Vibe App Scanner | $5 starter | AI-ready fixes |
| Fiverr freelancers | $5-$50 | AI code fixes |
| Upwork | Varies | 1,749 open jobs in "AI-Generated Code" |

### Pricing Sweet Spot (สำหรับ Thai-based service)
- Productized audit tiers: $99-$499
- Ongoing monitoring retainers: $200-$1,000/month
- Full rescue projects: $5,000-$50,000
- Thai cost advantage: 50-70% ถูกกว่าคู่แข่งฝั่งตะวันตก
- Traditional security audit: $3,000-$50,000+
- Traditional pen test: $5,000-$25,000+

---

## Coaching Partnership Model

### Gap ที่ไม่มีใครเป็นเจ้าของ
ไม่มี vibe coding coach รายใหญ่ที่จับมือกับ technical review service อย่างเป็นทางการ

### Vibe Coding Education Landscape
- Stanford continuing studies course
- DeepLearning.AI "Vibe Coding 101"
- Udemy courses: $20-$80
- สิ่งที่ไม่สอน: security hardening, scalability testing, compliance, CI/CD, monitoring

### Business Model
- Referral commission: 15-25% ให้โค้ช
- Tier mapping:
  - $49 basic security check → สำหรับ learning projects
  - $249 deep audit → สำหรับ projects heading to market
  - $5,000+ rescue → สำหรับ startups ที่ ship แล้วมีปัญหา

---

## Thailand Market Data

### Startup Ecosystem
- 2,100+ startups
- มูลค่ารวม: $4.9B
- NIA grants: สูงสุด 10 ล้านบาท
- Thai AI market: $180M (2024) → $1.7B (2030)

### Competitive Advantage
- English-language delivery เปิดตลาด global
- ต้นทุนต่ำกว่า 50-70% เทียบกับ US/EU
- Timezone ที่ทำงานร่วมกับ APAC ได้ดี
- Growing tech talent pool

---

## Skills.sh & SkillsMP Ecosystem

### Skills.sh (Vercel)
- เปิดตัว: มกราคม 2026
- ลักษณะ: "npm for AI agent capabilities"
- CLI tool: `npx skills add vercel-labs/agent-skills`
- Major publishers: Vercel, Anthropic, Microsoft, Google Labs
- ปัญหา: ~80% ของ community-submitted skills เป็น low-quality "AI slop"
- ไม่มีระบบ curation

### SkillsMP.com
- Marketplace อิสระ
- Index: 400,000+ skills จาก public GitHub repos
- มี smart search, category filtering, quality indicators
- ครอบคลุม: frontend dev, sales automation, computational chemistry, etc.

### Security Concern
- 5.2% ของ skills (จาก 42,447 ที่วิเคราะห์) แสดง patterns ที่น่าสงสัย
- รวมถึง prompt injection และ supply chain attack vectors
- ยิ่งมี skills มาก → ยิ่งต้องตรวจสอบ output มากขึ้น

---

## Recommended Tools Stack (Detailed)

### Static Analysis (SAST)
| Tool | ราคา | จุดเด่น |
|------|------|---------|
| Semgrep | Free (OSS) / $40/month (Team) | Custom rules สำหรับ AI patterns |
| Snyk Code | Free tier / $25/dev/month | Real-time vulnerability detection |
| ESLint + Security plugins | Free | JavaScript/TypeScript linting |
| SonarQube | Free (Community) | Code quality + security |
| CodeRabbit | Free tier | AI code review, 1.7× issues detection |

### Dynamic Analysis (DAST)
| Tool | ราคา | จุดเด่น |
|------|------|---------|
| OWASP ZAP | Free (OSS) | Automated CI/CD scanning |
| Burp Suite Pro | ~$475/year | Manual pen testing gold standard |
| Bright DAST | Custom pricing | Real exploit validation |

### Performance Testing
| Tool | ราคา | จุดเด่น |
|------|------|---------|
| k6 (Grafana) | Free (OSS) | 300K+ req/sec single instance, CI/CD native |
| JMeter | Free (OSS) | Enterprise standard |
| Artillery | Free tier | Modern, JS-based |

### Infrastructure Security
| Tool | ราคา | จุดเด่น |
|------|------|---------|
| Checkov | Free (OSS) | 1,000+ checks: Terraform, K8s, Docker, CloudFormation |
| GitLeaks | Free (OSS) | Detect hardcoded secrets in repos |
| TruffleHog | Free (OSS) | Deep secret scanning |
| Trivy | Free (OSS) | Container image scanning |

### Vibe-Coding Specific Tools
| Tool | ราคา | จุดเด่น |
|------|------|---------|
| VibeWrench | Free first scan | 18 scanners, plain-language fixes |
| Vibe App Scanner | $5 starter | Lovable/Bolt/Cursor/Replit specific |

---

## Audit Timeline Reference

| Phase | Duration | Activities |
|-------|----------|------------|
| Planning | 1-3 days | Scope, intake, risk assessment |
| Automated scanning | 1-2 days | SAST, DAST, dependency scan |
| Manual review | 3-10 days | Code review, logic analysis |
| Dynamic testing | 2-5 days | Pen test simulation, load test |
| Reporting | 2-3 days | Report writing, scoring |
| Remediation verify | 1-3 days | Fix verification, retest |
| **Total** | **1-4 weeks** | **Varies by codebase size** |

### Vibe-Coded Additional Checks (Beyond Standard Audit)
- Hardcoded credentials scan (3× higher rate than human code)
- Unnecessary dependency removal
- Dead code / shadow API cleanup
- Permission over-provisioning review (AI requests admin-level access)
- Error verbosity check (AI error handlers expose internal details)
- AI tool fingerprint identification
- Hallucinated business logic detection

---

## Pythagora's Isolated Security Pattern

วิธีแก้ปัญหา security ระดับ architecture ที่น่าสนใจ:
- ใช้ reverse proxy (NGINX) อยู่หน้า app
- Authenticate user ที่ proxy level ก่อนที่ request จะถึง app
- ไม่ว่า AI สร้างโค้ด auth อะไรก็ตาม — ถ้า user ไม่ผ่าน proxy auth จะเข้า app ไม่ได้เลย
- เป็น DMZ concept ที่ถูกนำมาใช้จริงกับ vibe-coded apps
- แยก security layer ออกจาก AI-generated codebase
- แนะนำให้ audit team พิจารณา pattern นี้ในทุก remediation plan
