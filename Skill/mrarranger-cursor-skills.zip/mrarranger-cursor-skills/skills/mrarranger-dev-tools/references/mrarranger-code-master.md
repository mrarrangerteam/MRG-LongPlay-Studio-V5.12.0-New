---
name: mrarranger-code-master
description: |
  MRARRANGER Code Master - ระบบเขียน Code ขั้นเทพระดับ Staff/Principal Engineer
  ครอบคลุม Clean Code, Design Patterns, SOLID, Architecture, Refactoring, API Design,
  Multi-Language Mastery (TypeScript, Python, Rust, Go), Performance, Security, DevOps, Git
  ให้ Claude เขียน code ที่ไม่ใช่แค่ "ทำงานได้" แต่ clean, maintainable, scalable, secure
  ใช้เมื่อ: (1) เขียน code ที่ต้องการคุณภาพสูง (2) refactor code เก่า (3) ออกแบบ architecture
  (4) ทำ API design (5) เลือก design pattern (6) เพิ่ม performance (7) แก้ security issues
  (8) วาง project structure (9) เขียน code ภาษาอะไรก็ได้ (10) ต้องการ code review ระดับ senior
  (11) อะไรก็ตามที่เกี่ยวกับการเขียนโปรแกรม coding programming development
  ใช้ skill นี้ทุกครั้งที่เขียน code แม้ user ไม่ได้บอกว่าต้องการ "code ขั้นเทพ" - ยกระดับทุก output เสมอ
  Commands: /code [lang] [task], /clean [code], /pattern [name], /arch [type], /refactor [code],
  /api [design], /perf [optimize], /secure [audit], /git [workflow], /scaffold [project]
---

# MRARRANGER Code Master

ระบบเขียน Code ระดับ Staff/Principal Engineer - ทุกบรรทัดมีเหตุผล ทุก function มีจุดประสงค์

## Quick Commands

```
/code [lang] [task]     → เขียน code คุณภาพสูง (ระบุภาษา)
/clean [code]           → Clean up / refactor code
/pattern [name]         → ใช้ Design Pattern
/arch [type]            → ออกแบบ Architecture
/refactor [code]        → Refactoring อย่างเป็นระบบ
/api [design]           → API Design (REST/GraphQL/tRPC)
/perf [optimize]        → Performance optimization
/secure [audit]         → Security audit
/git [workflow]         → Git workflow & conventions
/scaffold [project]     → สร้าง project structure
/review [code]          → Code review ระดับ Senior
/migrate [from] [to]    → Migrate code ระหว่างภาษา/framework
```

## Reference Files (อ่านเพิ่มเติม)

```
references/design-patterns.md      → Factory, Strategy, Observer, Repository, Builder,
                                     Singleton, Adapter, Decorator + Selection Guide
references/api-perf-security.md    → REST API Conventions, Zod Validation, DB Optimization,
                                     Caching, OWASP Top 10, Security Checklist, Git Workflow
```

---

## Code Philosophy: The MRARRANGER Way

### 5 Laws of Great Code
```
1. CLARITY > CLEVERNESS
   โค้ดที่คนอ่านแล้วเข้าใจทันที > โค้ดที่เขียน one-liner ฉลาดแต่อ่านไม่รู้เรื่อง

2. EXPLICIT > IMPLICIT
   บอกตรงๆ ว่าทำอะไร ไม่ต้องเดา ไม่ต้อง trace

3. SIMPLE > EASY
   Simple = ทำ 1 อย่างแล้วทำได้ดี / Easy = ทำง่ายแต่อาจจะซับซ้อนข้างใน

4. COMPOSITION > INHERITANCE
   ประกอบ pieces เล็กๆ เข้าด้วยกัน > สืบทอดจาก class ใหญ่ๆ

5. DELETE > ADD
   ลบ code ที่ไม่จำเป็นออก > เพิ่ม feature ที่ไม่มีคนใช้
```

---

## SOLID Principles (Applied)

### S - Single Responsibility
```typescript
// BAD: ทำหลายอย่างใน 1 class
class UserService {
  createUser(data) { /* ... */ }
  sendWelcomeEmail(user) { /* ... */ }
  generateInvoice(user) { /* ... */ }
}

// GOOD: แต่ละ class ทำ 1 อย่าง
class UserService { createUser(data: CreateUserDTO): Promise<User> { /* ... */ } }
class EmailService { sendWelcomeEmail(user: User): Promise<void> { /* ... */ } }
class StorageService { uploadFile(file: File, path: string): Promise<string> { /* ... */ } }
```

### O - Open/Closed
```typescript
// BAD: ต้องแก้ function ทุกครั้งที่เพิ่ม payment method
function processPayment(method: string, amount: number) {
  if (method === 'credit') { /* ... */ }
  else if (method === 'promptpay') { /* ... */ }
}

// GOOD: เพิ่ม payment ได้โดยไม่แก้ code เดิม
interface PaymentProcessor { process(amount: number): Promise<PaymentResult>; }
class CreditCardProcessor implements PaymentProcessor { async process(amount) { /* ... */ } }
class PromptPayProcessor implements PaymentProcessor { async process(amount) { /* ... */ } }

const processors: Record<string, PaymentProcessor> = {
  credit: new CreditCardProcessor(),
  promptpay: new PromptPayProcessor(),
};
```

### L - Liskov Substitution
```typescript
// ลูกต้องใช้แทนพ่อได้โดยไม่พัง
// BAD: class Penguin extends Bird { fly() { throw new Error("Can't fly!"); } }
// GOOD:
class Bird { move() { /* ... */ } }
class FlyingBird extends Bird { fly() { /* ... */ } }
class Penguin extends Bird { swim() { /* ... */ } }
```

### I - Interface Segregation
```typescript
// BAD: interface ใหญ่เกิน → GOOD: แยกเล็กๆ
interface Workable { work(): void; }
interface Eatable { eat(): void; }
interface Codeable { code(): void; }
class Developer implements Workable, Eatable, Codeable { /* ... */ }
```

### D - Dependency Inversion
```typescript
// BAD: ผูกกับ implementation ตรงๆ
class OrderService { private db = new MySQLDatabase(); }

// GOOD: depend on abstraction
class OrderService {
  constructor(private db: Database, private mailer: Mailer) {}
}
const orderService = new OrderService(new PostgresDatabase(config), new ResendMailer(apiKey));
```

---

## Clean Code Rules

### Naming Conventions
```typescript
// Variables: ชื่อบอกว่า "คืออะไร"
const maxRetries = 3;                    // ไม่ใช่ n, x, val
const activeUsers = getActiveUsers();     // ไม่ใช่ data, result
const isAuthenticated = checkAuth();      // boolean → is/has/can/should

// Functions: ชื่อบอกว่า "ทำอะไร" (verb)
function calculateTotalPrice(items: CartItem[]): number { /* ... */ }
function fetchUserProfile(userId: string): Promise<User> { /* ... */ }
function validateEmail(email: string): boolean { /* ... */ }

// Classes: noun / Constants: SCREAMING_SNAKE_CASE
class OrderService { /* ... */ }
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const SUPPORTED_CURRENCIES = ['THB', 'USD', 'EUR'] as const;

// Types: PascalCase, ไม่ใส่ I prefix
type UserId = string;
interface CreateOrderRequest { /* ... */ }
type PaymentMethod = 'credit' | 'promptpay' | 'truemoney';
```

### Function Rules
```typescript
// RULE 1: ทำแค่ 1 อย่าง, orchestrator ประสานงาน
async function processOrder(order: Order): Promise<OrderResult> {
  const validated = await validateOrder(order);
  const total = calculateTotal(validated);
  const payment = await chargePayment(validated, total);
  await Promise.all([sendConfirmation(validated, payment), updateInventory(validated)]);
  return { order: validated, payment, total };
}

// RULE 2: Parameters ไม่เกิน 3 (ถ้ามากกว่า → ใช้ object)
function createUser(input: CreateUserInput): Promise<User> { /* ... */ }

// RULE 3: ไม่เกิน 20-30 lines (ideal < 15)

// RULE 4: Return early, avoid deep nesting
function getDiscount(user: User | null): number {
  if (!user) return 0;
  if (!user.isPremium) return 0.05;
  if (user.orders > 10) return 0.2;
  return 0.1;
}
```

### Error Handling
```typescript
// Custom errors ที่ meaningful
class AppError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500,
    public isOperational: boolean = true,
  ) {
    super(message);
    this.name = this.constructor.name;
  }
}

class NotFoundError extends AppError {
  constructor(resource: string, id: string) {
    super(`${resource} with id "${id}" not found`, 'NOT_FOUND', 404);
  }
}

class ValidationError extends AppError {
  constructor(public fields: Record<string, string>) {
    super('Validation failed', 'VALIDATION_ERROR', 400);
  }
}

// Handle errors ที่ boundary (ไม่ใช่ทุก function)
async function getUser(id: string): Promise<User> {
  const user = await db.users.findById(id);
  if (!user) throw new NotFoundError('User', id);
  return user;
}

// Catch ที่ API boundary
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: { code: err.code, message: err.message }
    });
  }
  console.error('Unexpected error:', err);
  res.status(500).json({ error: { code: 'INTERNAL', message: 'Something went wrong' } });
});

// Never swallow errors silently
try { await riskyOperation(); } catch (e) {
  logger.error('Failed to do X', { error: e, context: { userId } });
}
```

---

## Architecture Patterns

### Decision Guide
```
PROJECT SIZE         → ARCHITECTURE
MVP / Side project   → Monolith (Next.js full-stack)
Small-Medium SaaS    → Modular Monolith (feature folders)
Large / Multi-team   → Microservices (เริ่มจาก monolith ก่อน!)
Event-heavy          → Event-Driven (Kafka/RabbitMQ)
```

### Feature-Based Folder Structure (Recommended)
```
src/
├── features/
│   ├── auth/
│   │   ├── components/     # UI components
│   │   ├── hooks/          # Custom hooks
│   │   ├── services/       # Business logic
│   │   ├── types.ts        # Types
│   │   └── index.ts        # Public API
│   ├── products/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── repository.ts   # Data access
│   │   └── index.ts
│   └── orders/
├── shared/
│   ├── components/         # Shared UI
│   ├── hooks/              # Shared hooks
│   ├── lib/                # Utilities
│   └── types/              # Shared types
├── infrastructure/
│   ├── database/           # DB client, migrations
│   ├── cache/              # Redis, in-memory
│   └── queue/              # Job queue
└── app/                    # Next.js app router / entry point
```

### Layer Rules
```
IMPORT RULES (ห้ามข้าม layer):
  components → hooks → services → repository → database
  ✅ components import hooks
  ✅ hooks import services
  ❌ repository ห้าม import components

FEATURE RULES:
  ✅ features/auth import shared/*
  ✅ features/orders import features/auth (through public API)
  ❌ features/auth ห้าม import features/orders internals
```

---

## Multi-Language Quick Reference

### TypeScript → Python → Rust → Go
```
CONCEPT          TS                     PY                    RUST                  GO
Variable         const x = 1            x = 1                 let x = 1;            x := 1
Type             x: string              x: str                x: String             var x string
Function         function f(x: T): R    def f(x: T) -> R:     fn f(x: T) -> R {}    func f(x T) R {}
Interface        interface I {}          Protocol / ABC        trait T {}             interface I {}
Null             null / undefined        None                  Option<T>             nil
Error            throw Error             raise Exception       Result<T, E>          error return
Async            async/await             async/await           async/.await          goroutines
Collection       Array<T>                list[T]               Vec<T>                []T
Map              Map<K,V>                dict[K,V]             HashMap<K,V>          map[K]V
Enum             enum E {}               class E(Enum):        enum E {}             const iota
Package          npm                     pip/uv                cargo                 go mod
Test             vitest/jest             pytest                cargo test            go test
Formatter        prettier                black/ruff            rustfmt               gofmt
Linter           eslint                  ruff                  clippy                golint
```

---

## Code Quality Checklist (ใช้ทุกครั้ง)

```
BEFORE WRITING:
□ เข้าใจ requirements ชัด (ถาม user ถ้าไม่ชัด)
□ มี plan / pseudocode ก่อนเขียน
□ เลือก approach ที่ simple ที่สุดที่ work

WHILE WRITING:
□ ชื่อ variables/functions สื่อความหมาย
□ Functions ทำ 1 อย่าง, < 30 lines
□ Error handling ครบถ้วน
□ Types/interfaces กำหนดชัด
□ ไม่มี magic numbers (ใช้ constants)
□ Comments อธิบาย "ทำไม" ไม่ใช่ "ทำอะไร"

AFTER WRITING:
□ อ่าน code ตัวเองอีกครั้ง (self-review)
□ ลบ dead code, console.log, TODOs
□ Check edge cases (null, empty, boundary)
□ Performance: มี N+1? unnecessary loops?
□ Security: มี injection? exposed secrets?
□ Tests ครอบคลุม happy path + edge cases
□ Code ที่ซ้ำ → extract เป็น shared function
```
