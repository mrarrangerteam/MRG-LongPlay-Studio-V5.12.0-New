---
name: mrarranger-cli-tools
description: ระบบสร้าง Command Line Tools ครบวงจร - CLI design, Node.js/Python/Go/Rust CLI frameworks, interactive prompts, and distribution
commands:
  - /cli
  - /cli-node
  - /cli-python
  - /cli-go
  - /cli-rust
  - /tui
  - /publish-cli
---

# MRARRANGER CLI Tools

**ระบบสร้าง Command Line Tools ครบวงจร** - Complete CLI development system.

## 1. CLI Design Principles

### POSIX Conventions
```bash
# Standard structure
command [options] [arguments]

# Options (flags)
--option          # long form (recommended)
-o               # short form
--option=value   # with equals

# Help & version
command --help
command -h
command --version
command -v

# Exit codes
0   # success
1   # general error
2   # misuse of shell command
127 # command not found
```

### Usability Principles
```
1. Help is King
   ✓ Every command has --help
   ✓ Help is clear and concise
   ✓ Show examples in help

2. Sensible Defaults
   ✓ Don't require all flags
   ✓ Make common options simple

3. Progress Feedback
   ✓ Show progress for long operations
   ✓ Don't silently hang

4. Error Messages
   ✓ Clear, actionable errors
   ✓ Suggest fixes
```

## 2. Node.js CLI Frameworks

### Commander.js
- Most popular Node CLI library
- Supports subcommands, options, variadic arguments
- Built-in help generation

### Yargs
- Advanced argument parsing
- Strong validation and middleware support
- Great for complex CLIs

### Ink (React for CLI)
- Component-based CLI with React
- Interactive UI components
- Perfect for rich terminal interfaces

### Prompt Libraries
- **inquirer.js**: Full-featured prompting
- **prompts**: Lightweight alternative
- **enquirer**: User-friendly prompts

## 3. Python CLI Frameworks

### Click
- Simple, elegant API
- Decorators for commands and options
- Built-in help system
- Type validation
- Password inputs

### Typer
- Modern Python CLI framework
- Type hints for parameters
- Automatic help generation
- Built on Click

### Questionary
- Interactive prompts library
- Multiple question types
- Keyboard navigation
- Validation

## 4. Go CLI Framework: Cobra

### Setup
```bash
go get -u github.com/spf13/cobra/v2
cobra-cli init
cobra-cli add create
```

### Structure
- Root command
- Subcommands
- Flags (options)
- Arguments
- Automatic help system

## 5. Rust CLI Framework: Clap

### Features
- Declarative syntax with derive macros
- Type-safe argument parsing
- Automatic help and version
- Validation
- Shell completions

### Setup
```bash
cargo new mycli
# Add: clap = { version = "4.0", features = ["derive"] }
```

## 6. Output Formatting

### Colors & Styling
**Node.js**: chalk library for colors
**Python**: colorama for cross-platform colors
**Go**: charmbracelet/lipgloss for styling
**Rust**: colored crate for terminal colors

### Tables
**Node.js**: cli-table3
**Python**: tabulate, rich
**Go**: github.com/olekukonko/tablewriter

### Progress Bars
**Node.js**: cli-progress
**Python**: tqdm, alive-progress
**Go**: github.com/schollz/progressbar

### Spinners/Loaders
**Node.js**: ora
**Python**: halo, alive-progress
**Go**: github.com/charmbracelet/bubbles

## 7. Interactive Prompts

### Node.js: inquirer.js
- Input, list, checkbox, confirm, password
- Validation and transformation
- Conditional questions

### Node.js: prompts
- Simpler alternative
- Lightweight dependency
- Good for simple scenarios

### Python: questionary
- User-friendly API
- Multiple question types
- Styleable and customizable

## 8. Configuration Management

### Config Files
Store user preferences in ~/.config/app/config.json or similar locations

### Environment Variables
Use .env files or process.env for configuration

### Priority Order
1. Command line flags (highest)
2. Environment variables
3. Config files
4. Defaults (lowest)

## 9. Shell Completions

### Bash/Zsh Completion
- Dynamic completion for commands and options
- Framework-specific implementations
- Manual or automatic generation

**Node.js**: Commander.js has built-in support
**Python**: Click can generate completions
**Go**: Cobra generates completions automatically
**Rust**: Clap can generate completions

### Installation
Copy completion scripts to ~/.bash_completion.d/ or /usr/share/zsh/site-functions/

## 10. Testing CLI Tools

### Node.js Testing
Use execSync to run CLI commands and check output
Jest for test framework

### Python Testing
Click provides CliRunner for isolated testing
pytest as test framework

### Best Practices
- Test success and error cases
- Verify exit codes
- Check output messages
- Test argument parsing
- Test configuration loading

## 11. Publishing CLI Tools

### npm (Node.js)
```bash
# Add to package.json:
"bin": {
  "mycli": "./bin/index.js"
}
# npm publish
# Install: npm install -g mycli
```

### PyPI (Python)
```bash
# setup.py with entry_points
# python setup.py sdist bdist_wheel
# twine upload dist/*
```

### Homebrew (macOS)
Create formula in your tap repository
Users install with: brew install your-org/tap/mycli

### GitHub Releases
Publish binaries directly for Go/Rust CLIs

## 12. Building TUI (Terminal User Interface)

### Node.js: Ink
React-based terminal UI
Component composition
Flexbox layout

### Go: Bubble Tea
TUI framework by Charm
Model-Update-View pattern
Rich interactive interfaces

### Rust: Crossterm
Terminal abstraction
Low-level control
Event handling

### Python: Rich, Textual
Text formatting and tables
Full TUI framework with widgets
Terminal control library

---

## Reference Files

For complete code examples and detailed implementations, see:
- `references/frameworks-setup.md` - Framework setup for all languages
- `references/commander-yargs-examples.md` - Node.js CLI frameworks
- `references/click-typer-examples.md` - Python CLI frameworks
- `references/cobra-clap-examples.md` - Go and Rust CLIs
- `references/prompts-and-ui.md` - Interactive prompts and output formatting
- `references/testing-publishing.md` - Testing and distribution guide

## Commands Summary

- `/cli [framework]` - CLI design principles
- `/cli-node [tool]` - Node.js CLI frameworks (Commander, yargs, Ink)
- `/cli-python [tool]` - Python CLI (Click, Typer)
- `/cli-go [feature]` - Go CLI with Cobra
- `/cli-rust [feature]` - Rust CLI with Clap
- `/tui [framework]` - Terminal UI (Ink, Bubble Tea)
- `/publish-cli [platform]` - Publishing (npm, PyPI, Homebrew)

**MRARRANGER CLI Tools: Powerful, user-friendly, professional.**
