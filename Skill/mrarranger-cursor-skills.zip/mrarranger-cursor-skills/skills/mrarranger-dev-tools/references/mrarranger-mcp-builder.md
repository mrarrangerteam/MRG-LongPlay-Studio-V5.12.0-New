---
name: mrarranger-mcp-builder
description: |
  MRARRANGER MCP Builder - ระบบสร้าง MCP (Model Context Protocol) Server อย่างถูกวิธี
  ครอบคลุม Tool Design, Error Handling, Security, Testing, Deployment
  สอนสร้าง MCP Server ที่ Production-ready ไม่ใช่แค่ prototype
  ใช้เมื่อ: (1) สร้าง MCP Server ใหม่ (2) เพิ่ม tools ให้ Claude/AI agents (3) เชื่อมต่อ API ผ่าน MCP
  (4) Debug MCP Server (5) ออกแบบ Tool naming/schema (6) ทำ MCP ให้ production-ready
  (7) สร้าง custom connectors (8) อะไรก็ตามที่เกี่ยวกับ MCP protocol
  Commands: /mcp [type], /tool [name], /server [api], /debug-mcp [issue], /deploy-mcp [target]
---

# MRARRANGER MCP Builder

ระบบสร้าง MCP Server ตั้งแต่ design จนถึง production deployment

## Quick Commands

```
/mcp [type]             → สร้าง MCP Server (stdio/sse/streamable-http)
/tool [name]            → ออกแบบ tool definition
/server [api-name]      → สร้าง MCP server จาก API
/debug-mcp [issue]      → Debug MCP connection/tool issues
/deploy-mcp [target]    → Deploy MCP server
/schema [resource]      → ออกแบบ resource schema
```

---

## MCP Architecture Overview

```
┌──────────────────────┐
│    AI Agent (Host)   │  Claude, Cursor, Copilot, etc.
│    (Claude/etc.)     │
└──────┬───────────────┘
       │ MCP Protocol (JSON-RPC 2.0)
       │
┌──────▼───────────────┐
│    MCP Server        │  Your custom server
│  ┌─────────────────┐ │
│  │ Tools           │ │  Functions the AI can call
│  │ Resources       │ │  Data the AI can read
│  │ Prompts         │ │  Prompt templates
│  └─────────────────┘ │
└──────┬───────────────┘
       │
┌──────▼───────────────┐
│  External Services   │  APIs, DBs, Files, etc.
└──────────────────────┘
```

---

## Tool Design Principles

### Semantic Naming
ชื่อ tool ต้อง self-documenting - AI agent ต้องเข้าใจจากชื่อว่าทำอะไร

```
GOOD:
  search_customers       → ชัดเจน: ค้นหาลูกค้า
  create_invoice         → ชัดเจน: สร้าง invoice
  get_order_status       → ชัดเจน: ดูสถานะ order

BAD:
  do_thing              → ไม่รู้ว่าทำอะไร
  process               → กว้างเกินไป
  handle_request        → ไม่ specific
  customerAction        → ไม่ชัดว่า action อะไร
```

### Tool Granularity
```
WORKFLOW TOOLS (recommended for most cases):
  - 1 tool = 1 complete user intent
  - เช่น send_email, create_report, deploy_app
  - AI ต้องตัดสินใจน้อย → error น้อย

API COVERAGE TOOLS (use when needed):
  - 1 tool = 1 API endpoint
  - เช่น list_users, get_user, update_user, delete_user
  - Flexible แต่ AI ต้อง chain หลาย calls
```

### Tool Definition Template
```typescript
{
  name: "search_products",
  description: "Search products by name, category, or price range. Returns up to 20 results sorted by relevance. Use this when the user wants to find or browse products.",
  inputSchema: {
    type: "object",
    properties: {
      query: {
        type: "string",
        description: "Search query - product name or keywords"
      },
      category: {
        type: "string",
        description: "Product category filter",
        enum: ["electronics", "clothing", "food", "other"]
      },
      min_price: {
        type: "number",
        description: "Minimum price in THB"
      },
      max_price: {
        type: "number",
        description: "Maximum price in THB"
      },
      limit: {
        type: "number",
        description: "Max results to return (default: 10, max: 20)",
        default: 10
      }
    },
    required: ["query"]
  }
}
```

### Description Best Practices
```
description ต้องบอก:
1. WHAT: tool ทำอะไร (1 sentence)
2. WHEN: ใช้เมื่อไหร่ (ช่วยให้ AI ตัดสินใจถูก)
3. RETURNS: ให้อะไรกลับมา (format, limits)
4. CAVEATS: ข้อจำกัดที่สำคัญ (rate limits, permissions)

ตัวอย่าง:
"Search products by name, category, or price range.
Returns up to 20 results sorted by relevance with title, price, and image URL.
Use this when the user wants to find, browse, or compare products.
Note: results are cached for 5 minutes."
```

---

## MCP Server Template (TypeScript)

### Basic Stdio Server
```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({
  name: "my-server",
  version: "1.0.0",
});

// Tool with proper error handling
server.tool(
  "search_items",
  "Search items by query. Returns matching items with name and description.",
  {
    query: z.string().describe("Search query"),
    limit: z.number().optional().default(10).describe("Max results"),
  },
  async ({ query, limit }) => {
    try {
      const results = await searchAPI(query, limit);
      return {
        content: [{
          type: "text",
          text: JSON.stringify(results, null, 2)
        }]
      };
    } catch (error) {
      // Error ที่ AI agent เข้าใจและ self-correct ได้
      return {
        content: [{
          type: "text",
          text: `Error searching: ${error.message}. Try a different query or check if the service is available.`
        }],
        isError: true
      };
    }
  }
);

// Resource
server.resource(
  "config",
  "config://settings",
  async (uri) => ({
    contents: [{
      uri: uri.href,
      mimeType: "application/json",
      text: JSON.stringify(config)
    }]
  })
);

// Start
const transport = new StdioServerTransport();
await server.connect(transport);
```

---

## Error Handling Strategy

### Self-Correcting Errors
AI agents ทำงานได้ดีที่สุดเมื่อ error messages ช่วยให้แก้ไขตัวเองได้:

```typescript
// BAD: Agent ไม่รู้จะแก้ยังไง
return { content: [{ type: "text", text: "Error 500" }], isError: true };

// GOOD: Agent รู้ว่าต้องทำอะไรต่อ
return {
  content: [{
    type: "text",
    text: `Could not find user with ID "${userId}". ` +
          `Available actions: use search_users to find the correct user ID, ` +
          `or try listing all users with list_users.`
  }],
  isError: true
};
```

### Error Categories
```typescript
function handleError(error: unknown, context: string): ToolResult {
  if (error instanceof NotFoundError) {
    return errorResult(
      `${context} not found. Use the search or list tool to find valid IDs.`
    );
  }
  if (error instanceof ValidationError) {
    return errorResult(
      `Invalid input: ${error.message}. Check parameter types and required fields.`
    );
  }
  if (error instanceof RateLimitError) {
    return errorResult(
      `Rate limit reached. Wait ${error.retryAfter}s before trying again.`
    );
  }
  if (error instanceof AuthError) {
    return errorResult(
      `Authentication failed. The API key may be expired or invalid. ` +
      `Ask the user to check their credentials.`
    );
  }
  // Unexpected
  return errorResult(
    `Unexpected error in ${context}: ${String(error)}. ` +
    `This might be a temporary issue - try again.`
  );
}
```

---

## Security Checklist

```
INPUT VALIDATION:
□ Validate all inputs with Zod schema
□ Sanitize strings (no injection)
□ Limit array/string lengths
□ Validate URLs/paths (no path traversal)

AUTHENTICATION:
□ API keys in environment variables (ไม่ hardcode)
□ Token refresh logic (if needed)
□ Per-user auth isolation (multi-tenant)

DATA:
□ ไม่ return sensitive data (passwords, tokens)
□ Mask PII in logs
□ Limit response size (ไม่ dump entire database)

RATE LIMITING:
□ Rate limit per tool
□ Timeout on external calls
□ Circuit breaker for failing services
```

---

## Testing MCP Server

### Manual Test
```bash
# Test with MCP Inspector
npx @modelcontextprotocol/inspector node build/index.js

# Test specific tool
echo '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"search_items","arguments":{"query":"test"}}}' | node build/index.js
```

### Automated Tests
```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";

describe("MCP Server", () => {
  let server: McpServer;

  beforeEach(async () => {
    server = createServer();
    const transport = new InMemoryTransport();
    await server.connect(transport);
  });

  it("should search items successfully", async () => {
    const result = await server.callTool("search_items", { query: "test" });
    expect(result.isError).toBeFalsy();
    const data = JSON.parse(result.content[0].text);
    expect(data.length).toBeGreaterThan(0);
  });

  it("should handle invalid input gracefully", async () => {
    const result = await server.callTool("search_items", {});
    expect(result.isError).toBeTruthy();
  });
});
```

---

## Deployment Options

### Claude Desktop (claude_desktop_config.json)
```json
{
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["/path/to/build/index.js"],
      "env": { "API_KEY": "your-key" }
    }
  }
}
```

### Claude Code (.claude/settings.json)
```json
{
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["build/index.js"],
      "cwd": "/path/to/server"
    }
  }
}
```

### Remote SSE / Streamable HTTP
```typescript
// สำหรับ deploy บน server (เช่น Vercel, Railway)
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import express from "express";

const app = express();
app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({ sessionId: req.headers["x-session-id"] });
  await server.connect(transport);
  await transport.handleRequest(req, res);
});
app.listen(3000);
```

---

## MCP Project Scaffold

เมื่อ user ต้องการสร้าง MCP Server ให้สร้าง structure นี้:

```
my-mcp-server/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts          # Server entry point
│   ├── tools/            # Tool definitions
│   │   ├── search.ts
│   │   └── create.ts
│   ├── resources/        # Resource definitions
│   ├── lib/              # Shared utilities
│   │   ├── api-client.ts # External API client
│   │   └── errors.ts     # Error handling
│   └── types.ts          # Type definitions
├── tests/
│   └── tools.test.ts
└── README.md
```
