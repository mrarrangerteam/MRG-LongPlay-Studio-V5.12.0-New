---
name: mrarranger-debug-master
description: ระบบ Debug และ Troubleshoot ขั้นเทพ - Systematic debugging methodology, error reading, DevTools, Node.js/Python debugging, profiling, and production troubleshooting
commands:
  - /debug
  - /trace
  - /profile
  - /log
  - /error
  - /fix-error
---

# MRARRANGER Debug Master

**ระบบ Debug และ Troubleshoot ขั้นเทพ** - A comprehensive debugging system for developers.

## 1. Systematic Debugging Methodology

### กระบวนการ Debug พื้นฐาน
The four-step debugging cycle ensures systematic problem-solving:

**Reproduce → Isolate → Fix → Verify**

```
1. REPRODUCE (ทำให้เกิดปัญหาซ้ำ)
   - นำปัญหามาให้เกิด consistently
   - จดขั้นตอนการทำให้เกิดอย่างชัดเจน
   - ตรวจสอบว่าเป็นปัญหาจริงหรือเป็น one-off issue

2. ISOLATE (แยกโค้ดที่เป็นสาเหตุ)
   - แบ่ง code ให้เล็กลง progressively
   - สร้าง minimal reproducible example (MRE)
   - หา exact line / function ที่ทำให้เกิดปัญหา

3. FIX (แก้ไขปัญหา)
   - เข้าใจ root cause ก่อนแก้
   - เปลี่ยนแปลง code อย่างเล็กน้อย (one change at a time)
   - บันทึก why you made the fix

4. VERIFY (ยืนยันว่าแก้ได้ถูกต้อง)
   - ทำให้ปัญหาเกิดซ้ำ → ควรไม่เกิด
   - ทดสอบ edge cases
   - เพิ่ม regression test
```

## 2. Error Reading & Stack Traces

### JavaScript/Node.js Error Reading
```javascript
// ตัวอย่าง: TypeError: Cannot read property 'name' of undefined
// Stack trace interpretation:
TypeError: Cannot read property 'name' of undefined
    at Object.getUserName (/app/user.js:45:12)
    at processUser (/app/processor.js:78:5)
    at main (/app/index.js:12:3)

// การอ่าน stack trace:
// - Top line = actual error
// - Each line = function that was called
// - /app/user.js:45:12 = file, line, column
// - Root cause usually 2-3 levels up
```

### Python Exception Handling
```python
# Python traceback ให้ข้อมูลจาก inner scope ไปยัง outer scope
try:
    value = data["key"]["nested"]  # KeyError
except KeyError as e:
    print(f"Error: {e}")  # ดูว่า key ไหนที่ missing
```

### Common Error Patterns
- `undefined is not a function` → Function ที่ถูกเรียกไม่มีอยู่
- `Cannot read property X of null` → Object ยังไม่ถูก initialize
- `ECONNREFUSED` → Server ไม่ใช่งาน / port ผิด
- `CORS error` → Cross-origin request ไม่ได้รับ approval

## 3. Browser DevTools

### Console Tab (บันทึก Errors & Warnings)
```javascript
// console api ใช้งาน:
console.log("info")       // standard message
console.error("error")    // red colored error
console.warn("warning")   // yellow warning
console.table([{a:1},{b:2}])  // display as table
console.time("label")     // start timer
console.timeEnd("label")  // end timer, log duration

// Filtering:
// - Error level dropdown (All, Errors, Warnings)
// - Search filters
// - Group Similar = collapse duplicate errors
```

### Network Tab (Monitor API Calls)
```
- Request headers / Response headers
- Payload (request body)
- Response (response body)
- Timing (waiting, downloading, processing)
- Status codes: 2xx (success), 3xx (redirect), 4xx (client), 5xx (server)
```

### Performance & Memory Tabs
```javascript
// Performance: Record → play action → Stop
// Shows: FCP, LCP, CPU bottlenecks, long tasks

// Memory: Heap snapshots reveal memory leaks
// Allocation timeline: show where memory grows
```

### Sources Tab (สำหรับ Debugging Code)
```javascript
// Breakpoints:
debugger;  // หยุด execution ที่บรรทัดนี้

// In DevTools:
// - Click line number เพื่อ set breakpoint
// - Step over / into / out
// - Watch expressions
// - Conditional breakpoints
```

## 4. Node.js Debugging

### Using --inspect Flag
```bash
node --inspect app.js
# Open: chrome://inspect in Chrome
# หรือใช้ VSCode Debugger

node --inspect-brk app.js
# Pause at startup (สำหรับ debug initialization code)
```

### Debugger Statement
```javascript
// app.js
function problematicFunction() {
  debugger;  // execution pauses here
  // ... code
}

// Run: node --inspect app.js
// Attach debugger, then call function
```

### NDB (Better Node.js Debugger)
```bash
npm install -g ndb
ndb node app.js
# Opens Chrome DevTools with better UX
```

## 5. Python Debugging

### PDB (Python Debugger)
```python
import pdb

def calculate(x, y):
    pdb.set_trace()  # Pause execution
    result = x / y
    return result

# Commands: n (next), s (step), c (continue), l (list)
```

### Breakpoint() - Python 3.7+
```python
def function():
    x = 10
    breakpoint()  # Calls pdb
    y = x * 2
```

### IPython Debugger
```bash
pip install ipdb
# In code: from ipdb import set_trace; set_trace()
# More features: syntax highlighting, tab completion
```

### Traceback Analysis
```python
import traceback
try:
    1 / 0
except Exception:
    traceback.print_exc()  # ให้ full stack trace
```

## 6. Logging Best Practices

### Structured Logging (JSON format)
```javascript
// Node.js with winston
const logger = require('winston');

logger.info('user_created', {
  user_id: 123,
  email: 'user@example.com',
  timestamp: new Date().toISOString()
});
// Output: {"level":"info","message":"user_created","user_id":123}
```

### Log Levels (ลำดับ Priority)
```
ERROR   - something broke, needs fixing
WARN    - potential issue, but still working
INFO    - important state changes
DEBUG   - detailed info for troubleshooting
TRACE   - very detailed, only in dev
```

### Python Logging
```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
logger.error("Something went wrong", exc_info=True)
```

## 7. Performance Profiling

### CPU Profiling (Node.js)
```bash
node --prof app.js
node --prof-process isolate-*.log > profile.txt
# View: grep TOTAL profile.txt
```

### Memory Profiling
```javascript
// Check heap size:
console.log(process.memoryUsage());
// {
//   rss: 29.3 MB,      // resident set size
//   heapTotal: 9.2 MB, // total heap allocated
//   heapUsed: 5.8 MB   // heap actually using
// }

// If heapUsed grows over time → memory leak
```

### Python Profiling
```python
import cProfile

cProfile.run('expensive_function()')
# Shows: cumulative time, per-call time, function call count
```

## 8. Network Debugging

### curl for API Testing
```bash
curl -X POST https://api.example.com/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John"}' \
  -v  # verbose (show headers)
```

### httpie (Better curl)
```bash
pip install httpie
http POST api.example.com/users name=John
# Pretty prints JSON, syntax highlighting
```

### DNS Issues
```bash
nslookup example.com
dig example.com
# Shows DNS resolution
```

## 9. Database Debugging

### Slow Query Detection
```sql
-- MySQL: Enable slow query log
SET GLOBAL slow_query_log = 'ON';
SET GLOBAL long_query_time = 1;

-- PostgreSQL: EXPLAIN ANALYZE
EXPLAIN ANALYZE SELECT * FROM users WHERE id = 123;
-- Shows: seq scan vs index scan, rows returned, execution time
```

### Connection Pooling Issues
```javascript
// Check current connections:
SELECT COUNT(*) FROM pg_stat_activity;
// If near max_connections → queries hang

// Solution: increase pool size, or add timeout
const pool = new Pool({ max: 20, idle: 5000 });
```

## 10. Common Error Patterns

### CORS Error
```javascript
// Frontend: Cannot access API due to CORS
// Backend must set CORS headers:
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:3000');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE');
  next();
});
```

### Memory Leaks
```javascript
// Problem: Event listeners not removed
button.addEventListener('click', handler);
// Fix: Remove when not needed
button.removeEventListener('click', handler);

// Problem: Timers not cleared
const timeout = setTimeout(() => {}, 1000);
clearTimeout(timeout);  // Always cleanup
```

### Race Conditions
```javascript
// Problem: Non-atomic operations
let counter = 0;
async function increment() {
  counter++;  // Not atomic in async context
}

// Fix: Use atomic operation or lock
const counter = new AtomicInteger(0);
```

## 11. Production Debugging

### Remote Debugging (Without Stopping Server)
```bash
# Enable on production (carefully!)
NODE_OPTIONS="--inspect-publish-uuids" node app.js

# In secure network, connect debugger
# Or use logging to understand issues
```

### Log Analysis
```bash
# Find all errors in last hour:
grep "ERROR" app.log | tail -1000

# Count error types:
grep "ERROR" app.log | cut -d' ' -f2 | sort | uniq -c

# Time-series analysis:
grep "2024-03-15" app.log | wc -l  # logs per day
```

### Health Check Endpoints
```javascript
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    memory: process.memoryUsage(),
    uptime: process.uptime()
  });
});
```

## 12. React Debugging

### React DevTools Extension
```javascript
// Components tab: inspect component state/props
// Profiler tab: measure render performance
// Highlight renders when components update

// Enable Strict Mode (dev only):
<React.StrictMode>
  <App />
</React.StrictMode>
```

### why-did-you-render
```bash
npm install @welldone-software/why-did-you-render
# Logs unnecessary re-renders with reasons
```

### Common React Issues
```javascript
// Problem: State not updating
setState(obj);  // May batch with other updates

// Problem: Dependency array issues
useEffect(() => { ... }, [])  // empty = run once
useEffect(() => { ... }, [dep])  // run when dep changes

// Problem: Stale closures
// Fix: use useCallback/useMemo
```

## 13. TypeScript Debugging

### Type Errors
```typescript
// Error: Type 'string | number' not assignable to 'string'
const value: string | number = getValue();
const str: string = value;  // ❌ Not safe

// Fix: Type guard
if (typeof value === 'string') {
  const str: string = value;  // ✓ Safe
}
```

### Async/Await Issues
```typescript
async function fetch() {
  return await getData();  // Always returns Promise
}

// Wrong: calling without await
function caller() {
  const result = fetch();  // result is Promise, not data
}

// Fix: await the call
async function caller() {
  const result = await fetch();
}
```

---

## Commands Summary

- `/debug [service/function]` - Set up debugging environment
- `/trace [function]` - Trace function execution
- `/profile [type]` - CPU/Memory profiling
- `/log [level]` - Configure logging
- `/error [type]` - Explain error patterns
- `/fix-error [description]` - Get debugging help

**MRARRANGER Debug Master: Systematic, methodical, reproducible debugging.**
