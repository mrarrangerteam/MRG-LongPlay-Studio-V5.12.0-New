# Team 9: AI/LLM Security Team

## บทบาท
AI Security Specialist — ตรวจ prompt injection, LLM abuse, AI API cost control, model security

## ทำไมทีมนี้สำคัญ
- OWASP Top 10 for LLM Applications 2025 ระบุ Prompt Injection เป็นอันดับ 1
- OpenAI ยอมรับว่า prompt injection "unlikely to ever be fully solved"
- 87% ของ AI-generated PRs มีช่องโหว่อย่างน้อย 1 รายการ (DryRun Security มี.ค. 2026)
- มีเพียง 34.7% ขององค์กรที่มี prompt injection defense

## สถิติ & CVEs ล่าสุด
- CVE-2025-54135 (CurXecute): Arbitrary command execution ใน Cursor ผ่าน MCP
- CVE-2025-55284: Data exfiltration จาก Claude Code ผ่าน DNS requests
- CVE-2025-59944: Case sensitivity ทำให้ RCE ใน Cursor ได้
- IDEsaster research (ธ.ค. 2025): 30+ vulnerabilities ใน AI IDEs ทุกตัว, 24 CVEs

## Checklist

### 1. OWASP Top 10 for LLM Applications 2025
| # | Risk | สิ่งที่ตรวจ |
|---|------|-----------|
| LLM01 | Prompt Injection | Input sanitization, instruction hierarchy |
| LLM02 | Sensitive Info Disclosure | Output filtering, PII ไม่หลุดผ่าน AI |
| LLM03 | Supply Chain | AI model provenance, plugin/skill vetting |
| LLM04 | Data & Model Poisoning | Training data integrity |
| LLM05 | Improper Output Handling | Output validation ก่อน render/execute |
| LLM06 | Excessive Agency | AI ทำ action อะไรได้บ้าง, human-in-the-loop |
| LLM07 | System Prompt Leakage | System prompt hardening, canary instructions |
| LLM08 | Vector & Embedding Weaknesses | RAG security |
| LLM09 | Misinformation | Output verification |
| LLM10 | Unbounded Consumption | Token limits, cost caps, "Denial of Wallet" |

### 2. Prompt Injection Prevention
- Input sanitization ก่อนส่งไป LLM (regex + semantic filtering)
- Instruction hierarchy: system > developer > user prompts
- ไม่ใส่ user input ตรงๆ ใน system prompt
- Output validation ก่อน render หรือ execute tool
- Canary instructions ใน system prompt เพื่อ detect leakage

### 3. AI API Cost Control
- Token budget limits per user/session
- Cost alerts เมื่อ usage ผิดปกติ
- Rate limiting สำหรับ AI endpoints
- Output token caps (output แพงกว่า input 3-5x)
- Monitor cost per feature — chatbot feature อาจจาก $50/เดือน → $50,000/เดือน

### 4. AI Bill of Materials (AI-BOM)
- รายการ AI models ที่ใช้ทั้งหมด
- API providers + versions
- Data sources สำหรับ RAG/fine-tuning
- Third-party AI plugins/skills

### 5. MCP Server Security
- MCP stacks มี 92% exploit probability เมื่อเชื่อม 10 plugins (VentureBeat)
- 492 MCP servers พบไม่มี authentication หรือ encryption (Trend Micro)
- 36.7% vulnerable to SSRF (BlueRock Security)
- ตรวจ: input validation, container isolation, stdio transport, human confirmation
- ดู vulnerablemcp.info สำหรับ CVE database

### 6. AI Agent Autonomy Controls
- AI agents มีมากกว่ามนุษย์ 82:1 ใน enterprise (Palo Alto Networks)
- OWASP Top 10 for Agentic Applications (ธ.ค. 2025)
- Compromised agent สามารถ poison 87% ของ downstream decisions ภายใน 4 ชั่วโมง
- ต้องมี: Least agency principle, human-in-the-loop, action logging, rollback capability

## Tools
- Lakera Guard (prompt injection detection)
- Microsoft Prompt Shields
- CrowdStrike semantic filters
- vulnerablemcp.info (MCP CVE database)
