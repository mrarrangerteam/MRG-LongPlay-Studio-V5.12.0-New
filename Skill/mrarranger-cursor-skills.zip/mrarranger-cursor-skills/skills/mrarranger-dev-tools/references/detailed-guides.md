# Technical Documentation - Detailed Guides & Examples

## README Complete Template

```markdown
# Project Name

## Badges
[![npm version](https://img.shields.io/npm/v/package.svg)](https://www.npmjs.com/package/package)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Description
สั้นๆ 1-2 paragraph อธิบาย project ทำอะไร

## Installation
```bash
npm install package-name
```

## Quick Start
```javascript
const pkg = require('package-name');
pkg.doSomething();
```

## Features
- ✓ Feature 1
- ✓ Feature 2
- ✓ Feature 3

## API Reference
### `function(options)`
- `options.param1` (string) - Description

## Configuration
```json
{
  "key": "value"
}
```

## Examples
### Basic Usage
Code example here

### Advanced Usage
Code example here

## Contributing
1. Fork repository
2. Create feature branch
3. Commit changes
4. Push and create PR

## License
MIT
```

## Changelog Format

```markdown
# Changelog

All notable changes to this project will be documented in this file.

## [1.2.0] - 2024-03-15

### Added
- ✨ New feature for user authentication
- 📝 Documentation for API endpoints

### Fixed
- 🐛 Memory leak in cache system
- 🔒 Security issue in password reset

### Changed
- 🔄 Refactored database connection pooling
- 📊 Improved performance of list query

### Deprecated
- ⚠️ Old auth method (use newAuth instead)

### Removed
- 🗑️ Legacy API v1 endpoints

## [1.1.0] - 2024-02-01

### Added
- Basic user management
```

## ADR Template

```markdown
# ADR 001: Use PostgreSQL instead of MongoDB

## Status
Accepted

## Context
เราต้องเลือก database สำหรับ project ใหม่
- ข้อมูลมี structure ชัดเจน
- ต้องการ strong consistency
- ต้องรองรับ complex queries

## Decision
เลือกใช้ PostgreSQL แทน MongoDB

## Consequences
### Positive
- ✓ Strong ACID guarantees
- ✓ Complex queries easily done
- ✓ Excellent tooling

### Negative
- ✗ ต้อง schema migration เมื่อเปลี่ยน structure
- ✗ ต้อง data normalization

## Alternatives Considered
1. MongoDB - แต่ loose schema ทำให้ยากในการ maintain consistency
2. DynamoDB - ได้ความ scalability แต่ query language ทำให้ยุ่ง
```

## Runbook: High Database Load

```markdown
# Runbook: High Database Load

## Symptoms
- Database connection pool exhaustion
- 500 errors on API endpoints
- Response time > 5 seconds

## Immediate Actions
1. Check current connections:
   ```sql
   SELECT COUNT(*) FROM pg_stat_activity;
   ```

2. Identify slow queries:
   ```sql
   SELECT query, mean_time FROM pg_stat_statements
   ORDER BY mean_time DESC LIMIT 10;
   ```

3. If critical: enable read-only mode
   ```sql
   ALTER SYSTEM SET default_transaction_read_only = on;
   SELECT pg_reload_conf();
   ```

## Resolution
1. Scale database resources
2. Optimize slow queries
3. Implement caching layer
4. Add query timeout

## Prevention
- Monitor connection pool regularly
- Set up alerting at 70% capacity
- Regular query performance review
```

## Deployment Playbook

```markdown
# Deployment Checklist

- [ ] Code review completed
- [ ] Tests passing (unit, integration, e2e)
- [ ] Database migrations tested
- [ ] Environment variables configured
- [ ] Security scan passed
- [ ] Monitoring alerts configured
- [ ] Runbooks reviewed
- [ ] Rollback plan documented

## Deployment Steps
1. Merge to main branch
2. CI/CD pipeline runs tests
3. Build Docker image
4. Push to registry
5. Update Kubernetes deployment
6. Monitor for errors (10 minutes)
7. Update documentation
```

## System Design Example: Real-time Chat

```markdown
# System Design: Real-time Chat

## Requirements
### Functional
- Users can send messages
- Messages delivered in < 1 second
- Support 10,000 concurrent users

### Non-functional
- 99.9% uptime
- Messages persisted for 30 days
- Scalable to millions of messages

## Architecture
- Frontend: React WebSocket client
- Backend: Node.js with Socket.io
- Database: PostgreSQL + Redis cache
- Message queue: Kafka for reliability

## Database Schema
```
users (id, username, email)
messages (id, user_id, chat_id, content, created_at)
chats (id, name, created_at)
```

## API Endpoints
- POST /api/chats/{id}/messages
- GET /api/chats/{id}/messages
- WebSocket /ws/chats/{id}
```

## Documentation-as-Code Tools

### Docusaurus Setup
```bash
npm init docusaurus@latest my-docs classic
npm start  # Local development

# Structure:
# docs/
#   tutorial.md
#   api/
#     overview.md
#     endpoints.md
# blog/
#   2024-01-01-announcement.md
```

### MkDocs Configuration
```yaml
# mkdocs.yml
site_name: My Documentation
nav:
  - Home: index.md
  - Getting Started: getting-started.md
  - API:
    - Overview: api/overview.md
    - Endpoints: api/endpoints.md

theme: material
plugins:
  - search
  - mermaid2
```

### VitePress Setup
```bash
npm add -D vitepress
npx vitepress init

# docs/
#   index.md
#   guide.md
#   api.md
```

## Mermaid Diagrams

### Flow Diagram
```mermaid
graph TD
    A[User] -->|login| B[Auth Service]
    B -->|verify| C[Database]
    C -->|token| B
    B -->|return| A
```

### Sequence Diagram
```mermaid
sequenceDiagram
    Client->>Server: Request
    Server->>Database: Query
    Database-->>Server: Result
    Server-->>Client: Response
```

## PlantUML Examples

```
@startuml
class User {
  - id: int
  - name: string
  + getName(): string
}

class Order {
  - id: int
  - user_id: int
  + getTotal(): decimal
}

User "1" -- "*" Order
@enduml
```

## C4 Model Architecture

```
System Context: E-Commerce
[User] -uses-> [E-Commerce System]
[E-Commerce System] -uses-> [Payment Gateway]
[E-Commerce System] -uses-> [Email Service]
```

## Storybook Example

```javascript
// Button.stories.js
export default {
  title: 'Components/Button',
  component: Button,
};

export const Primary = {
  args: {
    label: 'Click me',
    variant: 'primary',
  },
};

export const Secondary = {
  args: {
    label: 'Click me',
    variant: 'secondary',
  },
};
```

## Database Schema Documentation

### dbdocs.io Format
```
Table users {
  id int [primary key]
  email varchar [unique]
  created_at timestamp

  indexes {
    email
  }
}

Table posts {
  id int [primary key]
  user_id int [ref: > users.id]
  title varchar
  content text
}

Ref: posts.user_id > users.id
```

## Writing Style Guide

### General Principles
1. **Use Active Voice**
   - ❌ "The file is created by the system"
   - ✓ "The system creates the file"

2. **Be Concise**
   - ❌ "In order to accomplish the task of..."
   - ✓ "To accomplish..."

3. **Examples > Theory**
   - Show code examples before explaining

4. **Consistency**
   - Use same terminology
   - Same formatting for code blocks
   - Same structure for similar sections

5. **Clear Headings**
   - Readers scan headings, so make them descriptive
