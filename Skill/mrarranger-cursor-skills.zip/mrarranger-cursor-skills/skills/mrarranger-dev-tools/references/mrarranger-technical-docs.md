---
name: mrarranger-technical-docs
description: ระบบสร้างเอกสารเทคนิคครบวงจร - API docs, code documentation, README, ADR, diagrams, and documentation-as-code
commands:
  - /docs
  - /api-docs
  - /readme
  - /changelog
  - /adr
  - /diagram
  - /spec
  - /runbook
---

# MRARRANGER Technical Documentation

**ระบบสร้างเอกสารเทคนิคครบวงจร** - Complete technical documentation system.

## 1. API Documentation

### OpenAPI/Swagger 3.0 Specification
```yaml
# openapi.yaml
openapi: 3.0.0
info:
  title: User API
  version: 1.0.0
  description: สำหรับจัดการ users

paths:
  /users:
    get:
      summary: List all users
      parameters:
        - name: limit
          in: query
          schema:
            type: integer
      responses:
        '200':
          description: Array of users
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/User'

components:
  schemas:
    User:
      type: object
      properties:
        id:
          type: integer
        name:
          type: string
        email:
          type: string
      required:
        - id
        - name
```

### Redoc & Swagger UI
```bash
# Generate interactive documentation
npm install -D redoc-cli swagger-ui-express

# Generate static HTML
redoc-cli build openapi.yaml -o index.html

# Serve with Express
app.use(swaggerUi.serve, swaggerUi.setup(swaggerDocument));
```

## 2. Code Documentation

### JSDoc Format
```javascript
/**
 * Calculate user age from birth date
 * @param {Date} birthDate - User birth date (ต้องเป็น Date object)
 * @returns {number} Age in years
 * @throws {TypeError} If birthDate is not a Date
 * @example
 * const age = calculateAge(new Date('1990-01-01'));
 * console.log(age); // 34
 */
function calculateAge(birthDate) {
  if (!(birthDate instanceof Date)) {
    throw new TypeError('birthDate must be a Date');
  }
  return Math.floor((Date.now() - birthDate) / 31536000000);
}
```

### TSDoc (TypeScript)
```typescript
/**
 * Processes user data and returns normalized result
 * @param user - User object containing name and email
 * @param options - Configuration options (optional)
 * @returns Processed user with additional fields
 * @throws InvalidUserError If user data is incomplete
 */
function processUser(user: User, options?: ProcessOptions): ProcessedUser {
  // implementation
}
```

### Python Docstrings
```python
def calculate_discount(price: float, percentage: int) -> float:
    """
    Calculate discounted price

    ใช้สำหรับคำนวณราคาหลังหักส่วนลด

    Args:
        price: Original price (ต้องมากกว่า 0)
        percentage: Discount percentage (0-100)

    Returns:
        Discounted price

    Raises:
        ValueError: If price < 0 or percentage not in 0-100

    Example:
        >>> calculate_discount(100, 10)
        90.0
    """
    if price < 0 or not (0 <= percentage <= 100):
        raise ValueError("Invalid parameters")
    return price * (1 - percentage / 100)
```

## 3. README Best Practices

Essential sections for a good README:
- **Badges**: CI/CD status, license, version
- **Description**: 1-2 paragraphs explaining what the project does
- **Installation**: Clear step-by-step installation instructions
- **Quick Start**: Minimal code example to get started
- **Features**: List of key capabilities with checkmarks
- **API Reference**: Function/method signatures and parameters
- **Configuration**: Configuration options and environment variables
- **Examples**: Basic and advanced usage examples
- **Contributing**: Guidelines for contributors
- **License**: License type

See references/readme-template.md for a complete template.

## 4. Changelog Format

### Keep a Changelog Standard
Changes are categorized as:
- **Added**: New features
- **Fixed**: Bug fixes
- **Changed**: Changes to existing functionality
- **Deprecated**: Features marked for removal
- **Removed**: Removed features
- **Security**: Security vulnerability fixes

### Conventional Commits Format
```
commit: type(scope): description

Types:
- feat:     New feature
- fix:      Bug fix
- docs:     Documentation changes
- style:    Code style (no functional change)
- refactor: Refactoring without feature change
- test:     Test additions
- chore:    Build, dependencies, tooling
```

See references/changelog-guide.md for detailed examples.

## 5. Architecture Decision Records (ADR)

ADRs document important technical decisions with context, consequences, and alternatives.

**Key sections:**
- **Status**: Accepted, Rejected, Superseded
- **Context**: Problem statement and requirements
- **Decision**: What was chosen and why
- **Consequences**: Positive and negative impacts
- **Alternatives Considered**: Other options evaluated

See references/adr-template.md for complete format.

## 6. Runbooks & Playbooks

### Incident Response Runbook
Contains symptoms, immediate actions, resolution steps, and prevention measures.

### Deployment Playbook
Checklist and step-by-step process for safe deployments.

See references/runbooks-guide.md for detailed templates.

## 7. Technical Specifications

System design documents include:
- Functional requirements
- Non-functional requirements
- System architecture
- Database schema
- API endpoints
- Scalability considerations

See references/system-design-guide.md for complete format.

## 8. Documentation-as-Code Tools

### Docusaurus (React Documentation)
Modern documentation framework with versioning and search.

### MkDocs (Python Markdown)
Simple, fast documentation with Material theme.

### VitePress (Vue Documentation)
Lightweight alternative with excellent performance.

See references/doc-tools-guide.md for setup and usage.

## 9. Diagramming & Visualizations

### Mermaid
Flowcharts, sequence diagrams, and Gantt charts in pure text.

### PlantUML
UML diagrams for classes, components, and deployments.

### C4 Model
Architecture context diagrams at different abstraction levels.

See references/diagramming-guide.md for examples.

## 10. Storybook for UI Components

Component-driven documentation system for React, Vue, Angular, etc.

See references/storybook-guide.md for setup and examples.

## 11. Database Schema Documentation

Tools like dbdocs.io allow documenting:
- Table structures with fields and types
- Primary/foreign key relationships
- Indexes and constraints
- Documentation strings

See references/database-docs-guide.md for format.

## 12. Writing Style Guide

### General Principles
1. **Use Active Voice**: "The system creates..." not "The file is created..."
2. **Be Concise**: Avoid unnecessary words
3. **Examples > Theory**: Show code before explaining
4. **Consistency**: Same terminology, formatting, structure
5. **Clear Headings**: Help readers scan and navigate

See references/style-guide.md for detailed guidelines.

---

## Reference Files

For detailed examples, templates, and complete guides, see:
- `references/readme-template.md` - Complete README template
- `references/changelog-guide.md` - Changelog format and examples
- `references/adr-template.md` - ADR template and examples
- `references/runbooks-guide.md` - Runbook and playbook templates
- `references/system-design-guide.md` - System design document format
- `references/doc-tools-guide.md` - Documentation tool setup guides
- `references/diagramming-guide.md` - Mermaid, PlantUML, C4 examples
- `references/storybook-guide.md` - Storybook component documentation
- `references/database-docs-guide.md` - Database schema documentation format
- `references/style-guide.md` - Complete writing style guide

## Commands Summary

- `/docs [topic]` - Generate documentation
- `/api-docs` - Create OpenAPI specification
- `/readme [project]` - Generate README
- `/changelog` - Maintain changelog
- `/adr [decision]` - Write ADR
- `/diagram [type]` - Create architecture diagram
- `/spec [system]` - Write technical specification
- `/runbook [scenario]` - Create operational runbook

**MRARRANGER Technical Documentation: Clear, complete, maintainable.**
