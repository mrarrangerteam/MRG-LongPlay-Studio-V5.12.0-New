# CLI Tools - Detailed Examples & Implementations

## Commander.js Complete Example

```javascript
#!/usr/bin/env node

const { Command } = require('commander');
const program = new Command();

program
  .name('myapp')
  .description('My awesome CLI tool')
  .version('1.0.0');

// Create command with options
program
  .command('create <name>')
  .description('Create new project')
  .option('-t, --template <type>', 'Template type', 'default')
  .action((name, options) => {
    console.log(`Creating ${name} with template: ${options.template}`);
  });

// Subcommands
program
  .command('user')
  .description('User management')
  .addCommand(
    new Command('create')
      .description('Create user')
      .option('--email <email>', 'User email')
      .action((options) => console.log('Creating user'))
  );

// Variadic arguments
program
  .command('concat [files...]')
  .description('Concatenate files')
  .action((files) => {
    console.log(files);
  });

// Global options
program
  .option('-v, --verbose', 'Verbose output')
  .option('--config <file>', 'Config file path');

program.parse(process.argv);
```

## Yargs Complete Example

```javascript
const yargs = require('yargs');

yargs
  .command(
    'create <name>',
    'Create new project',
    (yargs) => {
      return yargs
        .positional('name', {
          describe: 'Project name',
          type: 'string',
        })
        .option('template', {
          alias: 't',
          describe: 'Template type',
          default: 'default',
        })
        .option('force', {
          alias: 'f',
          describe: 'Overwrite existing',
          type: 'boolean',
        });
    },
    (argv) => {
      console.log(`Creating ${argv.name}`);
      console.log(`Template: ${argv.template}`);
      console.log(`Force: ${argv.force}`);
    }
  )
  .option('verbose', {
    alias: 'v',
    describe: 'Verbose output',
    type: 'boolean',
  })
  .argv;
```

## Ink (React CLI) Example

```javascript
// index.js
const React = require('react');
const { render } = require('ink');
const SelectInput = require('ink-select-input');

const App = () => {
  const [selected, setSelected] = React.useState(null);

  const items = [
    { label: 'Create project', value: 'create' },
    { label: 'Deploy app', value: 'deploy' },
    { label: 'View logs', value: 'logs' },
  ];

  if (!selected) {
    return (
      <SelectInput
        items={items}
        onSelect={(item) => setSelected(item.value)}
      />
    );
  }

  return <div>You selected: {selected}</div>;
};

render(<App />);
```

## Click (Python) Example

```python
import click

@click.group()
@click.version_option()
def cli():
    """My awesome CLI tool"""
    pass

@cli.command()
@click.argument('name')
@click.option('--template', '-t', default='default', help='Template type')
def create(name, template):
    """Create new project"""
    click.echo(f'Creating {name} with template: {template}')

@cli.command()
@click.option('--format', type=click.Choice(['json', 'csv']), default='json')
def list(format):
    """List items"""
    click.echo(f'Listing in {format} format')

if __name__ == '__main__':
    cli()
```

## Click Interactive Prompts

```python
import click

@click.command()
def setup():
    """Interactive setup"""
    name = click.prompt('Project name')
    author = click.prompt('Author', default='Anonymous')

    if click.confirm('Add git?'):
        click.echo('Initializing git...')

    password = click.prompt('Password', hide_input=True)

    template = click.prompt(
        'Template',
        type=click.Choice(['blank', 'web', 'api']),
        default='blank'
    )

    click.secho('Setup complete!', fg='green')

if __name__ == '__main__':
    setup()
```

## Typer (Modern Python) Example

```python
import typer
from typing import Optional

app = typer.Typer()

@app.command()
def create(
    name: str = typer.Argument(..., help='Project name'),
    template: str = typer.Option('default', '--template', '-t', help='Template type'),
    force: bool = typer.Option(False, '--force', '-f', help='Overwrite existing'),
):
    """Create new project"""
    typer.echo(f"Creating {name}")
    typer.echo(f"Template: {template}")

@app.command()
def deploy(
    service: str = typer.Argument(...),
    env: str = typer.Option('staging', '--env', help='Environment'),
):
    """Deploy service"""
    typer.secho(f"Deploying {service} to {env}", fg=typer.colors.GREEN)

if __name__ == '__main__':
    app()
```

## Cobra (Go) Example

```go
// cmd/create.go
package cmd

import (
    "fmt"
    "github.com/spf13/cobra"
)

var createCmd = &cobra.Command{
    Use:   "create [name]",
    Short: "Create new project",
    Args:  cobra.ExactArgs(1),
    Run: func(cmd *cobra.Command, args []string) {
        name := args[0]
        template, _ := cmd.Flags().GetString("template")
        fmt.Printf("Creating %s with template: %s\n", name, template)
    },
}

func init() {
    rootCmd.AddCommand(createCmd)
    createCmd.Flags().StringP("template", "t", "default", "Template type")
}
```

## Clap (Rust) Example

```rust
use clap::{Parser, Subcommand};

#[derive(Parser)]
#[command(name = "mycli")]
#[command(about = "My awesome CLI", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,

    #[arg(short, long, global = true)]
    verbose: bool,
}

#[derive(Subcommand)]
enum Commands {
    Create {
        #[arg(help = "Project name")]
        name: String,

        #[arg(short, long, default_value = "default")]
        template: String,
    },
    List {
        #[arg(short, long, value_parser = ["json", "csv"])]
        format: Option<String>,
    },
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Create { name, template } => {
            println!("Creating {} with {}", name, template);
        }
        Commands::List { format } => {
            println!("Listing as {}", format.unwrap_or("json".into()));
        }
    }
}
```

## inquirer.js (Interactive Prompts)

```javascript
const inquirer = require('inquirer');

inquirer
  .prompt([
    {
      type: 'input',
      name: 'name',
      message: 'Project name:',
      validate: (val) => val.length > 0 || 'Required',
    },
    {
      type: 'list',
      name: 'template',
      message: 'Choose template:',
      choices: ['blank', 'web', 'api'],
    },
    {
      type: 'checkbox',
      name: 'features',
      message: 'Select features:',
      choices: ['TypeScript', 'ESLint', 'Testing'],
    },
    {
      type: 'confirm',
      name: 'git',
      message: 'Initialize git?',
      default: true,
    },
  ])
  .then((answers) => {
    console.log(answers);
  });
```

## prompts (Lightweight)

```javascript
const prompts = require('prompts');

(async () => {
  const response = await prompts([
    {
      type: 'text',
      name: 'name',
      message: 'Project name',
    },
    {
      type: 'select',
      name: 'template',
      message: 'Template',
      choices: [
        { title: 'Blank', value: 'blank' },
        { title: 'Web', value: 'web' },
      ],
    },
  ]);
  console.log(response);
})();
```

## questionary (Python)

```python
import questionary

name = questionary.text("Project name:").ask()
template = questionary.select(
    "Choose template:",
    choices=["blank", "web", "api"]
).ask()

features = questionary.checkbox(
    "Select features:",
    choices=["TypeScript", "ESLint", "Testing"]
).ask()
```

## Output: Colors & Styling

```javascript
// Node.js: chalk
const chalk = require('chalk');

console.log(chalk.green('Success!'));
console.log(chalk.red.bold('Error'));
console.log(chalk.blue.underline('Info'));
```

```python
# Python: colorama
from colorama import Fore, Back, Style

print(Fore.GREEN + 'Success!')
print(Fore.RED + Style.BRIGHT + 'Error')
```

## Output: Tables

```javascript
// Node.js: cli-table3
const Table = require('cli-table3');

const table = new Table({
  head: ['Name', 'Age', 'City'],
  colWidths: [30, 10, 20],
});

table.push(['John Doe', 30, 'New York']);
table.push(['Jane Smith', 25, 'London']);
console.log(table.toString());
```

## Output: Progress Bars

```javascript
// Node.js: cli-progress
const cliProgress = require('cli-progress');

const bar = new cliProgress.SingleBar({
  format: 'Progress |{bar}| {percentage}% || {value}/{total}',
  barCompleteChar: '\u2588',
  barIncompleteChar: '\u2591',
});

bar.start(100, 0);
for (let i = 0; i <= 100; i += 10) {
  bar.update(i);
}
bar.stop();
```

## Output: Spinners

```javascript
// Node.js: ora
const ora = require('ora');

const spinner = ora('Loading...').start();

setTimeout(() => {
  spinner.succeed('Done!');
}, 1000);

// Or with error
setTimeout(() => {
  spinner.fail('Failed!');
}, 1000);
```

## Configuration Management

```javascript
// .clirc or cli.config.json
{
  "author": "My Name",
  "template": "web",
  "autoInstall": true
}

// Load config
const fs = require('fs');
const path = require('path');

const configPath = path.join(process.env.HOME, '.clirc');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
```

## Shell Completions (Commander.js)

```javascript
program
  .option('--completion')
  .action((options) => {
    if (options.completion) {
      console.log('create\nlist\ndeploy\nremove');
    }
  });

// Install in ~/.bashrc or ~/.zshrc
eval "$(mycli --completion)"
```

## Testing CLI Tools (Node.js)

```javascript
// __tests__/cli.test.js
const { execSync } = require('child_process');

test('create command works', () => {
  const output = execSync('node cli.js create test-project').toString();
  expect(output).toContain('Creating test-project');
});

test('help shows version', () => {
  const output = execSync('node cli.js --help').toString();
  expect(output).toContain('1.0.0');
});
```

## Testing CLI Tools (Python)

```python
from click.testing import CliRunner
from mycli import cli

def test_create():
    runner = CliRunner()
    result = runner.invoke(cli, ['create', 'test-project'])
    assert result.exit_code == 0
    assert 'Creating test-project' in result.output
```

## Publishing to npm

```json
{
  "name": "mycli",
  "version": "1.0.0",
  "bin": {
    "mycli": "./bin/index.js"
  }
}
```

```bash
npm publish
npm install -g mycli
```

## Publishing to PyPI

```python
# setup.py
from setuptools import setup

setup(
    name='mycli',
    version='1.0.0',
    entry_points={
        'console_scripts': [
            'mycli=mycli.cli:main',
        ],
    },
)
```

```bash
python setup.py sdist bdist_wheel
twine upload dist/*
```

## Homebrew Formula

```ruby
class Mycli < Formula
  desc "My awesome CLI"
  homepage "https://github.com/user/mycli"
  url "https://github.com/user/mycli/archive/v1.0.0.tar.gz"
  sha256 "xxxxx"

  def install
    bin.install "mycli"
  end
end
```

## Ink (React CLI) Layout

```javascript
const React = require('react');
const { render, Box, Text } = require('ink');

const App = () => (
  <Box flexDirection="column">
    <Box>
      <Text>Welcome to </Text>
      <Text bold color="blue">
        MyApp
      </Text>
    </Box>
    <Box marginTop={1}>
      <Text>Version 1.0.0</Text>
    </Box>
  </Box>
);

render(<App />);
```

## Bubble Tea (Go TUI)

```go
package main

import (
    tea "github.com/charmbracelet/bubbletea"
    "fmt"
)

type model struct {
    choices []string
    cursor  int
}

func (m model) Init() tea.Cmd {
    return nil
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
    switch msg := msg.(type) {
    case tea.KeyMsg:
        if msg.String() == "q" {
            return m, tea.Quit
        }
    }
    return m, nil
}

func (m model) View() string {
    return "Select an option"
}

func main() {
    p := tea.NewProgram(model{choices: []string{"a", "b", "c"}})
    p.Run()
}
```
