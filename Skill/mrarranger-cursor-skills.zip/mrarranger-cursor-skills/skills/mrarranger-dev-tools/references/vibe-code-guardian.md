---
name: vibe-code-guardian
description: |
  Vibe Code Guardian — ระบบตรวจสอบและ Harden งาน Vibe-Coded แบบบริษัท Tech Startup
  15 ทีมเสมือน (CTO, Security, Backend, Frontend, DevOps/DMZ, QA, Performance, Compliance, AI Security, Observability, DB, Platform, Legal, Enterprise, Accessibility)
  Multi-Agent ตรวจโค้ดจาก AI tools (Cursor, Lovable, Bolt, Replit, v0, Claude Code)
  ใช้เมื่อ: (1) ตรวจ vibe code (2) security audit (3) harden ก่อน production (4) scalability test (5) DMZ review (6) compliance (GDPR/PDPA) (7) full tech audit (8) audit report (9) fix vibe code (10) QA ก่อนขาย SaaS
  Triggers: vibe code audit, security check, harden, production ready, ตรวจสอบโค้ด AI, DMZ, compliance, guardian

  Commands: /guardian /audit /security /performance /dmz /compliance /fix /report /team
---

# Vibe Code Guardian

ระบบตรวจสอบและ Harden งาน Vibe-Coded แบบบริษัท Tech Startup เต็มรูปแบบ

## Philosophy

> "Vibe coding สร้างได้เร็ว แต่ 45% ของโค้ด AI มีช่องโหว่ร้ายแรง — Guardian คือทีมที่ทำให้มันพร้อมขาย"

งานวิจัยจาก Veracode, Apiiro, CodeRabbit, Wiz Research 2025-2026 พบว่า:
- 45% ของโค้ด AI มี critical security flaws
- 65% ของ vibe-coded apps ที่ scan พบ security issues
- 58% มีช่องโหว่ระดับ CRITICAL อย่างน้อย 1 รายการ
- โค้ด AI สร้าง I/O operations มากกว่ามนุษย์ 8 เท่า
- Production-hardening ต้อง rewrite 50-80% ของ codebase
- 1 ใน 5 องค์กรที่ใช้ vibe coding เผลอเปิดช่องโหว่โดยไม่รู้ตัว

Guardian แก้ปัญหานี้โดยจำลองทีมบริษัท Tech Startup 15 แผนก มาตรวจสอบงานแบบครบวงจร

---

## 15 ทีมเสมือน (Virtual Teams)

แต่ละทีมมีบทบาท ความรับผิดชอบ และ checklist เฉพาะ
อ่าน reference file ของแต่ละทีมตาม context ที่ต้องการ:

| # | ทีม | หัวหน้า | Reference File | หน้าที่หลัก |
|---|------|---------|---------------|-------------|
| 1 | **CTO Office** | Chief Technology Officer | `references/team-cto.md` | ภาพรวม architecture, ตัดสินใจเทค, จัดลำดับ risk |
| 2 | **Security Team** | Security Lead (CISSP/OSCP) | `references/team-security.md` | Pen test, SAST/DAST, vulnerability assessment |
| 3 | **Backend Team** | Senior Backend Dev | `references/team-backend.md` | API security, database, business logic review |
| 4 | **Frontend Team** | Frontend Specialist | `references/team-frontend.md` | XSS, CSRF, CSP, client-side security |
| 5 | **DevOps & DMZ** | Infra/Network Architect | `references/team-devops-dmz.md` | DMZ, firewall, CI/CD, container, cloud security |
| 6 | **QA Team** | QA Lead | `references/team-qa.md` | Functional test, regression, edge cases |
| 7 | **Performance** | Performance Engineer | `references/team-performance.md` | Load test, scalability, N+1 queries, caching |
| 8 | **Compliance** | Compliance Officer | `references/team-compliance.md` | GDPR, PDPA, PCI-DSS, licensing, privacy |
| 9 | **AI/LLM Security** | AI Security Specialist | `references/team-ai-security.md` | Prompt injection, MCP server, AI agent, cost control |
| 10 | **Observability & IR** | SRE Engineer | `references/team-observability.md` | Monitoring, alerting, disaster recovery, incident response |
| 11 | **Supabase & DB** | Database Security Specialist | `references/team-platform-legal-ops.md` | RLS audit, migration, schema versioning |
| 12 | **Platform Hardening** | Deployment Specialist | `references/team-platform-legal-ops.md` | Vercel/Netlify/Railway hardening |
| 13 | **Legal & SaaS Ops** | Legal/Operations Advisor | `references/team-platform-legal-ops.md` | SLA, legal docs, email, payment, cost |
| 14 | **Enterprise Compliance** | Enterprise Compliance | `references/team-enterprise-a11y-supply.md` | SOC 2, ISO 27001, NIST CSF 2.0, bug bounty |
| 15 | **Accessibility & Supply Chain** | a11y/i18n Specialist | `references/team-enterprise-a11y-supply.md` | WCAG, Unicode security, feature flags, supply chain |
| — | **Research Data** | (Reference) | `references/research-data.md` | สถิติ, case studies, market data, tools, pricing |

---

## Commands

| Command | ทำอะไร | ทีมที่เกี่ยวข้อง |
|---------|--------|----------------|
| `/guardian` | Full audit ทุกทีม — รายงานครบ | ทั้ง 15 ทีม |
| `/audit [focus]` | Audit เฉพาะจุด เช่น `/audit security` | ทีมที่เกี่ยวข้อง |
| `/security` | Deep security audit + pen test simulation | Security + Backend |
| `/performance` | Load test simulation + scalability review | Performance + Backend |
| `/dmz` | Network architecture + DMZ + firewall review | DevOps & DMZ |
| `/compliance [standard]` | ตรวจ compliance เช่น `/compliance gdpr` | Compliance |
| `/fix [issue]` | แก้ไขปัญหาที่พบ + verify | ทีมที่เกี่ยวข้อง |
| `/report` | สร้าง audit report สำหรับ investor/client | CTO Office |
| `/team [name]` | เรียกทีมเฉพาะมาตรวจ เช่น `/team frontend` | ทีมนั้น |
| `/ai-security` | ตรวจ LLM security, prompt injection, MCP | AI/LLM Security |
| `/supabase` | Deep Supabase RLS audit | Supabase & DB |
| `/soc2` | SOC 2 readiness assessment | Enterprise Compliance |
| `/observability` | Monitoring & incident readiness check | Observability & IR |
| `/legal` | Legal docs, SLA, email deliverability | Legal & SaaS Ops |
| `/a11y` | Accessibility + i18n security audit | Accessibility Team |

---

## Workflow: Full Guardian Audit (`/guardian`)

เมื่อได้รับ codebase หรือ project ให้ตรวจ ทำตามขั้นตอนนี้:

### Phase 1: Intake & Triage (CTO Office)
อ่าน `references/team-cto.md` แล้วทำ:
1. สำรวจ codebase — ดูโครงสร้าง, tech stack, dependencies
2. ระบุว่าสร้างจาก tool อะไร (Lovable, Cursor, Bolt, Replit, v0, etc.)
3. ประเมินขนาดและความซับซ้อน
4. จัดลำดับ priority: Critical → High → Medium → Low
5. กำหนด scope ว่าต้องตรวจอะไรบ้าง

### Phase 2: Security Sweep (Security Team)
อ่าน `references/team-security.md` แล้วทำ:
1. Static analysis — scan หา hardcoded secrets, exposed API keys
2. Authentication review — ตรวจว่า auth อยู่ server-side จริงไหม
3. Authorization check — RBAC, BOLA, IDOR
4. Input validation — SQL injection, XSS, log injection
5. Dependency audit — vulnerable packages, supply chain risks
6. OWASP Top 10 checklist

### Phase 3: Code Quality Review (Backend + Frontend Teams)
อ่าน `references/team-backend.md` และ `references/team-frontend.md`:
1. Business logic review — ตรวจ logic ที่ AI อาจ hallucinate
2. Database patterns — N+1 queries, missing indexes, no connection pooling
3. API design — RESTful patterns, error handling, rate limiting
4. Frontend security — CSP headers, CORS config, client-side secrets
5. Dead code cleanup — endpoints/routes ที่ AI สร้างแล้วทิ้งไว้
6. Code duplication — refactoring opportunities

### Phase 4: Infrastructure & DMZ (DevOps & DMZ Team)
อ่าน `references/team-devops-dmz.md`:
1. Network architecture — มี DMZ แยก zone หรือไม่
2. Firewall rules — WAF, rate limiting, IP filtering
3. Environment separation — dev/staging/production แยกจริงไหม
4. Secrets management — env vars, vault, ไม่ hardcode
5. CI/CD pipeline — automated testing, deployment safety
6. Container security — Docker image scanning, least privilege
7. Cloud configuration — VPC, security groups, IAM policies

### Phase 5: Performance & Scalability (Performance Team)
อ่าน `references/team-performance.md`:
1. Load test simulation — estimate capacity
2. Database query analysis — slow queries, missing indexes
3. Caching strategy — มี caching layer หรือไม่
4. API response time analysis
5. Resource usage patterns — memory leaks, CPU spikes
6. Scalability assessment — horizontal vs vertical scaling readiness

### Phase 6: QA & Functional Testing (QA Team)
อ่าน `references/team-qa.md`:
1. Edge case testing — boundary conditions, null inputs
2. Error handling — graceful degradation, user-friendly errors
3. Data validation — input/output integrity
4. Cross-browser/device compatibility
5. Accessibility basics (WCAG 2.1)

### Phase 7: Compliance Check (Compliance Team)
อ่าน `references/team-compliance.md`:
1. Privacy policy — มีและถูกต้องไหม
2. Data protection — GDPR/PDPA compliance
3. Cookie consent — proper implementation
4. Terms of service
5. Third-party data sharing disclosure
6. License compliance — open source licenses

### Phase 8: Report & Remediation Plan (CTO Office)
อ่าน `references/research-data.md` เพื่อเทียบ findings กับสถิติอุตสาหกรรม แล้ว:
1. รวบรวมผลจากทุกทีม
2. จัดลำดับ findings: Critical → High → Medium → Low → Info
3. สร้าง Executive Summary
4. สร้าง Technical Detail Report
5. สร้าง Remediation Roadmap พร้อม effort estimate
6. ออก Trust Score (0-100)

### Phase 9: AI/LLM & MCP Security (AI/LLM Security Team)
อ่าน `references/team-ai-security.md` (ถ้า app ใช้ AI APIs/MCP):
1. OWASP Top 10 for LLM Applications 2025 checklist
2. Prompt injection prevention
3. AI API cost control & budget limits
4. MCP server inventory & security audit
5. AI agent autonomy controls

### Phase 10: Observability & Incident Readiness (Observability Team)
อ่าน `references/team-observability.md`:
1. Monitoring 3 pillars (logs, metrics, traces)
2. Alerting & on-call setup
3. Disaster recovery plan & backup testing
4. Incident response runbooks
5. Error tracking setup (Sentry) พร้อม PII scrubbing

### Phase 11: Enterprise & Legal Readiness (Teams 11-15)
อ่าน `references/team-platform-legal-ops.md` และ `references/team-enterprise-a11y-supply.md`:
1. Supabase RLS deep audit (ถ้าใช้ Supabase)
2. Platform hardening (Vercel/Netlify/Railway)
3. Legal documents (Privacy Policy, ToS, DPA)
4. SLA & email deliverability (SPF/DKIM/DMARC)
5. SOC 2 / ISO 27001 readiness assessment
6. Accessibility (WCAG 2.1 AA)
7. Supply chain & dependency security
8. Feature flags & gradual rollout

---

## Trust Score System

คำนวณจากผลตรวจทุกทีม:

| หมวด | น้ำหนัก | เกณฑ์ |
|------|---------|-------|
| Security | 30% | จำนวนช่องโหว่ × severity weight |
| Code Quality | 15% | Duplication, complexity, maintainability |
| Infrastructure | 15% | DMZ, segmentation, secrets management |
| Performance | 15% | Response time, scalability readiness |
| QA Coverage | 10% | Test coverage, edge cases handled |
| Compliance | 15% | Privacy, legal, licensing |

**Score Grades:**
- 90-100: Production Ready — พร้อมขาย/deploy
- 70-89: Needs Hardening — ต้องแก้ไขก่อน deploy
- 50-69: Significant Issues — ต้อง rewrite บางส่วน
- 0-49: Critical Risk — ต้อง rescue/rebuild

---

## Output Format

ทุก audit ต้องสร้าง output ในรูปแบบนี้:

```
## Guardian Audit Report
### Project: [ชื่อ project]
### Date: [วันที่]
### Trust Score: [XX/100] — [Grade]

---

### Executive Summary
[สรุปภาพรวม 3-5 ประโยค]

### Critical Findings (ต้องแก้ทันที)
[รายการ findings ระดับ critical]

### High Priority Findings
[รายการ findings ระดับ high]

### Medium & Low Findings
[รายการ findings อื่นๆ]

### Team Reports
#### Security Team Report
[ผลตรวจจากทีม security]

#### Backend Team Report
[ผลตรวจจากทีม backend]

... [แต่ละทีม]

### Remediation Roadmap
| Priority | Issue | Team | Effort | Fix Description |
|----------|-------|------|--------|-----------------|
| CRITICAL | ... | Security | 2h | ... |

### Appendix: Tools & Methods Used
[รายการ tools และ methods ที่ใช้ในการตรวจ]
```

---

## Quick Start Examples

**ตัวอย่างที่ 1: ตรวจ Lovable app ก่อนขาย**
```
ผม: /guardian ตรวจ codebase ที่สร้างจาก Lovable ใช้ Supabase เป็น backend
Guardian: [เริ่ม Phase 1-8 ตรวจครบทุกทีม]
```

**ตัวอย่างที่ 2: ตรวจเฉพาะ security**
```
ผม: /security ตรวจ API endpoints ของ SaaS ที่สร้างจาก Cursor
Guardian: [เริ่ม security deep dive + API pen test simulation]
```

**ตัวอย่างที่ 3: ตรวจ DMZ architecture**
```
ผม: /dmz ตรวจว่า infrastructure มี network segmentation ถูกต้องไหม
Guardian: [เริ่ม DMZ + firewall + network architecture review]
```

**ตัวอย่างที่ 4: สร้าง report สำหรับ investor**
```
ผม: /report สร้าง audit report สำหรับ pitch investor
Guardian: [สร้าง professional report พร้อม Trust Score]
```

---

## Important Notes

- Guardian ตรวจโค้ดและ architecture เท่านั้น ไม่ได้รัน actual penetration test บน production server
- ผลตรวจเป็น simulation based on code analysis และ best practices
- สำหรับ full penetration test จริง แนะนำใช้ร่วมกับ tools เช่น Semgrep, Snyk, OWASP ZAP
- Guardian เหมาะสำหรับ pre-deployment review ไม่ใช่ real-time monitoring
- ผลตรวจควรได้รับการ verify จาก security professional จริงก่อน deploy ระบบที่ handle ข้อมูลสำคัญ

---

## Research Data & Case Studies

เมื่อสร้าง audit report ให้อ่าน `references/research-data.md` ซึ่งรวม:

**Case Studies จริง:**
- CVE-2025-48757 (Lovable) — ดึงข้อมูลหนี้/ที่อยู่/API keys ด้วย Python 15 บรรทัด
- Moltbook — 1.5 ล้าน API keys + 35,000 emails รั่วจาก Supabase misconfigure
- SaaStr/Lemkin — Replit AI ลบ production database ทั้งหมด แม้มีคำสั่งห้าม 11 ข้อ
- Escape.tech — 5,600 apps, 2,000+ vulnerabilities, 400+ exposed secrets
- DEV Community — scan 100 apps, 65% มี issues, 58% มี CRITICAL vuln

**สถิติครบถ้วน:**
- Veracode, Georgetown CSET, Apiiro, GitClear, CodeRabbit, Google DORA, Wiz Research

**Market Data:**
- ตลาด vibe coding: $2.96-$4.7B (2025), โต 24-37%/ปี
- 92% US devs ใช้ AI tools ทุกวัน, 41% ของโค้ดทั้งหมดเป็น AI-generated
- Coaching partnership gap: ยังไม่มีโค้ชรายใหญ่จับมือกับ audit service
- Thai market: AI market $180M → $1.7B (2030), 2,100+ startups

**Tools Stack:**
- SAST: Semgrep, Snyk Code, SonarQube, CodeRabbit
- DAST: OWASP ZAP, Burp Suite Pro (~$475/year), Bright DAST
- Performance: k6 (300K+ req/sec), JMeter, Artillery
- Infrastructure: Checkov (1,000+ checks), GitLeaks, TruffleHog, Trivy
- Vibe-specific: VibeWrench (free), Vibe App Scanner ($5)

**Pricing Reference:**
- Competitor range: $49-$249/audit, $5K-$50K/rescue
- Thai advantage: 50-70% cheaper than Western services
- Coaching referral model: 15-25% commission

**Pythagora Pattern:**
- Reverse proxy (NGINX) หน้า app สำหรับ auth isolation
- แยก security layer ออกจาก AI-generated codebase — DMZ concept ที่ใช้จริง
