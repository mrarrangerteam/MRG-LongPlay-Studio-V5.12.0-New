# Code Review Graph — มหาเทพ Code Review System

> Semantic Knowledge Graph + AI-Powered Review + Blast Radius Analysis
> Inspired by: Greptile, CodeRabbit, Qodo, obra/superpowers, Trail of Bits
> Replaces: review-pr, review-delta, build-graph (3 skills → 1 reference)

---

## QUICK COMMANDS

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/review-pr [PR#]` | รีวิว PR ด้วย knowledge graph | Structured review + blast radius |
| `/review-delta` | รีวิวเฉพาะ changes ล่าสุด | Token-efficient delta review |
| `/build-graph [full]` | สร้าง/อัพเดต knowledge graph | Graph stats + node count |
| `/blast [file/func]` | วิเคราะห์ blast radius | Impact map + risk score |
| `/security-review` | Security-focused review | OWASP + vulnerability scan |
| `/review-arch` | Architecture review | Dependency analysis + design patterns |
| `/review-perf` | Performance review | N+1, memory leaks, bottlenecks |
| `/review-test` | Test coverage review | Missing tests + coverage gaps |

---

## 1. KNOWLEDGE GRAPH SYSTEM

### 1.1 Graph Architecture (Greptile-Inspired)

```
Knowledge Graph Structure:
├── Nodes (Code Entities)
│   ├── Files — source code files with metadata
│   ├── Functions/Methods — with signatures, complexity, LOC
│   ├── Classes/Structs — with inheritance hierarchy
│   ├── Variables/Constants — with type information
│   ├── Modules/Packages — with dependency graph
│   └── Tests — mapped to what they test
│
├── Edges (Relationships)
│   ├── calls → (function calls function)
│   ├── imports → (file imports file)
│   ├── inherits → (class extends class)
│   ├── implements → (class implements interface)
│   ├── tests → (test covers function)
│   ├── depends_on → (module depends on module)
│   ├── modifies → (function writes to variable)
│   └── type_of → (variable is type of class)
│
└── Metadata
    ├── Last modified timestamp
    ├── Git blame (who wrote what)
    ├── Complexity scores (cyclomatic, cognitive)
    ├── Change frequency (hotspot detection)
    └── Test coverage percentage
```

### 1.2 Building the Graph

```
Step 1: Initialize — call build_or_update_graph_tool(full_rebuild=True)
  - First time: full parse of entire codebase
  - Subsequent: incremental update (only changed files)

Step 2: Verify — call list_graph_stats_tool()
  - Check node count, edge count, languages detected
  - Confirm no parsing errors

Step 3: Query — use query_graph_tool() with patterns:
  - "callers_of" → who calls this function
  - "callees_of" → what does this function call
  - "tests_for" → which tests cover this
  - "dependents_of" → what depends on this module
  - "inheritance_tree" → class hierarchy
  - "imports_of" → file dependency chain

Supported Languages:
Python, TypeScript/JavaScript, Go, Rust, Java, C#, Ruby,
Kotlin, Swift, PHP, C/C++ (11 languages)

Storage: .code-review-graph/graph.db (SQLite in repo root)
Auto-update: via hooks on edit/commit (incremental)
```

### 1.3 Advanced Graph Queries

```python
# Hotspot Detection — files that change most frequently
def find_hotspots(graph, top_n=10):
    """Find code hotspots: frequently changed + high complexity"""
    nodes = graph.query("files ORDER BY change_frequency DESC")
    return [
        {
            "file": n.path,
            "changes_30d": n.change_frequency,
            "complexity": n.avg_complexity,
            "risk_score": n.change_frequency * n.avg_complexity,
            "last_author": n.last_blame_author,
            "test_coverage": n.test_coverage_pct
        }
        for n in nodes[:top_n]
    ]

# Dependency Depth — how deep is the import chain
def dependency_depth(graph, file_path):
    """Calculate transitive dependency depth"""
    visited = set()
    def dfs(path, depth):
        if path in visited:
            return depth
        visited.add(path)
        deps = graph.query(f"imports_of:{path}")
        return max((dfs(d.path, depth+1) for d in deps), default=depth)
    return dfs(file_path, 0)

# Orphan Detection — code with no callers
def find_orphans(graph):
    """Find functions/classes with zero callers (dead code candidates)"""
    all_funcs = graph.query("functions")
    return [f for f in all_funcs if len(graph.query(f"callers_of:{f.id}")) == 0
            and not f.is_entry_point and not f.is_test]
```

---

## 2. PR REVIEW SYSTEM (Full Review)

### 2.1 Four-Phase Review Process

```
PHASE 1: SCOPE UNDERSTANDING (What changed and why?)
├── Read PR title, description, linked issues
├── Get changed files list: git diff main...<branch>
├── Categorize changes: feature / bugfix / refactor / config / docs
├── Identify scale: Small (<50 lines) / Medium / Large (>500 lines)
└── Flag: Large PRs should ideally be split

PHASE 2: GRAPH-POWERED CONTEXT (Who's affected?)
├── Update graph: build_or_update_graph_tool(base="main")
├── Get review context: get_review_context_tool(base="main")
├── Get blast radius: get_impact_radius_tool(base="main")
├── For each high-impact function:
│   ├── query_graph_tool(pattern="callers_of", target=<func>)
│   ├── query_graph_tool(pattern="tests_for", target=<func>)
│   └── Check if public API changed (breaking change?)
└── Map: changed_files → impacted_files → risk_level

PHASE 3: DEEP REVIEW (Line-by-line with context)
├── For each changed file (ordered by risk: highest first):
│   ├── Read full source (not just diff)
│   ├── Check: correctness, edge cases, error handling
│   ├── Check: security (injection, auth, data exposure)
│   ├── Check: performance (N+1, memory, complexity)
│   ├── Check: style & consistency with codebase
│   ├── Check: naming (clear, descriptive, consistent)
│   └── Check: test coverage for changed functions
├── Cross-file analysis:
│   ├── Interface contracts preserved?
│   ├── Error propagation correct?
│   └── State mutations safe across boundaries?
└── Use semantic_search_nodes_tool for related code PR might've missed

PHASE 4: STRUCTURED OUTPUT (Clear, actionable feedback)
├── Summary (1-3 sentences)
├── Risk assessment (Low/Medium/High/Critical)
├── File-by-file findings with severity labels
├── Missing tests report
├── Architecture concerns
└── Actionable recommendations
```

### 2.2 Severity Classification System

```
Every finding MUST be labeled with one of these severities:

🔴 BLOCKING — Must fix before merge
   Examples: security vulnerability, data loss risk, crash bug,
   breaking public API without migration, missing auth check

🟠 IMPORTANT — Should fix, PR can wait
   Examples: race condition risk, missing error handling,
   performance regression, incomplete validation

🟡 NIT — Minor improvement, don't block on this
   Examples: naming suggestion, style inconsistency,
   comment improvement, import ordering

💡 SUGGESTION — Optional enhancement idea
   Examples: refactoring opportunity, design pattern,
   library alternative, future consideration

📚 LEARNING — Educational note for the author
   Examples: language idiom, framework best practice,
   security pattern explanation

👏 PRAISE — Acknowledge good work
   Examples: clean abstraction, thorough error handling,
   excellent test coverage, good naming
```

### 2.3 Output Template

```markdown
## PR Review: <title>

### Summary
<1-3 sentence overview of what this PR does>

### Risk Assessment
- **Overall risk**: Low / Medium / High / Critical
- **Blast radius**: X files directly changed, Y files indirectly impacted
- **Test coverage**: N changed functions covered / M total
- **Breaking changes**: Yes/No (if yes, detail what breaks)

### Findings

#### <file_path> (Risk: High/Medium/Low)
- 🔴 **BLOCKING** [Line XX]: <description>
  ```suggestion
  // suggested fix
  ```
- 🟠 **IMPORTANT** [Line YY]: <description>
- 👏 **PRAISE**: Clean separation of concerns

#### <file_path_2> (Risk: Low)
- 🟡 **NIT** [Line ZZ]: <description>

### Blast Radius Analysis
| Impacted File | Relationship | Risk |
|---------------|-------------|------|
| `src/api/handler.py` | calls `modified_func()` | Medium |
| `tests/test_api.py` | tests `modified_func()` | Update needed |

### Missing Tests
- `new_function()` in `src/service.py` — no test coverage found
- `error_path` in `src/handler.py` — error case not tested

### Architecture Concerns
<any architectural issues or improvement suggestions>

### Recommendations
1. <actionable suggestion with specific file/line>
2. <actionable suggestion>
```

---

## 3. DELTA REVIEW (Token-Efficient)

### 3.1 When to Use Delta vs Full Review

```
Use DELTA review when:
- Quick check on recent changes (last commit only)
- Working in iterative development (frequent small changes)
- Token budget is limited
- Focus on specific file or function

Use FULL review when:
- PR ready for merge (complete review needed)
- Major refactoring
- Security-sensitive changes
- New developer's code
```

### 3.2 Delta Review Process

```
Step 1: Update graph — build_or_update_graph_tool() [incremental]
Step 2: Get delta context — get_review_context_tool() [auto-detects git diff]
Step 3: Analyze blast radius from impacted_nodes and impacted_files
Step 4: Focus review on:
  - Functions whose callers changed (signature/behavior risk)
  - Classes with inheritance changes (Liskov concerns)
  - Files with many dependents (high-risk)
Step 5: Verify tests — query_graph_tool(pattern="tests_for", target=<func>)
Step 6: Output compact report

Advantages over full review:
- 5-10x fewer tokens (only changed + impacted code)
- Auto-identifies blast radius without manual file searching
- Flags untested functions automatically
- Shows structural context (callers, inheritance chains)
```

---

## 4. BLAST RADIUS ANALYSIS

### 4.1 Multi-Hop Impact Detection

```
Blast radius = all code that could be affected by a change.

Level 0: The changed code itself
Level 1: Direct callers/importers of changed code (1-hop)
Level 2: Callers of callers (2-hop) — often where bugs manifest
Level 3+: Transitive dependents (deep impact, rare but critical)

Risk scoring:
- Each node gets: risk = (dependency_count × change_severity) / test_coverage
- High risk: widely depended upon + no tests + breaking change
- Medium risk: some dependents + partial tests
- Low risk: few dependents + well tested

Visualization:
changed_func() [MODIFIED]
  ├── caller_a() [IMPACTED - 1 hop] → has tests ✅
  ├── caller_b() [IMPACTED - 1 hop] → NO tests ⚠️
  │   └── caller_b_parent() [IMPACTED - 2 hop] → has tests ✅
  └── test_changed_func() [TEST - needs update]
```

### 4.2 Breaking Change Detection

```python
# Patterns that indicate breaking changes:
BREAKING_PATTERNS = [
    "function_signature_changed",    # Parameters added/removed/reordered
    "return_type_changed",           # Return type modified
    "exception_type_changed",        # Different exceptions thrown
    "public_api_removed",            # Public function/class deleted
    "enum_value_removed",            # Enum option removed
    "config_key_renamed",            # Configuration key changed
    "database_schema_changed",       # Migration needed
    "proto_field_removed",           # Protobuf breaking change
    "http_endpoint_changed",         # REST API path/method changed
    "event_payload_changed",         # Event schema modified
]

# Auto-detect:
def detect_breaking_changes(diff, graph):
    """Analyze diff against graph to find breaking changes"""
    breakages = []
    for changed_func in diff.changed_functions:
        old_sig = graph.get_signature(changed_func, version="before")
        new_sig = graph.get_signature(changed_func, version="after")

        if old_sig != new_sig:
            callers = graph.query(f"callers_of:{changed_func}")
            if len(callers) > 0:
                breakages.append({
                    "function": changed_func,
                    "type": "signature_change",
                    "callers_affected": len(callers),
                    "severity": "BLOCKING" if len(callers) > 5 else "IMPORTANT"
                })
    return breakages
```

---

## 5. SECURITY REVIEW MODULE

### 5.1 OWASP Top 10 (2025) Checklist

```
For each changed file, check:

A01 — Broken Access Control
  □ Authentication required for sensitive endpoints?
  □ Authorization checks at every layer?
  □ IDOR vulnerabilities (direct object reference)?
  □ CORS properly configured?

A02 — Cryptographic Failures
  □ No hardcoded secrets/API keys?
  □ Encryption at rest and in transit?
  □ Secure hash algorithms (bcrypt, argon2, not MD5/SHA1)?
  □ Proper key management?

A03 — Injection
  □ SQL queries parameterized (no string concatenation)?
  □ Command injection prevented (no shell=True with user input)?
  □ XSS sanitized (output encoding)?
  □ Template injection mitigated?

A04 — Insecure Design
  □ Rate limiting on sensitive endpoints?
  □ Input validation (whitelist, not blacklist)?
  □ Fail-safe defaults (deny by default)?

A05 — Security Misconfiguration
  □ Debug mode disabled in production?
  □ Default credentials removed?
  □ Error messages don't leak stack traces?
  □ Security headers set (CSP, HSTS, X-Frame)?

A06 — Vulnerable Components
  □ Dependencies up to date?
  □ Known CVEs in dependency tree?
  □ Minimal dependency footprint?

A07 — Authentication Failures
  □ Brute force protection?
  □ Session management secure?
  □ Password policy enforced?
  □ MFA available for sensitive operations?

A08 — Data Integrity Failures
  □ CI/CD pipeline secured?
  □ Dependency integrity verified (lock files)?
  □ Auto-update sources trusted?

A09 — Logging & Monitoring
  □ Security events logged?
  □ No sensitive data in logs?
  □ Audit trail for critical operations?

A10 — SSRF (Server-Side Request Forgery)
  □ URL validation on user-provided URLs?
  □ Internal network access restricted?
  □ DNS rebinding mitigated?
```

### 5.2 AI/LLM-Specific Security (2026)

```
For code using AI/LLM:

□ Prompt injection prevention (user input sanitized before LLM)
□ System prompt not exposed to user
□ LLM output sanitized before use in code/SQL/commands
□ Rate limiting on AI API calls (cost control)
□ PII not sent to external AI APIs without consent
□ AI responses validated before acting on them
□ MCP server permissions scoped (least privilege)
□ Agent actions reversible (no irreversible operations without confirmation)
```

---

## 6. PERFORMANCE REVIEW MODULE

### 6.1 Performance Checklist

```
Database:
□ N+1 query detection (loop with queries inside)
□ Missing indexes on filtered/joined columns
□ Unbounded queries (no LIMIT)
□ Large transaction blocks (should be smaller)
□ Connection pooling configured

Memory:
□ Large objects properly garbage collected
□ Streams used for large data (not loading all into memory)
□ Circular references avoided
□ Cache with TTL (not unbounded growth)

Concurrency:
□ Race conditions prevented (locks, atomic operations)
□ Deadlock risk assessed
□ Thread/goroutine leaks prevented
□ Connection limits respected

API:
□ Pagination implemented for list endpoints
□ Response size bounded
□ Timeout configured for external calls
□ Retry with backoff (not retry storm)
□ Caching headers set (ETags, Cache-Control)

Frontend:
□ Bundle size impact checked
□ Lazy loading for heavy components
□ Image optimization
□ No layout thrashing in DOM manipulation
```

---

## 7. TEST COVERAGE ANALYSIS

### 7.1 Test Gap Detection

```python
def analyze_test_gaps(graph, changed_files):
    """Find functions that changed but have no tests"""
    gaps = []

    for file in changed_files:
        functions = graph.query(f"functions_in:{file}")
        for func in functions:
            tests = graph.query(f"tests_for:{func.id}")
            if not tests:
                complexity = func.cyclomatic_complexity
                callers = len(graph.query(f"callers_of:{func.id}"))
                gaps.append({
                    "function": func.name,
                    "file": file,
                    "complexity": complexity,
                    "callers": callers,
                    "priority": "HIGH" if complexity > 5 or callers > 3 else "MEDIUM",
                    "suggestion": generate_test_suggestion(func)
                })

    return sorted(gaps, key=lambda g: g["priority"] == "HIGH", reverse=True)

def generate_test_suggestion(func):
    """Generate a test skeleton for the function"""
    return f"""
def test_{func.name}():
    # Test happy path
    result = {func.name}({func.example_args})
    assert result == expected_value

    # Test edge cases
    # TODO: Test with empty input
    # TODO: Test with invalid input
    # TODO: Test error handling
"""
```

### 7.2 Test Quality Assessment

```
Beyond coverage percentage, assess:

1. Test Isolation — each test independent? No shared mutable state?
2. Assertion Quality — meaningful assertions? Not just "no error"?
3. Edge Cases — boundary values, empty inputs, null, overflow?
4. Error Paths — exceptions, timeouts, network failures tested?
5. Integration Points — API contracts, database interactions, external services?
6. Regression Value — would this test catch the bug if it re-appeared?
```

---

## 8. ARCHITECTURE REVIEW

### 8.1 Design Pattern Detection

```
The graph can detect common patterns and anti-patterns:

Good Patterns (praise):
✅ Single Responsibility — class/module has one clear purpose
✅ Dependency Injection — dependencies passed in, not created
✅ Interface Segregation — small, focused interfaces
✅ Repository Pattern — data access abstracted
✅ Event-driven — loose coupling via events

Anti-Patterns (flag):
⚠️ God Object — class with 20+ methods or 500+ lines
⚠️ Circular Dependencies — A imports B imports A
⚠️ Shotgun Surgery — one change requires modifying 10+ files
⚠️ Feature Envy — method uses more of another class's data
⚠️ Deep Nesting — 4+ levels of if/for/while nesting
```

### 8.2 Dependency Health

```python
def assess_dependency_health(graph):
    """Assess overall dependency structure health"""
    metrics = {
        "circular_deps": find_circular_dependencies(graph),
        "max_depth": max_dependency_depth(graph),
        "orphan_modules": find_orphan_modules(graph),
        "coupling_score": calculate_coupling(graph),  # Lower = better
        "cohesion_score": calculate_cohesion(graph),   # Higher = better
        "instability_index": calculate_instability(graph),  # 0-1, lower = more stable
    }

    health = "HEALTHY" if (
        len(metrics["circular_deps"]) == 0 and
        metrics["max_depth"] < 8 and
        metrics["coupling_score"] < 0.5 and
        metrics["cohesion_score"] > 0.6
    ) else "NEEDS ATTENTION" if (
        len(metrics["circular_deps"]) < 3 and
        metrics["max_depth"] < 12
    ) else "CRITICAL"

    return {"health": health, **metrics}
```

---

## 9. CI/CD INTEGRATION

### 9.1 GitHub Actions Integration

```yaml
# .github/workflows/ai-review.yml
name: AI Code Review
on:
  pull_request:
    types: [opened, synchronize]

jobs:
  review:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: write
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0  # Full history for graph

      - name: Build Knowledge Graph
        run: |
          # Build/update the code graph
          claude -p "Run /build-graph full"

      - name: AI Review
        run: |
          # Run the review
          claude -p "Run /review-pr ${{ github.event.pull_request.number }}"

      - name: Security Review
        run: |
          claude -p "Run /security-review"
```

### 9.2 Pre-commit Hook

```bash
#!/bin/bash
# .git/hooks/pre-commit — auto-update graph on commit

# Update graph incrementally
claude -p "Run /build-graph" --quiet 2>/dev/null &

# Run quick security check on staged files
STAGED=$(git diff --cached --name-only)
if [ -n "$STAGED" ]; then
    claude -p "Quick security check on: $STAGED" --quiet
fi
```

---

## 10. REVIEW WORKFLOW PATTERNS

### 10.1 The Obra/Superpowers Pattern

```
Complete SDLC workflow with code review integrated:

1. Issue → Plan → Implement → Open PR
2. /build-graph — ensure graph is current
3. /review-pr — full AI review with graph context
4. Fix findings (iterate on BLOCKING items)
5. /review-delta — re-check only the fixes
6. Human approval — final sign-off
7. Merge → Deploy

Key principle: "Review early, review often"
Don't wait for the full PR — review as you build.
```

### 10.2 Review Checklist by Change Type

```
Feature Addition:
□ Tests added for all new functions
□ Documentation updated
□ No breaking changes to existing API
□ Error handling for all edge cases
□ Logging for observability
□ Feature flag if needed

Bug Fix:
□ Root cause identified (not just symptom fix)
□ Regression test added (prevents re-occurrence)
□ Related code checked for similar bugs
□ Blast radius verified (fix doesn't break elsewhere)

Refactoring:
□ Behavior unchanged (functional equivalence)
□ All existing tests pass
□ Performance not regressed
□ No accidental API changes

Dependency Update:
□ Changelog reviewed for breaking changes
□ Lock file updated
□ Known CVEs checked
□ Integration tests pass
□ Bundle size impact acceptable

Config/Infrastructure:
□ Secrets not hardcoded
□ Environment-specific values externalized
□ Rollback plan exists
□ No sensitive data exposed in logs/configs
```

---

## 11. MULTI-REPO SUPPORT

### 11.1 Cross-Repository Impact

```
For monorepos or microservice architectures:

1. Build graph for each repo/service
2. Map inter-service dependencies:
   - API contracts (OpenAPI/Proto)
   - Shared libraries
   - Event schemas
   - Database migrations

3. Cross-repo blast radius:
   - Service A API change → check all consumers
   - Shared lib change → rebuild all dependents
   - Schema change → verify all services compatible
   - Proto change → regenerate clients

4. Review includes:
   - Contract compatibility verification
   - Downstream service impact assessment
   - Migration/rollout strategy evaluation
```

---

## RESPONSE FORMATS

### When user asks /review-pr
Use the full template from Section 2.3 above.

### When user asks /review-delta
```
## Delta Review — [date/commit hash]

### Changes
<list of changed files>

### Risk Level: Low / Medium / High
### Blast Radius: X files impacted

### Findings
- [severity] [file:line]: <description>

### Tests Status
- ✅ Covered: <list>
- ⚠️ Missing: <list>
```

### When user asks /blast [target]
```
## Blast Radius: <target>

### Direct Impact (1-hop)
| Caller | File | Has Tests |
|--------|------|-----------|
| func_a | src/a.py | ✅ |
| func_b | src/b.py | ⚠️ No |

### Indirect Impact (2-hop)
| Node | Hops | Risk |
|------|------|------|
| module_x | 2 | Medium |

### Risk Score: X/10
### Recommendation: <action>
```

### When user asks /security-review
Use OWASP checklist from Section 5 as structured output.

---

## DISCLAIMER

```
⚠️ AI code review is a complement, not a replacement for human review.
- AI may miss domain-specific bugs that require business context
- Security findings should be verified by security professionals
- Performance suggestions should be benchmarked in real environments
- Always have a human reviewer approve before merging critical changes
```
