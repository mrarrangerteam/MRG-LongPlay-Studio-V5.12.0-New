# Team 11: Supabase & Database Security Specialist

## บทบาท
Database Security Specialist — เชี่ยวชาญ Supabase RLS, database migration, schema versioning

## ทำไมทีมนี้สำคัญ
- Supabase คือ default backend ของ Lovable, Bolt, และ Cursor projects
- CVE-2025-48757 expose 170+ Lovable apps (CVSS 8.26)
- Supabase tables ใหม่มี RLS disabled by default
- ใครก็ได้ที่มี anon_key (ดูได้จาก DevTools) สามารถ dump database ทั้งหมด

## Supabase RLS Audit Checklist

### 1. Table-Level RLS
- ทุก table ที่มี user data ต้องเปิด RLS: `ALTER TABLE ... ENABLE ROW LEVEL SECURITY;`
- ตรวจทุก table: `SELECT tablename, rowsecurity FROM pg_tables WHERE schemaname = 'public';`
- Force RLS สำหรับ table owner: `ALTER TABLE ... FORCE ROW LEVEL SECURITY;`

### 2. Policy Review
- ไม่มี policy ที่ `USING (true)` สำหรับ SELECT/UPDATE/DELETE
- Multiple permissive policies รวมกันด้วย OR — อาจเปิดกว้างเกินไป
- ใช้ `auth.uid()` ไม่ใช่ `user_metadata` (user แก้ metadata ได้เอง)

### 3. Views & Functions
- Views bypass RLS by default → ต้อง set `security_invoker = true`
- Functions ที่ `SECURITY DEFINER` bypass RLS → ใช้ `SECURITY INVOKER` แทน
- RPC functions ต้องมี auth check

### 4. Key Management
- anon_key ใน frontend = OK (ออกแบบมาให้ public)
- service_role key ใน frontend = CRITICAL (ต้องอยู่ server-side เท่านั้น)
- ตรวจ JS bundles สำหรับ service_role key pattern

### 5. Migration & Schema Versioning
- Schema changes อยู่ใน version-controlled migration files
- ทุก migration มี rollback path
- Zero-downtime patterns (expand-contract) สำหรับ production
- Data integrity validation หลัง migration

### Tools
- SupaShield CLI: `supashield audit`, `supashield lint`, `supashield coverage`
- SupaSec (safe exploit testing with auto rollback)
- Vibe App Scanner (150+ secret patterns + Supabase misconfig)

---

# Team 12: Platform Hardening Team

## บทบาท
Deployment Platform Specialist — hardening Vercel, Netlify, Railway, cloud platforms

## Checklist

### Vercel
- Deployment Protection enabled (preview URLs ไม่ public)
- Environment variables แยกตาม Development/Preview/Production
- NEXT_PUBLIC_ prefix ไม่ใช้สำหรับ secrets
- WAF active พร้อม custom rules
- Log Drains configured
- CSP headers set
- Vercel Production Checklist ผ่านครบ

### Netlify
- Secrets Controller enabled (scan code + build output)
- Deploy previews restricted
- Environment variables per context
- Build hooks secured

### Railway
- Always-on services (no cold start)
- Private networking enabled
- Environment variables secured
- Volume backups configured

### General Platform Checks
- Custom domain with SSL (ไม่ใช่ .vercel.app / .netlify.app ใน production)
- DNS configured correctly (A/CNAME records)
- CDN caching headers set
- Edge functions มี auth

---

# Team 13: Legal & SaaS Operations Team

## บทบาท
Legal/Operations Advisor — SLA, legal documents, email deliverability, payment security

## ทำไมทีมนี้สำคัญ
- Vibe-coded apps แทบไม่เคย ship พร้อม legal documents
- Gmail เริ่ม reject emails ที่ไม่มี SPF/DKIM/DMARC ตั้งแต่ พ.ย. 2025
- Payment fraud กรณี vibe-coded gateway ทำให้เสียหาย $2M (มี.ค. 2025)

## Checklist

### 1. Legal Documents
- Privacy Policy (ตาม GDPR/PDPA)
- Terms of Service
- Cookie Policy + Consent Banner (opt-in)
- Data Processing Agreement (DPA) สำหรับ B2B
- Acceptable Use Policy
- Refund Policy (ถ้ามี payment)

### 2. SLA Infrastructure
- SLI monitoring + real-time dashboards
- Internal SLO เข้มกว่า external SLA (99.95% ถ้า SLA 99.9%)
- Severity classification (Sev1-3) + response times
- Public status page (auto-update จาก monitoring)

### 3. Email Deliverability (บังคับตั้งแต่ 2025)
- SPF record published
- DKIM (2048-bit key) configured
- DMARC record published (เริ่ม p=none → p=quarantine → p=reject)
- One-click unsubscribe headers
- Transactional vs marketing แยก IP
- Spam rate < 0.1%

### 4. Payment Security (Beyond PCI-DSS)
- Webhook HMAC-SHA256 signature validation
- Idempotency keys on all payment requests
- Server-side price validation (never trust client amounts)
- 3D Secure for applicable transactions
- Refund/chargeback handling procedures

### 5. Cloud Cost Management
- Cost dashboards per team/feature
- AI API usage monitoring per-feature + cost alerts
- Non-production environments shutdown outside business hours (65-75% savings)
- Right-sizing analysis (no instances below 20% avg CPU)

### 6. Documentation Standards
- OpenAPI 3.1 specs for all APIs
- Architecture Decision Records (ADRs)
- AI context files (.cursorrules, CLAUDE.md) in version control
- Local dev setup < 30 minutes
- Onboarding guide for new developers
