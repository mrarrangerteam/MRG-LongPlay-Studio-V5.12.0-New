---
name: mrarranger-hr-team
description: "MRARRANGER HR and Team Management - Hiring Pipeline (Job Description, Screening, Interview, Offer Letter), Onboarding (30-60-90 Day Plan, Training), Performance Review (OKR, KPI, 360 Feedback), Team Building (Culture, Values, Remote Team), Employee Handbook, Compensation and Benefits, Offboarding, Conflict Resolution, Leadership Development, Organizational Design. Commands: /hire /onboard /review /okr /team /handbook /compensation /offboard /leadership /orgdesign. Triggers: hiring, onboarding, HR, performance review, OKR, team building, employee handbook, leadership"
---

# HR & Talent Management Skill

## Overview

This skill provides comprehensive HR and talent management guidance covering the entire employee lifecycle from recruitment through offboarding. It includes frameworks for building high-performing teams, managing compensation, and fostering strong company culture.

## Core Competencies

### 1. Recruitment & Hiring Pipeline

**Job Description Creation**

**Components of Effective JD**:
- Job title and reporting line
- Department and location
- Summary (2-3 sentences)
- Key responsibilities (5-8 bullet points)
- Required qualifications
- Preferred qualifications
- Compensation range (increasingly expected)
- Benefits overview
- Company culture/mission alignment

**Writing Best Practices**:
- Use clear, jargon-free language
- Include specific, measurable responsibilities
- Make skill requirements realistic (80/20 rule)
- Avoid overuse of superlatives
- Include diversity and inclusion statement
- Ensure ADA compliance

**Screening Process**

**Resume Screening Criteria**:
- Experience level and relevant background
- Skills match (must-haves vs nice-to-haves)
- Career progression and gaps
- Geographic considerations
- Salary expectations alignment

**Phone Screen Template**:
- Introduction and role overview (5 min)
- Career history summary (5 min)
- Role-specific technical questions (10 min)
- Compensation and logistics (5 min)
- Candidate questions (5 min)

**Screening Red Flags**:
- Unexplained employment gaps (probe respectfully)
- Frequent job changes without progression
- Unclear answers about past responsibilities
- Misalignment with stated requirements
- Concerns about past performance issues

**Interview Questions & Structure**

**Behavioral Interview Framework** (STAR method):
- Situation: Set the scene
- Task: Define the challenge
- Action: What they did
- Result: Outcomes and learnings

**Sample Behavioral Questions**:
- "Tell me about a time you led a challenging project"
- "Describe a situation where you handled conflict with a colleague"
- "Share an example of failure and what you learned"
- "Tell me about a time you had to adapt quickly"
- "Describe how you prioritize when overwhelmed"

**Technical Interview**:
- Relevant technical skills assessment
- Problem-solving approach evaluation
- Communication of technical concepts
- Depth of expertise verification
- Industry-specific tools/frameworks

**Culture Fit Assessment**:
- Alignment with company values
- Working style compatibility
- Team dynamics fit
- Communication style
- Growth mindset indicators

**Interview Panel Structure**:
- Hiring Manager (1 interview)
- Peer/Team Member (1-2 interviews)
- Cross-functional Stakeholder (optional)
- Final Interview with Senior Leader

**Offer Letter Development**

**Essential Components**:
- Job title and reporting relationship
- Start date
- Compensation (base salary or hourly rate)
- Bonus/commission structure (if applicable)
- Benefits effective date
- Signing bonus or relocation assistance
- Stock options/equity (if applicable)
- At-will employment clause
- Contingency conditions (background check, reference check)
- Offer expiration date (typically 5 business days)

**Offer Negotiation Strategy**:
- Prepare acceptable ranges before offering
- Document request rationale
- Consider non-monetary benefits
- Maintain professional relationship
- Set clear deadline for decision
- Get executive approval for significant deviations

### 2. Onboarding & Integration

**30-60-90 Day Plan**

**Days 1-30: Orientation & Foundations**
- Pre-arrival: Send welcome materials, IT setup, office access
- Day 1: Welcome, office tour, team introductions, IT setup completion
- Week 1: Company overview, core systems training, team meetings, direct report meetings
- Week 2-4: Role-specific training, shadowing, key stakeholder meetings, initial projects
- Metrics: System access complete, policies acknowledged, first deliverable started

**Days 30-60: Integration & Contribution**
- Increased project responsibility
- Cross-functional collaboration
- Feedback check-in with manager
- Relationship building beyond immediate team
- Early quick wins and contributions
- Mid-point performance conversation

**Days 60-90: Productivity & Independence**
- Full project ownership
- Team contribution demonstrated
- Extended network established
- Competency in core responsibilities
- 90-day formal review and feedback
- Retention discussion and career path alignment

**Onboarding Checklist**
- Pre-arrival:
  - HR paperwork prepared
  - IT equipment ordered
  - Office/desk setup
  - Welcome email sent
  - Manager briefing complete

- Day 1:
  - Welcome meeting with HR and manager
  - Office tour and access cards
  - IT setup and password reset
  - Benefits overview
  - Company handbook acknowledgment

- Week 1:
  - Role and team introductions
  - System access validation
  - Company culture overview
  - Compliance training
  - Direct report meetings scheduled

- Ongoing:
  - Weekly check-ins with manager
  - Bi-weekly team meetings
  - Monthly feedback sessions
  - 30/60/90-day reviews

**Training Program Structure**

**Components**:
1. **Compliance Training** (required, documented)
   - Anti-harassment and discrimination
   - Data security and confidentiality
   - Acceptable use policy
   - Health and safety
   - Regulatory requirements (varies by industry)

2. **Product/Service Training**
   - Customer journey understanding
   - Product features and roadmap
   - Competitive landscape
   - Market positioning

3. **Systems Training**
   - CRM, financial, HR systems
   - Communication tools
   - Project management systems
   - Security protocols

4. **Role-Specific Training**
   - Technical deep dives
   - Workflow and processes
   - Key stakeholder mapping
   - Success metrics and expectations

**Training Delivery**:
- New hire orientation (group or individual)
- Manager-led role training
- Peer mentoring/buddy system
- Online modules for compliance
- Documentation and resources library
- Certification programs (where applicable)

### 3. Performance Management & Review

**OKR (Objectives and Key Results) Framework**

**Definition**:
- Objectives: What you want to achieve (qualitative, inspirational)
- Key Results: How you measure success (quantitative, measurable)

**OKR Structure** (quarterly or annual):
- 3-5 Objectives per person
- 2-3 Key Results per Objective
- Ambitious but achievable (60-70% completion is good)

**OKR Cycle**:
1. Planning (top-down and bottom-up input)
2. Alignment (cascade and connect to broader goals)
3. Execution (weekly progress updates)
4. Check-in (mid-cycle reviews at 6-8 weeks)
5. Assessment (final scoring and learnings)

**Sample OKR**:
- **Objective**: Improve customer onboarding experience
- **Key Results**:
  - Reduce time to first value from 30 to 7 days
  - Achieve 90% new customer satisfaction score
  - Complete 5 customer success playbooks

**KPI (Key Performance Indicator) Tracking**

**Types of KPIs**:
- **Output KPIs**: Tasks completed, deliverables shipped
- **Quality KPIs**: Defect rate, customer satisfaction
- **Efficiency KPIs**: Time to completion, cost per unit
- **Behavioral KPIs**: Response time, collaboration quality

**KPI Dashboard Management**:
- Real-time visibility
- Monthly trend analysis
- Outlier investigation
- Regular discussion in 1-on-1s
- Quarterly review and adjustment

**360-Degree Feedback**

**Process**:
1. Select 5-8 reviewers (manager, peers, direct reports, cross-functional)
2. Anonymous feedback collection (online survey or interviews)
3. Structured questions (behavior, collaboration, impact)
4. Synthesis of feedback by HR/executive coach
5. Confidential feedback delivery (often coach-facilitated)
6. Development plan creation based on insights

**Feedback Framework**:
- What's working well/strengths
- Areas for development/improvement
- Specific examples and impact
- Recommendations for growth

**Performance Review Cycle**

**Bi-Annual or Annual Reviews**:

**Pre-Review**:
- Employee self-assessment
- Manager preparation (gather feedback, document examples)
- Collect data (OKRs, KPIs, 360 feedback)
- Calibration with peers/leadership

**Review Meeting**:
- Recognition of achievements (specific examples)
- Discussion of development areas
- Feedback from 360 review (if applicable)
- Alignment with company and role expectations
- Career development discussion
- Compensation adjustment discussion (if applicable)

**Post-Review**:
- Document rating and decisions
- Communicate outcomes
- Create development plan
- Schedule follow-up conversations

**Performance Ratings**:
- Exceeds Expectations (top performer)
- Meets Expectations (solid performer)
- Needs Improvement (concerns, PIP consideration)
- Detrimental Impact (underperformance, likely exit)

**Managing Underperformance**

**Performance Improvement Plan (PIP)**:
1. Document specific performance issues
2. Define measurable improvement goals
3. Provide necessary support and resources
4. Set clear timeline (typically 30-90 days)
5. Schedule regular check-ins
6. Document progress
7. Assess at end: improvement or termination

**PIP Components**:
- Current performance gaps
- Specific, measurable goals
- Timeline and milestones
- Support provided (training, coaching, tools)
- Monitoring frequency
- Success criteria
- Consequences if not met

### 4. Team Building & Culture

**Company Values & Culture Definition**

**Creating Core Values**:
1. Define 3-5 core values that represent the company
2. Make values specific and actionable
3. Link to hiring, performance, and decisions
4. Communicate through stories and examples
5. Model values from leadership

**Examples**:
- Transparency: Open communication, honest feedback
- Accountability: Own outcomes, follow through
- Growth: Continuous learning, embrace challenges
- Customer Focus: Solve real problems, seek feedback
- Collaboration: Work together, leverage diversity

**Culture Initiatives**

**Recurring Traditions**:
- All-hands meetings (monthly or quarterly)
- Team lunches or social events
- Mentorship programs
- Recognition/awards programs
- Volunteer days
- Learning stipend and conference attendance

**Remote Team Building**:
- Virtual coffee roulettes (random 1:1s)
- Async social channels
- Quarterly in-person offsites
- Virtual team games and contests
- Wellness stipend for home office/fitness
- Flexible schedule recognition

**Values in Action**:
- Hire for culture fit and values alignment
- Feature values in performance reviews
- Celebrate examples of values lived
- Address violations consistently
- Tell company stories and history
- Model values from leadership visibly

### 5. Employee Handbook Development

**Essential Handbook Sections**

**Company Overview**:
- Mission, vision, and values
- Company history
- Organizational structure
- Locations and contact information

**Employment Policies**:
- At-will employment statement
- Equal opportunity and non-discrimination
- Anti-harassment and retaliation
- Accommodation procedures
- Code of conduct
- Conflict of interest

**Time Off & Leave**:
- PTO/vacation policy (accrual, carryover)
- Sick leave
- Parental leave (maternity, paternity, adoption)
- Bereavement leave
- Jury duty and voting time
- Military service leave
- Leave request process

**Compensation & Benefits**:
- Salary and pay schedule
- Overtime policies
- Bonus and incentive structure
- Benefits overview (health, dental, vision)
- Retirement plans (401k, matching)
- Flexible spending accounts
- Life insurance
- Disability insurance
- Wellness programs

**Health & Safety**:
- Workplace safety standards
- Drug and alcohol policy
- Workplace injury reporting
- Ergonomic considerations
- Return-to-work procedures

**Standards of Conduct**:
- Professional behavior expectations
- Communication guidelines
- Dress code (if applicable)
- Attendance and punctuality
- Use of company resources
- Social media policy
- Data security and confidentiality
- Gifts and entertainment policy

**Termination & Severance**:
- Voluntary resignation notice period
- Involuntary termination
- Severance packages (if offered)
- Reference checks
- Exit interview process
- Return of company property

**Handbook Process**:
- Draft by HR
- Legal review
- Leadership approval
- Employee acknowledgment/signature
- Annual review and updates
- Communicate changes to staff
- Keep searchable online version

### 6. Compensation & Benefits Management

**Compensation Strategy**

**Market Analysis**:
- Research comparable positions in market
- Use salary surveys (Glassdoor, LinkedIn, custom surveys)
- Analyze by role, location, experience level
- Benchmark against competitors
- Develop pay bands and ranges

**Internal Equity**:
- Ensure fairness across similar roles
- Document job leveling and descriptions
- Regular pay equity audits
- Address discrepancies
- Transparent communication on pay philosophy

**Compensation Philosophy Statement**:
- Position relative to market (target 50th, 75th percentile)
- Performance-based increases and bonuses
- Equity/stock option approach
- Transparency level
- Review frequency

**Benefits Program Design**

**Health Benefits**:
- Medical insurance (negotiate plans and costs)
- Dental insurance
- Vision insurance
- Mental health coverage
- Wellness programs
- Employee Assistance Program (EAP)
- Health Savings Account (HSA)

**Retirement Benefits**:
- 401(k) plan with employer match
- Roth IRA options
- Investment education
- Contribution limits and vesting schedules
- Plan administration and compliance

**Paid Time Off**:
- Unlimited PTO (implementation and guardrails)
- Traditional accrual model (hours per year)
- Blackout dates and approval process
- Rollover policies
- Payout upon termination

**Additional Benefits**:
- Life insurance (company-paid + voluntary)
- Short-term and long-term disability
- Employee Stock Purchase Plan (ESPP)
- Stock options/RSUs
- Professional development stipend
- Tuition reimbursement
- Commuter benefits
- Flexible work arrangements
- Family planning benefits

**Compensation Communication**:
- Total rewards statement (annual)
- Benefits guides and open enrollment materials
- One-on-one compensation discussions
- Market data transparency
- Career progression and earning potential

### 7. Offboarding Process

**Offboarding Checklist**

**Resignation/Termination**:
- Document reason (if applicable)
- Schedule exit meeting with HR and manager
- Determine final day and transition plan
- Communicate timeline to team
- Brief replacement or coverage plan

**Knowledge Transfer**:
- Document current projects and status
- Handoff of key accounts/relationships
- Code/documentation repositories
- Process guides and procedures
- Key contact information
- Password/access documentation (secure transfer)

**IT & Facilities**:
- Disable system access on final day
- Retrieve company equipment (laptop, phone, keys, badge)
- Transfer files to shared drives
- Remove from communication channels
- Delete email (or archive based on retention)
- Ensure VPN/remote access disabled

**Financial & Legal**:
- Final paycheck (including accrued PTO)
- COBRA/health insurance continuation notice
- 401(k) distribution options
- Stock option exercise deadline (if applicable)
- Return of signing bonuses (if clawback applies)
- Non-compete/NDA reminder
- References policy review

**Exit Interview**:
- Conduct within 1-2 weeks of departure
- Cover reasons for leaving
- Feedback on role, manager, team
- Company culture feedback
- Highlights and areas for improvement
- Rehire eligibility discussion
- Encourage Glassdoor/Blind feedback (or discourage if concerns)

**Alumni Management**:
- Alumni network (LinkedIn group)
- Boomerang rehire program
- Reference contact information
- Alumni events and updates
- Maintain relationships

### 8. Conflict Resolution & Workplace Relations

**Conflict Resolution Framework**

**Levels of Response**:

**Level 1: Informal/Direct**
- Direct conversation between parties
- Active listening and understanding
- Focus on interests, not positions
- Seek win-win solutions
- Manager facilitation (if needed)

**Level 2: Mediation**
- Neutral third party (manager, HR)
- Structured conversation process
- Separate meetings if needed
- Focus on finding common ground
- Documented agreement

**Level 3: Formal Investigation**
- HR involvement
- Confidential investigation process
- Document gathering and interviews
- Legal review (if necessary)
- Disciplinary action (if warranted)
- Follow-up and monitoring

**Mediation Best Practices**:
- Create psychological safety
- Active listening without judgment
- Help clarify interests and concerns
- Generate options together
- Reach mutual agreement
- Document resolution
- Follow up on implementation

**Difficult Conversations**

**Preparation**:
- Have facts/examples documented
- Clarify the objective
- Choose appropriate timing and location
- Anticipate reactions and responses
- Plan next steps

**Conversation Structure**:
1. State facts (specific, recent examples)
2. Listen to their perspective
3. Discuss impact and concerns
4. Agree on path forward
5. Follow up and monitor

**Examples**:
- Performance issues
- Behavioral concerns
- Interpersonal conflicts
- Policy violations
- Resignation acceptance

**Workplace Harassment & Discrimination**

**Prevention**:
- Clear anti-harassment policies
- Mandatory training for all staff
- Reporting mechanisms (multiple channels)
- Safe reporting environment
- Non-retaliation protections

**Response Protocol**:
1. Take all reports seriously
2. Confidential investigation
3. Document thoroughly
4. Interviewing parties and witnesses
5. Maintain confidentiality
6. Determine facts
7. Take corrective action
8. Follow up on retaliation
9. Maintain documentation

### 9. Leadership Development & Succession Planning

**Leadership Development Program**

**Components**:
- Executive coaching (1-on-1)
- Group training and workshops
- 360-degree feedback
- Mentorship and peer coaching
- Stretch assignments
- Conference attendance
- Book clubs and learning groups

**Key Leadership Competencies**:
- Vision and strategy
- Decision-making
- Communication
- Emotional intelligence
- Delegation
- Performance management
- Resilience and adaptability
- Inclusive leadership
- Change management

**Development Plans**:
- Assess current vs. desired competencies
- Set specific development goals
- Identify learning methods
- Define success metrics
- Regular check-ins and adjustment
- Document progress

**Succession Planning**

**Process**:
1. Identify critical leadership roles
2. Define future capability needs
3. Assess current talent
4. Identify high-potential employees
5. Create development plans
6. Provide stretch opportunities
7. Monitor and adjust
8. Document plans

**Succession Tiers**:
- Immediate succession (ready now or within 1-2 years)
- Medium-term succession (2-5 years)
- Long-term succession (5+ years)
- External candidate identification (if needed)

**Retention Strategy for High Performers**:
- Clear career path and growth opportunities
- Competitive compensation and benefits
- Meaningful work and impact
- Leadership opportunities
- Professional development investment
- Recognition and visibility
- Flexible work arrangements
- Stock options/equity (where applicable)

### 10. Organizational Design & Structure

**Organizational Design Principles**

**Structure Options**:
- Functional (grouped by role/expertise)
- Divisional (grouped by product/geography)
- Matrix (both functional and divisional)
- Flat (minimal hierarchy, cross-functional teams)
- Pod-based (small autonomous teams)

**Considerations**:
- Company size and scale
- Product/service portfolio
- Market dynamics
- Company culture
- Communication patterns
- Decision-making speed
- Span of control (4-6 direct reports optimal)

**Role Definition**

**Job Description Components** (beyond recruitment JD):
- Purpose and accountabilities
- Key responsibilities
- Success metrics
- Relationships and reporting
- Required qualifications
- Development opportunities

**Levels and Ladders**

**Creating Level Progression**:
- Individual contributor tracks (IC1-IC5+)
- Management tracks (Manager-Director-VP-C-level)
- Specialist/expert tracks (Tech Fellow, Principal)
- Career framework documentation
- Transparent criteria for advancement

**Level Definitions**:
- Scope of impact (individual, team, organization, market)
- Complexity and autonomy
- Mentorship and influence
- Decision-making authority
- Compensation bands

**Headcount Planning**

**Forecasting**:
- Define headcount by department/role
- Timeline for hires
- Budget allocation
- Hiring priorities
- Resource constraints

**Hiring Acceleration**:
- Concurrent interviews
- Video pre-screening
- Hiring partnerships/recruitment agencies
- Internship programs
- Diversity recruiting initiatives

## Quick Reference

### Common Commands & Triggers
- `/hire` - Recruitment and hiring guidance
- `/onboard` - Onboarding procedures and plans
- `/review` - Performance review process
- `/okr` - OKR framework and tracking
- `/team` - Team building and culture initiatives
- `/handbook` - Employee handbook sections
- `/compensation` - Compensation strategy and structure
- `/offboard` - Offboarding checklist
- `/leadership` - Leadership development programs
- `/orgdesign` - Organizational structure and design

## Conclusion

Effective HR management requires comprehensive systems, clear communication, and genuine investment in employee development. These frameworks enable building and scaling high-performing, engaged teams while maintaining culture and fairness throughout the employee lifecycle.
