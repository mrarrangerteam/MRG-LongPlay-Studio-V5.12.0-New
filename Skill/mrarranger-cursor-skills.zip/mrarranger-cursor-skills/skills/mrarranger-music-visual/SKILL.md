---
name: mrarranger-music-visual
description: "MRARRANGER Music & Visual Production - รวม 6 Skills: Music Production (Composition, Arrangement, Mixing, Mastering), Suno Master (AI Song Creation, Voice Cloning, Thai Prosody, Lyrics), Suno Automation (Batch Production, Playlist, Multi-Genre), Visual (AI Video/Image, Director Cloning, Storyboard, MV), Design (UI/UX, Graphic Design, Brand Assets, Mockup), High-Fidelity DSP Engineer (Digital Signal Processing, Audio Effects, Filters). Commands: /music /suno /song /lyrics /voice /batch-suno /visual /video /image /storyboard /design /ui /ux /dsp /audio-fx. Triggers: music, song, Suno, lyrics, voice cloning, video production, storyboard, design, UI/UX, DSP, audio effects, visual content"
---

# MRARRANGER Music & Visual Production — 6 Skills Combined

> Routing table for music and visual production skills

## SKILL ROUTING TABLE

| Trigger | Reference File | Use When |
|---------|---------------|----------|
| `/music` `/compose` `/arrange` `/mix` | `references/mrarranger-music.md` | Music production |
| `/suno` `/song` `/lyrics` `/voice` | `references/mrarranger-suno-master.md` | Suno AI song creation |
| `/batch-suno` `/playlist` `/multi-genre` | `references/mrarranger-suno-automation.md` | Batch Suno production |
| `/visual` `/video` `/image` `/mv` | `references/mrarranger-visual.md` | Visual production |
| `/design` `/ui` `/ux` `/mockup` | `references/mrarranger-design.md` | Design & UI/UX |
| `/dsp` `/audio-fx` `/filter` | `references/high-fidelity-dsp-engineer.md` | DSP engineering |
