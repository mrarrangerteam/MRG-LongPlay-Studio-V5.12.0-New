# mrarranger-design

**Source:** `/mnt/skills/user/mrarranger-design/SKILL.md`
**Size:** 8731 bytes

---

---
name: mrarranger-design
description: |
  ระบบออกแบบครบวงจร - Graphic Design, UI/UX, Layout, Typography, Color Theory, Brand Identity
  สร้าง Design Brief, Wireframe, Style Guide, และ Design Specs ระดับมืออาชีพ
  ใช้เมื่อ: (1) ออกแบบ Graphic/Poster/Banner (2) ออกแบบ UI/UX (3) สร้าง Brand Identity (4) เลือก Color Palette (5) จัด Layout (6) เลือก Typography
  Commands: /design [type], /ui [screen], /palette [mood], /layout [format], /brand [name], /font [style]
---

# MRARRANGER Design System

## Quick Commands

```
/design poster [topic]      → ออกแบบ Poster
/design banner [platform]   → ออกแบบ Banner
/design social [platform]   → ออกแบบ Social Graphics
/ui [screen-type]           → ออกแบบ UI Screen
/ux [flow-type]             → ออกแบบ User Flow
/palette [mood]             → สร้าง Color Palette
/layout [format]            → แนะนำ Layout
/brand [name]               → สร้าง Brand Identity
/font [style]               → แนะนำ Font Pairing
```

## Design Principles

### Core Principles
```
1. Hierarchy - สิ่งสำคัญต้องเด่น
2. Balance - สมดุลทางสายตา
3. Contrast - ความแตกต่างสร้างความน่าสนใจ
4. Alignment - จัดเรียงอย่างมีระบบ
5. Repetition - ความสม่ำเสมอสร้างเอกภาพ
6. Proximity - สิ่งที่เกี่ยวข้องอยู่ใกล้กัน
7. White Space - พื้นที่ว่างคือพลัง
```

## Color Theory

### Color Psychology
```
Red: พลัง, ความเร่งด่วน, ความหลงใหล
Orange: ความสนุก, มิตรภาพ, ความมั่นใจ
Yellow: ความสุข, ความหวัง, ความสดใส
Green: ธรรมชาติ, การเติบโต, ความสงบ
Blue: ความน่าเชื่อถือ, มืออาชีพ, ความสงบ
Purple: หรูหรา, ความคิดสร้างสรรค์, ปัญญา
Pink: ความอ่อนโยน, โรแมนติก, สนุกสนาน
Black: หรูหรา, ทันสมัย, พลัง
White: บริสุทธิ์, เรียบง่าย, สะอาด
```

### Color Palette Formulas
```
Monochromatic: เฉดเดียว หลาย tone
Complementary: สีตรงข้าม (Blue + Orange)
Analogous: สีข้างเคียง (Blue + Green + Teal)
Triadic: 3 สี ห่างเท่ากัน (Red + Yellow + Blue)
Split-Complementary: 1 สี + 2 สีข้างตรงข้าม
```

### Palette by Mood
```
Professional/Corporate:
#2C3E50, #3498DB, #ECF0F1, #1ABC9C

Energetic/Bold:
#E74C3C, #F39C12, #9B59B6, #1ABC9C

Calm/Minimal:
#F8F9FA, #E9ECEF, #6C757D, #212529

Luxury/Premium:
#1A1A2E, #D4AF37, #F5F5F5, #16213E

Playful/Fun:
#FF6B6B, #4ECDC4, #FFE66D, #95E1D3

Nature/Organic:
#2D5016, #5C8A3E, #A8D08D, #F4E8C1
```

## Typography

### Font Categories
```
Serif: ดั้งเดิม น่าเชื่อถือ (Times, Georgia, Playfair)
Sans-Serif: ทันสมัย สะอาด (Helvetica, Inter, Poppins)
Display: โดดเด่น สะดุดตา (สำหรับ Headlines)
Monospace: เทคนิค โค้ด (Fira Code, JetBrains)
Script: สวยงาม โรแมนติก (ใช้น้อยๆ)
```

### Font Pairing Rules
```
1. Contrast แต่ไม่ Conflict
2. 2-3 fonts สูงสุด
3. Heading + Body ต่างประเภท
4. ใช้ weight สร้าง hierarchy

Classic Pairings:
- Playfair Display + Source Sans Pro
- Montserrat + Merriweather
- Poppins + Lora
- Roboto + Roboto Slab
- Inter + Georgia

Thai Font Pairings:
- Prompt + Sarabun
- Kanit + Mitr
- IBM Plex Thai + Noto Sans Thai
```

### Typography Scale
```
Base: 16px
Scale Ratio: 1.25 (Major Third)

h1: 48px (3rem)
h2: 39px (2.4rem)
h3: 31px (1.95rem)
h4: 25px (1.56rem)
h5: 20px (1.25rem)
body: 16px (1rem)
small: 13px (0.8rem)
```

## Layout Systems

### Grid Systems
```
12-Column Grid (Web Standard):
- Flexible, divisible by 2,3,4,6
- Gutter: 16-32px
- Max-width: 1200-1440px

8-Point Grid (UI):
- ทุก spacing เป็นเลขคูณ 8
- 8, 16, 24, 32, 40, 48, 64, 80...
```

### Layout Patterns

**F-Pattern (Content-heavy):**
```
[Logo]----[Nav]----[Nav]----[CTA]
[Hero Image / Headline          ]
[Content]     [Content]    [Side]
[Content]     [Content]    [Side]
```

**Z-Pattern (Landing Page):**
```
[Logo]------------------[CTA]
        [Hero Image]
[Feature]---[Feature]---[Feature]
[CTA Button]
```

**Card Layout:**
```
[Card][Card][Card][Card]
[Card][Card][Card][Card]
```

**Split Screen:**
```
[Image    |    Content]
[50%      |    50%    ]
```

## UI/UX Design

### UI Components Checklist
```
Navigation:
□ Navbar / Header
□ Sidebar
□ Breadcrumbs
□ Tabs
□ Pagination

Forms:
□ Input Fields
□ Dropdowns
□ Checkboxes/Radio
□ Buttons (Primary/Secondary/Ghost)
□ Error States

Content:
□ Cards
□ Lists
□ Tables
□ Modals
□ Tooltips

Feedback:
□ Loading States
□ Success/Error Messages
□ Empty States
□ Progress Indicators
```

### UX Flow Templates

**Onboarding Flow:**
```
Welcome → Value Prop → Sign Up → Personalization → First Action → Success
```

**E-commerce Flow:**
```
Browse → Product Detail → Add to Cart → Checkout → Payment → Confirmation
```

**SaaS Flow:**
```
Landing → Features → Pricing → Sign Up → Onboarding → Dashboard
```

### Mobile UI Patterns
```
Tab Bar Navigation: 3-5 items
Hamburger Menu: Secondary nav
Bottom Sheet: Actions/Options
Pull to Refresh: Lists
Infinite Scroll: Feeds
Floating Action Button: Primary action
```

## Brand Identity

### Brand Identity Checklist
```
Strategy:
□ Brand Purpose (Why)
□ Brand Values (What we believe)
□ Brand Personality (If brand was a person)
□ Target Audience (Who we serve)
□ Positioning (vs competitors)

Verbal Identity:
□ Brand Name
□ Tagline
□ Voice & Tone Guidelines
□ Messaging Framework

Visual Identity:
□ Logo (Primary + Variations)
□ Color Palette (Primary + Secondary)
□ Typography System
□ Iconography Style
□ Photography Style
□ Illustration Style
□ Pattern/Texture Library

Applications:
□ Business Cards
□ Letterhead
□ Email Signature
□ Social Media Templates
□ Presentation Template
□ Website Design
```

### Logo Design Principles
```
1. Simple - จดจำง่าย
2. Memorable - ไม่เหมือนใคร
3. Versatile - ใช้ได้ทุกที่ทุกขนาด
4. Appropriate - เหมาะกับธุรกิจ
5. Timeless - ไม่ตกยุค

Logo Types:
- Wordmark (Google, Coca-Cola)
- Lettermark (IBM, HBO)
- Symbol/Icon (Apple, Nike)
- Combination (Adidas, Burger King)
- Emblem (Starbucks, Harley-Davidson)
```

## Design Specs Template

```markdown
## Design Specifications

### Canvas Size
- Width: [X]px
- Height: [Y]px
- Resolution: [DPI]

### Color Palette
- Primary: #XXXXXX
- Secondary: #XXXXXX
- Accent: #XXXXXX
- Background: #XXXXXX
- Text: #XXXXXX

### Typography
- Heading: [Font], [Weight], [Size]
- Body: [Font], [Weight], [Size]
- Caption: [Font], [Weight], [Size]

### Spacing
- Margins: [X]px
- Padding: [X]px
- Gap between elements: [X]px

### Elements
1. [Element 1]: Position, Size, Style
2. [Element 2]: Position, Size, Style
...

### Export Settings
- Format: [PNG/JPG/SVG/PDF]
- Quality: [%]
- Color Profile: [sRGB/CMYK]
```

## Platform-Specific Sizes

### Social Media
```
Instagram:
- Post: 1080x1080px
- Story: 1080x1920px
- Reel Cover: 1080x1920px

Facebook:
- Post: 1200x630px
- Cover: 820x312px
- Story: 1080x1920px

YouTube:
- Thumbnail: 1280x720px
- Channel Art: 2560x1440px

LinkedIn:
- Post: 1200x1200px
- Cover: 1584x396px

Twitter/X:
- Post: 1200x675px
- Header: 1500x500px

TikTok:
- Video: 1080x1920px
```

### Print
```
Business Card: 3.5x2 inches (300 DPI)
A4: 210x297mm
Letter: 8.5x11 inches
Poster A3: 297x420mm
Banner: Custom (300 DPI for print)
```

## File References

- `references/color-palettes.md` - 50+ Color Palettes พร้อมใช้
- `references/ui-patterns.md` - UI Patterns ทุกประเภท
- `references/brand-examples.md` - ตัวอย่าง Brand Identity