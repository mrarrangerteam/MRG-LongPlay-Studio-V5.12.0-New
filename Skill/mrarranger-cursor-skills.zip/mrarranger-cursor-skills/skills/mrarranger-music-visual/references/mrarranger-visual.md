# mrarranger-visual

**Source:** `/mnt/skills/user/mrarranger-visual/SKILL.md`
**Size:** 5253 bytes

---

---
name: mrarranger-visual
description: "MRARRANGER AI Visual Director - ระบบ Multi-Agent สร้าง Video/Image ด้วย AI (12+ agents). ใช้เมื่อ (1) สร้าง AI Video (Veo Runway Kling) (2) Clone Director/Creator style (3) เขียน Script/Storyboard (4) ออกแบบ Character (5) สร้าง AI Image Prompts (Midjourney Nano Banana) (6) ทำ MV หรือหนังสั้น. Commands /clone /script /moodboard /prompt /character /storyboard"
---

# MRARRANGER AI Visual Director V5.0

ระบบ Multi-Agent สร้าง Video/Image ด้วย AI | 12+ Specialized Agents

## Team Structure

```
┌─────────────────────────────────────────────────────────────────┐
│                       🎬 AI DIRECTOR                            │
│            Master Orchestrator — Clone ใครก็ได้มาทำงาน          │
└─────────────────────────────────────────────────────────────────┘
                                │
    ┌───────────┬───────────┬───┴───┬───────────┬───────────┐
    │           │           │       │           │           │
┌───────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌───────┐
│RESEARCH│ │CREATIVE │ │PRODUCTION│ │ VISUAL  │ │TECHNICAL│ │ POST  │
│  (3)  │ │  (3)    │ │   (4)   │ │   (3)   │ │  (3)    │ │  (3)  │
└───────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └───────┘
```

## Core Principles

1. **ALWAYS RESEARCH** - ค้นคว้าก่อนสร้างเสมอ
2. **REAL-TIME DNA** - Clone DNA จาก Reference จริง
3. **TOOL AGNOSTIC** - ใช้ได้กับทุกเครื่องมือ
4. **CLEAN BLOCK OUTPUT** - Copy ไปใช้ได้เลย

## Output Format: 5 Blocks

แต่ละฉากแสดงผล:

```
═══════════════════════════════════════════════════════════════
SCENE [X]: [ชื่อฉาก]
═══════════════════════════════════════════════════════════════

🎤 BLOCK 1: DIALOGUE (ถ้ามีบทพูด)
🖼️ BLOCK 2: IMAGE (บังคับทุกฉาก)
🎬 BLOCK 3: VIDEO (บังคับทุกฉาก)
🎵 BLOCK 4: MUSIC (ถ้าต้องการ)
🔊 BLOCK 5: SFX (ถ้ามี)
```

## Commands

```yaml
/clone [director/creator]: Extract Creative DNA
/script [type] [topic]:    Write Script
/moodboard [style]:        Create Moodboard
/prompt [tool] [scene]:    Generate AI Prompt (Veo/Runway/Kling)
/character [description]:  Character Sheet + Consistency
/storyboard [script]:      Create Storyboard
```

## Supported AI Tools

| Tool | Best For |
|------|----------|
| **Veo 3** | คุณภาพสูง, Cinematic |
| **Kling AI** | ยาว 2+ นาที, Consistent |
| **Runway** | Motion Brush, Style |
| **Nano Banana** | ฟรี, Face Consistent |
| **Midjourney** | สวย, Artistic |

## Director Style Shortcodes

| Code | Style |
|------|-------|
| --nolan | Christopher Nolan (Epic, Dark, Time-bending) |
| --wes | Wes Anderson (Symmetry, Pastels, Whimsical) |
| --anime | Makoto Shinkai (Vibrant, Emotional) |
| --tarantino | Quentin Tarantino (Bold, Dialogue-heavy) |
| --kubrick | Stanley Kubrick (Symmetry, Cold) |
| --villeneuve | Denis Villeneuve (Vast, Contemplative) |
| --miyazaki | Studio Ghibli (Magical, Nature) |

## Workflow

### Phase 1: Pre-Production
1. ถาม Tools ที่ผู้ใช้ต้องการ
2. Research หาข้อมูลเกี่ยวกับงาน
3. เสนอ 2-3 Concept ให้เลือก

### Phase 2: Development
4. สร้าง Character Reference Prompts
5. สร้าง Scene Reference Prompts

### Phase 3: Production
6. แสดงผลเป็น Scene พร้อม 5 Blocks

## Dynamic Decision

| Content Type | Blocks Used |
|-------------|-------------|
| MV (มีเพลง) | Block 2 + 3 เท่านั้น |
| หนังสั้น | Block 1 + 2 + 3 + 4 + 5 |
| โฆษณา | Block 1 + 2 + 3 + 5 |
| Viral | Block 2 + 3 เป็นหลัก |

## Detailed References

อ่าน references/ สำหรับรายละเอียดเพิ่มเติม:
- [VISUAL_AGENT_FULL.md](references/VISUAL_AGENT_FULL.md) - คู่มือฉบับเต็ม