# mrarranger-music

**Source:** `/mnt/skills/user/mrarranger-music/SKILL.md`
**Size:** 4659 bytes

---

---
name: mrarranger-music
description: "MRARRANGER AI Music Producer - ระบบ Multi-Agent สร้างเพลงสำหรับ Suno AI (12 agents). ใช้เมื่อ (1) สร้างเพลงด้วย Suno AI (2) Clone เพลง/ศิลปิน (3) Voice Cloning (4) เขียนเนื้อเพลง (5) Thai Prosody สำหรับเพลงไทย (6) Batch สร้างหลายเพลง. Commands /clone /playlist /batch /compose /suno /lyrics /dna"
---

# MRARRANGER AI Music Producer V5.2

ระบบ Multi-Agent สร้างเพลงสำหรับ Suno AI | 12 Specialized Agents

## Team Structure

```
┌─────────────────────────────────────────────────────────────────┐
│                    👔 EXECUTIVE PRODUCER (EP)                   │
└─────────────────────────────────────────────────────────────────┘
                                │
          ┌─────────────────────┼─────────────────────┐
          │                     │                     │
┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐
│  🔬 RESEARCH    │   │  🎵 PRODUCTION  │   │  ✅ QUALITY     │
│  • DNA Research │   │  • Lyricist     │   │  • QA Specialist│
│  • Style Decode │   │  • Composer     │   │  • Prosody Check│
│  • Trend Analyst│   │  • Producer     │   │  • Format Valid │
│  • Gear Special │   │  • Vocal Expert │   │                 │
└─────────────────┘   └─────────────────┘   └─────────────────┘
```

## Critical Rules

1. **RESEARCH FIRST** - ค้นคว้าก่อนสร้างเสมอ ห้ามเดา
2. **STYLE ≤ 1000** - Style Prompt ต้องไม่เกิน 1000 ตัวอักษร
3. **NO ARTIST NAMES** - ห้ามใส่ชื่อศิลปินจริงใน Style Prompt

## Output Format

| ประเภท | Output Blocks |
|--------|---------------|
| เพลงร้อง | 3 Blocks: Lyrics + Style Prompt + Title |
| Instrumental | 2 Blocks: Style Prompt + Title |
| Batch Mode | แยกไฟล์ .md ทุกเพลง |

## Commands

```yaml
/clone [เพลง]:     Clone DNA 5 Steps อัตโนมัติ
/playlist [n] [genre]: Longplay Mode → ถาม 2 หรือ 3 Blocks
/batch [n] [genre]:    Automation Mode → Output .md files
/compose [genre] [mood]: สร้างเพลงใหม่
/suno [description]:    Generate Suno v5 Prompt
/lyrics [theme] [style]: เขียนเนื้อเพลง
/dna [song/artist]:     Extract Music DNA
/clone-voice [artist]:  Voice Cloning Parameters
/thai-song [theme]:     Thai Prosody-optimized Song
```

## Data Classification

| Type | Action | Examples |
|------|--------|----------|
| **ALWAYS RESEARCH** | ต้อง Search ทุกครั้ง | Artist DNA, Song DNA, Suno Features, Trends |
| **REFERENCE + RESEARCH** | ใช้ KB + Research ยืนยัน | Genre BPM, Chord Progressions, Rhythm Patterns |
| **STATIC KNOWLEDGE** | ใช้ KB ได้เลย | Thai Prosody, Thai Pronunciation, Meta Tags |

## Clone DNA 5 Steps

1. **DNA Research** - ค้นหาข้อมูล Artist/Song
2. **Style Decode** - วิเคราะห์ Production Style
3. **Lyrics Writing** - เขียนเนื้อเพลง (ถ้าเป็นเพลงร้อง)
4. **QA Check** - ตรวจสอบ Prosody และ Format
5. **Output** - ส่งมอบ Clean Blocks

## Thai Prosody (สำหรับเพลงไทย)

ระบบ Tone-Melody Mapping:
- สามัญ (Mid) → Stable notes
- เอก (Low) → Descending
- โท (Falling) → High to low
- ตรี (High) → Rising
- จัตวา (Rising) → Low to high

## Detailed References

อ่าน references/ สำหรับรายละเอียดเพิ่มเติม:
- [MUSIC_AGENT_FULL.md](references/MUSIC_AGENT_FULL.md) - คู่มือฉบับเต็ม