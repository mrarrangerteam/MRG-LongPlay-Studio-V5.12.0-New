# mrarranger-suno-master

**Source:** `/mnt/skills/user/mrarranger-suno-master/SKILL.md`
**Size:** 28303 bytes

---

---
name: "mrarranger-suno-master"
description: "MRARRANGER Suno Master - ระบบ Multi-Agent สร้างเพลงครบวงจรสำหรับ Suno AI รวม 12 Agents, DNA Research, Thai Prosody, Voice Cloning, Automation File Format, Batch Mode พร้อม QA Pipeline. Commands: /clone /batch /playlist /compose /suno /lyrics /dna /clone-voice /thai-song /suno-auto /queue"
---

# 🎵 MRARRANGER SUNO MASTER SKILL

**ระบบ Multi-Agent สร้างเพลงครบวงจร | 12 Specialized Agents | Suno AI Production**

---

# PART I: SYSTEM ARCHITECTURE

---

## 🤖 12-AGENT TEAM STRUCTURE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    👔 EXECUTIVE PRODUCER (EP)                               │
│                         "The Decision Maker"                                │
│   Role: รับ Brief → มอบหมาย → รวบรวม → ตัดสินใจขั้นสุดท้าย → ส่งมอบ         │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                    ▼               ▼               ▼
┌───────────────────────┐ ┌─────────────────────┐ ┌─────────────────────────┐
│  🔬 RESEARCH UNIT     │ │ 🎵 PRODUCTION UNIT  │ │  ✅ QUALITY UNIT        │
│                       │ │                     │ │                         │
│ • DNA Researcher      │ │ • Lyricist Expert   │ │ • QA Specialist         │
│ • Style Decoder       │ │ • Composer Expert   │ │ • Prosody Checker       │
│ • Trend Analyst       │ │ • Producer Expert   │ │ • Format Validator      │
│ • Gear Specialist     │ │ • Vocal Expert      │ │                         │
└───────────────────────┘ └─────────────────────┘ └─────────────────────────┘
```

---

## 📋 QUICK COMMANDS

| Command | Description |
|---------|-------------|
| `/clone [เพลง/ศิลปิน]` | Clone DNA 5 Steps อัตโนมัติ |
| `/playlist [n] [genre]` | Longplay Mode → สร้าง Playlist |
| `/batch [n] [genre]` | Automation Mode → Output .md files |
| `/compose [genre] [mood]` | สร้างเพลงใหม่ |
| `/suno [description]` | Generate Suno v5 Prompt |
| `/lyrics [theme] [style]` | เขียนเนื้อเพลง |
| `/dna [song/artist]` | Extract Music DNA |
| `/clone-voice [artist]` | Voice Cloning Parameters |
| `/thai-song [theme]` | Thai Prosody-optimized Song |
| `/suno-auto [n] [style]` | สร้าง n เพลง สไตล์เดียว |
| `/suno-auto [n] [style] [dna1,dna2,...]` | สร้าง n เพลง หลาย DNA |
| `/queue [n]` | สร้าง Queue File n เพลง |

---

## 🔐 CRITICAL RULES

```yaml
rules:
  1_research_first: "ค้นคว้าข้อมูล Real-time ก่อนสร้างเสมอ ห้ามเดา"
  2_style_limit: "Style Prompt ≤ 1000 ตัวอักษร (STRICT)"
  3_no_artist_names: "ห้ามใส่ชื่อศิลปินจริงใน Style Prompt"
  4_suno_format: "ใช้ Format บังคับสำหรับ Suno Automation"
```

---

## 📊 DATA CLASSIFICATION

| Type | Action | Examples |
|------|--------|----------|
| **ALWAYS RESEARCH** | ต้อง Search ทุกครั้ง | Artist DNA, Song DNA, Suno Features, Trends |
| **REFERENCE + RESEARCH** | ใช้ KB + Research ยืนยัน | Genre BPM, Chord Progressions, Rhythm Patterns |
| **STATIC KNOWLEDGE** | ใช้ KB ได้เลย | Thai Prosody, Thai Pronunciation, Meta Tags |

---

## 🎯 OUTPUT FORMAT

| ประเภท | Output Blocks |
|--------|---------------|
| เพลงร้อง | 3 Blocks: Lyrics + Style Prompt + Title |
| Instrumental | 2 Blocks: Style Prompt + Title |
| Batch/Automation | แยกไฟล์ .md ทุกเพลง |

---

# PART II: DNA RESEARCH PROTOCOL

---

## 🧬 CLONE DNA 5 STEPS

```yaml
step_1_dna_research:
  agent: "DNA Researcher"
  action: "Web Search ข้อมูล Artist/Song"
  output: "DNA Report"
  
step_2_style_decode:
  agent: "Style Decoder"
  action: "วิเคราะห์ Production Style"
  categories:
    - Harmony DNA (Key, BPM, Chord Progressions)
    - Melodic DNA (Vocal Range, Melody Contour)
    - Rhythmic DNA (Time Signature, Groove)
    - Production DNA (Instruments, FX, Mix)
    - Lyrical DNA (Theme, Rhyme Scheme)
    - Structural DNA (Song Form, Sections)
    - Emotional DNA (Mood Arc, Energy)
  output: "Style Profile"
  
step_3_lyrics_writing:
  agent: "Lyricist Expert"
  action: "เขียนเนื้อเพลง (ถ้าเป็นเพลงร้อง)"
  check: "Thai Prosody (ถ้าเป็นเพลงไทย)"
  output: "Lyrics Draft"
  
step_4_qa_check:
  agent: "QA Specialist"
  action: "ตรวจสอบ Prosody, Format, Character Count"
  checklist:
    - Style Prompt ≤ 1000 chars
    - ไม่มีชื่อศิลปินใน Style
    - Prosody ถูกต้อง (เพลงไทย)
  output: "QA Report"
  
step_5_output:
  agent: "EP"
  action: "รวบรวมและส่งมอบ Clean Blocks"
  output: "Final Output"
```

---

## 🔬 7 DNA CATEGORIES

```yaml
1_harmony_dna:
  elements: ["Key", "BPM", "Time Signature", "Chord Progressions"]
  example: "Key: G Major, BPM: 92, 4/4, I-V-vi-IV progression"

2_melodic_dna:
  elements: ["Vocal Range", "Melody Contour", "Hook Pattern"]
  example: "Range: G3-D5, Contour: Rising verse, Falling chorus"

3_rhythmic_dna:
  elements: ["Groove", "Syncopation", "Feel"]
  example: "Straight 8ths, Light swing feel, Pocket groove"

4_production_dna:
  elements: ["Core Instruments", "Support Instruments", "FX", "Mix Style"]
  example: "Acoustic guitar, Electric piano, Reverb heavy, Warm vintage"

5_lyrical_dna:
  elements: ["Theme", "Rhyme Scheme", "Language Style"]
  example: "Theme: Nostalgia, ABAB rhyme, Conversational"

6_structural_dna:
  elements: ["Form", "Section Length", "Dynamics"]
  example: "Verse-PreChorus-Chorus-Bridge, 16-bar verse, pp to ff"

7_emotional_dna:
  elements: ["Mood Arc", "Energy Flow", "Tension/Release"]
  example: "Bittersweet to hopeful, Low energy build, Strong release"
```

---

# PART III: SUNO AUTOMATION FORMAT

---

## 🔒 MANDATORY FORMAT PROTOCOL

> ⛔ **กฎเหล็ก — บังคับปฏิบัติทุกครั้ง ไม่มีข้อยกเว้น**

### 🔴 TRIGGER CONDITIONS

| เมื่อผู้ใช้บอก | ต้องใช้ Format นี้ |
|---------------|-------------------|
| "Suno Automation" | ✅ บังคับ |
| "Queue File" | ✅ บังคับ |
| "Automation File" | ✅ บังคับ |
| ".md สำหรับ Suno" | ✅ บังคับ |
| "Batch Songs" | ✅ บังคับ |
| "สร้างหลายเพลงใน 1 ไฟล์" | ✅ บังคับ |
| `/suno-auto` | ✅ บังคับ |
| `/queue` | ✅ บังคับ |

---

## 📄 FILE STRUCTURE TEMPLATE

### 🎯 HEADER SECTION

```markdown
# 🎵 [Collection Name] — [Artist/Style] Style ([N] Songs)

> Suno Automation Queue — [Description]

---
```

### 🎼 STYLE PROMPT SECTION

```markdown
## 🎼 Style Prompt (ใช้ทุกเพลง)

\`\`\`
[Full Style Prompt in ONE LINE - no line breaks, ≤1000 chars]
\`\`\`

---
```

### 🎤 DNA REFERENCE TABLE (ถ้ามีหลาย DNA)

```markdown
## 🎤 [N] Songwriters DNA Reference

| # | Songwriter DNA | Style Influence |
|---|----------------|-----------------|
| 1 | Ed Sheeran | Acoustic fingerstyle, percussive, storytelling |
| 2 | John Mayer | Bluesy fingerpicking, smooth, relaxed |
| ... | ... | ... |

---
```

### 🎵 SONG SECTION (ทำซ้ำทุกเพลง)

```markdown
## เพลงที่ 1

**ชื่อเพลง:** 1.Song Title (Subtitle)

**Style:** [Full Style Prompt - same as above, ONE LINE]

**เนื้อเพลง:**
[Intro]
(Acoustic Guitar melody with reverb and delay, [description] floating, [instrument] enter)

[Verse 1]
Line 1
Line 2
Line 3
Line 4

Line 5
Line 6
Line 7
Line 8

[Pre-Chorus]
Line 1
Line 2
Line 3
Line 4

[Chorus]
Line 1
Line 2
Line 3
Line 4
Line 5

[Verse 2]
Line 1
Line 2
Line 3
Line 4

Line 5
Line 6
Line 7
Line 8

[Pre-Chorus]
Line 1
Line 2
Line 3
Line 4

[Chorus]
Line 1
Line 2
Line 3
Line 4
Line 5

[Bridge]
Line 1
Line 2
Line 3
Line 4

[Outro]
(Acoustic Guitar melody with reverb delay, [description] fade)
Final lyric line... with ellipsis...
[End]

**Songwriter Influence:** [Artist Name]

---
```

### 📋 SUMMARY TABLE SECTION

```markdown
# 📋 Summary Table — [N] Songs

| # | ชื่อเพลง | Songwriter DNA | Theme |
|---|----------|----------------|-------|
| 1 | Song Title (Subtitle) | Artist Name | Theme description |
| 2 | ... | ... | ... |

---

🔥 Generated by MRARRANGER AI STUDIO — Suno Master
```

---

## 🎯 SONG STRUCTURE PATTERN

```yaml
standard_structure:
  intro: "(Acoustic Guitar melody with reverb and delay, [description], [instrument])"
  
  verse_1:
    lines: 8  # (4 + blank + 4)
    syllables: "8-12 per line"
    rhyme: "ABAB or AABB"
    
  pre_chorus:
    lines: 4
    purpose: "emotional build, tension"
    
  chorus:
    lines: "5-6"
    purpose: "anthemic, memorable, emotional peak"
    
  verse_2:
    lines: 8
    purpose: "story progression, new perspective"
    
  bridge:
    lines: 4
    purpose: "contrast, realization, emotional peak"
    
  outro: "(Acoustic Guitar melody with reverb delay, [description] fade)"
  
  end: "[End]"  # MANDATORY
```

---

## 🎨 STYLE PROMPT TEMPLATES

### Soft Pop Rock (Goo Goo Dolls Style)

```
[Primary Genre: Soft Pop Rock] + [Secondary Genre: Acoustic Light Rock], Core Instruments: Acoustic Guitar (open chords), Electric Guitar (chorus FX), Bass Guitar, Soft Snare Drum, Support Instruments: Electric Piano, Warm Pad, Ambient Strings, Tempo: 90 BPM, Key: A Major, Mood: Nostalgic, Hopeful, Bittersweet, Vocal: Male, Warm Mid-Range, Slightly Raspy, Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Clean acoustic tone, analog warmth, light tape saturation, FX: Stereo Reverb (medium hall), Subtle Delay on Guitar, Dynamic: mp → f → mp
```

### Acoustic Pop (Ed Sheeran Style)

```
[Primary Genre: Acoustic Pop] + [Secondary Genre: Folk Pop], Core Instruments: Acoustic Guitar (fingerstyle), Loop Pedal Layers, Beatbox Elements, Support Instruments: Light Percussion, Subtle Bass, Tempo: 95 BPM, Key: G Major, Mood: Intimate, Storytelling, Warm, Vocal: Male, Mid-Range, Conversational, Occasional Rap Sections, Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Close-mic acoustic, percussive guitar, loop-based build, FX: Room Reverb, Subtle Compression, Dynamic: p → mf → p
```

### Blues Rock (John Mayer Style)

```
[Primary Genre: Blues Rock] + [Secondary Genre: Soul Pop], Core Instruments: Electric Guitar (bluesy bends), Acoustic Guitar, Bass Guitar, Drums (groove-focused), Support Instruments: Organ, Wurlitzer, Tempo: 85 BPM, Key: E Major, Mood: Smooth, Relaxed, Soulful, Vocal: Male, Silky Tenor, Bluesy Runs, Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Warm tube amp tone, vintage compression, FX: Spring Reverb, Tape Delay, Dynamic: mp → f → mp
```

### Alternative Rock (Coldplay Style)

```
[Primary Genre: Alternative Rock] + [Secondary Genre: Atmospheric Pop], Core Instruments: Piano, Electric Guitar (delay-heavy), Bass Guitar, Drums (anthemic), Support Instruments: Synth Pads, Strings, Glockenspiel, Tempo: 120 BPM, Key: Eb Major, Mood: Euphoric, Ethereal, Anthemic, Vocal: Male, Falsetto Moments, Emotional Delivery, Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Spacious mix, Brian Eno influence, FX: Long Reverb, Dotted Eighth Delay, Dynamic: p → ff → p
```

### Irish Folk Rock (Kodaline Style)

```
[Primary Genre: Irish Folk Rock] + [Secondary Genre: Cinematic Pop], Core Instruments: Acoustic Guitar, Piano, Electric Guitar (atmospheric), Bass Guitar, Drums (building), Support Instruments: Strings (cinematic), Choir Elements, Tempo: 75 BPM, Key: C Major, Mood: Heartbreak, Cinematic, Bittersweet, Vocal: Male, Emotional Tenor, Irish Lilt, Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Cinematic swell, orchestral build, FX: Hall Reverb, Subtle Delay, Dynamic: pp → ff → pp
```

---

## 📊 SONGWRITER DNA LIBRARY

| Artist | DNA Characteristics |
|--------|---------------------|
| Ed Sheeran | Acoustic fingerstyle, percussive, loop-based, storytelling |
| John Mayer | Bluesy fingerpicking, smooth tenor, relaxed groove |
| James Bay | Raspy vocals, raw emotion, organic rock |
| Jason Mraz | Funky syncopation, playful, jazzy, positive |
| The Script | Soulful Irish lilt, emotional rasp, explosive chorus |
| Coldplay | Anthemic falsetto, ethereal atmosphere, U2 influence |
| OneRepublic | Anthemic, orchestral, driving, cinematic |
| Goo Goo Dolls | Raspy rock, open tuning, vulnerable yet powerful |
| Lifehouse | Post-grunge, intimate verses, wall of sound chorus |
| Passenger | Whisper-folk, intimate, wanderlust themes |
| Hozier | Deep soulful voice, gospel influence, poetic lyrics |
| Lewis Capaldi | Emotional powerhouse, raw vulnerability, belting |
| Damien Rice | Delicate intensity, whisper-to-scream dynamics |
| Snow Patrol | Emotional build, stadium intimacy, simple profound lyrics |
| The Fray | Piano-rock, earnest delivery, radio-ready hooks |
| Kodaline | Irish heartbreak, cinematic swell, emotional crescendo |

---

# PART IV: THAI PROSODY SYSTEM

---

## 🇹🇭 วรรณยุกต์ TO PITCH MAPPING

| วรรณยุกต์ | Pitch | Contour | Placement |
|----------|-------|---------|-----------|
| สามัญ (Mid) | E4-A4 | mid flat | Stable notes |
| เอก (Low) | C4-G4 | mid-low falling | Descending |
| โท (Falling) | F3-C5 | high falling | High → Down |
| ตรี (High) | G4-D5 | high flat | Rising |
| จัตวา (Rising) | C4-A4 | rising | Low → High |

---

## 🎤 THAI PRONUNCIATION FIX (17 วิธี)

### BASIC FIXES

```yaml
1_short_lines:
  bad: "คืนนี้ฉันคิดถึงเธอมากเหลือเกินไม่รู้จะทำยังไง"
  good: |
    คืนนี้ฉันคิดถึงเธอ
    มากเหลือเกิน
    ไม่รู้จะทำยังไง
  rule: "4-8 พยางค์ต่อบรรทัด"

2_timing_marks:
  "...": "หยุดยาว"
  ",": "หยุดสั้น"
  "--": "หยุดกลาง"
  "-": "แบ่งพยางค์"

3_structure_tags:
  tags: ["[Verse 1]", "[Chorus]", "[Bridge]"]

4_word_swaps:
  เธอ: "เทอ"
  จะ: "จา"
  อยู่: "ยู"
  ไม่: "ไม"
  ก็: "ก้อ"
  ไป: "ปาย"

5_section_lines:
  verse: "4-6 บรรทัด"
  chorus: "4-6 บรรทัด"

6_vocal_tags:
  tags: ["(Clear Vocals)", "[Staccato]", "[Spoken Word]"]

7_section_spacing:
  rule: "เว้น 1 บรรทัดว่างระหว่าง sections"
```

---

## 🪕 THAI INSTRUMENTS

| Instrument | Sound Description |
|------------|-------------------|
| พิณ | Bright plucked strings, twangy, energetic |
| แคน | Reedy, nasal, continuous drone |
| ซอด้วง | High-pitched bowed strings, plaintive |
| ซออู้ | Lower bowed strings, melancholic |
| กลองยาว | Deep resonant drums, ceremonial |
| ฆ้องวง | Metallic circular melody |
| ระนาดเอก | Bright wooden xylophone |

---

# PART V: VOICE CLONING PIPELINE

---

## 🎙️ VOICE DNA ANALYSIS

```yaml
phase_1_analysis:
  elements:
    - "Timbre (นุ่ม/แหบ/ใส/ทุ้ม)"
    - "Range (C3-C5)"
    - "Vibrato (เร็ว/ช้า)"
    - "Breathiness (0-100%)"
    - "Delivery (belt/whisper/raspy)"
    - "Accent (Thai/Isan/English)"

phase_2_profile:
  - "Create Voice DNA JSON"
  - "Convert to Suno Vocal Tags"
```

---

## 🎤 VOICE DNA TEMPLATE

```yaml
voice_dna:
  voice_id: "VOICE-[REGION]-[GENDER]-[NUMBER]"
  gender: "male/female"
  
  ranges:
    male_bass: "E2-E4"
    male_baritone: "A2-A4"
    male_tenor: "C3-C5"
    female_alto: "F3-F5"
    female_mezzo: "A3-A5"
    female_soprano: "C4-C6"
    
  timbre_options: 
    - warm
    - bright
    - dark
    - raspy
    - clear
    - husky
    
  delivery_styles:
    - belt
    - whisper
    - raspy
    - falsetto
    - powerful
    - soft
    - emotional
```

---

# PART VI: META FORMAT SYSTEM

---

## 🎚️ META FORMAT STRUCTURE

```yaml
format: "[Section][META: Instrument with panning (L##/R##), Hz, reverb %, FX, dynamics]"

components:
  panning: "L0-L50, R0-R50, Center"
  hz: "low-pass 180Hz, 9k-12k boost"
  reverb: "reverb 12%, reverb 16%"
  dynamics: "pp, p, mp, mf, f, ff"
  fx: "delay 1/8D, chorus FX"
```

### Examples

```yaml
verse: "[Verse 1][META: Acoustic guitar fingerpicking L18, electric ambient shimmer R22, bass 180Hz, reverb 12%, dynamics mp]"

chorus: "[Chorus][META: Acoustic double-track L40/R40, electric bright sparkly L35/R35, tambourine center, dynamics mf→f]"

bridge: "[Bridge][META: Acoustic muted L16, reverse reverb swells R30, long hall reverb, dynamics p→mp]"
```

---

# PART VII: BATCH / AUTOMATION MODE

---

## 📦 BATCH COMMAND

```yaml
command: "/batch [จำนวน] [Genre/Style]"

examples:
  - "/batch 5 Soft Pop"
  - "/batch 10 Lo-Fi Chill"
  - "/batch 20 Acoustic Ballad"
  - "/batch 100 Christmas Chill"

options:
  same_songwriter: "/batch 10 Soft Pop --songwriter [ชื่อ]"
  rotate_songwriters: "/batch 10 Soft Pop --rotate-songwriters"
  custom_template: "/batch 10 Soft Pop --template [ชื่อ template]"

output: "แยกไฟล์ .md ทุกเพลง"
```

---

## 📄 BATCH OUTPUT FORMAT

```yaml
filename_pattern: "[NUMBER]_[Song_Title].md"

examples:
  - "001_Morning_Light.md"
  - "002_Gentle_Waves.md"
  - "003_Paper_Hearts.md"

file_structure: |
  # [Song Title]
  
  [NUMBER]_[Song_Title]
  
  ---
  
  # Lyrics
  
  [Section with META tags]
  [Lyrics]
  
  ---
  
  # Style
  
  [Full Style Prompt]
```

---

# PART VIII: QA CHECKLIST

---

## ✅ PRE-OUTPUT CHECKLIST

```
┌────────────────────────────────────────────┐
│  📋 SUNO MASTER QA CHECKLIST               │
├────────────────────────────────────────────┤
│                                            │
│  □ Style Prompt ≤ 1000 chars               │
│    → Character count verified?             │
│                                            │
│  □ NO Artist Names in Style                │
│    → ไม่มีชื่อศิลปินจริง?                    │
│                                            │
│  □ Thai Prosody (เพลงไทย)                  │
│    → วรรณยุกต์-melody mapping ถูกต้อง?      │
│    → Word swaps applied?                   │
│                                            │
│  □ Song Structure                          │
│    → Intro → Verse → Pre-Chorus → Chorus?  │
│    → Bridge → Outro → [End]?               │
│                                            │
│  □ Format Valid (Automation)               │
│    → ## เพลงที่ N?                          │
│    → **ชื่อเพลง:** N.Title (Subtitle)?      │
│    → **Songwriter Influence:**?            │
│    → --- หลังจบเพลง?                        │
│                                            │
│  □ Summary Table                           │
│    → มีครบทุกเพลง?                          │
│                                            │
└────────────────────────────────────────────┘
```

---

## ✅ SUNO AUTOMATION FILE CHECKLIST

```
┌────────────────────────────────────────────┐
│  📋 SUNO AUTOMATION FILE CHECKLIST         │
├────────────────────────────────────────────┤
│                                            │
│  □ Header: # 🎵 [Name] — [Style] ([N])     │
│    → ครบถ้วน?                              │
│                                            │
│  □ Subtitle: > Suno Automation Queue       │
│    → มี?                                   │
│                                            │
│  □ Style Prompt Section                    │
│    → ## 🎼 Style Prompt (ใช้ทุกเพลง)?      │
│    → อยู่ใน code block?                    │
│    → 1 บรรทัดเดียว?                        │
│                                            │
│  □ DNA Table (ถ้ามีหลาย DNA)               │
│    → ## 🎤 N Songwriters DNA Reference?    │
│                                            │
│  □ ทุกเพลงมี:                              │
│    → ## เพลงที่ N?                         │
│    → **ชื่อเพลง:** N.Title (Subtitle)?     │
│    → **Style:** (1 บรรทัด)?                │
│    → **เนื้อเพลง:**?                       │
│    → [Intro] with () description?          │
│    → [Verse 1] [Pre-Chorus] [Chorus]?      │
│    → [Verse 2] [Pre-Chorus] [Chorus]?      │
│    → [Bridge]?                             │
│    → [Outro] with () description?          │
│    → [End]?                                │
│    → **Songwriter Influence:**?            │
│    → --- หลังจบเพลง?                       │
│                                            │
│  □ Summary Table                           │
│    → # 📋 Summary Table — N Songs?         │
│    → มีทุกเพลง?                            │
│                                            │
│  □ Footer                                  │
│    → 🔥 Generated by MRARRANGER?           │
│                                            │
└────────────────────────────────────────────┘
```

---

# PART IX: WORKFLOW

---

## 🔄 SUNO MASTER WORKFLOW

```
┌─────────────────────────────────────────────────────────────┐
│  🎵 SUNO MASTER PRODUCTION WORKFLOW                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  STEP 1: 📋 RECEIVE BRIEF                                   │
│  ─────────────────────────────────────────                  │
│  • รับ Brief จากผู้ใช้                                       │
│  • วิเคราะห์ประเภทงาน (Single/Batch/Clone)                  │
│  • กำหนด Output Format (2 หรือ 3 Blocks)                    │
│                                                             │
│  STEP 2: 🔬 DNA RESEARCH                                    │
│  ─────────────────────────────────────────                  │
│  • Web Search Artist/Song DNA                               │
│  • วิเคราะห์ 7 DNA Categories                                │
│  • สร้าง DNA Report                                         │
│                                                             │
│  STEP 3: 🎼 STYLE DECODE                                    │
│  ─────────────────────────────────────────                  │
│  • สร้าง Style Prompt (≤1000 chars)                         │
│  • ไม่มีชื่อศิลปิน                                           │
│  • ONE LINE format                                          │
│                                                             │
│  STEP 4: ✍️ LYRICS WRITING                                  │
│  ─────────────────────────────────────────                  │
│  • เขียนเนื้อเพลงตาม DNA                                     │
│  • Thai Prosody (เพลงไทย)                                   │
│  • Structure: Intro → Outro → [End]                         │
│                                                             │
│  STEP 5: ✅ QA CHECK                                        │
│  ─────────────────────────────────────────                  │
│  • ตรวจ Style Prompt length                                 │
│  • ตรวจ Prosody (Thai)                                      │
│  • ตรวจ Format                                              │
│                                                             │
│  STEP 6: 📤 OUTPUT                                          │
│  ─────────────────────────────────────────                  │
│  • Clean Blocks (Single)                                    │
│  • .md Files (Batch/Automation)                             │
│  • Summary Table (Automation)                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 FORMAT LOCK ACTIVE

> กฎนี้มีผลบังคับใช้ตลอดเวลา ไม่มีข้อยกเว้น
> 
> ถ้าไม่ใช้ Format ตามนี้ = ไฟล์จะไม่ทำงานกับ Suno Automation

---

🔥 **Generated by MRARRANGER AI STUDIO — Suno Master Skill**