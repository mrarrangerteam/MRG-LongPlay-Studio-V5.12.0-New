---
name: mrarranger-investor-fundraise
description: "MRARRANGER Investor Relations and Fundraising - Pitch Deck Strategy, Investor Outreach, Term Sheet Analysis, Cap Table Management, Due Diligence Preparation, Financial Projections, Valuation Methods (DCF, Comparable, Precedent), Funding Rounds (Pre-seed to Series C+), Investor Updates, Board Meeting Prep, Exit Strategy, Venture Debt, SAFE/Convertible Notes. Commands: /pitch /investor /termsheet /captable /duediligence /valuation /fundraise /board /exit /safe. Triggers: pitch deck, investor, fundraising, term sheet, cap table, valuation, due diligence, Series A, SAFE"
---

# Investor Relations & Fundraising Skill

## Overview

This skill provides comprehensive guidance on venture capital fundraising, investor relations, and growth capital management. It covers the complete fundraising journey from pitch strategy through exit, enabling founders to effectively communicate with and secure capital from investors.

## Core Competencies

### 1. Pitch Deck Strategy & Design

**Pitch Deck Purpose & Audience**

**When to Use Pitch Deck**:
- Investor meetings (in-person or virtual)
- Conference presentations
- Demo days
- Board updates
- Internal alignment
- Partnership discussions

**Audience Considerations**:
- Investor type (angel, early-stage VC, growth-stage PE)
- Industry expertise (depth vs breadth)
- Investment ticket size and focus
- Geographic focus and stage
- Previous startup experience

**Deck Structure** (10-12 slides)

**1. Cover Slide**
- Company name and logo
- Tagline (one-liner value proposition)
- Founder names
- Date

**2. Problem Statement**
- Specific, painful problem
- Quantify the opportunity (market size, urgency)
- Who has the problem (target customer)
- Current solutions and why they're insufficient
- Emotional connection to problem

**3. Solution**
- Your approach to solving the problem
- Key features and benefits
- Why you're uniquely positioned
- Visual demo or mockup
- Differentiation from alternatives

**4. Market Opportunity**
- Total addressable market (TAM)
- Serviceable addressable market (SAM)
- Serviceable obtainable market (SOM)
- TAM growth projections
- Market trends supporting opportunity

**5. Business Model**
- How you make money (pricing, unit economics)
- Revenue streams
- Key assumptions
- Gross margin and LTV:CAC ratio
- Path to profitability

**6. Traction & Validation**
- Customer acquisition (# customers, MRR, revenue)
- Growth rates and trajectory
- Key partnerships or validation
- Press coverage or awards
- Product metrics (usage, engagement)
- Testimonials or case studies

**7. Go-to-Market Strategy**
- Customer acquisition channels
- Sales process and cycle length
- Marketing approach
- Distribution partnerships
- Expansion strategy

**8. Team & Organization**
- Founding team bios (education, experience)
- Key hires and advisors
- Relevant expertise and background
- Why this team can execute
- Board of advisors

**9. Competition & Defensibility**
- Competitive landscape
- Direct and indirect competitors
- Your competitive advantage
- Barriers to entry (IP, data, network)
- Why you'll win

**10. Use of Funds**
- Funding ask (amount and valuation implied)
- Breakdown by category (product, marketing, team)
- 18-24 month runway plan
- Key milestones to achieve
- Path to next funding round

**11. Financial Projections**
- 5-year revenue forecast
- Key assumptions documented
- Unit economics and growth rates
- Gross margin trajectory
- Path to profitability or cash flow positive

**12. Call to Action**
- Investment ask
- Next steps
- Contact information
- Optional: vision/impact statement

**Design Best Practices**

**Visual Design**:
- Clean, modern design (no cluttered slides)
- Consistent branding and color scheme
- Large, readable fonts (40+ pt minimum)
- Professional imagery (avoid generic stock photos)
- Data visualization (charts, graphs over tables)
- Limited text (use speaker notes for detail)
- One key message per slide

**Storytelling**:
- Narrative arc (problem → solution → traction → vision)
- Emotional opening (relatable problem)
- Clear logic flow
- Specific examples and stories
- Numbers and quantification
- Anticipate investor questions
- End with vision/impact

**Common Mistakes**:
- Too much text on slides
- Unclear problem or unclear how you solve it
- Not demonstrating traction
- Weak or unfocused team story
- Overly optimistic projections without assumptions
- No clear ask or call to action
- Generic competitive analysis
- Poorly explained unit economics

**Pitch Deck Variations**

**Early-stage (Pre-seed/Seed)**:
- Focus on problem, team, and vision
- Traction less critical (progress acceptable)
- Quick prototype or mockup
- Team background and passion
- Market size estimation (less precise)

**Growth-stage (Series A/B/C)**:
- Strong traction and growth metrics
- Detailed unit economics
- Clear path to profitability or exit
- Experienced team with relevant background
- Large market opportunity
- Competitive differentiation

**Series D+**:
- Profitability or clear path to it
- Significant revenue base
- Enterprise/institutional customers
- Management team depth
- International expansion plans
- Strategic positioning for exit

### 2. Investor Outreach & Relationship Building

**Investor Identification**

**Investor Types**:
- **Angel Investors**: High-net-worth individuals, typically early-stage
- **Seed-stage VCs**: Small funds, early companies, $0.5-3M checks
- **Early-stage VCs (Series A/B)**: Larger funds, growth companies, $2-10M checks
- **Growth-stage VCs (Series C+)**: Large funds, efficient growth, $10M+ checks
- **Corporate Venture**: CVC arms of large companies, strategic interest
- **Venture Debt**: Non-dilutive capital, expects repayment with interest
- **PE Firms**: Later-stage, buyout focus, operational expertise

**Finding Investors**:
- AngelList (now Wellfound), Angel investors
- PitchBook, Crunchbase, CB Insights databases
- LinkedIn networking and warm intros
- Industry conferences and pitch competitions
- Existing investor networks and portfolios
- Accelerators and incubators
- Industry-specific VCs and blogs

**Screening for Fit**:
- Investment stage (do they invest at your stage?)
- Check size (minimum/maximum they write)
- Industry/vertical (do they specialize?)
- Geography (local or willing to travel?)
- Track record (exits, returns, company building)
- Value-add (beyond capital, expertise/network)
- Investment thesis alignment

**Warm Introductions**

**Importance**:
- 50-100x higher response rate than cold emails
- Mutual vouching builds credibility
- Establishes context and relevance
- Investors trust their networks

**Asking for Introductions**:
- Identify connectors (founders they've backed, advisors, employees)
- Personalize request (why specific investor)
- Provide context (company, round, ask)
- Make introduction easy (short summary, mutual benefit)
- Thank promptly and update on outcome
- Pay it forward (introduce others)

**Outreach Strategy**

**Timing & Sequencing**:
- Start 3-4 months before capital needed
- Create momentum (multiple conversations)
- Create scarcity (but be honest about process)
- Don't approach all investors simultaneously
- Follow-up cadence: initial → week 2 → week 4 → pause → re-engage

**Email Template**:
- Subject: "Intro to [investor] via [mutual connection]"
- Opening: Establish common connection and credibility
- Problem/Opportunity: 1-2 sentences of what you're solving
- Traction: Key metrics or validation
- Ask: Specific ask (meeting, feedback, intro to others)
- Attachment: 1-page summary or pitch deck link
- Tone: Confident but humble, eager but not desperate

**Meeting Logistics**:
- Timezone and schedule convenience
- 30-minute initial meetings (scoping)
- 1-hour follow-up meetings (deep dive)
- In-person preferred if possible (or high-quality video)
- Professional setting (your office, coffee, or coworking)
- Prepare specific questions
- Follow up with notes and next steps

### 3. Term Sheet Analysis & Negotiation

**Term Sheet Components**

**Key Terms Overview** (typical startup term sheet):

**Valuation-Related**:
- **Valuation**: Pre-money (before investment) and post-money (after)
- **Investment Amount**: Total capital being raised
- **Price Per Share**: Calculated from valuation and shares outstanding
- **Pre-emptive Rights**: Investor's right to participate in future rounds

**Governance & Control**:
- **Board Seats**: Representation in company governance
- **Voting Rights**: Approval for major decisions (hiring, budgets, exits)
- **Protective Provisions**: Veto rights on major actions
- **Drag-along Rights**: Ability to force minority shareholders to sell

**Economic & Liquidation**:
- **Liquidation Preference**: Order of payout in acquisition/exit
- **Participating vs Non-participating**: Can investor get both preference + pro-rata?
- **Conversion Rights**: Preferred stock conversion to common
- **Dividend Rights**: Annual dividend (typically 0% for growth companies)

**Anti-dilution**:
- **Weighted Average**: Protects against lower valuations in future rounds
- **Full Ratchet**: Most aggressive protection (rarely given)
- **No Anti-dilution**: Simplest (founders prefer)

**Dilution Example**:
- Series A: $10M pre-money valuation, $2M investment
- If Series B at lower valuation (down round):
  - Weighted average: Adjustment based on amount raised and down amount
  - Full ratchet: Investor gets significantly more shares (harsh on founders)

**Term Sheet Analysis**

**Red Flags**:
- Excessive board seats (should be <50%)
- Overly broad protective provisions (hard to operate)
- Unusual anti-dilution terms (suggests challenging investor)
- Onerous governance requirements (slow decision-making)
- Unusual liquidation preferences (1x, 2x, 3x preferences)
- Drag-along with low thresholds (can force exit prematurely)

**Standard Terms** (Seed/Series A):
- 1x non-participating liquidation preference (return investment before other payouts)
- Single-digit board seat
- Weighted-average anti-dilution
- Standard protective provisions (hiring, budget, major sales)
- Conversion rights (preferred → common)
- No dividend
- Founder-friendly timing and vest

**Negotiation Strategy**

**Before Negotiation**:
- Get legal counsel (startup lawyer familiar with VC)
- Understand investor's motivations
- Know your walk-away terms
- Get multiple offers if possible
- Benchmark against market standards

**Key Negotiation Points**:
1. **Valuation**: Most critical, impacts your ownership
2. **Anti-dilution**: Affects future dilution
3. **Board seats**: Impacts operational control
4. **Protective provisions**: Affects day-to-day decisions
5. **Liquidation preference**: Impacts investor return structure

**Negotiation Tactics**:
- Get offers from multiple investors (create competition)
- Understand investor's constraints (board approval needed, fund size)
- Separate value discussions from other terms
- Use silence (don't negotiate against yourself)
- Know when to concede (focus on most important terms)
- Document everything in writing
- Stay professional and relationship-focused

**Common Tradeoffs**:
- Higher valuation ↔ more protective provisions
- Lower valuation ↔ founder-friendly governance
- Board seat ↔ less hands-on investor
- Weighted-average ↔ full ratchet anti-dilution

**After Signing**:
- Ensure proper documentation (stock certificates, board paperwork)
- Understand regulatory compliance (securities law)
- Maintain good investor relations
- Execute on milestones
- Keep investor updated

### 4. Cap Table Management & Ownership Tracking

**Cap Table Fundamentals**

**What Is a Cap Table?**
- Comprehensive record of company ownership
- Shows each shareholder and share count
- Reflects dilution over time and funding rounds
- Critical for taxes, compliance, fundraising, and exit

**Cap Table Components**:
- Founder shares and vesting schedules
- Employee option pool (size and vesting)
- Investor shares and preferred stock classes
- Convertible notes and their terms
- SAFEs and their conversion mechanics
- Warrants and other options
- Any special shares or classes

**Cap Table Creation & Maintenance**

**Initial Setup**:
1. Determine total authorized shares
2. Issue founder shares with vesting (typically 4-year, 1-year cliff)
3. Set aside option pool (10-20% for early stage)
4. Document all equity grants
5. Board resolutions for each grant
6. Stock ledger maintenance

**Tools & Templates**:
- Manual (Excel spreadsheet)
- Carta or Pulley (cap table software)
- Legal templates (Cooley, LawDepot)
- Accountant review for accuracy
- Annual updates and true-up

**Dilution & Ownership Impact**

**Dilution Calculation**:
- Pre-money valuation: $10M
- Investment: $2M
- Post-money: $12M
- Investor ownership: 2M/12M = 16.7%
- Founder ownership decreases proportionally

**Multiple Rounds Example**:
- Founder: 1,000,000 shares (100% at inception)
- Series A: Investor gets 200,000 shares for $2M (post-money $12M)
  - Founder ownership: 1,000,000 / 1,200,000 = 83.3%
- Series B: New investor gets 400,000 shares for $4M (post-money $16M)
  - Founder ownership: 1,000,000 / 1,400,000 = 71.4%

**Shareholder Communications**:
- Cap table not shared externally (confidential)
- Ownership % communicated to board/investors
- Equity statements to employees (showing own grants)
- Updates with each funding round
- Transparency about dilution

### 5. Due Diligence Preparation

**Due Diligence Overview**

**What Is Due Diligence?**
- Investor's investigation of company before investing
- Confirms representations in pitch deck
- Identifies risks and issues
- Takes 4-8 weeks typically

**Types of Due Diligence**:
- **Financial**: Audit of financial statements, projections
- **Legal**: Corporate structure, IP, contracts
- **Technical**: Product roadmap, architecture, security
- **Market**: TAM, competitive positioning, customer validation
- **Operational**: Team, processes, risks

**Due Diligence Preparation**

**Data Room Setup**:
- Secure folder or platform (Dropbox, Google Drive, or specialized data room software)
- Organized by category
- Clear file naming and structure
- Access control and audit trails
- Document list/index

**Essential Documents by Category**:

**Corporate & Legal**:
- Articles of incorporation and bylaws
- Cap table (fully diluted)
- Board minutes and resolutions
- Shareholder agreements
- Option pool and grant documents
- Employment agreements
- Equity incentive plans

**Financial**:
- Audited or reviewed financial statements
- Monthly P&L and balance sheet (last 12 months)
- Financial projections (3-5 years)
- Unit economics analysis
- Cash flow projections
- Key assumptions documented

**Contracts & Intellectual Property**:
- Customer contracts (largest 5-10)
- Partner agreements
- Vendor/supplier contracts
- IP assignment agreements (employees, contractors)
- Patent/trademark registrations
- Open source license compliance

**Product & Technology**:
- Product roadmap
- Technical architecture overview
- Security and data protection measures
- Disaster recovery and backup procedures
- Development methodology
- Key metrics dashboard

**Market & Customers**:
- Customer list and contract values
- Customer testimonials and case studies
- Market research and TAM analysis
- Competitive analysis
- Win/loss analysis
- References (customer and partner)

**Team**:
- Founder and key team bios
- Org chart
- Board and advisor information
- Key employee agreements
- Advisors and their backgrounds

**Compliance & Risk**:
- Regulatory compliance status
- Data privacy and security procedures
- Insurance policies
- Known issues or risks
- Litigation history (if any)
- Regulatory filings

**Due Diligence Calls & Meetings**

**Investor Calls**:
- Financial deep dive (CFO or founder)
- Technology and product (CTO or product lead)
- Sales and customer dynamics (CEO or VP Sales)
- Team capability and background

**Customer References**:
- Investor talks to 3-5 key customers
- Validate growth and satisfaction
- Understand use cases
- Gauge likeliness to renew/expand

**Red Flags During Due Diligence**:
- Information inconsistencies
- Missing documents
- Outdated or inaccurate projections
- Undisclosed customer churn
- Key person dependencies
- IP or legal issues
- Regulatory concerns
- Unresolved conflicts with shareholders

**Addressing Issues**:
- Transparency and honesty
- Explain context and mitigation
- Provide resolution timeline
- Don't hide or misrepresent
- Address head-on, not defensively

### 6. Financial Projections & Unit Economics

**Financial Projection Framework**

**5-Year Projections** (typical investor requirement):

**Top-Down Revenue**:
- Year 1: $100K MRR × 12 = $1.2M ARR
- Growth rate: 10% monthly → annual 120% growth
- Year 2: $1.2M × 3.2x growth = $3.8M
- Year 3-5: Decelerating growth (80%, 60%, 40%)

**Bottom-Up Revenue**:
- Customers × Average Contract Value (ACV) × months
- Year 1: 50 customers × $2,000 ACV × 12 = $1.2M
- Add growth: new customer acquisition + upsell

**Operating Expenses**:
- Salaries: Headcount plan with cost per role
- Marketing: CAC × customers acquired
- Product/Engineering: Salary + infrastructure
- General & Administrative: Corporate overhead
- Other: Office, tools, insurance

**Key Metrics to Project**:
- Monthly recurring revenue (MRR)
- Customer acquisition cost (CAC)
- Lifetime value (LTV)
- Churn rate
- Gross margin %
- Burn rate and runway

**Unit Economics Deep Dive**

**Customer Acquisition Cost (CAC)**:
- Total marketing spend / New customers acquired
- Example: $50,000 marketing / 100 new customers = $500 CAC
- Should be <15% of first-year revenue (targets vary by model)
- Payback period: (CAC) / (Monthly margin per customer)

**Lifetime Value (LTV)**:
- (Monthly revenue per customer - Monthly cost) × Customer lifetime (months)
- Example: ($2,000 - $500) / monthly × 36 months = $54,000 LTV
- LTV:CAC Ratio: Should be 3:1 minimum (higher is better)
- LTV:CAC of 5:1 or higher shows strong unit economics

**Churn Rate**:
- % of customers lost per month
- Impact on LTV: Higher churn = shorter lifetime
- Example: 5% monthly churn = 20-month average customer lifetime
- Lower churn enables lower CAC payback and higher LTV

**Gross Margin**:
- (Revenue - Cost of Goods Sold) / Revenue
- SaaS: 70-90% typical
- Marketplace: 20-40% typical
- Physical product: 30-60% typical
- Target improvement: Show path to higher margins

**Important Notes on Projections**:
- Document key assumptions clearly
- Be realistic (50-150% of actual is acceptable)
- Conservative is better than overly optimistic
- Show scenario analysis (base, upside, downside)
- Update frequently as actual results arrive
- Explain variances to prior projections

### 7. Valuation Methods & Analysis

**Valuation Approaches**

**1. Discounted Cash Flow (DCF) Analysis**

**Process**:
1. Project future cash flows (5-10 years)
2. Estimate terminal value (value at end of projection)
3. Discount flows to present value using discount rate
4. Sum PV of flows + terminal value = company value

**Formula**: PV = CF1/(1+r) + CF2/(1+r)² + ... + Terminal Value/(1+r)^n

**Example**:
- Year 1 cash flow: -$500K (burn)
- Year 2: -$200K
- Year 3-5: Positive cash flow increasing
- Terminal value: $50M exit
- Discount rate: 40% (high risk startup)
- DCF valuation: ~$10-15M

**Advantages**: Theoretically sound, based on economics
**Disadvantages**: Highly sensitive to assumptions, difficult for early-stage

**2. Comparable Company Analysis**

**Methodology**:
1. Identify comparable public companies
2. Calculate valuation multiples (EV/Revenue, EV/EBITDA)
3. Apply to your company's financials
4. Adjust for differences (growth, margins, market)

**Example**:
- Comparable SaaS company: $1B market cap, $100M revenue
- EV/Revenue multiple: 10x
- Your company: $5M revenue
- Valuation: 10x × $5M = $50M

**Challenges**: Limited comparables for early-stage, public ≠ private

**3. Precedent Transactions**

**Methodology**:
1. Identify recent acquisitions of similar companies
2. Analyze purchase price multiples
3. Adjust for your company's metrics
4. Apply multiples to your company

**Example**:
- Company A acquired for $100M (had $10M revenue)
- Multiple: 10x revenue
- Company B acquisition: $150M (had $12M revenue)
- Multiple: 12.5x revenue
- Your company with $5M revenue: 11x average → $55M valuation

**Timing**: Most relevant in later stages and around acquisitions

**Valuation in Different Stages**

**Seed/Pre-seed**:
- Minimal financials, use Comparable Startup Method
- Typical: 0.1x - 0.5x future Series A valuation
- Post-money: $2-5M typical
- Pure equity-based (no cash flow metrics)

**Series A**:
- Early traction available
- Revenue multiple method (1-5x revenue typical)
- Or DCF with high discount rate
- Typical: $5-20M post-money

**Series B/C**:
- Predictable revenue
- Revenue multiples: 5-20x
- Growth-adjusted valuations
- Market comparables emerging
- Typical: $30-100M+ post-money

**Series D+**:
- Strong profitability or clear path to it
- Public market comparables most relevant
- EV/Revenue multiples of 10-50x+
- Typical: $100M+ pre-money

### 8. Funding Rounds & Investment Structures

**Funding Round Types & Sequence**

**Pre-seed**:
- Amount: $100K - $500K
- Sources: Founders, angels, friends/family
- Purpose: Product development, market validation
- Typical: 15-25% dilution

**Seed Round**:
- Amount: $500K - $2M
- Sources: Seed VCs, angels, incubators
- Purpose: Product-market fit, first customers
- Typical: 20-30% dilution
- Note: May use SAFEs or convertible notes

**Series A**:
- Amount: $2M - $10M
- Sources: Early-stage VCs
- Purpose: Scale sales and marketing, expand team
- Typical: 25-35% dilution
- Note: Priced round (preferred stock)

**Series B**:
- Amount: $10M - $50M
- Sources: Growth-stage VCs
- Purpose: Enter new markets, product expansion
- Typical: 20-30% dilution
- Note: Multiple lead and follow-on investors

**Series C & Beyond**:
- Amount: $50M+
- Sources: Growth VCs, late-stage, crossover
- Purpose: Rapid scaling, market domination
- Typical: 15-25% dilution per round

**Alternative Funding Structures**

**Convertible Notes**:
- Debt that converts to equity at Series A
- Includes discount (e.g., 20% off Series A price)
- Cap: Maximum valuation at conversion
- Term: Maturity date (typically 2-3 years, converts or repays)
- Useful for: Bridge financing, early funding
- Risk: May not convert if no Series A

**SAFE (Simple Agreement for Future Equity)**:
- Not debt, not equity (pre-emptive rights only)
- Simpler and faster than convertible note
- Discount and/or valuation cap
- Converts on Series A, acquisition, or IPO
- No interest or maturity date
- Increasingly standard (Y Combinator uses)

**Equity**:
- Direct share issuance
- Most transparent
- Triggers immediate capitalization table update
- Standard in Series A+ rounds

**Advantages/Disadvantages**:
- Convertible notes: Simpler, delayed valuation, interest owed
- SAFEs: Simpler, investor-friendly, convertible only
- Equity: Transparent, clear ownership, more complex legal

### 9. Investor Updates & Communications

**Investor Update Cadence**

**Frequency**:
- Monthly: Standard for seed/early-stage
- Quarterly: Once institutional investors involved
- As-needed: Major milestones (fundraising close, major win)

**Format**:
- Email (most common)
- Slide deck (quarterly preferred)
- In-person (annually recommended)
- Video message (adds personalization)

**Investor Update Content**

**Monthly Update Structure** (1-2 pages):

**Metrics**:
- MRR/ARR and growth rate
- Customer count and growth
- Key product metrics (DAU, engagement, etc.)
- Burn rate and runway
- Key OKR progress

**Highlights**:
- Major wins (customers, partnerships, press)
- Product releases and progress
- Team updates (hires, departures)
- Market opportunities

**Challenges & Asks**:
- Current obstacles or risks
- What you need help with (intros, advice)
- Specific asks for investor support

**Tone & Style**:
- Transparent (good and bad)
- Concise (investors are busy)
- Quantified (metrics, specific numbers)
- Forward-looking (what's next)
- Avoid hype or over-spinning

**Bad Updates**:
- Vague metrics (no numbers)
- All positive with no challenges
- Asking for money without context
- Missing for months then reaching out
- Generic content not specific to company

**Nurturing Investor Relationships**

**Pro Tips**:
- Include investor in wins (tag in press release, customer reference)
- Seek advice proactively (help on recruiting, customer strategy)
- Update even in slow months
- Celebrate milestones with investors
- Annual in-person visits (if local)
- Introduce investors to each other (network building)
- Ask for intros to other investors or customers
- Be responsive to investor questions/requests

### 10. Board Meetings & Governance

**Board Meeting Purpose & Frequency**

**Typical Schedule**:
- Quarterly: Standard for VC-backed startups
- 1.5-2 hours per meeting
- In-person preferred but virtual acceptable
- Regular schedule (same day each quarter)

**Board Composition**:
- Founder/CEO (always)
- Board chair (outside investor or founder)
- Board members: 3-5 typical
  - 1-2 investors
  - Outside independent director (helps with governance)
  - Sometimes another founder

**Board Meeting Agenda**

**Standard 90-Minute Meeting**:

**1. Strategic Update (30 min)**:
- Metrics review (revenue, growth, engagement)
- Wins and challenges
- Market and competitive changes
- Strategic initiatives progress

**2. Financial Review (20 min)**:
- Actual results vs. forecast
- Balance sheet and cash position
- Runway calculation
- Key assumptions changes

**3. Risk Discussion (10 min)**:
- Major risks and mitigation
- Competitive threats
- Technical/operational risks
- Market risks

**4. Governance Items (15 min)**:
- Option grants and equity matters
- Major contract approvals
- Officer appointments
- Committee assignments

**5. Closed Session (if needed)**:
- Investor-only discussion
- Compensation review
- CEO performance feedback

**Board Preparation**

**Pre-Meeting Deliverables** (48 hours before):
- Board deck (10-15 pages)
- Financial statements and commentary
- KPI dashboard
- List of decisions needed

**Board Deck Contents**:
- Cover page with highlight summary
- Metrics page (revenue, growth, key KPIs)
- Product/feature updates
- Sales and marketing update
- Team and organizational updates
- Financial dashboard
- Risk and mitigation
- Strategy and initiatives
- Decisions/approvals needed
- Appendix with detailed data

**During Meeting**:
- Clear presenter (usually CEO)
- Prepare for questions and debate
- Take notes on action items
- Document decisions made
- Record minutes for compliance

**Post-Meeting**:
- Distribute meeting minutes
- Track action items with owners
- Update on commitments made
- Share investor intros or help promised

### 11. Exit Strategy & Planning

**Exit Types & Timelines**

**Acquisition (Most Common)**:
- **Strategic Acquisition**: Acquired by larger company in same/adjacent market
- **Financial Acquisition**: Acquired for financial returns
- **Timeline**: 5-10 years typical
- **Valuation**: 5-20x revenue, varies greatly
- **Impact**: Founder may leave or stay, employees absorbed

**Initial Public Offering (IPO)**:
- **Requirement**: $100M+ revenue, strong growth
- **Timeline**: 10+ years
- **Valuation**: Public market multiples (varies)
- **Impact**: Founders often stay, company transforms

**Secondary Sale**:
- **What**: Earlier investors and employees liquidate shares
- **When**: Between rounds, after successful exit signal
- **Impact**: Partial liquidity before exit

**Exit Strategy Development**

**Questions to Clarify**:
1. Who are potential acquirers? (strategic or financial)
2. What makes your company attractive acquisition target?
3. What's your timeline? (5-year, 10-year plan)
4. How does this shape product and team building?
5. What's your minimum acceptable exit value?

**Acquirer Identification**:
- Competitors in your market
- Adjacent market players who could benefit
- Large tech companies (often acquihires for talent)
- Strategic partners
- Roll-up platforms in your category

**Exit Preparation** (2-3 years before):

**Financial**:
- Clean financial statements and processes
- Documented revenue contracts
- Clear cost structure
- Unit economics and CAC/LTV clarity

**Operational**:
- Documented processes and procedures
- Scalable infrastructure and systems
- Management team (less dependent on founder)
- No key person dependencies

**Legal**:
- Clean cap table
- Clear IP ownership
- No litigation or unresolved issues
- Up-to-date contracts
- Properly documented equity

**Product**:
- Market leadership or defensibility
- Scalable architecture
- Customer testimonials and references
- Documented roadmap
- Technology differentiation

**Team**:
- Experienced leadership team
- Documented hiring and promotion practices
- Key retention agreements (if critical)
- Culture documentation

### 12. Venture Debt & Non-dilutive Funding

**Venture Debt Overview**

**What Is It?**
- Debt financing for startups
- Repayment expected (not equity)
- Typically 3-5 year term
- Interest rates: 10-20% annually
- Can be combined with equity financing

**Use Cases**:
- Bridge financing between equity rounds
- Working capital for growth
- Non-dilutive capital (no ownership given)
- Extend runway without equity dilution
- Growth acceleration (hire, market)

**Structure**:
- Principal: Amount borrowed (e.g., $1M)
- Interest: 10-20% annually
- Term: 36-60 months
- Warrants: Discount to equity (0.5-3% warrant coverage)
- Covenants: Financial metrics to maintain

**Venture Debt Providers**:
- Specific debt funds (Silicon Valley Bank, Horizon Technology, Clearco)
- Banks with VC lending divisions
- Non-bank fintech lenders
- Credit lines secured by future revenue (MRR-based)

**Advantages & Disadvantages**:

**Advantages**:
- Non-dilutive (no equity given up)
- Preserves founder ownership
- Can extend runway significantly
- Forces financial discipline
- Can accelerate growth if used strategically

**Disadvantages**:
- Fixed obligation to repay
- Reduces available cash
- May not be available until strong revenue
- Interest and warrant coverage costs
- Requires financial covenants

**Venture Debt Negotiation**:
- Interest rate (lower is better)
- Warrant coverage (lower is better)
- Repayment terms (longer is better)
- Prepayment penalties (avoid or minimize)
- Financial covenants (must be achievable)

### 13. SAFE & Convertible Note Terms

**SAFE (Simple Agreement for Future Equity)**

**Mechanics**:
- Investment amount with SAFE agreement
- Converts to preferred stock at Series A
- Discount to Series A price (e.g., 20%)
- Valuation cap (maximum value for conversion)
- MFN (Most Favored Nation) clause

**Example Conversion**:
- Investment: $100K SAFE with 20% discount and $1M cap
- Series A: Valued at $5M, $1M investment
- Conversion: $100K SAFE converts at $1M valuation (capped)
- Shares: $100K ÷ ($1M ÷ capitalization) = higher share count than new investors

**Advantages** (for investors):
- Simple and fast
- Lower legal costs
- No interest accrual
- MFN ensures fairness across SAFEs
- Clear conversion mechanics

**Advantages** (for founders):
- Faster than convertible notes
- No interest obligation
- No maturity date stress
- Increasingly standard (easy for investors)

**Convertible Notes**

**Mechanics**:
- Loan with interest (often 2-4% simple interest)
- Converts to preferred stock at Series A
- Discount to Series A price (e.g., 20%)
- Valuation cap (maximum conversion value)
- Maturity date (e.g., 2 years)

**Difference from SAFE**:
- Convertible notes accrue interest
- Convertible notes have maturity date (repayment deadline)
- SAFE has no interest, no maturity
- Convertible note is debt; SAFE is not

**If No Series A**:
- Convertible notes: Must repay principal + interest at maturity
- SAFEs: No repayment obligation (no equity, just future rights)

**Negotiation Terms**:
- Interest rate (2-6% typical)
- Discount (15-30% typical)
- Valuation cap ($500K-$3M typical for early seed)
- Maturity date (18-36 months)
- MFN clause (fairness across investors)

## Quick Reference

### Common Commands & Triggers
- `/pitch` - Pitch deck strategy and design
- `/investor` - Investor outreach and relationships
- `/termsheet` - Term sheet analysis and negotiation
- `/captable` - Cap table management and dilution
- `/duediligence` - Due diligence preparation
- `/valuation` - Valuation methods and analysis
- `/fundraise` - Fundraising process and strategy
- `/board` - Board meetings and governance
- `/exit` - Exit strategy and planning
- `/safe` - SAFE and convertible note mechanics

## Conclusion

Successful fundraising requires strategic planning, clear communication, and disciplined execution. Understanding investor perspectives, preparing thoroughly, and maintaining excellent investor relations transforms capital raising from a painful necessity into a value-creating partnership that accelerates company growth.
