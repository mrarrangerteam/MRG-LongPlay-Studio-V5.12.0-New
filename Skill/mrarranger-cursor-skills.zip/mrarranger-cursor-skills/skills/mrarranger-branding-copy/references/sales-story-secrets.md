# sales-story-secrets

**Source:** `/mnt/skills/user/sales-story-secrets/SKILL.md`

---

---
name: sales-story-secrets
description: "Sales Story Secrets — ระบบสร้าง Sales Story ครบวงจรจาก Jim Edwards (Sales Story Secrets Master Class + Hero's Journey Webinar + Video Story Brainstorming Wizard) รวม Hero's Journey Story Arc 9 ขั้น, 7 Story Blueprints (Against All Odds, Real World Desperation, I'm Mad As Hell, Plain Sight Secret, Zero To Hero, Hidden Genius, Unknown Prophet), Story Sandwich Method (Intro→Story→Transition), Hook-Story-Offer Integration, 32+ Story Intros, 7 Story Outros, 3 Transition Methods (Benefit/PAS/Straight), 3 Story Elements (Characters/Plot/Movement), Story Length Guidelines + Chapter System, Engagement→Know→Story Framework, Emotional Resolution Table, Don't Overthink It Checklist, Basic 3-Step Story Formula (Quick Start), Emotional Storytelling Tips, Story Perspective (1st/3rd person), 50+ Story Brainstorming Prompts, Video Story Brainstorming (4 Core Questions × 6 Sources = 20+ Ideas), Reverse Engineering Story Points, 5 Real Case Studies with Revenue Proof, Secret Weapon Resources. ใช้เมื่อ: (1) สร้าง Sales Story สำหรับ Sales Page/VSL/Webinar (2) เขียน Origin Story/Brand Story (3) สร้าง Hero's Journey Outline แบบละเอียด (4) เลือก Story Blueprint ที่เหมาะกับธุรกิจ (5) เขียน Story Transitions เข้า-ออก (6) Brainstorm Story Ideas สำหรับ Video/Content (7) วิเคราะห์ Sales Story ที่มีอยู่ (8) สร้าง Emotional Story Copy (9) เขียน Story สำหรับ Email/Blog/FB Live/YouTube/TikTok (10) สร้าง Case Study Story (11) สร้าง Hook-Story-Offer Structure (12) แบ่ง Story เป็น Chapters สำหรับเนื้อหายาว. Commands: /story-blueprint /hero-arc /story-sandwich /story-transition /story-brainstorm /story-analyze /origin-story /case-study-story /story-tips /story-wizard /story-ideas /story-moral /story-angles /story-to-script /story-quick /hook-story-offer"
---

# Sales Story Secrets — Complete Storytelling-for-Sales System

> **Based on**: Jim Edwards' Sales Story Secrets Master Class + The Hero's Journey Webinar + Video Story Idea Brainstorming Wizard
> **Core Philosophy**: "เราถูกโปรแกรมมาให้รักเรื่องเล่า และให้ความสนใจกับเรื่องเล่าที่ดี — ทุกคนเป็นนักเล่าเรื่องได้"
> **Key Principle**: Story ที่ดี = Characters + Plot + Movement → สร้าง Emotional Involvement → นำไปสู่การขาย
> **Usage**: Sales Letters, VSL, Webinars, FB Lives, YouTube, TikTok, Reels, Blog Posts, Articles, Email, Podcast, On Stage, In Person
> **Proven Results**: TNR Sales Letter → $2.5M+ revenue / 5-Steps To Getting Anything You Want → Six Figures / Countless webinars and videos

---

## ⚡ QUICK START — Basic 3-Step Story Formula

สำหรับคนที่ต้องการเริ่มใช้ Story ทันที:

```
┌─────────────────────────────────────────────┐
│  STEP 1: INTRO                              │
│  "Let me tell you a quick story about ...." │
├─────────────────────────────────────────────┤
│  STEP 2: TELL THE STORY                     │
│  - Fit the time you have                    │
│  - Develop the intended emotion             │
│  - Answer: "What happened?" +               │
│    "How did it make you feel?"              │
├─────────────────────────────────────────────┤
│  STEP 3: TRANSITION TO THE MORAL            │
│  "So the moral of this story is ...."       │
│  "So the big takeaway here is ...."         │
└─────────────────────────────────────────────┘
```

**ก่อนเขียน Story ตอบ 3 คำถามนี้ก่อน:**
1. **Moral**: อะไรคือ moral/meaning/point ของเรื่องที่จะเล่า?
2. **Emotion**: อยากให้คนฟังรู้สึกอะไรเมื่อจบ?
3. **Action**: อยากให้คนฟังทำอะไรหลังฟังจบ?

---

## ทำไมต้องใช้ STORY ใน Sales Copy?

### เหตุผลหลัก
1. **มนุษย์ถูก Hardwire มาให้รักเรื่องเล่า** — ตั้งแต่มนุษย์ถ้ำเล่ากันรอบกองไฟ ถึงอียิปต์ใช้ Hieroglyphics — สมองเราคิดเป็นภาพ/การกระทำ/อารมณ์
2. **ดึงคนเข้าสู่ Copy โดยธรรมชาติ** — คนอยากฟังเรื่องเล่า ไม่ต้องบังคับ
3. **Non-threatening** — ให้คนสรุปเองว่า "นี่คือสิ่งที่ฉันต้องการ" → รู้สึกว่าเป็นไอเดียของตัวเอง
4. **สร้าง Contrast** — เห็นภาพ Pain / เห็นภาพ Solution / เห็นภาพตัวเอง enjoy solution / รู้สึกดีขึ้น (มีคนแย่กว่า) / เห็นความเป็นไปได้ (see a path)
5. **ตอบคำถามที่ลูกค้าไม่รู้ตัวว่ามี**: ทำไมต้องฟังคุณ? / ทำไมต้องเชื่อ? / ทำไมเสนอสินค้านี้? / ทำไมต้องซื้อจากคุณ?
6. **ง่ายต่อการเข้าใจ** — คนจับ moral/point ได้ง่ายผ่าน Story

### ข้อพิสูจน์: ทุกคนเป็นนักเล่าเรื่องอยู่แล้ว
- "เล่าเรื่องวันนี้ให้ฟังหน่อย?" / "ไปเที่ยวมาเป็นไงบ้าง?" / "คอมใหม่เป็นไง?"
→ **แค่ยังไม่รู้วิธีใช้มันขายของ**

---

## 3 ELEMENTS ของทุก STORY ที่ดี

### 1. CHARACTERS (ตัวละคร)
- **Hero**: คุณ / เพื่อน / ลูกค้า / ตัวแทน (proxy)
- **Villain**: คน (หัวหน้าเลว, อุตสาหกรรมคอร์รัปชั่น) / สถานการณ์ (เศรษฐกิจ) / สิ่งที่ต้องต่อสู้ → เป็น Scapegoat

### 2. PLOT (เนื้อเรื่อง)
- ปัญหาที่ต้องแก้
- อุปสรรค: Conspiracy / Physical limitation / Lack of knowledge / Self-motivation / External circumstances

### 3. MOVEMENT (การเคลื่อนไหว)
- จน→รวย / ทำงานหนัก→อิสระ / เศร้า→มีความสุข / ถูกกดขี่→มีอำนาจ
- **เป้าหมาย**: พาผู้อ่านจากสถานะ "แย่" → "ดีมาก"

→ 3 องค์ประกอบรวมกัน = **Emotional Involvement**

---

## THE HERO'S JOURNEY — Story Arc หลัก

### Story Arc (9 ขั้น + Optional)

```
═══ 1. START ═══ สถานะปกติ ชีวิตธรรมดา (ตั้ง baseline)
═══ 2. CHANGE ═══ เกิดเหตุการณ์ / ตัดสินใจ / เลือก (ชีวิตเลื่อนลงต่ำกว่า baseline)
═══ 3. PROBLEM / CONFLICT ═══ ปัญหาเกิดทันที เห็น villain
═══ 4. BAD TO WORSE ═══ สถานการณ์เลวร้ายลงต่อเนื่อง
═══ 5. ROCK BOTTOM ═══ จุดที่แย่ที่สุด สิ้นหวัง
═══ 6. REVELATION / DISCOVERY ═══ ค้นพบ / ตระหนักรู้ / ตัดสินใจเปลี่ยน ← "Epiphany Moment" (product เข้ามาตรงนี้)
═══ 7. TRANSFORMATION ═══ เริ่มฟื้นตัว ไต่กลับเหนือ baseline
═══ 8. RETURN HOME ═══ กลับสู่ "Normal ใหม่" ที่ดีกว่าเดิม
═══ 9. ASCENSION ═══ สำเร็จเกินคาด — "Happy Ending on Steroids"

═══ OPTIONAL: LOSS OF RESOURCE/TRUSTED FRIEND ═══ เสริมความลึก (Obi-Wan/Dumbledore เสียชีวิต)
═══ RETURN OF RESOURCE/FRIEND ═══ กลับมาในช่วงสำคัญ (Han Solo กลับมาช่วย)
```

### Hero's Journey Wizard (Q1-Q22)

เมื่อได้รับ `/hero-arc` หรือ `/story-wizard`:

```
[START]
Q1: ตอนเริ่มต้น คุณ/ตัวละครหลักเป็นใคร ทำอะไร? → "ตอนนั้นผม/เธอเป็น ___"
Q2: สถานการณ์ตอนนั้นเป็นยังไง? → "สถานการณ์คือ ___"

[CHANGE]
Q3: เกิดอะไรขึ้นที่ทำให้ทุกอย่างเริ่มเปลี่ยน? → "สิ่งที่เกิดขึ้นคือ ___"

[PROBLEM / CONFLICT]
Q4: ปัญหาหรือความขัดแย้งอะไรเกิดขึ้นทันที? → "ปัญหาคือ ___"

[BAD TO WORSE]
Q5: สถานการณ์แย่ลงอย่างไร? → "มันแย่ลงเพราะ ___"
Q6: อะไรเป็นสาเหตุ? → "เกิดจาก ___"
Q7: รู้สึกอย่างไรตอนนั้น? → "รู้สึกเหมือน ___"

[ROCK BOTTOM]
Q8: อะไรคือจุดที่รู้ว่าถึงทางตัน? → "รู้ว่าถึงจุดต่ำสุดตอน ___"
Q9: จุดต่ำสุดนั้นกระทบด้านอื่นของชีวิตอย่างไร? → "มันส่งผลให้ ___"
Q10: รู้สึกอย่างไร? → "รู้สึก ___"

[REVELATION / DISCOVERY]
Q11: ค้นพบ/ตระหนักรู้/ตัดสินใจอะไรที่เปลี่ยนทุกอย่าง? → "ตอนนั้นเองที่ผมค้นพบ ___"
Q12: อะไรทำให้เกิดการตระหนักรู้นั้น? → "เพราะ ___"
Q13: รู้สึกอย่างไร? (2-3 คำ) → "รู้สึก ___"

[TRANSFORMATION]
Q14: ทำอะไรบ้างเพื่อพลิกสถานการณ์? → "สิ่งที่ทำคือ ___"

[RETURN]
Q15: ทำอะไรได้ที่เมื่อก่อนทำไม่ได้? → "ตอนนี้ทำได้ ___"
Q16: การเดินทางนี้เปลี่ยนตัวเอง/เปิดโอกาสใหม่อย่างไร? → "เปลี่ยนไปตรงที่ ___"
Q17: มองตัวเองอย่างไร ณ จุดนี้? → "มองตัวเองว่า ___"

[ASCENSION]
Q18: ตัดสินใจ/สรุป/ตระหนักอะไรจากทั้งหมดนี้? → "สรุปได้ว่า ___"
Q19: ตอนนี้อยู่ตรงไหนของเส้นทาง? → "ตอนนี้ผม ___"
Q20: ทำอะไรได้ที่เมื่อก่อนทำไม่ได้? → "ตอนนี้สามารถ ___"
Q21: รู้สึกอย่างไรหลังจบเส้นทางนี้? → "รู้สึก ___"
Q22: Moral / Big Takeaway สำหรับคนฟังคืออะไร? → "สิ่งที่อยากให้จำไว้คือ ___"
```

**Control**: รายละเอียดมาก = เรื่องยาว / น้อย = เรื่องสั้น
**Output**: Story Outline + Full Draft (สั้น/กลาง/ยาว) + Tie-in to product

---

## 7 STORY BLUEPRINTS — FULL DETAIL

### #1 — "Against All Odds" (Rags to Riches)
- **Tagline**: ฉันแย่มาก แต่สำเร็จได้ — คุณก็ทำได้
- **Hero**: Underdog ไม่มีข้อได้เปรียบ (ยิ่งมี DISadvantages ยิ่งดี)
- **Villain**: อุปสรรคสุดขั้ว (เศรษฐกิจ, insider กักความรู้)
- **Plot**: เอาชนะอุปสรรคที่ดูเป็นไปไม่ได้ ปัญหาถาโถมไม่หยุด
- **Movement**: สิ้นหวัง/จน → ร่ำรวย/อุดมสมบูรณ์
- **Emotion**: ท้อแท้ → พอใจ, สำนึกบุญคุณ
- **Resolution**: แรงบันดาลใจว่าตัวเองก็ทำได้

### #2 — "Real-World Desperation"
- **Tagline**: ฉันสิ้นหวัง แต่หาทางออกได้
- **Hero**: คนที่มีปัญหา/อุปสรรคยักษ์ที่ผู้อ่านเข้าถึงได้
- **Villain**: ปัญหาที่ขวางทาง "Time is running out!"
- **Plot**: เอาชนะด้วยไหวพริบ/โชค/divine intervention
- **Movement**: สิ้นหวัง → ชนะ villain
- **Emotion**: Frustrated สุดขีด → โล่งใจ
- **ต่างจาก #1**: ปัญหาเฉพาะ/ฉับพลัน ไม่ใช่การต่อสู้ยาวนาน

### #3 — "I'm Mad As Hell"
- **Tagline**: ฉันเบื่อที่เห็นคนถูกเอาเปรียบ
- **Hero**: คนที่เห็นความอยุติธรรมแล้วลุกขึ้นทำ
- **Villain**: คน/สถานการณ์ที่เอาเปรียบคนบริสุทธิ์
- **Plot**: เห็นความทุกข์ → ไม่นิ่งเฉย → ลุกขึ้นสู้
- **Movement**: โกรธ → ให้ความรู้ + ลงโทษ villain
- **Resolution**: อยากออกจากกลุ่มที่ถูกเอาเปรียบ → เข้าร่วมกลุ่ม "คนฉลาด"

### #4 — "Plain Sight Secret"
- **Tagline**: ฉันค้นพบวิธี "ลับ" ที่ซ่อนอยู่ตรงหน้า
- **Hero**: คนที่มีปัญหาใหญ่
- **Plot**: ดิ้นรนหา → ช่วงเวลาแห่งความกระจ่าง → เห็นคำตอบที่อยู่ตรงหน้าตลอด
- **Movement**: frustrated เรื้อรัง → ทางออกง่ายๆ สงบ
- **Resolution**: ปัญหาเรื้อรังแก้ได้ง่ายๆ ด้วย solution นี้

### #5 — "Zero to Hero"
- **Tagline**: ฉันเคยเป็นเหยื่อ แล้วกลายเป็นฮีโร่
- **Hero**: Ultimate underdog ไม่มีใครคาดหวัง
- **Plot**: "Zero" ค้นพบแรงบันดาลใจหลัง DRAMATIC event — นี่คือ EXTREME
- **Movement**: ไม่มีความหวังเลย → ชัยชนะ + transformation
- **Resolution**: "ถ้าคนนั้นยังทำได้ ฉันก็ต้องทำได้!"

### #6 — "Hidden Genius"
- **Tagline**: ฉันพบคนที่เก่งมาก แต่ไม่รู้ตัว
- **Hero**: คนที่ไม่รู้ว่าตัวเองเก่ง / backdoor expert
- **Plot**: ความเก่งถูกเปิดเผยเมื่อเอาชนะ villain → ตัดสินใจช่วยคนอื่น
- **Movement**: mystery solution → ถูก recognize
- **Resolution**: อยากได้ solution จาก hero

### #7 — "Unknown Prophet"
- **Tagline**: ศาสดาไม่เคยเป็นที่รู้จักในบ้านเกิด
- **Hero**: Expert ที่ไม่ได้รับการยอมรับ
- **Villain**: ปัญหา + คนในวงที่ไม่ยอมรับ
- **Plot**: ออกไป "เมืองอื่น" → ช่วยคนสำเร็จ → กลับมาเป็น conquering hero
- **Movement**: ไม่มีใครรู้จัก → recognized expert
- **Resolution**: ตระหนักว่า hero คือ expert จริง

### Blueprint Selection Table
| Blueprint | ใช้เมื่อ |
|-----------|---------|
| #1 Against All Odds | มี personal story ต่อสู้ยาวนาน |
| #2 Real-World Desperation | มีปัญหาเฉียบพลัน แก้สำเร็จ |
| #3 I'm Mad As Hell | เป็น insider เห็นความไม่ถูกต้อง |
| #4 Plain Sight Secret | ค้นพบเทคนิคที่คนอื่นมองข้าม |
| #5 Zero to Hero | Extreme transformation จาก bottom |
| #6 Hidden Genius | แนะนำ expert/mentor ลับ |
| #7 Unknown Prophet | Expert ที่เพิ่งได้รับการยอมรับ |

---

## HOOK-STORY-OFFER — เชื่อม Story กับโครงสร้างการขาย

```
┌─ 1. HOOK ─────────────────────────────────┐
│  Headline/Opening ที่ดึงความสนใจ           │
│  สัญญาบางอย่างกับผู้อ่าน                    │
├─ 2. STORY (= Hero's Journey) ─────────────┤
│  ใช้ Story Blueprints + Hero's Journey Arc │
│  สร้าง Emotional Involvement               │
│  เชื่อมด้วย Story Sandwich Method          │
├─ 3. OFFER ────────────────────────────────┤
│  Product/Service = Resolution              │
│  Benefits + Proof + Scarcity + CTA         │
└───────────────────────────────────────────┘
```

**Hero's Journey = "Story" ส่วนกลางของ HSO**
- Hook = ชวนให้อยากฟัง Story
- Story = Hero's Journey Arc → emotional involvement
- Offer = Resolution ที่ Product มอบให้ = Happy Ending สำหรับผู้อ่าน

**ตำแหน่ง Story ใน Sales Letter**: มักอยู่ **ต้น** — หลัง Hook ทันที

---

## ENGAGEMENT → KNOW → STORY Framework

สำหรับ Content ออนไลน์ (FB Lives, Blog, YouTube, TikTok):

```
ENGAGE → ดึงความสนใจ (Hook/คำถาม)
   ↓
KNOW → ทำให้รู้จักคุณ (ใครคือคุณ/ทำไมควรฟัง)
   ↓
STORY → เล่าเรื่องที่สร้าง Connection (Hero's Journey)
   ↓
[CTA/Offer] → นำไปสู่ Action
```

| Platform | Engage | Know | Story | CTA |
|----------|--------|------|-------|-----|
| FB Live | คำถาม/ข่าวร้อน | แนะนำตัว 15 วิ | 3-10 นาที | ลิงก์/Comment |
| YouTube | Hook 5 วิแรก | ช่อง/เกี่ยวกับอะไร 10 วิ | 5-15 นาที | Subscribe/Link |
| Blog Post | Headline + 1st para | ย่อหน้าที่ 2 | เนื้อเรื่อง | CTA ท้ายบทความ |
| TikTok/Reels | 1 วิแรก (Visual Hook) | ข้อความบนจอ | 15-60 วิ | ลิงก์ใน bio |
| Webinar | Slide 1-3 | Background สั้น | Hero's Journey เต็ม | Stack + Close |
| Email | Subject line | 1-2 ประโยคแรก | 3-5 ประโยค | คลิกลิงก์ |

---

## STORY SANDWICH METHOD

```
┌─ 1. STORY INTRO (ขนมปังบน) ──┐  ← Transition เข้า
├─ 2. THE STORY (เนื้อ) ────────┤  ← Hero's Journey
├─ 3. TRANSITION OUT (ขนมปังล่าง) ┘  ← ออกสู่ Sales Pitch
```

### 32 STORY INTROS (Transitions เข้า)
1. Let me tell you a quick story
2. I hope this story inspires you
3. Hopefully this will inspire you too...
4. Hopefully this story inspires you too...
5. Here's a quick story I think you'll like
6. This story made me ___ (cry, mad, really excited, furious, delirious, feel awesome, warm all over)
7. This story will make you ___ (cry, mad, really excited, furious, delirious, feel awesome, warm all over)
8. This story shocked the hell out of me
9. This story will shock you
10. This story is a real shocker
11. Here's a real "feel good" story
12. Here's a story you can't repeat
13. Here's a real tear-jerker story
14. Here's a real inspirational story
15. You won't believe this story
16. You won't sleep tonight after this story
17. This story won't let you sleep tonight
18. This story will make you sick
19. This story will make you green with envy
20. This story will have you in stitches
21. This story will have you in tears
22. This story will have you on pins and needles
23. This story will break your heart
24. This story will inspire you
25. Does this story sound familiar?
26. Does this story sound like someone you know?
27. Here's a story that won't make the news
28. Here's a real behind-the-scenes story
29. Here's a story they don't want you to know
30. Here's a story they hope never gets out
31. This shocking story is 100% true
32. Is this story your nightmare too?

### 7 TRANSITIONS ออก (สู่ Sales Pitch)
- "So what's the point of all this?"
- "What's the moral here?"
- "What does all this mean to you?"
- "Why is this important to you?"
- "So by now you're probably asking, 'What does this have to do with me?'"
- "So by now you're probably wondering what all this has to do with you."
- "Why have I told you all this?"

### 3 วิธี Transition เข้าสู่ Sales Message

**วิธี 1: Benefit Statement** — "So if you want [benefit], [benefit], and [benefit], keep reading" → แนะนำสินค้า
**วิธี 2: Problem – Agitate – Solve (PAS)** — Define ปัญหาจาก story → ทำให้แย่ลง → แนะนำสินค้าเป็น solution
**วิธี 3: Straight Introduction** — Story อธิบาย need/resolution แล้ว → สินค้าคือ next logical step → แนะนำตรงๆ

### หลัง Story จบ — ตอบ 6 คำถาม
1. **What do you offer?** (Summary + 6-12 product bullets)
2. **Why should they listen to you?** (Background credibility)
3. **Why should they believe you?** (3rd party: testimonials, statistics)
4. **Why should they buy now?** (Bonuses/scarcity)
5. **What's the guarantee?** (Money-back/performance)
6. **How do they buy it?** (Click Here/Instant Download)

---

## STORY LENGTH + CHAPTER SYSTEM

### Length Table
| ใช้ที่ไหน | ความยาว | เป้าหมาย |
|-----------|--------|----------|
| Email Teaser | 3 คำ - 3 ประโยค | คลิกลิงก์ |
| Blog Post | < 400 คำ | Engagement |
| Article | < 750 คำ | Authority |
| Video/FB Live | < 5 นาที | Connection |
| Sales Letter | 3 ย่อหน้า - 3 หน้า | Buying Frame |
| Webinar | 5-30 นาที | Full Hero's Journey |
| On Stage | 2-45 นาที | Inspire + Sell |

### Chapter System (Story ยาว 30-45 นาที)

```
Story ยาว 45 นาที → แบ่งเป็น Chapters:
Ch1 (5m): Start + Change
Ch2 (10m): Problem + Bad to Worse
Ch3 (10m): Rock Bottom + Revelation ← จุดที่ทรงพลังที่สุด
Ch4 (10m): Transformation + Return
Ch5 (10m): Ascension + Moral
```

- จบแต่ละ chapter ด้วย cliffhanger
- Chapter สั้น (2-5m) สำหรับ pace เร็ว / Chapter ยาว (10-30m) สำหรับ Rock Bottom/Revelation
- **เรื่องเดียวกัน ปรับยาวได้**: 2 นาที (Email) → 5m (FB Live) → 10m (Video) → 30m (Webinar/Stage)

---

## "DON'T OVERTHINK IT" CHECKLIST ✅

### เรื่องที่ดีถ้ามัน:
- [ ] ทำให้คุณรู้สึกอารมณ์รุนแรง
- [ ] เล่ายาก/เจ็บปวด
- [ ] มาจากช่วงเวลาที่ยากลำบาก
- [ ] สำเร็จท่ามกลางอุปสรรค
- [ ] มีการต่อสู้ครั้งใหญ่
- [ ] มี emotional swing ขนาดใหญ่
- [ ] มี financial payoff ใหญ่
- [ ] ช่วยรักษาบางสิ่ง/บางคน
- [ ] ทำลายบางสิ่งที่สมควร

### **และ** ต้อง:
- [ ] **สมเหตุสมผลกับสิ่งที่คุณขาย**

| | เรื่อง | สินค้า | ผล |
|---|--------|--------|-----|
| ✅ | สูญเสียธุรกิจ + ข้อมูล 10 ปี จาก ransomware | Anti-virus software | สมเหตุสมผล! |
| ❌ | ลุงเมาทำลายคริสต์มาส | Anti-virus software | ไม่เกี่ยวกัน! |

---

## STORYTELLING TIPS

### 1. Make It Conversational
- เล่าเหมือนให้เพื่อนฟังในบาร์: "Let me tell you a story about..." / "You'll never guess what I saw..."

### 2. Make It Descriptive
- พลังอยู่ที่รายละเอียด — เช็ค: อ่านออกเสียง → ตรงไหนลาก/สะดุด → ตัดออก

### 3. Get Emotional
- ตื่นเต้นตอนเขียน → พลังส่งผ่าน / **เคล็ดลับ: พูดดัง 10% + เร็วขึ้น 10%**
- ใช้คำที่ลูกค้าใช้: "หงุดหงิด" / "โกรธจัด" / "กลัวจนตัวสั่น"

### 4. Avoid Contradictions
- เรื่องต้อง add up ในตัวเอง / สินค้า = กุญแจสู่ผลลัพธ์ที่พระเอกได้

### 5. Story Perspective
- **1st Person**: ดีที่สุด — เขียนง่าย, สร้าง bond, ทำให้ "real"
- **3rd Person**: เล่าเรื่องคนอื่น (ระวังชื่อ)
- **Hypothetical**: ได้ แต่ต้องบอกชัด
- **Proxy**: "Let me tell you about a guy named FRED..."

### 6. Secret Weapon Resources (แนะนำโดย Jim Edwards)
- **"Words That Sell"** by Richard Bayan — 6,000+ entries
- **"Phrases That Sell"** by Edward Werz & Sally Germain
- **"More Words That Sell"** by Richard Bayan
→ ค้นหาคำ/วลีที่มีพลังแทนคำธรรมดา → Story มีผลกระทบมากขึ้น

---

## HOW TO CHOOSE YOUR STORY

### 2 ขั้นตอน
1. **ระบุ**: ลูกค้าอยู่ตรงไหนใน Hero's Journey ของตัวเอง?
2. **ถาม**: เรื่องอะไรจากชีวิตฉัน/ลูกค้า/คนรู้จัก จะ "พบ" ลูกค้าตรงจุดนั้น → พาไปสู่ Happy Ending?

### เรื่องไม่จำเป็นต้องเกี่ยวกับตัวคุณ
- **สินค้า** (Origin Story) / **คนอื่น** (เปลี่ยนชื่อได้) / **ลูกค้า** (proxy) / **Hypothetical**
- แต่ **1st person มักดีที่สุด**: เขียนง่าย + Bond ผู้อ่าน + ทำให้ "real"

---

## REVERSE ENGINEERING YOUR STORY POINT

```
[จุดจบ] Action ที่อยากให้ทำ (ซื้อ/สมัคร/คลิก)
    ↑
[4] Feeling ที่อยากสร้าง
    ↑
[3] Result ที่ลูกค้าอยากได้
    ↑
[2] Path ที่ตัวละครหลักใช้
    ↑
[1] จุดเริ่มต้นของทุกอย่าง (START)
```
→ เขียนเรื่องจาก [1] ไป [จุดจบ] ตามลำดับ

---

## EMOTIONAL RESOLUTION TABLE

| อารมณ์ที่สร้าง | Resolution ที่ต้องการ | ตัวอย่าง Tie-in |
|---------------|---------------------|----------------|
| โกรธ (Mad) | ยุติธรรม / แก้แค้น / พอใจ | "นี่คือเหตุผลที่สร้างเครื่องมือนี้" |
| มีแรงบันดาลใจ (Inspired) | เปลี่ยนแปลง / รักษาความรู้สึก | "ถ้าอยากเริ่มเส้นทางเดียวกัน นี่คือขั้นตอนแรก" |
| รัก (Love) | แบ่งปัน / กระจาย | "แชร์ให้คนที่คุณรักรู้ด้วย" |
| กลัว (Fear) | แก้ไขทันที! / ผู้ช่วย / ทางออก | "อย่าปล่อยให้เกิดกับคุณ — นี่คือวิธีป้องกัน" |

---

## VIDEO STORY BRAINSTORMING — 4 Questions × 6 Sources

### 4 Core Questions
**Q1 MORAL**: "The thing I really want you to take away from this is ________."
**Q2 MEANING**: "So what this means to you is ________."
**Q3 EMOTION**: "By the end of the story you should feel ________."
**Q4 ACTION**: "Now, as a result of what we just shared here, I want you to consider ________."

### 6 แหล่ง Story Ideas (3-5 ไอเดีย/แหล่ง = 18-30 Ideas)
1. **Personal Experience** — เหตุการณ์ในชีวิตตัวเอง
2. **Customer Stories** — เรื่องราวลูกค้า/คนรอบข้าง
3. **Historical/Famous** — คนดัง/ประวัติศาสตร์ที่สื่อ Moral เดียวกัน
4. **Analogy/Metaphor** — เปรียบเทียบจากธรรมชาติ/กีฬา/ชีวิตประจำวัน
5. **News/Current Events** — ข่าว/เหตุการณ์ปัจจุบัน
6. **Fictional/Hypothetical** — สถานการณ์สมมุติที่คนเห็นภาพ

### Example Projects
| Product | Moral | Meaning | Emotion | Action |
|---------|-------|---------|---------|--------|
| Executive Coaching | We all need a mentor | Need mentors to grow | Inspired, wanting a mentor | Join coaching |
| MLM Opportunity | Try again | อย่ายอมแพ้ | มีกำลังใจลองใหม่ | สมัครโอกาส |
| Heavy Metal Detox | Need to detox | สะสมสารพิษมากกว่าคิด | ตกใจ + อยากแก้ไข | สั่งซื้อ detox |
| Alkaline Water | Find out about water | น้ำส่งผลมากกว่าคิด | อยากรู้เพิ่ม | ทดลองใช้ |

---

## 50+ STORY BRAINSTORMING PROMPTS

**ครู/สัตว์เลี้ยง/วัยเด็ก:** ...about a special teacher / a special pet / a memorable childhood experience

**งาน/สถานที่/คน:** ...about experiences as a ___ (job) / a place that made me feel ___ / a person who made me feel ___

**อารมณ์รุนแรง:** ...about feeling so embarrassed I could die / felt proud of ___ / felt exhilarated / got in trouble at ___

**ความท้าทาย:** ...about a HUGE project / situation not funny then but is now / overcame a HUGE obstacle / a trip and felt scared / trip with cool discovery

**ชีวิต/ครอบครัว:** ...about the day I got ___ / something my child said / when I graduated (or didn't) / a once in a lifetime experience / a vacation dream/nightmare / conversation with a dying ___

**วิกฤต/สูญเสีย:** ...about a major health crisis (me/loved one) / a divorce/breakup / a major accident / unexpected trauma / weight loss-gain / physical disability or recovery

**การต่อสู้/ชัยชนะ:** ...about a big challenge I overcame / a defining moment / ethics/morals tested / split second decision / hard work finally paid off / had to accept defeat and reorganize / got knocked down but got back up

**เรียนรู้/ค้นพบ:** ...about figuring out technology / mastering a new skill / remodeling/learning to drive

**ชีวิตประจำวัน:** ...about ER visit / grocery store / mall / gym / visiting family / holidays / news story that caught attention / at the movies / driving my car / stopped at a traffic light / bolt of inspiration / working around the house / reading a book / interesting thought in the bathroom

**วิธีใช้**: เลือก prompt → เติมช่องว่าง → ระบุ Moral → เชื่อมกับสินค้า → เลือก Blueprint

---

## 5 REAL CASE STUDIES (พร้อม Revenue Proof)

### #1: "Against All Odds" — FSBOHelp.com
- **Blueprint**: #1 + #4 | **Movement**: despair → success
- ต้องขาย 2 บ้านใน 45 วัน → 2 สัปดาห์ไม่มีคนโทร → ตื่นตี 1:20 ได้ "คำตอบ" → บ้านแรกขายใน 2 วัน full price → สร้างหนังสือ → ช่วยคนอื่น

### #2: "I'm Mad As Hell" — MortgageLoanTips.com
- **Blueprint**: #3 | **Movement**: righteous anger → reveal secrets
- Mortgage Banker 10+ ปี เห็น broker โกง → โกรธจนสร้าง "TEN Dirty Little Secrets" → ช่วยคนได้ดอกเบี้ยต่ำสุด

### #3: "Zero to Hero" — Net Reporter Membership
- **Blueprint**: #5 | **Revenue**: **$2.5M+** | **Movement**: rags → riches
- $138K/ปี → paperboy → ล้มละลาย → ป่วยหัวใจ → เข้า seminar → $411,365 first ebook → 7-figure business

### #4: "Hidden Genius" — MiniSite Creator v2.0
- **Blueprint**: #6 | **Movement**: fear → confidence
- ลูกเขยบาดเจ็บจากสงคราม Iraq ทำงานได้ 2 ชม./วัน → สอน Jon ใช้ software → revamp ทั้งคอร์ส → "ถ้าคนนี้ยังทำได้ ไม่มีข้อแก้ตัว"

### #5: "Against All Odds" Extended — 5 Steps To Getting Anything You Want
- **Blueprint**: #1 + #5 | **Revenue**: **Six Figures** | **Movement**: devastation → dream life
- $72K/ปี → ล้มละลาย → trailer → $9K/ปี → ค้นพบ 5-Step System → 14-acre waterfront estate + 7-figure business

---

## สิ่งสำคัญที่สุดของทุก STORY

**#1 KEY**: ทุกเรื่องต้องมี **"POINT"** — ไม่มีใครชอบเรื่องที่ไม่มี point (**คนเกลียดมัน!**)
- Point คืออะไร? เชื่อมกับ sales message อย่างไร?
- Point = สะพานเชื่อมไปสู่ sales message ที่เหลือ

---

## COMMANDS

| Command | Description |
|---------|-------------|
| `/story-blueprint [#/name]` | สร้าง Story จาก 7 Blueprints |
| `/hero-arc [topic]` | Hero's Journey Outline (Wizard Q1-Q22) |
| `/story-sandwich [topic]` | Story ครบ 3 ส่วน: Intro + Story + Transition |
| `/story-transition [type]` | Transition phrases (in/out) |
| `/story-brainstorm [product]` | 20+ Story Ideas (4 Questions × 6 Sources) |
| `/story-analyze [text]` | วิเคราะห์ Sales Story → feedback + rewrite |
| `/origin-story [brand]` | Origin Story ตาม Hero's Journey |
| `/case-study-story [details]` | Case Study format |
| `/story-tips` | Tips ทั้งหมด + Secret Weapon Resources |
| `/story-wizard` | Interactive Q1-Q22 → Complete Story |
| `/story-ideas [moral]` | Story Ideas จาก Moral (6 แหล่ง) |
| `/story-moral [product]` | หา Moral ที่เหมาะกับ Product |
| `/story-angles [topic]` | Story Angles หลายมุม |
| `/story-to-script [idea]` | Story Idea → Video Script (60s/3min/10min) |
| `/story-quick [topic]` | Quick Start — 3-Step Formula |
| `/hook-story-offer [product]` | Hook + Hero's Journey + Offer Structure |

---

## COMMAND EXECUTION RULES

### `/story-blueprint` → ถาม: สินค้า? กลุ่มเป้าหมาย? ปัญหา? Blueprint (1-7)? ใช้ที่ไหน? → Output: Outline + Draft + Transitions

### `/story-brainstorm` → ถาม 4 Core Questions (Moral/Meaning/Emotion/Action) → Output: 20+ Ideas (6 แหล่ง) + Top 5 + Content Calendar

### `/story-analyze` → วิเคราะห์: 3 Elements? Hero's Journey? Emotion? Sandwich? Transitions? Logic? HSO? Point? → Score (1-10) + Strengths + Weaknesses + Rewrite

### `/origin-story` → ถาม: ทำไมสร้าง? เหตุการณ์อะไร? อุปสรรค? ผลลัพธ์? → Origin Story + Transitions

### `/story-wizard` → Interactive Q1-Q22 → Complete Outline + Narrative Draft (สั้น/กลาง/ยาว) + Tie-in

### `/story-to-script` → สร้าง: Hook (3-5 วิ) → Setup → Conflict → Turning Point → Resolution + Moral → CTA → Output: Script (60s/3min/10min)

### `/story-quick` → ถาม 3 คำถาม (Moral/Emotion/Action) → Output: Story ด้วย Basic 3-Step Formula

### `/hook-story-offer` → ถาม: สินค้า? กลุ่มเป้าหมาย? ปัญหา? Story ส่วนตัว? → Output: Hook (3-5 headlines + opening) + Story (Full Hero's Journey) + Offer (Transition + Benefits + CTA)

---

## CASE STUDY FORMAT

```
📋 CASE STUDY: [ชื่อ/หัวข้อ]
━━━━━━━━━━━━━━━━━━━━━
📝 Summary: [สรุปสั้นๆ]
👤 Main Character: [ตัวละครหลัก + บทบาท]
🦹 Villain: [ผู้ร้าย/อุปสรรค]
📖 Plot: [เนื้อเรื่อง + อุปสรรค]
🔄 Movement: [จุดเริ่ม] → [จุดจบ]
🎯 Blueprint: [ชื่อ Blueprint]
💰 Revenue/Result: [ผลลัพธ์ที่วัดได้]
💡 Why It Works: [เหตุผล]
🔗 Product Tie-in: [เชื่อมกับสินค้าอย่างไร]
```

---

## INTEGRATION WITH OTHER SKILLS

| Skill | วิธีเชื่อม |
|-------|-----------|
| **funnel-scripts-copywriting** | Story เป็นส่วน "Story" ใน HSO / VSL Script |
| **inception-copywriting** | Story Ideas → VDO/Webinar Script / Golden Nugget |
| **perfect-webinar-wizard** | Story → Epiphany Bridge Stories (Q8, Q20, Q26, Q32) |
| **alphamind-brand-cortex** | Origin Story → Brand Story ใน Brand House |
| **mrarranger-viral-content** | Story Ideas → Viral Short Video |
| **mrarranger-social** | Story → Social Posts ทุก Platform |
| **mrarranger-content** | Story ในบทความ Blog / Newsletter / Email |
| **mrarranger-content-master** | Story → Conversion Content |
| **mrarranger-sales** | Story ใน Sales Funnel ทุกขั้น |
| **mrarranger-outreach** | Mini-stories ใน Cold Email / Follow-up |
| **dan-koe-framework** | Story → Signal Content (ไม่ใช่ Slop) |
