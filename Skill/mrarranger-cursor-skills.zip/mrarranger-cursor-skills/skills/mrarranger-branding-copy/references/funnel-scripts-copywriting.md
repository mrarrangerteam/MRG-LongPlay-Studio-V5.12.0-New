# funnel-scripts-copywriting

**Source:** `/mnt/skills/user/funnel-scripts-copywriting/SKILL.md`
**Size:** 26889 bytes

---

---
name: funnel-scripts-copywriting
description: "Funnel Scripts Copywriting System - ระบบเขียน Copy ขายครบวงจรจาก Jim Edwards & Russell Brunson (Funnel Scripts / Copywriting Secrets) รวม 10 เหตุผลที่คนซื้อ, Hero's 2 Journeys Storytelling, Hook-Story-Offer Framework, Timeless Classic Headlines (122 สูตร), Decision Tree Script, Live Event Invitation Script, OTO Scripts (4 แบบ), Abandoned Cart Email Sequence (3 Reasons Framework), About Me Scripts (สำหรับ Google Ads/SEO/Blog/Social Media), Dirty Little Secrets Script (สร้าง Product Names/Headlines/Hooks/Lead Magnet Ideas), Customer Avatar Definition, VSL/Long Form/Short Form Sales Letter, Guarantee ที่ขายได้, และ Features vs Benefits Conversion. ใช้เมื่อ: (1) เขียน Sales Copy/Sales Letter (2) สร้าง Headlines ที่ดึงดูด (3) เขียน Hook-Story-Offer (4) สร้าง OTO/Upsell Copy (5) เขียน Abandoned Cart Emails (6) สร้าง Live Event Invitation Copy (7) ทำ Decision Tree สำหรับขาย (8) เขียน VSL Script (9) สร้าง Guarantee ที่ขาย (10) แปลง Features เป็น Benefits (11) สร้าง Customer Avatar (12) ใช้ Storytelling เพื่อขาย (13) เขียน About Me Page/Bio (14) สร้าง Dirty Little Secrets Headlines/Product Names. Commands: /headline /hook /story /offer /oto /cart-email /event /decision-tree /avatar /guarantee /vsl /salespage /copy-analyze /about-me /dirty-secrets /testimonial-request /demo-script /hero-journey /onboarding /origin-story"
---

# Funnel Scripts Copywriting System

> **Based on**: Jim Edwards' Copywriting Secrets + Funnel Scripts Tips & Training Series
> **Core Philosophy**: "ทุกคนเขียน Sales Copy ได้ — ไม่มีใครเกิดมารู้วิธีเขียน Copy"
> **Key Principle**: Copy ที่ดี = เข้าใจลูกค้า + โครงสร้างที่ถูก + ภาษาที่โดนใจ

---

## CORE FOUNDATIONS (จาก Copywriting Secrets)

### Copywriting ≠ การเขียนทั่วไป
Copywriting คือการเขียนเพื่อกระตุ้นให้คนทำบางอย่าง (ซื้อ, สมัคร, คลิก) — ไม่ใช่แค่ให้ข้อมูล

### 10 เหตุผลที่คนซื้อของ (ท่องให้ขึ้นใจ)
เมื่อเขียน Copy ทุกชิ้น ให้ถามว่า "สินค้า/บริการนี้ช่วยกลุ่มเป้าหมาย _____ ได้อย่างไร?"

1. **Make money** — ทำเงินได้มากขึ้น
2. **Save money** — ประหยัดเงิน
3. **Save time** — ประหยัดเวลา
4. **Avoid effort** — ลดความยุ่งยาก
5. **Escape pain** — หนีจากความเจ็บปวด (กาย/ใจ)
6. **Get comfort** — ได้ความสะดวกสบาย
7. **Better health** — สุขภาพดีขึ้น/สะอาดขึ้น
8. **Gain praise** — ได้รับคำชม
9. **Feel loved** — รู้สึกเป็นที่รัก
10. **Social status** — เพิ่มสถานะทางสังคม

### สิ่งที่ขายคนจริงๆ (What REALLY Sells)
คนไม่ได้ซื้อ Features — คนซื้อ **ผลลัพธ์ที่จะเกิดขึ้นกับชีวิตเขา** (Benefits → Payoffs)

**การแปลง Features → Benefits → Payoffs:**
- Feature: "คอร์สมี 50 วิดีโอ" 
- Benefit: "เรียนรู้ทุกขั้นตอนแบบ step-by-step"
- Payoff: "ทำให้คุณเริ่มขายได้ภายใน 7 วัน แม้ไม่เคยขายออนไลน์มาก่อน"

### Customer Avatar (ลูกค้าในอุดมคติ)
ก่อนเขียน Copy ต้องรู้จักลูกค้าให้ชัด:
- ปัญหาที่เขาเผชิญอยู่คืออะไร?
- เขาพยายามแก้มาแล้วกี่ครั้ง? ล้มเหลวเพราะอะไร?
- ความกลัวลึกๆ ของเขาคืออะไร?
- ความฝันที่แท้จริงคืออะไร?
- เขาใช้ภาษาแบบไหนพูดถึงปัญหา?
- เขาอยู่ที่ไหน (online/offline)?

### Headlines — สำคัญที่สุด
Headline แย่ = ไม่มีใครอ่านต่อ = ขายไม่ได้ ไม่ว่า Copy ข้างในจะดีแค่ไหน

### Guarantee ที่ขายได้
Guarantee ไม่ใช่แค่ "คืนเงินได้" — ต้องทำให้ Guarantee กลายเป็น **เหตุผลเพิ่มเติมที่ควรซื้อ**

### สิ่งที่ห้ามทำ (The One Thing You Should NEVER Do)
อย่าเขียน Copy โดยไม่เข้าใจลูกค้า — อย่าเดา อย่าสมมุติ

### ปัจจัยที่คนลืมใส่ใน Copy
Urgency + Scarcity — ทำไมต้องซื้อ **ตอนนี้**?

### VSL vs Long Form vs Short Sales Letter
- **VSL (Video Sales Letter)**: เหมาะกับ cold traffic, ราคา $47-$997
- **Long Form**: เหมาะกับคนชอบอ่าน, SEO ดี, ราคาสูง
- **Short Form**: เหมาะกับ warm traffic ที่รู้จักเราแล้ว, ราคาต่ำ

---

## COMMANDS

| Command | Description |
|---------|-------------|
| `/headline [product]` | สร้าง Headlines 10-20 แบบ จาก Timeless Classic Scripts (122 สูตร) |
| `/hook [topic]` | สร้าง Hook ที่หยุด scroll + ดึงคนเข้ามา |
| `/story [topic]` | สร้าง Story ตาม Hero's 2 Journeys + 3 Acts + 5 Turning Points |
| `/offer [product]` | สร้าง Offer ที่ปฏิเสธไม่ได้ |
| `/oto [type] [product]` | สร้าง OTO Copy (faster/next-step/help/done-for-you) |
| `/cart-email [product]` | สร้าง Abandoned Cart Email Sequence (3 เหตุผล) |
| `/event [details]` | สร้าง Live Event Invitation Copy ครบชุด |
| `/decision-tree [product]` | สร้าง Decision Tree Script สำหรับขาย |
| `/avatar [product]` | สร้าง Customer Avatar Profile |
| `/guarantee [product]` | สร้าง Guarantee ที่ช่วยขาย |
| `/vsl [product]` | สร้าง VSL Script |
| `/salespage [product]` | สร้าง Sales Page Copy เต็มรูปแบบ |
| `/copy-analyze [text]` | วิเคราะห์ Copy ที่มีอยู่ + แนะนำปรับปรุง |
| `/about-me [name/brand]` | สร้าง About Me Copy สำหรับบุคคลหรือบริษัท (Google Ads/SEO/Blog/Social) |
| `/dirty-secrets [niche]` | สร้าง "Dirty Little Secrets" Headlines, Product Names, Hooks, Lead Magnet Ideas |
| `/testimonial-request [product]` | สร้าง Testimonial Request Email Sequence (auto-pilot) |
| `/demo-script [product]` | สร้าง DEMO Script ตาม Billy Mays Framework (7 ส่วน) |
| `/hero-journey [topic]` | สร้าง Hero's Journey Story Outline (Wizard format ครบทุกขั้น) |
| `/onboarding [product]` | สร้าง Onboarding Email Funnel Sequence (สูงสุด 11 emails) |
| `/origin-story [product]` | สร้าง Origin Story / Sales Story จาก Negative Event → Discovery → Payoffs |

---

## COMMAND DETAILS

### /headline — Timeless Classic Headlines (122 สูตร)

**ที่มา**: Victor O. Schwab (1898-1980) รวบรวม 100 headlines ที่ได้ผลที่สุด + Jim Edwards ขยายเป็น 122 สูตร ปรับให้ทันสมัย

เมื่อได้รับ `/headline` → ถาม:
1. สินค้า/บริการคืออะไร?
2. กลุ่มเป้าหมายคือใคร?
3. ผลลัพธ์หลักที่ลูกค้าจะได้?
4. ปัญหาหลักที่แก้ได้?

จากนั้นสร้าง 15-20 Headlines จากสูตรเหล่านี้:

**หมวด How-to / วิธีการ:**
- "วิธี [ผลลัพธ์ที่ต้องการ] โดยไม่ต้อง [สิ่งที่ไม่อยากทำ]"
- "วิธีง่ายๆ ที่จะ [ผลลัพธ์] ใน [ระยะเวลา]"
- "ความลับของ [ผลลัพธ์] ที่ [กลุ่มคน] ไม่อยากให้คุณรู้"

**หมวด คำถาม:**
- "คุณทำผิดพลาด [จำนวน] ข้อนี้ใน [หัวข้อ] หรือเปล่า?"
- "ใครอีกที่อยาก [ผลลัพธ์]?"
- "คุณจะ [ผลลัพธ์ที่อยากได้] ไหม ถ้า [เงื่อนไขง่ายๆ]?"

**หมวด ท้าทาย / กระตุ้น:**
- "ลองให้ [ผลิตภัณฑ์] [ระยะเวลา] แล้วดูผลลัพธ์ด้วยตัวคุณเอง"
- "คำเตือน: อย่า [ทำสิ่งนี้] จนกว่าคุณจะ [เงื่อนไข]"
- "[จำนวน] เหตุผลที่ [กลุ่มเป้าหมาย] เลือก [สินค้า]"

**หมวด เรื่องเล่า / ประสบการณ์:**
- "พวกเขาหัวเราะตอนผม [ทำสิ่งนี้] แต่เมื่อผม [ผลลัพธ์]..."
- "ผม [สถานการณ์แย่] จนกระทั่ง [ค้นพบสิ่งนี้]"

**หมวด ตัวเลข / สถิติ:**
- "[ตัวเลข] วิธีที่จะ [ผลลัพธ์] ใน [ระยะเวลา]"
- "ผม [ผลลัพธ์เหลือเชื่อ] ใน [เวลาสั้น] — นี่คือวิธี"

**หมวด ข้อเสนอ / โปรโมชั่น:**
- "ฟรี! [สิ่งมีค่า] สำหรับ [กลุ่มเป้าหมาย]"
- "ประหยัด [จำนวน] กับ [สินค้า] — แค่ [เงื่อนไขง่าย]"

**สำคัญ**: สร้าง Headlines หลายแบบ คละหมวด ให้ลูกค้าเลือก ปรับ และ Test ได้

---

### /hook — สร้าง Hook

Hook คือประโยคแรกที่ทำให้คนหยุดสิ่งที่ทำอยู่แล้วสนใจ

**5 ประเภท Hook:**
1. **Question Hook**: ถามคำถามที่โดนใจ → "เคยรู้สึกไหมว่า...?"
2. **Statement Hook**: พูดอะไรที่สวนกระแส → "การทำงานหนักไม่ได้ทำให้รวย"
3. **Story Hook**: เริ่มด้วยเรื่องเล่า → "เมื่อ 3 ปีก่อน ผมเกือบเจ๊ง..."
4. **Stat Hook**: ใช้ตัวเลขน่าตกใจ → "87% ของธุรกิจ..."
5. **Challenge Hook**: ท้าทาย → "ถ้าคุณทำ 3 ข้อนี้ไม่ได้ คุณยังไม่พร้อม..."

เมื่อได้รับ `/hook` → ถาม:
1. หัวข้อ/สินค้าคืออะไร?
2. กลุ่มเป้าหมาย?
3. จะใช้ที่ไหน? (FB, IG, Email, VSL, Sales Page)

สร้าง 5-10 Hooks คละประเภท พร้อมบอกว่าเหมาะใช้ที่ไหน

---

### /story — Hero's 2 Journeys Storytelling

**จาก "Using Stories To Sell More"** — เรื่องเล่าคือเครื่องมือขายที่ทรงพลังที่สุด

**ใช้ Stories ได้ทุกที่**: Facebook, Instagram, Content Videos, Articles, Sales Letters, Email, Podcasts, Live Videos, Webinars

**โครงสร้างเรื่องเล่าที่ขาย (Hero's 2 Journeys):**

**Journey 1 — Achievement (ผลสำเร็จ)** (10% ของเรื่อง)
**Journey 2 — Transformation (การเปลี่ยนแปลงภายใน)** (90% ของเรื่อง)

**3 องค์ประกอบหลัก:**
1. **Character** (ตัวละคร) — ต้องสร้าง Rapport ผ่าน: Victim / Jeopardy / Likable / Funny / Powerful
2. **Desire** (ความต้องการ) — ต้องการอะไร: To Win / To Retrieve / To Escape / To Stop
3. **Conflict** (ความขัดแย้ง) — สร้าง EMOTION → ทำให้คนอ่านต่อ

**3 Acts:**
1. **Set Stage** (ตั้งฉาก) — ตอนนี้ / ก่อนหน้า
2. **Conflict** (ปัญหา/อุปสรรค)
3. **Resolution + Next Steps** (ทางออก → เชื่อมสินค้า)

**5 Turning Points of Conflict:**
1. Opportunity (โอกาส)
2. Change of Plans (แผนเปลี่ยน)
3. Point of No Return (จุดที่กลับไม่ได้)
4. Major Setback (อุปสรรคใหญ่)
5. The Climax → Aftermath (จุดสูงสุด → ผลลัพธ์)

**สำคัญ**: ทุกเรื่องต้องมี **POINT** (จุดประสงค์) + **Tie-in** (เชื่อมกลับไปที่สินค้า/บริการ)

เมื่อได้รับ `/story` → ถาม:
1. เรื่องเกี่ยวกับอะไร / สินค้าอะไร?
2. กลุ่มเป้าหมาย?
3. ใช้ที่ไหน? (สั้น 30 วินาที หรือ ยาว?)
4. จุดประสงค์ (POINT) คืออะไร?

สร้าง Story Outline ตาม 3 Acts + 5 Turning Points พร้อม Tie-in

---

### /offer — สร้าง Offer ที่ปฏิเสธไม่ได้

Offer ที่ดีประกอบด้วย:
1. **Main Product/Service** — สิ่งหลักที่ขาย
2. **Bonuses** — ของแถมที่เพิ่มมูลค่า
3. **Price Anchoring** — แสดงมูลค่าจริง vs ราคาที่จ่าย
4. **Guarantee** — ลดความเสี่ยง (ใช้ /guarantee)
5. **Urgency/Scarcity** — ทำไมต้องตอนนี้
6. **CTA (Call to Action)** — บอกให้ชัดว่าต้องทำอะไร

เมื่อได้รับ `/offer` → ถาม:
1. สินค้า/บริการหลักคืออะไร?
2. ราคาเท่าไหร่?
3. มี Bonus อะไรบ้าง?
4. มี Guarantee แบบไหน?
5. มี Urgency/Scarcity ไหม?

สร้าง Offer Stack + Copy สำหรับนำเสนอ Offer

---

### /oto — OTO (One Time Offer) Scripts

**4 ประเภท OTO:**

1. **Do it Faster** — "ทำให้เร็วขึ้น"
   - "ถ้าคุณชอบ [สินค้าหลัก] คุณจะรักสิ่งนี้! [OTO] จะช่วยให้คุณได้ผลลัพธ์เร็วขึ้น X เท่า..."

2. **Next Step** — "ขั้นตอนถัดไป"
   - "ตอนนี้คุณมี [สินค้าหลัก] แล้ว ขั้นตอนถัดไปคือ... [OTO] จะพาคุณไปอีกระดับ"

3. **Let Us Help You** — "ให้เราช่วย"
   - "เราเข้าใจว่าการ [ทำสิ่งนี้] อาจยุ่งยาก ให้ทีมเราช่วยคุณ..."

4. **Let Us Do It For You** — "ให้เราทำให้"
   - "ไม่มีเวลา? ให้เราทำ [สิ่งนี้] ให้คุณเลย! แค่ [เงื่อนไขง่ายๆ]..."

เมื่อได้รับ `/oto` → ถาม:
1. สินค้าหลัก (Front-end) คืออะไร?
2. OTO คืออะไร? ประเภทไหน? (faster/next-step/help/done-for-you)
3. ราคา OTO เท่าไหร่?

สร้าง OTO Page Copy รวม: Headline, Body, Price, CTA, Yes/No buttons

---

### /cart-email — Abandoned Cart Email Sequence

**3 เหตุผลที่คนทิ้งตะกร้า + วิธีแก้:**

1. **ถูกรบกวน (Distracted)** → Email ที่ 1: เตือนความจำ
   - โทรศัพท์ดัง, เน็ตหลุด, มีนัด, ไม่มีบัตรอยู่ตรงนั้น
   - Email: "สวัสดี! สังเกตว่าคุณยังไม่เสร็จ... ยังสนใจ [สินค้า] อยู่ไหม? ลิงก์อยู่นี่เลย"

2. **ยังไม่เชื่อในคุณค่า (Not Sold on Benefits)** → Email ที่ 2: เน้น Benefits + Payoffs
   - เห็นราคาแล้วรู้สึกไม่คุ้ม, ไม่เข้าใจว่าช่วยอะไร, มีคำถามที่ยังไม่ถูกตอบ
   - Email: เน้นย้ำ Benefits, Testimonials, ตอบ FAQ

3. **ไม่เชื่อว่าจะใช้ได้กับตัวเอง (Don't Believe It Will Work)** → Email ที่ 3: Social Proof + Case Studies
   - จะใช้ได้กับสถานการณ์เขาไหม?, คนอื่นเหมือนเขาเคยใช้ได้ไหม?, จะเสียเวลาเปล่าไหม?
   - Email: Testimonials จากคนคล้ายๆ, Case Study, Guarantee

**สำคัญ**: เราไม่รู้ว่าคนทิ้งตะกร้าเพราะเหตุผลไหน → ต้องส่ง 3 Emails ครอบคลุมทุกเหตุผล

เมื่อได้รับ `/cart-email` → ถาม:
1. สินค้า/บริการคืออะไร?
2. ราคาเท่าไหร่?
3. มี Testimonials/Case Studies ไหม?
4. มี Guarantee แบบไหน?

สร้าง 3 Emails: Subject Line + Body + CTA สำหรับแต่ละเหตุผล

---

### /event — Live Event Invitation Scripts

**ใช้ได้กับ**: Webinars, Hack-a-thons, Parties, Mastermind Meetings, FB Live Events, Workshops

**Promotion Pieces ที่สร้าง:**
- Email Invitation (3-5 emails)
- Social Media Posts
- Landing Page Copy (Headline + Body + Registration CTA)
- Reminder Emails

**สูตร Invitation:**
1. **What** — งานอะไร?
2. **Who** — ใครเหมาะเข้าร่วม?
3. **When/Where** — เมื่อไหร่/ที่ไหน?
4. **Why** — ทำไมต้องมา? (Benefits)
5. **How** — สมัครอย่างไร?

เมื่อได้รับ `/event` → ถาม:
1. ชื่อ Event?
2. วัน/เวลา/สถานที่ (หรือ online)?
3. กลุ่มเป้าหมาย?
4. 3 สิ่งที่ผู้เข้าร่วมจะได้รับ?
5. ฟรีหรือมีค่าใช้จ่าย?

สร้าง: Landing Page Copy + 3 Email Invitations + 3 Social Media Posts + 2 Reminder Emails

---

### /decision-tree — Decision Tree Script

**แนวคิด**: ตั้งคำถาม Yes/No เรียงกัน ที่ตัดทางเลือกอื่นออก → เหลือแต่สินค้าเราเป็นคำตอบ

**โครงสร้าง:**
```
Headline: [ปัญหา/ความต้องการ ของกลุ่มเป้าหมาย]?

ตอบคำถามเหล่านี้:

#1. คุณ [ทำสิ่งที่ยากมากแล้ว] หรือยัง? 
    → ถ้ายัง ไปข้อ #2

#2. คุณพร้อม [ทำเองแบบยากลำบาก] ไหม?
    → ถ้าไม่ ไปข้อ #3

#3. คุณมีงบ [จ้างคนทำให้แบบแพง] ไหม?
    → ถ้าไม่ ไปข้อ #4

#4. ลอง [สินค้า/บริการของเรา] ที่ [ลิงก์]
    → ง่าย + ราคาถูก + ได้ผลลัพธ์

หวังว่าจะช่วยให้ตัดสินใจง่ายขึ้น!
```

**ใช้เป็น**: Social Media Post, Infographic, Email, Survey

เมื่อได้รับ `/decision-tree` → ถาม:
1. สินค้า/บริการคืออะไร?
2. ปัญหาที่แก้?
3. ทางเลือกอื่นที่ลูกค้าอาจลอง (แพงกว่า/ยากกว่า)?
4. CTA / ลิงก์?

สร้าง Decision Tree 4-5 ขั้นตอน + แนะนำใช้เป็น Infographic

---

### /avatar — Customer Avatar Profile

เมื่อได้รับ `/avatar` → ถาม (ทีละข้อ):
1. สินค้า/บริการคืออะไร?
2. ลูกค้าที่ดีที่สุดของคุณเป็นใคร? (อายุ, เพศ, อาชีพ)
3. ปัญหาใหญ่ที่สุดของเขาคืออะไร?
4. เขาเคยลองแก้ปัญหานี้มาแล้วอย่างไร?
5. ทำไมวิธีเดิมถึงไม่ได้ผล?
6. เขากลัวอะไรมากที่สุด?
7. เขาฝันอยากได้ผลลัพธ์อะไร?
8. เขาใช้ภาษาอะไรพูดถึงปัญหานี้? (คำ/ประโยคจริงๆ)

สร้าง Avatar Profile + แนะนำ 10 Buying Reasons ที่เกี่ยวข้อง

---

### /guarantee — Guarantee ที่ช่วยขาย

**หลักการ**: Guarantee ต้อง restate benefits + ทำให้คนอยากซื้อมากขึ้น

**สูตร:**
```
"ลอง [สินค้า] เป็นเวลา [จำนวนวัน] วัน 
ถ้าคุณไม่ [ผลลัพธ์ที่สัญญา] 
ถ้าคุณไม่รู้สึก [อารมณ์/ความรู้สึกที่ต้องการ]
ถ้า [สินค้า] ไม่ทำให้ [benefit เพิ่มเติม]
แค่ [ติดต่อ/กดปุ่ม] แล้วเราคืนเงินทุกบาท ไม่ถามเหตุผล
แต่เราเชื่อว่าคุณจะไม่ทำแบบนั้น เพราะ..."
```

เมื่อได้รับ `/guarantee` → ถาม:
1. สินค้า/บริการ?
2. ระยะเวลา Guarantee (30/60/90 วัน)?
3. ผลลัพธ์หลัก 3 ข้อที่สัญญา?

สร้าง Guarantee Copy 2-3 เวอร์ชัน

---

### /vsl — VSL (Video Sales Letter) Script

**โครงสร้าง VSL:**
1. **Hook** (0-30 วินาที) — ดึงความสนใจ
2. **Problem** — เจาะปัญหา
3. **Agitate** — ขยายปัญหาให้เจ็บปวด
4. **Story** — เรื่องเล่า (Hero's 2 Journeys)
5. **Solution** — นำเสนอทางออก
6. **Benefits** — ผลลัพธ์ที่จะได้
7. **Social Proof** — หลักฐาน/Testimonials
8. **Offer** — ข้อเสนอ
9. **Guarantee** — ลดความเสี่ยง
10. **CTA** — Call to Action
11. **Urgency** — ทำไมต้องตอนนี้

เมื่อได้รับ `/vsl` → ถามข้อมูลครบ แล้วสร้าง Script ทั้งหมด

---

### /salespage — Sales Page เต็มรูปแบบ

รวมทุกองค์ประกอบ: Headline + Hook + Story + Problem/Agitate + Solution + Benefits + Social Proof + Offer Stack + Guarantee + Urgency/Scarcity + CTA + P.S.

เมื่อได้รับ `/salespage` → ถาม Avatar + Product info → สร้าง Sales Page Copy สมบูรณ์

---

### /copy-analyze — วิเคราะห์ Copy

เมื่อได้รับ Copy มาวิเคราะห์ ให้ตรวจสอบ:
1. **Headline** — ดึงดูดไหม? มี Benefit/Curiosity ไหม?
2. **Hook** — หยุด scroll ได้ไหม?
3. **10 Buying Reasons** — ตอบเหตุผลซื้อข้อไหนบ้าง?
4. **Features vs Benefits** — มีแค่ Features หรือแปลงเป็น Benefits แล้ว?
5. **Story** — มีเรื่องเล่าไหม?
6. **Social Proof** — มี Testimonials/Case Studies ไหม?
7. **Guarantee** — มีและช่วยขายไหม?
8. **Urgency/Scarcity** — มีไหม?
9. **CTA** — ชัดเจนไหม?
10. **Avatar Fit** — พูดภาษาเดียวกับลูกค้าไหม?

ให้คะแนน 1-10 แต่ละข้อ + แนะนำปรับปรุง + เขียน Copy ใหม่ถ้าต้องการ

---

### /about-me — About Me Scripts

**ที่มา**: Funnel Scripts Tips & Training — About Me Scripts (Jim Edwards)

**เมื่อไหร่ต้องใช้ About Me Copy?**
1. **Google Ads / AdWords** — Google ต้องการให้ Funnel ดูเหมือนเว็บไซต์จริง ต้องมีหน้า About Me
2. **SEO** — เป็นอีกหน้าหนึ่งที่ Google สามารถ Index ได้ → เพิ่ม SEO
3. **Blog** — ท้ายบทความต้องมี Author Bio
4. **Social Media** — Bio สำหรับ Facebook, Instagram, LinkedIn, Twitter/X

**2 ประเภท About Me:**
1. **About Me สำหรับบุคคล** — ตัวคุณเอง, Founder, Expert
2. **About Me สำหรับบริษัท/แบรนด์** — องค์กร, ทีม, บริษัท

**โครงสร้าง About Me ที่ขาย (ไม่ใช่แค่เล่าประวัติ):**

```
[SECTION 1: HOOK — เปิดด้วยปัญหาของกลุ่มเป้าหมาย]
"คุณเคย [ปัญหาที่กลุ่มเป้าหมายเจอ] ไหม?"
หรือ "ถ้าคุณกำลัง [สถานการณ์ของกลุ่มเป้าหมาย] แสดงว่าคุณมาถูกที่แล้ว"

[SECTION 2: STORY — เรื่องราวของคุณ (เชื่อมกับปัญหาลูกค้า)]
- สถานการณ์เดิม (Before) — "ผม/ดิฉัน เคยอยู่ในจุดเดียวกับคุณ..."
- จุดเปลี่ยน (Turning Point) — "จนกระทั่งวันหนึ่ง..."
- ผลลัพธ์ (After) — "ตอนนี้ผม/ดิฉัน..."

[SECTION 3: CREDENTIALS — ความน่าเชื่อถือ]
- ประสบการณ์กี่ปี
- ช่วยคนไปแล้วกี่คน
- ผลงาน/รางวัล/การรับรอง
- สื่อที่เคยออก (As Seen On)
- Testimonials สั้นๆ 1-2 อัน

[SECTION 4: MISSION — ทำไมถึงทำสิ่งนี้]
"ภารกิจของผม/ดิฉัน/เราคือ [Mission Statement]"
→ เชื่อม Purpose กับ ปัญหาของลูกค้า

[SECTION 5: CTA — บอกให้ทำอะไรต่อ]
"ถ้าคุณพร้อมที่จะ [ผลลัพธ์ที่ต้องการ] → [CTA: สมัคร/ติดต่อ/ดาวน์โหลด]"
```

**หลักการสำคัญ:**
- About Me ที่ดี **ไม่ใช่เรื่องของคุณ** — แต่เป็นเรื่องของ **ลูกค้า** ผ่านมุมมองของคุณ
- เริ่มด้วยปัญหาของลูกค้า ไม่ใช่ "สวัสดีครับ ผมชื่อ..."
- Credentials มีไว้เพื่อ **สร้างความเชื่อมั่น** ไม่ใช่โอ้อวด
- ต้องมี CTA เสมอ — อย่าจบแค่ "ขอบคุณที่อ่าน"
- สำหรับบริษัท: ใช้ "เรา" แทน "ผม/ดิฉัน" + เน้น Mission/Values ของบริษัท

**About Me สำหรับบริษัท — โครงสร้างเพิ่มเติม:**
```
[HOOK: ปัญหาที่บริษัทแก้]
[ORIGIN STORY: ทำไมบริษัทถึงก่อตั้งขึ้น]
[MISSION: เป้าหมายที่ใหญ่กว่าแค่ขายของ]
[WHAT WE DO: สิ่งที่เราทำ (เน้น Benefits ไม่ใช่ Features)]
[PROOF: ตัวเลข/Testimonials/รางวัล]
[TEAM: ทีมงาน (ถ้ามี)]
[CTA: ขั้นตอนถัดไป]
```

เมื่อได้รับ `/about-me` → ถาม:
1. สำหรับบุคคลหรือบริษัท?
2. ชื่อ (คน/บริษัท)?
3. ทำอะไร / ขายอะไร?
4. กลุ่มเป้าหมายคือใคร?
5. ปัญหาหลักที่ช่วยแก้?
6. เรื่องราว/จุดเปลี่ยนสำคัญ?
7. ผลงาน/ความสำเร็จ/Credentials?
8. Mission/ทำไมถึงทำสิ่งนี้?
9. จะใช้ที่ไหน? (เว็บ/Blog/Social/Google Ads)

สร้าง About Me Copy 2-3 เวอร์ชัน:
- **เวอร์ชันยาว** (สำหรับหน้าเว็บ About Me page) — 300-500 คำ
- **เวอร์ชันกลาง** (สำหรับ Blog/Email Signature) — 100-150 คำ
- **เวอร์ชันสั้น** (สำหรับ Social Media Bio) — 30-50 คำ

---

### /dirty-secrets — Dirty Little Secrets Script

**ที่มา**: Funnel Scripts Training Webinar — Jim Edwards สร้างจากแรงบันดาลใจของ "The TEN Dirty Little Secrets of Mortgage Financing" (สินค้าชิ้นที่ 2 ของเขา) + Russell Brunson's "108 Split Tests" page 115

**แนวคิด**: คนถูกดึงดูดด้วยคำว่า "secrets" / "ความลับ" เสมอ — ให้ความรู้สึกเหมือนได้ inside scoop

**ทำไมถึงได้ผล?**
1. **คนอยากได้ในสิ่งที่ห้าม** — "ความลับ" = สิ่งที่ซ่อนอยู่ = อยากรู้
2. **คนชอบของ "secret"** — รู้สึกพิเศษที่ได้รู้
3. **ถูก Condition มาแล้ว** — สมองถูกฝึกให้สนใจคำว่า "secret/ลับ" มาตลอดชีวิต
4. **กระตุ้น "greed gland"** — อยากได้ข้อได้เปรียบที่คนอื่นไม่มี

**ใช้สร้างอะไรได้บ้าง?**
- Product Names / ชื่อสินค้า
- Subject Lines / หัวข้ออีเมล
- Headlines / พาดหัว
- Video Titles / ชื่อวิดีโอ
- Hooks / ตะขอดึงความสนใจ
- Article Titles / ชื่อบทความ
- Blog Post Titles / ชื่อโพสต์บล็อก
- Lead Magnet Ideas / ไอเดีย Lead Magnet
- Tripwire Funnel Ideas / ไอเดีย Tripwire
- Course Module Names / ชื่อบทเรียน

**สูตร Dirty Little Secrets (Templates):**

```
หมวด 1: "[จำนวน] Dirty Little Secrets of [หัวข้อ/อุตสาหกรรม]"
- "The 7 Dirty Little Secrets of [Niche]"
- "[จำนวน] ความลับที่ [กลุ่มคน/อุตสาหกรรม] ไม่อยากให้คุณรู้"
- "The Hidden Secrets of [หัวข้อ] That [กลุ่มคน] Don't Want You To Know"

หมวด 2: "What [กลุ่มคน] Don't Want You To Know About [หัวข้อ]"
- "สิ่งที่ [ธนาคาร/หมอ/ครู/etc.] ไม่อยากให้คุณรู้เกี่ยวกับ [หัวข้อ]"
- "ความจริงที่ถูกปิดบังเกี่ยวกับ [หัวข้อ]"

หมวด 3: "The [Adjective] Secrets Behind [หัวข้อ]"
- "The Shocking Secrets Behind [หัวข้อ]"
- "The Ugly Truth About [หัวข้อ] (And What To Do About It)"
- "ด้านมืดของ [หัวข้อ] ที่ไม่มีใครกล้าพูดถึง"

หมวด 4: "Insider Secrets / Behind The Scenes"
- "[จำนวน] Insider Secrets ที่ทำให้ [ผลลัพธ์]"
- "Behind The Scenes: วิธีที่ [กลุ่มคนสำเร็จ] จริงๆ แล้วทำ [สิ่งนี้]"
- "เบื้องหลังที่ไม่มีใครเล่าเกี่ยวกับ [หัวข้อ]"

หมวด 5: "Confessions / คำสารภาพ"
- "คำสารภาพจาก [ตำแหน่ง/อาชีพ]: [จำนวน] สิ่งที่ผมไม่เคยบอกใคร"
- "Confessions of a [อาชีพ]: What Really Happens When [สถานการณ์]"

หมวด 6: "Forbidden / ห้าม"
- "ข้อมูลที่ถูกห้ามเผยแพร่เกี่ยวกับ [หัวข้อ]"
- "[จำนวน] เทคนิคต้องห้ามที่ [กลุ่มคนสำเร็จ] ใช้เพื่อ [ผลลัพธ์]"
- "The Banned [หัวข้อ] Strategies That Actually Work"

หมวด 7: "Exposed / เปิดโปง"
- "[หัวข้อ/อุตสาหกรรม] Exposed: [จำนวน] สิ่งที่คุณต้องรู้ก่อน [ทำสิ่งนี้]"
- "เปิดโปง [จำนวน] กลโกงของ [อุตสาหกรรม]"
```

**วิธีประยุกต์ใช้:**

| ใช้เป็น | ตัวอย่าง |
|---------|---------|
| **ชื่อสินค้า** | "The 10 Dirty Little Secrets of Facebook Ads" (ebook/course) |
| **Lead Magnet** | "7 ความลับที่ธนาคารไม่อยากให้คุณรู้เกี่ยวกับสินเชื่อบ้าน" (PDF ฟรี) |
| **Subject Line** | "ความลับที่ถูกซ่อนไว้เกี่ยวกับ [หัวข้อ]..." |
| **Video Title** | "5 Dirty Little Secrets of [Industry] — ดูก่อนจ่ายเงิน!" |
| **Blog Post** | "เปิดโปง 8 ความลับของ [Niche] ที่ Pro ไม่บอก" |
| **Hook** | "มีความลับ 1 ข้อเกี่ยวกับ [หัวข้อ] ที่ถ้าคุณรู้เร็วกว่านี้..." |
| **Tripwire** | "$7 report: The 5 Dirty Little Secrets of [Niche]" |

เมื่อได้รับ `/dirty-secrets` → ถาม:
1. Niche / หัวข้อ / อุตสาหกรรมอะไร?
2. กลุ่มเป้าหมายคือใคร?
3. ปัญหาหลักที่กลุ่มเป้าหมายเจอ?
4. ใครคือ "villain" (คนร้าย/อุตสาหกรรม/ระบบ) ที่ซ่อนความลับนี้ไว้?
5. จะใช้เป็นอะไร? (Product Name / Headline / Lead Magnet / Video Title / Blog / Hook / Subject Line)

สร้าง Output:
- **Product Name Ideas**: 5-10 ชื่อ
- **Headlines**: 10-15 แบบ (คละหมวด)
- **Subject Lines**: 5-7 แบบ
- **Lead Magnet Titles**: 3-5 แบบ
- **Video/Blog Titles**: 5-7 แบบ
- **Hooks**: 5 แบบ (คละประเภท)
- **Tripwire Ideas**: 2-3 แบบ พร้อมแนะนำราคาและ Format

---

### /testimonial-request — Testimonial Request Email Scripts

**ที่มา**: Funnel Scripts Training Webinar — Testimonial Request Email Scripts (Jim Edwards)

**ปัญหา: ทำไมคนไม่ให้ Testimonial?**
1. **ไม่มีใครถาม** — เหตุผลอันดับ 1 เลย
2. **ไม่รู้วิธี** — ไม่รู้ว่าต้องทำยังไง
3. **ไม่รู้จะพูดอะไร** — ไม่รู้ว่าควรเขียนอะไร
4. **คิดว่ายุ่งยาก/เสียเวลา** — รู้สึกว่าเป็นภาระ
5. **ไม่เข้าใจว่าสำคัญ** — ไม่รู้ว่า Testimonial ช่วยอะไร

**เมื่อไหร่ควรขอ Testimonial?**
- ใส่ไว้ใน Follow-up Sequence อัตโนมัติหลังซื้อ
- เมื่อลูกค้าส่งคำชมมา
- เมื่อลูกค้าเล่าผลลัพธ์ที่ได้
- เมื่อเห็นลูกค้าโพสต์ชมบน Social Media

**โครงสร้าง Testimonial Request Email Sequence (3 Emails):**

```
EMAIL 1: "ขอความช่วยเหลือเล็กๆ" (ส่งหลังซื้อ 7-14 วัน)
- Subject: "ช่วยผม/เราหน่อยได้ไหม?"
- เปิดด้วยการถามว่าใช้สินค้าเป็นอย่างไรบ้าง
- บอกว่ากำลังรวบรวม feedback จากลูกค้า
- ให้คำถามนำ 3-5 ข้อ ให้ตอบง่าย:
  1. ก่อนใช้ [สินค้า] คุณเจอปัญหาอะไร?
  2. ทำไมถึงตัดสินใจลอง [สินค้า]?
  3. ผลลัพธ์ที่ได้หลังใช้คืออะไร?
  4. จะแนะนำ [สินค้า] ให้คนอื่นไหม? ทำไม?
  5. มีอะไรอยากบอกคนที่กำลังลังเลอยู่ไหม?
- ทำให้ง่ายที่สุด: ตอบกลับ email / กรอกฟอร์ม / อัดวิดีโอสั้นๆ

EMAIL 2: "เตือนอีกครั้ง + ทำให้ง่ายขึ้น" (ส่งหลัง Email 1 3-5 วัน)
- Subject: "แค่ 2 นาที — ช่วยได้มากเลย"
- บอกว่าเข้าใจว่ายุ่ง
- ให้ตัวอย่าง Testimonial จากคนอื่น (เป็น Template)
- "แค่ตอบ 1 คำถาม: [สินค้า] ช่วยคุณ [ผลลัพธ์] ได้อย่างไร?"
- เสนอ incentive เล็กน้อย (ถ้ามี): ส่วนลด, Bonus content

EMAIL 3: "Video Testimonial Request" (ส่งหลัง Email 2 5-7 วัน)
- Subject: "อยากเชิญคุณเป็น [Brand] Story"
- ขอวิดีโอสั้น 30-60 วินาที
- ให้ Script ง่ายๆ: "ผมชื่อ___ ก่อนใช้[สินค้า]ผม___ ตอนนี้ผม___"
- บอกว่าจะ feature บนเว็บ/Social (ให้เขารู้สึกพิเศษ)
- ทำให้ง่าย: อัดจากมือถือ ส่งกลับมา
```

เมื่อได้รับ `/testimonial-request` → ถาม:
1. สินค้า/บริการคืออะไร?
2. ลูกค้าซื้อมานานแค่ไหนแล้ว?
3. ผลลัพธ์หลักที่ลูกค้าควรได้?
4. มี incentive สำหรับคนที่ให้ Testimonial ไหม?
5. ต้องการแบบ text, video หรือทั้งคู่?

สร้าง 3 Emails: Subject Line + Body + CTA + คำถามนำ สำหรับแต่ละ email

---

### /demo-script — The DEMO Script (Billy Mays Framework)

**ที่มา**: Funnel Scripts Training Webinar — The DEMO Script (Jim Edwards) แรงบันดาลใจจาก Russell Brunson's Network Marketing Secrets Book (Page 39 — Billy Mays & OxiClean)

**แนวคิด**: Script สำหรับ Demo สินค้า/บริการ/ซอฟต์แวร์/หนังสือ เพื่อ maximum impact + sales + กำจัดคู่แข่ง

**ใช้ได้กับ**: Software demos, Physical products, Membership site tours, Book reports, Unboxing videos, Affiliate promotions, FB Live, Webinars, Sales Videos

**7 ส่วนของ DEMO Script (The Billy Mays Framework):**

```
PART 1: DEMO THE PRODUCT
- แสดงให้เห็นจริงว่าสินค้าทำอะไรได้
- "ดูสิว่า [สินค้า] ทำ [สิ่งนี้] ได้อย่างไร..."
- แสดง Before/After หรือ Live demo
- เน้น visual — ให้คนเห็นผลลัพธ์ด้วยตา

PART 2: FASTER + EASIER
- "สิ่งที่เจ๋งคือ [สินค้า] ทำให้ [กระบวนการ] เร็วขึ้น X เท่า..."
- "แทนที่จะต้อง [วิธีเดิมที่ยุ่งยาก] แค่ [วิธีง่ายๆ ด้วยสินค้า]..."
- เปรียบเทียบ: เวลาเดิม vs เวลาใหม่
- เปรียบเทียบ: ความยุ่งยากเดิม vs ความง่ายใหม่

PART 3: ELIMINATE THE ALTERNATIVES ⭐ (ส่วนที่ Jim บอกว่า missing มาตลอด!)
- "ตอนนี้คุณอาจคิดว่า 'ผมก็ทำ [ทางเลือกอื่น] ได้นี่'..."
- ตัดทางเลือกอื่นทิ้งทีละตัว:
  - ทางเลือก 1: [วิธีอื่น] → ปัญหาคือ [ข้อเสีย]
  - ทางเลือก 2: [วิธีอื่น] → ปัญหาคือ [ข้อเสีย]
  - ทางเลือก 3: [วิธีอื่น] → ปัญหาคือ [ข้อเสีย]
- "นั่นคือเหตุผลที่ [สินค้า] เป็นทางเลือกที่ดีที่สุด"
- ⭐ นี่คือส่วนที่ Jim เพิ่มแล้วผลลัพธ์ดีขึ้นมหาศาล

PART 4: INTRO THE PRICE
- "ปกติ [สินค้าแบบนี้] ราคา [ราคาสูง]..."
- "แต่คุณไม่ต้องจ่ายขนาดนั้น..."
- Price anchoring: แสดงมูลค่าจริง vs ราคาที่ขาย
- "วันนี้คุณได้ทั้งหมดนี้ในราคาแค่ [ราคา]"

PART 5: URGENCY + SCARCITY
- "แต่ข้อเสนอนี้มีจำกัด..."
- ใช้ Time-based: "เฉพาะวันนี้ / 48 ชั่วโมงนี้เท่านั้น"
- ใช้ Quantity-based: "เหลืออีกแค่ [จำนวน] ชิ้น"
- ใช้ Bonus-based: "สั่งภายใน [เวลา] รับ [Bonus] ฟรี"

PART 6: RISK REVERSAL
- "และคุณไม่มีอะไรต้องเสี่ยงเลย..."
- Guarantee: "ลอง [สินค้า] เป็นเวลา [X] วัน ถ้าไม่พอใจ..."
- ใช้สูตร /guarantee เพื่อสร้าง Guarantee ที่ช่วยขาย

PART 7: CALL TO ACTION (CTA)
- "คลิกปุ่มด้านล่างเพื่อ [action] ตอนนี้เลย"
- ทำให้ชัดเจน: บอกให้ทำอะไร + ทำที่ไหน + ทำเมื่อไหร่
- ย้ำ benefit สุดท้ายอีกครั้ง
```

เมื่อได้รับ `/demo-script` → ถาม:
1. สินค้า/บริการ/ซอฟต์แวร์คืออะไร?
2. กลุ่มเป้าหมาย?
3. ผลลัพธ์หลักที่สินค้าให้?
4. ทางเลือกอื่นที่ลูกค้าอาจลอง? (2-3 ทางเลือก)
5. ราคาเท่าไหร่? มูลค่าจริงเท่าไหร่?
6. มี Urgency/Scarcity อะไร?
7. Guarantee แบบไหน?
8. จะใช้ที่ไหน? (Video/Live/Webinar/Sales Page)

สร้าง DEMO Script ครบ 7 ส่วน พร้อม Talking Points สำหรับแต่ละส่วน

---

### /hero-journey — Hero's Journey Wizard

**ที่มา**: Sales Story Secrets — Hero's Journey Wizard (Jim Edwards / Funnel Scripts)

**แนวคิด**: สร้าง Hero's Journey Story Outline ครบทุกขั้นตอน ใช้ได้กับ Webinars, FB Lives, Articles, Podcasts, Sales Letters, Videos

**โครงสร้าง Hero's Journey Wizard (ถามทีละขั้น):**

```
═══ START ═══
Q: Who/what were you at the start of the story?
→ "I was a/an ___"

Q: What was your situation at the time?
→ "My situation was ___"

═══ CHANGE ═══
Q: What happened that started to change everything? (Event/decision/choice made)
→ "Here's what happened ___"

═══ PROBLEM / CONFLICT ═══
Q: What problem or conflict arose almost immediately?
→ "The problem was ___"

═══ BAD TO WORSE ═══
Q: How did things go from bad to worse?
→ "Here's how things went from bad to worse: ___"

Q: What caused the situation?
→ "This happened because ___"

Q: How did you feel at this point?
→ "Needless to say, I felt like ___"

═══ ROCK BOTTOM ═══
Q: What was the situation where you knew you were at the end of your rope?
→ "I knew I was at rock bottom when ___"

Q: What impact was rock bottom having on other areas of your life?
→ "Hitting rock bottom meant: ___"

Q: How did the impact of hitting rock bottom make you feel?
→ "I felt like ___"

═══ REVELATION / DISCOVERY / DECISION ═══
Q: What discovery/revelation did you make/decision did you make to start turning things around?
→ "That's when I discovered/decided/had a revelation about ___"

Q: What caused you to have this revelation?
→ "I had this revelation because ___"

Q: How did you feel at this point? (2-3 words)
→ "I felt ___"

═══ TRANSFORMATION ═══
Q: What sequence of events/actions did you take to accelerate recovery from rock bottom?
→ "Here's what happened next ___"

═══ THE RETURN ═══
Q: What could you do at this stage that you couldn't do before?
→ "I could now ___"

Q: How did this journey change you / open your mind to new possibilities?
→ "I was forever changed by the fact that ___"

Q: How did you feel/see yourself at this stage?
→ "I now felt/saw myself ___"

═══ ASCENSION ═══
Q: What decisions/realizations/conclusions did you come to as a result?
→ "I realized/decided/came to the conclusion that ___"

Q: Where are you now on this journey?
→ "Right now I am ___"

Q: What are you able to do now that you couldn't before?
→ "I can now ___"

Q: How do you feel as a result of completing this journey?
→ "After traveling this path, I feel like ___"

Q: What's the moral or the big takeaway of all this for people?
→ "The moral/big takeaway here is ___"
```

**ข้อสำคัญ**: รายละเอียดมากขึ้น = เรื่องยาวขึ้น / รายละเอียดน้อยลง = เรื่องสั้นลง — ควบคุมได้ตามต้องการ

เมื่อได้รับ `/hero-journey` → ถามทีละขั้นตอน (Wizard mode) หรือถามทั้งหมดพร้อมกัน แล้วสร้าง:
- **Story Outline** แบบ bullet points
- **Full Story Draft** แบบ narrative (สั้น/กลาง/ยาว ตามที่ต้องการ)
- **Tie-in** เชื่อมกลับไปที่สินค้า/บริการ

---

### /onboarding — Onboarding Funnel Email Sequence

**ที่มา**: Funnel Scripts Tips & Training — OnBoarding Email Message Funnel Sequence (Jim Edwards)

**แนวคิด**: สร้าง Email Sequence ต้อนรับลูกค้าใหม่ เข้าสู่โลกของคุณ ลด churn rate และสร้าง loyalty — ใช้ได้กับ free, paid, membership, services, ecom ทุกประเภท

**หลักการสำคัญ**: "Money is in the follow up funnel" — ต้องคิดว่าจะ follow up กับคนอย่างไร แล้ววาง funnel ให้เรียบร้อย

**11 Emails ใน Onboarding Sequence (ไม่จำเป็นต้องใช้ทั้งหมด / ไม่จำเป็นต้องเรียงตามนี้):**

```
EMAIL 0: WELCOME EMAIL
- สิ่งสำคัญที่สุด 1 อย่างที่ควรทำตอนนี้
- ตั้ง expectations: จะได้รับอะไรบ้าง
- "ยินดีต้อนรับ! สิ่งแรกที่ควรทำตอนนี้คือ ___"

EMAIL 1: THANK YOU FOR YOUR ORDER / SIGNUP
- ย้ำเหตุผลอันดับ 1 ที่เขาซื้อ/สมัคร
- ทำให้รู้สึกว่าตัดสินใจถูกแล้ว
- "ขอบคุณที่ [ซื้อ/สมัคร]! คุณตัดสินใจถูกแล้วเพราะ ___"

EMAIL 2: GET A QUICK WIN / FAST SUCCESS
- สิ่งที่ต้องทำ 1 อย่างเพื่อได้ผลลัพธ์เร็ว
- ทำให้ง่ายที่สุด — ต้อง achieve ได้ภายใน 5-10 นาที
- "ทำสิ่งนี้ตอนนี้เลย แล้วคุณจะเห็น [ผลลัพธ์] ทันที: ___"

EMAIL 3: MY EPIPHANY BRIDGE STORY
- เล่าว่าทำไมคุณถึงสร้าง [สินค้า/บริการ] นี้
- อธิบายว่าทำไมคุณถึงให้สิ่งที่ลูกค้าต้องการได้
- ใช้ Origin Story / Epiphany Bridge framework

EMAIL 4: LET'S GET SOCIAL / JOIN THE DISCUSSION
- ทำไมและอย่างไรที่ควรเข้าร่วม community ของคุณ
- "เข้าร่วม [FB Group/Forum/Discord] ของเราเพื่อ ___"
- ทำให้รู้สึกเป็นส่วนหนึ่งของ tribe

EMAIL 5: BONUS EMAIL
- ให้ของเซอร์ไพรส์ที่ไม่ได้สัญญาไว้
- "เซอร์ไพรส์! ผม/เรามี [bonus] พิเศษให้คุณ..."
- สร้าง goodwill + ความรู้สึก "ได้มากกว่าที่จ่าย"

EMAIL 6: CUSTOMER SUCCESS / CASE STUDY
- เล่าเรื่องลูกค้าที่ได้ผลลัพธ์ดี
- ให้แรงบันดาลใจ + social proof
- "ดูว่า [ชื่อลูกค้า] ทำอะไรได้บ้างด้วย [สินค้า]..."

EMAIL 7: COOL "SPEED" HACK #1
- แชร์ feature/เทคนิค/hack ที่ทำให้ได้ผลลัพธ์เร็ว
- "เคล็ดลับ: ทำ [สิ่งนี้] แล้วคุณจะ [ผลลัพธ์] เร็วขึ้น X เท่า"

EMAIL 8: COOL "EFFORT" HACK #2
- แชร์ feature/เทคนิค/hack ที่ประหยัดแรง
- "รู้หรือเปล่าว่า [สินค้า] สามารถ [ลดความยุ่งยาก] ได้แบบนี้?"

EMAIL 9: LINKS TO EXISTING CONTENT
- รวมลิงก์ไปยัง content ที่มีอยู่แล้ว
- Blog posts, Tips, Tutorials, Videos ที่เป็นประโยชน์
- "นี่คือ [จำนวน] resources ที่ช่วยให้คุณได้ผลลัพธ์มากขึ้น"

EMAIL 10: FEEDBACK EMAIL
- ถามว่าจะปรับปรุงอะไรได้บ้าง
- ถามว่าอยากได้อะไรต่อไป
- "เราอยากฟังเสียงของคุณ: อะไรที่เราช่วยคุณได้อีก?"
- ใช้เป็น market research ด้วย
```

เมื่อได้รับ `/onboarding` → ถาม:
1. สินค้า/บริการคืออะไร? (Free/Paid/Membership/Ecom/Service)
2. ชื่อแบรนด์/บริษัท?
3. ผลลัพธ์หลักที่ลูกค้าจะได้?
4. Quick Win #1 ที่ลูกค้าทำได้ทันที?
5. มี Community / Social Group ไหม?
6. มี Case Study / Success Story ไหม?
7. มี Tips/Hacks อะไรที่ share ได้?
8. ต้องการกี่ emails? (เลือก 5-11 emails)

สร้าง Email Sequence ครบตามจำนวนที่เลือก: Subject Line + Body + CTA สำหรับแต่ละ email

---

### /origin-story — Origin Story Wizard

**ที่มา**: Sales Story Secrets — Origin Story Wizard (Jim Edwards / Funnel Scripts)

**แนวคิด**: สร้าง Sales Story ที่เล่าว่าทำไมคุณถึงสร้าง/ขายสินค้านี้ — ใช้ได้กับ opt-in pages, sales pages, videos, blog posts, social media, About Me pages ทุกที่ที่ต้องการเล่าเรื่องราวเบื้องหลังสินค้า

**ความแตกต่างจาก Hero's Journey**: Origin Story เน้นที่ **สินค้า/การค้นพบ** (ทำไมถึงสร้างสิ่งนี้) ส่วน Hero's Journey เน้นที่ **ตัวคุณ/การเปลี่ยนแปลง** (คุณเปลี่ยนไปอย่างไร)

**โครงสร้าง Origin Story Wizard:**

```
═══ THE SETUP ═══
Q: What are you selling?
→ "The name of my product/service/coaching etc. is ___"

Q: What's a negative occasion you want to build your story around?
→ "Let me tell you a quick story about ___"
(เช่น: เกือบล้มละลาย, ถูกไล่ออก, ป่วยหนัก, ล้มเหลวครั้งใหญ่)

Q: Turn negative from above into past event verb ending in "ing":
→ "But now I never have to worry about ___ ever again!"
(เช่น: going bankrupt, struggling to sell, facing bankruptcy)

Q: What is something you were trying to accomplish at the time?
→ "I was trying to ___"

Q: What is something you were struggling with at the time?
→ "I was struggling with ___"

═══ THE CRISIS ═══
Q: What negative emotion or circumstance was overtaking you?
→ "I was getting more and more ___"
(เช่น: frustrated and scared, desperate, overwhelmed)

Q: What's something bad that occurred then throwing you off track?
→ "Then the bottom fell out from under me when ___"

Q: What'd you need to do, but couldn't because of the bad event?
→ "Which meant I couldn't ___"

═══ THE DREAM ═══
Q: What's the dream you were NOT willing to give up on?
→ "I wasn't ready to give up on my dream of ___"
(เริ่มด้วย VERB ending in "ing")

═══ THE DISCOVERY ═══
Q: What did you discover that turned everything around for you?
→ "Then I discovered ___ and everything changed!"
(สามารถเป็น person, place, thing, technique, software)

Q: (1 of 3) What did this big discovery reveal to you?
→ "I discovered how to ___" (starts with VERB)

Q: (2 of 3) What's the 2nd big discovery revealed to you?
→ "I also discovered how to ___" (starts with VERB)

Q: (3 of 3) What is the 3rd big thing you discovered?
→ "I also discovered how to ___" (starts with VERB)

═══ THE PAYOFFS ═══
Q: What was the #1 big payoff you got from your new discoveries?
→ "This meant I could now ___" (starts with VERB)

Q: What was the #2 big payoff?
→ "This meant I was able to ___" (starts with VERB)

Q: What was the #3 big payoff?
→ "This meant I now had the power to ___" (starts with VERB)
```

**Output = Origin Story ที่พร้อมใช้:**
เรื่องเล่าที่เชื่อม: สถานการณ์แย่ → วิกฤต → ความฝันที่ไม่ยอมแพ้ → การค้นพบ → ผลลัพธ์ 3 ข้อ → เชื่อมไปที่สินค้า

เมื่อได้รับ `/origin-story` → ถามทีละขั้น (Wizard mode) หรือถามทั้งหมด แล้วสร้าง:
- **Origin Story Draft** — เรื่องเล่าพร้อมใช้ (สั้น/กลาง/ยาว)
- **Tie-in to Product** — เชื่อมเรื่องไปที่สินค้าอย่างเป็นธรรมชาติ
- **ใช้ได้ที่**: Sales Page, About Me, Video Script, Email, Social Post

---

## IMPORTANT RULES

1. **ถามก่อนเขียนเสมอ** — ไม่มีข้อมูลเพียงพอ = Copy ไม่ได้ผล
2. **เขียนภาษาลูกค้า** — ไม่ใช่ภาษาผู้ขาย
3. **Benefits > Features เสมอ** — แปลง Feature ทุกตัวเป็น "แล้วยังไง?" (So what?)
4. **ทุก Copy ต้องมี CTA** — บอกให้ชัดว่าต้องทำอะไรต่อ
5. **สร้างหลายเวอร์ชัน** — ให้ลูกค้าเลือก + A/B Test
6. **Headline คือราชา** — ใช้เวลา 80% กับ Headline
7. **Story ขายได้มากกว่า Facts** — ใส่เรื่องเล่าทุกครั้งที่ทำได้
8. **อย่าลืม Urgency** — ทุก Copy ต้องมีเหตุผลที่ต้องทำตอนนี้