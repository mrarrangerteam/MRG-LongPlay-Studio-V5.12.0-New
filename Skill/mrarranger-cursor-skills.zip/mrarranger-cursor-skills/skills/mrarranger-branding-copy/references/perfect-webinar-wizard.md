# perfect-webinar-wizard

**Source:** Perfect Webinar Wizard — FunnelScripts.com (Russell Brunson & Jim Edwards)
**Based on:** Expert Secrets by Russell Brunson + Perfect Webinar Framework

---

---
name: perfect-webinar-wizard
description: "Perfect Webinar Wizard — ระบบสร้าง Webinar Script ครบวงจรจาก Russell Brunson (Expert Secrets + Perfect Webinar Framework) รวม 78 คำถามที่ครอบคลุมทุกส่วนของ Webinar ตั้งแต่ Intro, Big Promise, 3 Secrets (Vehicle/Internal/External Beliefs), Stack Offer (5 Deliverables), Pricing Strategy, If/All Statements, Exclusive Bonus, Urgency/Scarcity, Close. ใช้เมื่อ: (1) สร้าง Perfect Webinar Script ตาม Russell Brunson Framework (2) วางโครงสร้าง Webinar ทั้ง 78 ส่วน (3) กรอก Webinar Input Data เพื่อสร้าง Script อัตโนมัติ (4) ออกแบบ Stack Offer สำหรับ Webinar (5) สร้าง 3 Secrets + Epiphany Bridge Stories (6) วาง Pricing Strategy (Total Value / Regular / Special) (7) เขียน If/All Statements สำหรับ Close (8) ออกแบบ Urgency Bonus. Commands: /webinar-wizard /webinar-fill /webinar-stack /webinar-secrets /webinar-close /webinar-review"
---

# Perfect Webinar Wizard — 78 Questions Framework

> **Creator**: Russell Brunson & Jim Edwards (FunnelScripts.com)
> **Based on**: Expert Secrets Book + Perfect Webinar Presentation Framework
> **Core Concept**: กรอก 78 คำถาม → สร้าง Complete Webinar Script อัตโนมัติ
> **ใช้ได้กับ**: Webinars, VSL (Video Sales Letters), Presentations, Stage Pitches, Masterclasses

---

## WEBINAR STRUCTURE OVERVIEW

Perfect Webinar แบ่งเป็น 6 ส่วนหลัก:

1. **INTRO & SETUP** (Q1-Q16) — ข้อมูลพื้นฐาน, กลุ่มเป้าหมาย, New Opportunity, Background, Proof, Pain Points
2. **SECRET #1 — THE VEHICLE** (Q17-Q22) — ทำลาย Limiting Belief เกี่ยวกับ Vehicle/วิธีการ
3. **SECRET #2 — INTERNAL BELIEFS** (Q23-Q28) — ทำลาย Limiting Belief ภายใน (ความสามารถตัวเอง)
4. **SECRET #3 — EXTERNAL BELIEFS** (Q29-Q34) — ทำลาย Limiting Belief ภายนอก (สิ่งแวดล้อม)
5. **THE STACK / OFFER** (Q35-Q68) — Stack Offer 5 Deliverables + Pricing Strategy
6. **THE CLOSE** (Q69-Q78) — If/All Statements, Exclusive Bonus, Urgency, CTA

---

## PART 1: INTRO & SETUP (Questions 1-16)

### Q1 — Your NAME
What is your name?
(Ex: Russell Brunson, Jim Edwards)

### Q2 — TITLE
What is the title of your webinar?
"How To [RESULT] Without [PAIN/OBJECTION]"
(Ex: How To Sell High Ticket Products Without Cold Calling; How To Set Up a 7-Figure Funnel in 30 Minutes Without Being Held Hostage By a Tech guy)
*(Expert Secrets, p. 157)*

### Q3 — TARGET Audience (Singular)
Who is your target audience (singular)?
"My target audience is a ______."
(Ex: online marketer; ebook author; speaker; small business owner)

### Q4 — TARGET Audience (Plural)
Who is your target audience (PLURAL)?
"______ are my target audience."
(Ex: online marketers; ebook authors; speakers; small business owners)

### Q5 — NEW OPPORTUNITY
What is the NEW OPPORTUNITY you're offering? (2-5 words)
(Ex: selling high ticket products; sales funnels; ebook marketing)
*(Expert Secrets, pp. 48-61, 160-161)*

### Q6 — VEHICLE
What is the VEHICLE that makes your New Opportunity possible?
(Ex: High Ticket Blueprint; ClickFunnels; Ebook Marketing Machine)
*(Expert Secrets, pp. 48-61, 160-161)*

### Q7 — BACKGROUND / Back Story / Qualify Yourself
What is your BACKGROUND as it relates to your audience and the topic? (3-4 Bullets)
(Ex: education; awards; accomplishments; cool personal facts)
*(Multi-line Bulleted List)*
*(Expert Secrets, pp. 161-162)*

### Q8 — EPIPHANY BRIDGE STORY
What is YOUR Epiphany Bridge Story?
Enter bullet outline of your story here.
*(Expert Secrets, pp. 114-127, 162)*

### Q9 — HOW YOUR STORY APPLIES TO THEM
HOW does your Epiphany Bridge Story apply to your audience's situation?
"Here's how my story/background applies to your situation _______."
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 163)*

### Q10 — PROOF!
What proof / case study / example do you have to show how it will also work for them?
"But it's not just me. Here's proof this'll work for you too."
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 164)*

### Q11 — Big PAYOFF #1
What is the #1 big payoff your audience wants in this area?
"They REALLY want to know how to _____." (VERB)
(Ex: make more money online; increase sales; reach financial freedom)

### Q12 — Big PAYOFF #2
What is the #2 big payoff your audience wants in this area?
"They also REALLY want to know how to _____." (VERB)
(Ex: create higher income from fewer sales; get more leads)

### Q13 — ENEMY
WHO is the ENEMY in this area? (PLURAL)
(Ex: big corporations; speaker bureaus; traditional publishers; Google; Bankers)
*(Expert Secrets, p. 25)*

### Q14 — #1 PAIN
What is the #1 pain / problem they want to avoid? (VERB ending in "ING")
"They REALLY want to AVOID _____."
(Ex: having to sell people over the phone; getting bogged down in technical stuff)

### Q15 — #2 PAIN
What is the #2 pain / problem they want to avoid? (VERB ending in "ING")
"They also REALLY want to AVOID _____."
(Ex: being held hostage by a tech guy; paying for outrageously expensive leads)

### Q16 — The BIG HOW TO
What is the One BIG HOW TO you'll focus on? (Big "HOW TO")
Include "how to" at the start.
(Ex: how to add high ticket sales to your sales funnel instantly)

---

## PART 2: SECRET #1 — THE VEHICLE (Questions 17-22)

> **Purpose**: ทำลาย Limiting Belief เกี่ยวกับ Vehicle — "ฉันไม่เข้าใจว่ามันจะช่วยฉันได้ยังไง"

### Q17 — SECRET #1 Title
What is the first secret you'll share on the webinar?
(Ex: How To Ethically Steal Over $1,000,000 Worth of Funnel Hacks From Your Competitors For Under $100)
*(Expert Secrets, pp. 134-136, 169)*

### Q18 — Vehicle Limiting Belief
What is their existing limiting belief about this (vehicle) secret?
"I don't understand how it (vehicle) will _______."
(Ex: work for me; help me make a 7-figure funnel)
*(Expert Secrets, p. 137)*

### Q19 — Vehicle Belief Reframe
How will you break and reframe that (vehicle) limiting belief?
"The truth is ______."
(Ex: the sales funnel process works to sell ANYTHING)
*(Expert Secrets, p. 172)*

### Q20 — Vehicle Epiphany Bridge Story
What Epiphany Bridge Story and points will you cover on this first secret?
(stories, talking points, demos, processes)
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 169)*

### Q21 — Vehicle PROOF
What PROOF do you have to support this first secret?
(stats, examples, case studies)
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 170)*

### Q22 — Other Vehicle Limiting Beliefs
What other limiting beliefs do we need to address about the Vehicle?
"I don't understand how it (vehicle) will _______."
*(Multi-line Bulleted List)*
*(Expert Secrets, pp. 171-172)*

---

## PART 3: SECRET #2 — INTERNAL BELIEFS (Questions 23-28)

> **Purpose**: ทำลาย Limiting Belief ภายใน — "ฉันไม่เก่ง/ไม่สามารถทำได้"

### Q23 — SECRET #2 Title
What is the second secret you'll share on the webinar?
(Ex: How To Then Clone Their PROVEN Funnel Inside ClickFunnels in Less Than 10 Minutes)
*(Expert Secrets, pp. 134-136, 169)*

### Q24 — Internal Limiting Belief
What is their existing limiting belief about this (Internal Beliefs) secret?
"I'm not _______."
(Ex: good at technical stuff; a writer; technically inclined)
*(Expert Secrets, p. 137)*

### Q25 — Internal Belief Reframe
How will you break and reframe that (Internal Beliefs) limiting belief?
"That doesn't matter because _______."
(Ex: ClickFunnels does all the work for you)
*(Expert Secrets, p. 172)*

### Q26 — Internal Epiphany Bridge Story
What Epiphany Bridge Story and points will you cover on this second secret?
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 169)*

### Q27 — Internal PROOF
What PROOF do you have to support this second secret?
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 170)*

### Q28 — Other Internal Limiting Beliefs
What other limiting beliefs do we need to address about their INTERNAL Beliefs?
"I'm not _______."
*(Multi-line Bulleted List)*
*(Expert Secrets, pp. 171-172)*

---

## PART 4: SECRET #3 — EXTERNAL BELIEFS (Questions 29-34)

> **Purpose**: ทำลาย Limiting Belief ภายนอก — "ฉันไม่รู้วิธี/ไม่มีทรัพยากร"

### Q29 — SECRET #3 Title
What is the third secret you'll share on the webinar?
(Ex: How To Get The Exact SAME Customers Who Are Going To Your Competitors' Funnels... To Start Coming To Your Funnel Instead)
*(Expert Secrets, pp. 134-136, 169)*

### Q30 — External Limiting Belief
What is their existing limiting belief about this (External Beliefs) secret?
"I don't know how to _______."
(Ex: get traffic to my funnel; sell my book once it's written)
*(Expert Secrets, p. 138)*

### Q31 — External Belief Reframe
How will you break and reframe that (External Beliefs) limiting belief?
"That's no problem because _______."
(Ex: you can see where your competitors are getting their traffic and run ads too)
*(Expert Secrets, p. 172)*

### Q32 — External Epiphany Bridge Story
What Epiphany Bridge Story and points will you cover on this third secret?
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 169)*

### Q33 — External PROOF
What PROOF do you have to support this third secret?
*(Multi-line Bulleted List)*
*(Expert Secrets, p. 170)*

### Q34 — Other External Limiting Beliefs
What other limiting beliefs do we need to address about their EXTERNAL Beliefs?
"I don't know how to _______."
*(Multi-line Bulleted List)*
*(Expert Secrets, pp. 171-172)*

---

## PART 5: THE STACK / OFFER (Questions 35-68)

> **Purpose**: สร้าง Irresistible Offer ด้วย Stack Method — 5 Deliverables + Pricing

### Q35 — NAME / TITLE of Offer
Name of what you're selling at the end of the webinar?
"The Title of my offer package is __________."
(Ex: Million Dollar Funnel Blueprint; High Ticket Profits Secrets)

### Q36 — WHAT You'll Sell
What are you actually selling on the webinar?
"I am selling a __________."
(Ex: package of software and tools; home study course; software; coaching; service)

### Deliverable #1 — MASTERCLASS (Q37-Q42)

**Q37** — NAME of core product
(Ex: 6 Week Funnel Hacks Masterclass; Ebook Marketing Machine)
*(Expert Secrets, pp. 146, 179-180)*

**Q38** — What's IN the core product?
List all the big stuff. *(One item/line = bulleted list)*
*(Expert Secrets, pp. 180-181)*

**Q39** — Proof / case studies that this works?
*(One item/line = bulleted list)*
*(Expert Secrets, p. 181)*

**Q40** — Types of people this works for
"This works for ____ who want to _____."
List several different groups.
*(Expert Secrets, p. 182)*

**Q41** — #1 Excuse & Objection Handler
"You might be thinking you can't get started because... Here's why that's a mistake..."
*(Expert Secrets, p. 183)*

**Q42** — How much is core product worth?
(Ex: $997; $497; $297)

### Deliverable #2 — TOOLS (Q43-Q49)

**Q43** — What TOOLS do they get?
Could be one tool or a list. *(Expert Secrets, p. 146)*

**Q44** — What tools enable them to DO
"With these tools you'll be able to _____."

**Q45** — What tools enable them to GET RID OF
"With these tools you can get rid of _____."

**Q46** — What problem did TOOLS solve for YOU?
"I didn't know how to _____. So I had to create/find a way to ____ for myself."
*(Expert Secrets, pp. 185-186)*

**Q47** — Time and money tools will save them
"This will save you a ton of time and money because ____."
*(Expert Secrets, p. 186)*

**Q48** — #1 Excuse & Objection Handler for tools
*(Expert Secrets, p. 187)*

**Q49** — How much are tools worth?
(Ex: $997; $497; $297)

### Deliverable #3 — TANGIBLE #1: Related to VEHICLE (Q50-Q54)

**Q50** — What proves the vehicle works for them?
(Ex: Million Dollar Funnel Clones; case studies; examples)
*(Expert Secrets, p. 147)*

**Q51** — Pain and cost to create this
"I had to go through ___ and ___ to get ___. But you won't have to because I'm giving you ___."
*(Expert Secrets, pp. 188-189)*

**Q52** — How this makes it easier/faster
"This is going to make it faster and easier for you to ____. How? Because it ____."
*(Expert Secrets, p. 189)*

**Q53** — #1 Excuse & Objection Handler
*(Expert Secrets, p. 189)*

**Q54** — How much is that worth?

### Deliverable #4 — TANGIBLE #2: Related to INTERNAL Struggle (Q55-Q59)

**Q55** — What removes their main internal struggle?
(Ex: Copywriting Secrets Course; Ad Writing Course)
*(Expert Secrets, p. 148)*

**Q56** — Pain and cost to create this
*(Expert Secrets, p. 188)*

**Q57** — How this makes it easier/faster
*(Expert Secrets, p. 189)*

**Q58** — #1 Excuse & Objection Handler
*(Expert Secrets, p. 189)*

**Q59** — How much is that worth?

### Deliverable #5 — TANGIBLE #3: Related to EXTERNAL Struggle (Q60-Q64)

**Q60** — What eliminates external roadblock?
(Ex: Instant Traffic Hacks; Facebook Ad Promo Hacks)
*(Expert Secrets, p. 148)*

**Q61** — Pain and cost to create this
*(Expert Secrets, p. 188)*

**Q62** — How this makes it easier/faster
*(Expert Secrets, p. 189)*

**Q63** — #1 Excuse & Objection Handler
*(Expert Secrets, p. 189)*

**Q64** — How much is that worth?

### Pricing Strategy (Q65-Q68)

**Q65** — TOTAL VALUE
Total up ALL deliverables. Aim for at least 10X the actual price.
(Ex: $5,000; $4,500; $2,000)

**Q66** — REGULAR PRICE
What is the regular price on your website?
(Ex: $997; $497; $97)

**Q67** — PRICE DROP REASON
"I'm giving you a special discount today because _____."
(Ex: you're here with me live on this webinar)
*(Expert Secrets, pp. 195-196)*

**Q68** — SPECIAL PRICE
What is the price when they buy TODAY?
(Ex: $997; $497; $97)

---

## PART 6: THE CLOSE (Questions 69-78)

### If/All Statements (Q69-Q71)

**Q69** — IF/ALL: VEHICLE (Related to Secret #1)
"If all this did/got you was _______, would it be worth it?" (starts with VERB)
(Ex: help you get your funnels set up without being held hostage by a tech guy)
*(Expert Secrets, pp. 192-193)*

**Q70** — IF/ALL: INTERNAL (Related to Secret #2)
"If all this did was _______, would it be worth it?" (starts with VERB)
(Ex: show you how to get it all done yourself even if you're not technical)
*(Expert Secrets, pp. 192-193)*

**Q71** — IF/ALL: EXTERNAL (Related to Secret #3)
"If all this did was _______, would it be worth it?" (starts with VERB)
(Ex: help you drive a ton of traffic and make more sales)
*(Expert Secrets, pp. 192-193)*

### Exclusive Bonus — Urgency & Scarcity (Q72-Q76)

**Q72** — #1 BEST bonus that creates urgency and scarcity
(Ex: Unlimited Funnels In Your Account (First 50 Only))
*(Expert Secrets, p. 149)*

**Q73** — Pain and cost to create this bonus
*(Expert Secrets, p. 188)*

**Q74** — How bonus makes it easier/faster
*(Expert Secrets, p. 189)*

**Q75** — #1 Excuse & Objection Handler for bonus
*(Expert Secrets, p. 189)*

**Q76** — How much is bonus worth?
(Ex: PRICELESS, $1,997; $997; $497)

### Final Close (Q77-Q78)

**Q77** — TIMEFRAME
"You'll start to see real results ______."
(Ex: in 1 Week or less; in less than 30 days; in just 30 minutes)

**Q78** — OFFER LINK
What is the special url they should go to?
(Ex: MySite.com/specialoffer/)

---

## COMMANDS

| Command | Description |
|---------|-------------|
| `/webinar-wizard` | Interactive mode — ถามทีละข้อ Q1-Q78 พร้อม Examples |
| `/webinar-fill [topic]` | กรอก 78 คำถามอัตโนมัติจาก Topic/Product ที่กำหนด |
| `/webinar-stack [product]` | สร้าง Stack Offer (Q35-Q68) แบบละเอียด |
| `/webinar-secrets [product]` | สร้าง 3 Secrets + Epiphany Bridge Stories (Q17-Q34) |
| `/webinar-close [product]` | สร้าง Close Section (Q69-Q78) If/All + Bonus + CTA |
| `/webinar-review [answers]` | Review & Optimize คำตอบที่กรอกแล้ว ให้คม + โดนใจ |

### /webinar-wizard — Interactive Mode
ถาม Q1-Q78 ทีละข้อ (หรือจัดกลุ่ม 3-5 ข้อ) พร้อมตัวอย่าง
→ Output: Complete Webinar Script Outline + Stack Slide + Close Script

### /webinar-fill
รับ Topic/Product → AI กรอก 78 คำถามให้ครบ → User Review & Edit
→ Output: Filled 78 Questions + Draft Webinar Script

### /webinar-stack
Focus เฉพาะ Stack Offer Section:
1. ตั้งชื่อ Offer Package
2. สร้าง 5 Deliverables (Masterclass + Tools + 3 Tangibles)
3. กำหนด Value + Pricing Strategy
4. เขียน Objection Handlers สำหรับแต่ละ Deliverable
→ Output: Complete Stack Offer + Value Ladder + Stack Slide Script

### /webinar-secrets
Focus เฉพาะ 3 Secrets Section:
1. Secret #1 — Vehicle (Limiting Belief + Reframe + Story + Proof)
2. Secret #2 — Internal (Limiting Belief + Reframe + Story + Proof)
3. Secret #3 — External (Limiting Belief + Reframe + Story + Proof)
→ Output: 3 Secrets Outline + Epiphany Bridge Stories + Transition Scripts

### /webinar-close
สร้าง Close Section:
1. If/All Statements (3 ข้อ)
2. Exclusive Bonus + Urgency/Scarcity
3. Final CTA + Offer Link
→ Output: Close Script + Urgency Copy + CTA Script

---

## PERFECT WEBINAR FLOW DIAGRAM

```
INTRO (Q1-Q16)
├── Who You Are + Credentials (Q1, Q7)
├── Big Promise / Title (Q2)
├── Target Audience (Q3-Q4)
├── New Opportunity + Vehicle (Q5-Q6)
├── Epiphany Bridge Story (Q8-Q9)
├── Proof (Q10)
├── Big Payoffs (Q11-Q12)
├── Enemy + Pain Points (Q13-Q15)
└── Big How To (Q16)

CONTENT — 3 SECRETS (Q17-Q34)
├── Secret #1: VEHICLE (Q17-Q22)
│   ├── Limiting Belief → Reframe
│   ├── Epiphany Bridge Story
│   └── Proof + Other Beliefs
├── Secret #2: INTERNAL (Q23-Q28)
│   ├── Limiting Belief → Reframe
│   ├── Epiphany Bridge Story
│   └── Proof + Other Beliefs
└── Secret #3: EXTERNAL (Q29-Q34)
    ├── Limiting Belief → Reframe
    ├── Epiphany Bridge Story
    └── Proof + Other Beliefs

THE STACK (Q35-Q68)
├── Offer Name + Type (Q35-Q36)
├── Deliverable #1: MASTERCLASS (Q37-Q42)
├── Deliverable #2: TOOLS (Q43-Q49)
├── Deliverable #3: TANGIBLE — Vehicle (Q50-Q54)
├── Deliverable #4: TANGIBLE — Internal (Q55-Q59)
├── Deliverable #5: TANGIBLE — External (Q60-Q64)
└── Pricing: Total Value → Regular → Drop Reason → Special (Q65-Q68)

THE CLOSE (Q69-Q78)
├── If/All Statements x3 (Q69-Q71)
├── Exclusive Bonus + Urgency (Q72-Q76)
├── Timeframe (Q77)
└── Offer Link / CTA (Q78)
```

---

## KEY PRINCIPLES

1. **New Opportunity > Improvement**: ขาย "โอกาสใหม่" ไม่ใช่ "ปรับปรุงสิ่งเดิม"
2. **3 Beliefs to Break**: Vehicle + Internal + External — ทำลายทั้ง 3 จึงจะขายได้
3. **Epiphany Bridge**: ใช้เรื่องเล่าเพื่อสร้าง "aha moment" ไม่ใช่ขายด้วย logic
4. **Stack Over Price**: สร้าง Value Stack ให้ 10X ขึ้นไป เทียบกับราคาขาย
5. **Each Deliverable = Addresses a Belief**: แต่ละชิ้นใน Stack ต้องแก้ Limiting Belief เฉพาะ
6. **If/All Close**: ให้คนตอบ "YES" ในหัว 3 ครั้งก่อน reveal ราคา