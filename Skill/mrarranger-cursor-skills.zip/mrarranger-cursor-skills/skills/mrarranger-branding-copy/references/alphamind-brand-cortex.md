# alphamind-brand-cortex

**Source:** `/mnt/skills/user/alphamind-brand-cortex/SKILL.md`
**Size:** 63259 bytes

---

---
name: alphamind-brand-cortex
description: "Alphamind Brand Cortex Academy by Paul Nathasit - Complete AI Content Engine for Business. Day1: MDM (Million Dollar Message), Brand House, Brand Cortex (6 Cortex). Day2: AI Conversion Content (24 techniques), Prompt Alchemy Framework, Content Wheel (72 topics). Day3: Sale Content Engine, 24 Selling Techniques, 4 Stages of Buying (AWARE/ACCEPT/ASPIRE/ACTION), Objection Crusher. Day4: Alphamind Workflow (Cortex→Framework→Keywords), Level of Expertise (Genin/Jonin/Kage), Fact vs Feeling. BONUS: 12 Sales Page Structure (96 techniques), 24 AI Selling Techniques (with Thai examples), 16 Brand Archetypes (full detail), 20 Tone of Voice styles, Perfect Sales Script 3.0, 96 Mega Prompts. Use for branding, positioning, content marketing, sales copy, AI system prompts, customer avatar, campaign planning, conversion content, selling scripts, sales pages, sales calls. Commands: /mdm /brandhouse /cortex /archetype /content /selling /prompt-alchemy /wiz /salespage /salescript /tone /megaprompt"
---

# Alphamind Brand Cortex Academy - Complete System

> **Creator**: Paul Nathasit (พอล ณัฐศิษฏ์) - Alphamind Thailand
> **Philosophy**: "ของดัง ได้ตังค์มากกว่า ของดี" | "คนเก่งเรื่อง AI ไม่จำเป็นต้องพรอมต์เองอีกต่อไป"
> **System**: Prompt Alchemy™ + Brand Cortex + Content Engine + Sale Engine
> **Workflow**: CORTEX (มันสมองของ CEO) → FRAMEWORK (กรอบการทำงาน) → KEYWORDS (การปรับแต่ง)
> **Quality Check**: ถูกต้อง (FACT) + ถูกใจ (FEELING)
> **Copyright**: All rights reserved 2024 - Alphamind Thailand

---

## COURSE STRUCTURE (4 Days)

**DAY 1 - BRAND CORTEX** (สร้างสมองที่ 2)
1. Million Dollar Message (MDM) - ประโยคเงินล้าน
2. Brand House - บ้านแบรนด์ ให้ AI ตัดสินใจแทนคุณ
3. Brand Cortex - สร้างสมองที่ 2 ให้ AI ทำงานแทนเจ้าของกิจการ (6 Cortex)

**DAY 2 - AI CONTENT ENGINE** (เครื่องผลิตคอนเทนต์)
1. AI Conversion Content - สร้างคอนเทนต์อย่างไรให้คนอยากซื้อขายกับคุณ
2. Prompt Alchemy™ - คนเก่งเรื่อง AI ไม่ต้องจำเป็นต้องพรอมต์ยาวๆ อีกต่อไป
3. Fast-Action Prompt - พรอมต์สั้นๆ แต่ได้ผลงานเหมือนนักการตลาดระดับโลก

**DAY 3 - AI SELLING CONTENT** (สร้างเครื่องจักรผลิตสุดยอดนักขาย)
1. Barriers - อุปสรรคของการซื้อ (5 Buying Barriers)
2. Stages - ขั้นตอนก่อนซื้อ (4A: AWARE→ACCEPT→ASPIRE→ACTION)
3. AI Selling Technique - 24 เทคนิคใช้ AI ช่วยลูกค้าเปิดใจให้อยากซื้อ

**DAY 4 - ALPHAMIND WORKFLOW** (ระบบทำงานครบวงจร)
1. Fact vs Feeling - เราจะรู้ได้ยังไงว่า AI ทำงานดีหรือไม่ดี
2. Level of Expertise - Genin (นักเรียน) → Jonin (อาจารย์) → Kage (ผู้สร้าง)
3. Alphamind Workflow - Cortex → Framework → Keywords

## COMMANDS

| Command | Description |
|---------|-------------|
| `/mdm [brand]` | สร้าง Million Dollar Message |
| `/brandhouse [brand]` | สร้าง Brand House |
| `/cortex [type]` | กรอก Cortex (company/brand/product/personal/customer/campaign/all) |
| `/archetype [brand]` | วิเคราะห์ Brand Archetype 16 แบบ (พร้อม Drive/Fear/Strategy/Voice/Color) |
| `/content [brand]` | สร้าง Conversion Content 24 แบบ + Content Wheel 72 หัวข้อ |
| `/selling [product]` | สร้าง Selling Content จาก 24 AI Selling Techniques (4 Stages) |
| `/prompt-alchemy` | สร้าง System Prompt จาก Cortex ทั้งหมด |
| `/wiz [brand]` | Wizard Mode ถามทีละข้อ |
| `/buying [product]` | วิเคราะห์ 5 Buying Barriers + 4 Stages (AWARE/ACCEPT/ASPIRE/ACTION) |
| `/salespage [product]` | สร้าง Sales Page ตาม 12-Section Structure (96 เทคนิค) |
| `/salescript [product]` | สร้าง Perfect Sales Script 3.0 (6 ขั้นตอนปิดการขาย) |
| `/tone [style]` | กำหนด Tone of Voice (20 แบบ) |
| `/megaprompt [type]` | ใช้ Mega Prompt Templates |

---

# ═══════════════════════════════════════
# DAY 1 PART 1: MILLION DOLLAR MESSAGE
# ═══════════════════════════════════════

## ปัญหาที่ MDM แก้
1. ลูกค้า**จำชื่อแบรนด์ไม่ได้** 2. ลูกค้า**จำจุดขายไม่ได้** 3. ลูกค้า**ไม่รู้ว่าทำไมต้องซื้อ** 4. ลูกค้าซื้อแล้วจะซื้อซ้ำ**จำไม่ได้** 5. ลูกค้าอยากแนะนำแต่**แนะนำไม่ได้**

## MDM Framework
```
Brand:          ชื่อแบรนด์ (บริษัท/สินค้า/บุคคล)
Target group:   ช่วยให้กลุ่มเป้าหมาย ___
Achieve result: ให้บรรลุเป้าหมายเรื่อง ___
Without doing:  โดยไม่ต้องทำ ___
So you can:     เพื่อให้ลูกค้าสามารถ ___
```

## ตัวอย่าง MDM
**Zero-Cash Property Tycoon**: ช่วยให้พนักงานประจำเงินเดือน 40,000+ | มีรายได้จากอสังหาฯ 100,000/เดือน | โดยไม่ต้องใช้เงินตัวเองลงทุน | เพื่อสะสมทรัพย์สินและสร้าง Passive Income

**MAD MUSCLE**: ช่วยให้ผู้บริหารที่ไม่มีเวลาไปยิม | สร้าง 6 packs หุ่นน่าฟันทันซัมเมอร์ | โดยไม่ต้องอดของหวาน ไม่ต้องออกกำลังกายหนัก | เพื่อเดินถอดเสื้อริมชายหาดได้แบบคูลๆ

**AI Content Conversion**: ช่วยให้พนักงานการตลาด | หารายได้เสริมเพิ่มได้เดือนละ 50,000 ใช้เวลา 30 นาที/วัน | โดยไม่ต้องโทรหาลูกค้า ไม่ต้องขายของ ไม่ต้องยิงแอด

---

# ═══════════════════════════════════════
# DAY 1 PART 2: BRAND HOUSE (บ้านแบรนด์)
# ═══════════════════════════════════════

## ปัญหาที่ Brand House แก้
1. **Identity**: แบรนด์ไม่ชัด คนจำไม่ได้ 2. **Direction**: พาลูกค้าไปไหนไม่ชัด 3. **Pillar**: เนื้อหากระจัดกระจาย 4. **Selling point**: จุดขายไม่ชัด ขายไม่ได้ก็เน้นแต่โปรโมชั่น

## Value Proposition 3 ระดับ
- **ระดับ 1**: ขาย Function (คุณสมบัติสินค้า)
- **ระดับ 2**: ขาย Time/Experience (ประสบการณ์)
- **ระดับ 3**: ขาย Opportunity/Transformation (โอกาส/การเปลี่ยนแปลง)

> "เปลี่ยนคุณค่าที่นำเสนอใหม่ มูลค่าก็เปลี่ยน" | Category Benefit ≠ Brand Benefit

## Brand House Framework
```
BRAND NAME (WHO):      ชื่อแบรนด์ (เลือก 1: บริษัท/สินค้า/บุคคล) - มี 1 คำจำง่าย ชื่อแบรนด์เป็นคำ ชื่อแบรนด์สื่อสาร
CATEGORY (WHERE):      หมวดหมู่ธุรกิจ/อุตสาหกรรม - อยู่ในหมวดหมู่ที่มีมูลค่าสูง
PURPOSE (WHY):         เป้าประสงค์ (ที่ไม่ใช่เรื่องเงิน - WordCloud Conviction)
POSITIONING (WHO):     จุดยืนในใจลูกค้า - เป็นโมเดล OTM, พร้อมยืนยันตำแหน่ง 3 แบบ
PROMISE (WHAT):        คำสัญญาสำคัญเพียงหนึ่งเดียว - สิ่งที่แตกต่างจากคู่แข่ง
PILLAR (HOW):          ข้อความสำคัญ 3 เสาหลัก (A, B, C)
PROOF (1-3 per Pillar): หลักฐาน 3 ข้อ x 3 Pillar = 9 Proofs
Brand Archetype (WHO):  บุคลิก (Primary 50-70%, Secondary 20-30%, Tertiary 10-20%) + Positioning, Promise, Proof
Brand Values (WHY):     ค่านิยม (A, B, C) สอดคล้องกับแต่ละ Pillar
```

## ตัวอย่าง: Alphamind Thailand
- **Category**: Marketing Automation Education
- **Purpose**: Empowering small entrepreneurs to live their life on their terms
- **Positioning**: AI Marketing Accelerator "ผู้เพิ่มศักยภาพธุรกิจด้วย AI"
- **Promise**: Empowering Entrepreneurs and Making more impact to the world
- **Pillar A**: Empower more (เพิ่มความสามารถหารายได้)
- **Pillar B**: Work less (ทำงานน้อยลงด้วย AI)
- **Pillar C**: Do what you do best (ทำในสิ่งที่อยากทำมากที่สุด)
- **Archetype**: HERO 50% + MAGICIAN 30% + Explorer 20%

---

# ═══════════════════════════════════════
# DAY 1 PART 3: BRAND CORTEX (6 มิติ)
# ═══════════════════════════════════════

## 1. Company Cortex (13 ข้อ)
ชื่อบริษัท, พันธกิจ, วิสัยทัศน์, ค่านิยมหลัก, เรื่องราวบริษัท, การวางตำแหน่ง, จุดแตกต่าง, คำมั่นสัญญา, ข้อความหลัก 3 ข้อ, การรับรู้, Brand Archetype, Corporate Identity/Visual, Company Voice

## 2. Brand Cortex (12 ข้อ)
ชื่อแบรนด์+Tagline, วิสัยทัศน์, ค่านิยม, เรื่องราว, Positioning, Differentiation, Promise, Pillar 3 ข้อ, Perception, Archetype, Identity/Visual, Voice

## 3. Product Cortex (9 ข้อ)
ชื่อสินค้า+Tagline, จุดประสงค์, Product Promise (A→B), Benefits, USP/Differentiation, Features/Functions, Price Point, Positioning, Competitive Landscape

## 4. Personal Brand Cortex (13 ข้อ)
ชื่อ, พันธกิจส่วนตัว, วิสัยทัศน์, ค่านิยม, เรื่องราว, Positioning, Differentiation, Promise, Pillar 3 ข้อ, Perception, Archetype, Identity/Visual, Voice

## 5. Customer Cortex (8 ข้อ)
Customer Avatar, Ideal Character, Non-Customer, Struggles, Roadblocks, **Core Currency** (ต้องวัดได้ เช่น "ผิวกระจ่างใสขึ้น 2 ระดับใน 14 วัน"), Increase Benefit, Decrease Pains

## 6. Campaign Cortex (11 ข้อ)
วัตถุประสงค์, เป้าหมาย SMART, KPIs, กลุ่มเป้าหมาย, ช่องทาง, CTA, งบประมาณ, กรอบเวลา, สินค้าที่โปรโมท, ราคาปกติ, ข้อเสนอพิเศษ

---

# ═══════════════════════════════════════
# DAY 2 PART 1: AI CONVERSION CONTENT
# ═══════════════════════════════════════

## 24 เทคนิค Conversion Content

### กลุ่ม CONVERSION (ดึงลูกค้าเข้ามา)
1. **SBS - Symptoms Before Solutions**: หาอาการก่อนแก้ปัญหา
2. **Relatable Struggle**: ลำบากเคียงกัน
3. **Curiosity Gap**: ปิดช่องว่างอยากรู้
4. **DCW - Defy Conventional Wisdom**: ท้าทายความเชื่อเดิม
5. **BFB - Breaking False Beliefs**: หลุดความเชื่อผิด

### กลุ่ม ENGAGEMENT (ดึงดูดความสนใจ)
6. **Elephant in the Room**: ช้างในห้อง
7. **Foundation Principles**: หลักการพื้นฐาน
8. **Signature Method**: วิธีเฉพาะของเรา
9. **Visual Framework**: แผนภาพง่ายๆ
10. **Compare the Alternatives**: เปรียบเทียบทางเลือก

### กลุ่ม DIGITAL ASSET (สร้างสินทรัพย์ดิจิทัล)
11. **Overcoming Skepticism**: ชัดข้อสงสัย
12. **Cost of Inaction**: ไม่ทำก็เสียกระทบ
13. **Triple Yes**: ใช่ ใช่ ใช่
14. **Great Paradox**: ปริศนาความขัดแย้ง
15. **Create Urgency**: สร้างความเร่งด่วน

### กลุ่ม AUTOMATION (สร้างระบบอัตโนมัติ)
16. **Opportunity Switch**: เปลี่ยนทิศทางให้เห็นโอกาส
17. **Cake or Coke**: แสดงให้เห็นว่าสามารถได้ทั้งสอง
18. **Cognitive Ease**: ทำเรื่องยากให้ง่าย
19. **Hero's Journey**: การเดินทางของฮีโร่
20. **Natural Law**: กฎธรรมชาติ

### กลุ่ม PROOF (หลักฐานความน่าเชื่อถือ)
21. **Price Anchoring**: ราคาอ้างอิง
22. **Familiarity Factor**: ความคล้ายคลึงที่คุ้นเคย
23. **Social Proof**: สังคมยืนยัน
24. **Compounding Effect**: ผลทวีคูณ

## วิธีใช้ Content Wheel สร้าง 72+ หัวข้อ
1. หา **Big Idea** (เราจะพาลูกค้าไปไหน จาก A → B)
2. หา **3 Key Messages** จาก Brand House Pillars
3. **คูณ 3 Pillars x 24 เทคนิค = 72 หัวข้อคอนเทนต์**
4. ใช้ AI สร้างคอนเทนต์จากแต่ละหัวข้อ

---

# ═══════════════════════════════════════
# DAY 2 PART 2: PROMPT ALCHEMY™
# ═══════════════════════════════════════

## Prompt Alchemy™ Framework (3 ชั้น x 5 องค์ประกอบ)

### โครงสร้างคำสั่ง (Structure of Prompt)
1. **Command** (คำสั่งที่ชัดเจน) - Create/Write/Identify/Analyze/Improve/Develop/Evaluate/Compare/Opinion
2. **Context** (บริบทที่เจาะจง) - Goal/Objective/Background/Location/Situation
3. **Output** (ผลลัพธ์ที่ต้องการ) - Timeline/Format/Number/Steps/Category
4. **Framework** (วิธีการคิด) - Language/Personality/Reference/Framework/Structure
5. **Cortex** (คลังข้อมูล) - Company/Brand/Personal/Product/Customer/Campaign

### ชุดคำสั่ง (Prompt Framework)
1. **System Prompt** - ชุดคำสั่งหลัก (ใส่ Cortex ทั้ง 6 ส่วน)
2. **Task-specific Prompt** - ชุดคำสั่งรอง (งานเฉพาะ)
3. **Negative Prompt** - ชุดคำสั่งป้องกัน

### Fast-Action Prompt (หลัง)
เปลี่ยนจากพรอมต์ยาว → พรอมต์สั้นที่ได้ผลเหมือนกัน เพราะ Cortex + Framework ถูกฝังไว้ใน System Prompt แล้ว
ตัวอย่าง: `[เขียนสคริปต์ในการปิดการขาย] โดยใช้ [Perfect Sales Script] สำหรับหลักสูตร [Income Automation] กลุ่มเป้าหมาย [เจ้าของธุรกิจ]`

## Thai Rewriting System (25 Variables)
Top 10: Simplicity 50%, Sentence Structure 100%, Engaging Headlines 100%, Persuasion 60%, Objection Handling 50%, Rhetorical Questions 50%, Counter-Intuitive Questions 80%, Benefits-Oriented Content 100%, Storytelling 40%, Customer-Centric Language 100%

---

# ═══════════════════════════════════════
# DAY 3: AI SELLING CONTENT ENGINE
# ═══════════════════════════════════════

## 5 Buying Barriers (อุปสรรคของการซื้อ)
1. **UNAWARE** - ไม่รู้ว่าตัวเองมีปัญหา
2. **PROBLEM** - รู้ว่าตัวเองมีปัญหา
3. **SOLUTION** - รู้ว่ามีทางแก้
4. **BRAND** - รู้ว่ามีตัวเลือกแบรนด์อะไรบ้าง
5. **MOST AWARE** - รู้หมดทุกอย่างแต่ไม่ลงมือทำ

> ตัวอย่าง: ชาไข่มุก (ทุกคน Most Aware) vs นาฬิกา Rolex (ต้องพา Unaware→Brand) vs ร้านซักผ้า Trendy Wash (ต้องสร้าง Awareness)
> "เมื่อเป้าหมายยิ่งใหญ่กว่าอุปสรรค" - ยกหินทั้งวัน แล้วได้เงินวัน 1 ล้าน คุณจะทำไหม?

## 4 Stages of Buying (4A Framework)

### Stage 1: AWARE (ตระหนักรู้)
ช่วยให้ลูกค้ารับรู้และตระหนักถึงปัญหาหรือความต้องการ

### Stage 2: ACCEPT (ยอมรับ)
กระตุ้นให้ลูกค้ายอมรับความท้าทายและความจำเป็นที่ต้องแก้ไข

### Stage 3: ASPIRE (ปรารถนา)
สร้างแรงบันดาลใจให้ลูกค้าเห็นภาพอนาคตที่ดีกว่า

### Stage 4: ACTION (ลงมือทำ)
กระตุ้นให้ลูกค้าตัดสินใจลงมือทำทันที

---

# ═══════════════════════════════════════
# 24 AI SELLING TECHNIQUES (ตาราง 4 Stages)
# ═══════════════════════════════════════

## Stage 1: AWARE (เทคนิค 1-5)

| No. | Technique | Objectives | ตัวอย่างภาษาไทย |
|-----|-----------|-----------|-----------------|
| 1 | Attention-Grabbing Headline (ใช้หัวข้อเรียกแขก) | ดึงความสนใจทันที | "ธุรกิจคุณกำลังเผาเงินกับการตลาดไร้ประสิทธิภาพอยู่หรือเปล่า?" / "เบื่อไหมกับการลดน้ำหนักที่ไม่เห็นผล?" / "ทำไมสตาร์ทอัพส่วนใหญ่ล้มเหลวในปีแรก?" |
| 2 | Problem-Solution (มีโจทย์อะไรที่แก้ไปแล้ว) | ระบุปัญหา นำเสนอสินค้าเป็นคำตอบ | "พนักงานลาออกบ่อย? นี่คือวิธีที่เราจะช่วยคุณได้" / "ค่าไฟพุ่งสูง? โซลูชันของเราช่วยคุณประหยัดได้" / "เว็บไซต์โหลดช้า? ลองใช้เครื่องมือเพิ่มประสิทธิภาพของเรา" |
| 3 | Storytelling (ใช้การเล่าเรื่อง) | สร้างความเชื่อมโยงผ่านเรื่องราว | "เส้นทางของเจ้าของธุรกิจเล็กๆ สู่กำไรหลักล้าน" / "การเดินทางสู่สุขภาพดีของคุณพ่อคนหนึ่งด้วยโปรแกรมของเรา" / "จากสตาร์ทอัพที่ดิ้นรนสู่ผู้นำตลาด" |
| 4 | Counter-Intuitive Question | กระตุ้นความอยากรู้ | "จริงหรือไม่? การกินไขมันมากขึ้นอาจช่วยให้คุณผอมลงได้" / "กลยุทธ์การตลาดราคาแพงกำลังฉุดรั้งคุณอยู่หรือเปล่า?" / "การไล่พนักงานที่เก่งที่สุดออกเป็นการตัดสินใจที่ถูกต้องจริงหรือ?" |
| 5 | Contrarian Approach | ท้าทายความเชื่อเดิม | "ทำไมการทำงานหนักขึ้นไม่ได้ทำให้คุณประสบความสำเร็จเสมอไป" / "ความจริงเกี่ยวกับอาหารไขมันต่ำ: ทำไมมันอาจกำลังทำร้ายสุขภาพคุณ" |

## Stage 2: ACCEPT (เทคนิค 6-10)

| No. | Technique | Objectives | ตัวอย่างภาษาไทย |
|-----|-----------|-----------|-----------------|
| 6 | Testimonials (มีคนได้ผลลัพธ์ไหม) | สร้างความน่าเชื่อถือผ่านความสำเร็จของลูกค้า | "เราช่วยธุรกิจเล็กๆ เพิ่มยอดขาย 50% ในเวลาแค่ 3 เดือน!" / "ดูว่าลูกค้าของเราพูดถึงบริการบัญชีของเรายังไงบ้าง" |
| 7 | Social Proof (ได้รับการยอดรับในวงกว้าง) | ตอกย้ำปัญหาผ่านกรณีศึกษา | "เข้าร่วมกับธุรกิจนับพันที่ไว้วางใจโซลูชันของเรา" / "ได้รับคะแนน 5 ดาวจากลูกค้ากว่า 10,000 ราย" |
| 8 | Authority (ทำไมลูกค้าต้องเชื่อคุณ) | สร้างความน่าเชื่อถือให้แบรนด์ | "กลยุทธ์การเติบโตของเราได้รับการตีพิมพ์ใน New York Times" / "CEO ของเราได้รับเชิญให้พูดในงานสุดยอดด้านสุขภาพระดับโลก" |
| 9 | Specificity (ระบุตัวเลขชัดเจน) | ใช้ตัวเลขทำให้น่าเชื่อถือ | "ลูกค้าของเราเห็นผลตอบแทนเฉลี่ย 300% ในเวลาแค่ 6 เดือน" / "ข้อมูลแสดงให้เห็นว่าเวลาระบบล่มลดลง 95%" |
| 10 | Addressing Objections (ขยี้คำคัดค้านในใจ) | จัดการความกังวลของลูกค้า | "กังวลเรื่องค่าใช้จ่าย? ดูวิธีที่ตัวเลือกการเงินของเราทำให้คุณจ่ายได้" / "ไม่แน่ใจว่าเหมาะกับคุณหรือไม่? ลองใช้ฟรีก่อน" |

## Stage 3: ASPIRE (เทคนิค 11-18)

| No. | Technique | Objectives | ตัวอย่างภาษาไทย |
|-----|-----------|-----------|-----------------|
| 11 | Benefit-Driven Language (ภาษาผลประโยชน์) | เน้นย้ำการเปลี่ยนแปลงและผลลัพธ์ | "เปลี่ยนบ้านธรรมดาให้เป็นบ้านอัจฉริยะด้วยโซลูชันระบบอัตโนมัติของเรา" / "สร้างร่างกายในฝันด้วยโปรแกรมฟิตเนสของเรา" |
| 12 | The 'Before and After' (ผลลัพธ์ก่อนและหลัง) | แสดงความแตกต่างระหว่างปัจจุบันและอนาคต | "ดูความแตกต่าง: ก่อนและหลังใช้ผลิตภัณฑ์ดูแลผิวของเรา" / "วิธีที่ลูกค้าของเราเพิ่มยอดขายได้ 200% ในเวลาเพียง 3 เดือน" |
| 13 | Exclusivity (ความรู้สึกพิเศษ) | สร้างความปรารถนาด้วยโอกาสพิเศษ | "เข้าร่วมเป็นสมาชิกพิเศษและเพลิดเพลินกับสิทธิพิเศษระดับพรีเมียม" / "จำกัดจำนวน: เหลือที่ว่างเพียง 100 ที่ในมาสเตอร์คลาสของเรา" |
| 14 | Micro-Commitment Strategy | สร้างความผูกพันทีละขั้น | "ทำแบบทดสอบ 2 นาทีของเราเพื่อค้นพบแผนการออกกำลังกายที่เหมาะกับคุณที่สุด" / "ลงทะเบียนทดลองใช้ฟรี" |
| 15 | Bonuses or Added Value (คนไทยชอบได้ของแถม) | เพิ่มมูลค่า สร้างแรงจูงใจ | "ลงทะเบียนวันนี้และรับการโค้ชแบบตัวต่อตัวฟรี 1 ครั้ง" / "สั่งซื้อตอนนี้และรับคู่มือโบนัสพิเศษ" |
| 16 | Value Stacking (แสดงมูลค่าของสิ่งต่างๆ) | เน้นมูลค่ารวมทั้งหมด | "แพ็คเกจการตลาดครบวงจรของเราในราคาสุดคุ้ม" / "ซื้อชุดสกินแคร์ของเราและประหยัด 20%" |
| 17 | Open Loops (สะกิดให้อยากแล้วจากไป) | กระตุ้นความสนใจด้วยเรื่องค้างคา | "พรุ่งนี้เราจะเปิดเผยความลับในการเพิ่มยอดขายของคุณเป็นสองเท่า" / "เร็วๆ นี้: ผลิตภัณฑ์สกินแคร์ปฏิวัติวงการของเรา" |
| 18 | Video Sales Letter (VSL) | ใช้วิดีโอแสดงการเปลี่ยนแปลงของลูกค้า | "ดูวิธีที่ผลิตภัณฑ์ของเราเปลี่ยนแปลงธุรกิจนี้" / "ชมผลลัพธ์ที่น่าทึ่งจากโปรแกรมลดน้ำหนักของเราในเวลาเพียง 30 วัน" |

## Stage 4: ACTION (เทคนิค 19-24)

| No. | Technique | Objectives | ตัวอย่างภาษาไทย |
|-----|-----------|-----------|-----------------|
| 19 | Urgency (ทำไมต้องตอนนี้) | สร้างความรู้สึกเร่งรีบ | "เหลือที่ว่างเพียง 10 ที่ – ลงทะเบียนตอนนี้!" / "โอกาสสุดท้ายในการประหยัด 30%" / "ข้อเสนอจำกัดเวลา: รับส่วนลด 20%" |
| 20 | Free Offer (มีอะไรแจก) | เสนอวิธีทดลองโดยไม่มีความเสี่ยง | "รับการทดลองใช้ซอฟต์แวร์ของเราฟรีวันนี้" / "ดาวน์โหลดอีบุ๊คฟรี" / "ปรึกษาฟรีสำหรับลูกค้าใหม่" |
| 21 | Call to Action (CTA) (ภาษาชวนลงมือทำ) | ให้ขั้นตอนชัดเจน | "คลิกที่นี่เพื่อเริ่มต้นการเดินทางสู่สุขภาพที่ดี" / "ลงทะเบียนตอนนี้เพื่อจองที่นั่ง" / "ซื้อตอนนี้เพื่อเริ่มการรีโนเวทบ้านของคุณวันนี้" |
| 22 | Limited Offer (จำไว้ว่าต้องมีข้อจำกัด) | ใช้ความจำกัดกระตุ้นการตัดสินใจ | "มีเพียง 100 ชิ้นเท่านั้น - รีบจับจองก่อนหมด!" / "ข้อเสนอนี้จะหมดอายุภายใน 24 ชั่วโมง" / "สินค้ามีจำนวนจำกัด" |
| 23 | Guarantee (รับรองผลลัพธ์) | ลดความเสี่ยงที่ลูกค้ารับรู้ | "รับประกันความพึงพอใจ 100% หรือคืนเงิน" / "ทดลองใช้โดยไม่มีความเสี่ยงเป็นเวลา 30 วัน" / "คืนเงินเต็มจำนวนหากคุณไม่พอใจ" |
| 24 | Clear and Simple Language (พูดจาภาษาคน) | สื่อสารขั้นตอนชัดเจน หลีกเลี่ยงศัพท์เทคนิค | "ไม่มีศัพท์แสงยุ่งยาก แค่ผลลัพธ์" / "พูดภาษาที่เข้าใจง่าย" / "ทำไมการส่งสารแบบเรียบง่ายถึงได้ผลดีที่สุด" |

---

# ═══════════════════════════════════════
# TOP 12 SALES PAGE STRUCTURE (96 เทคนิค)
# ═══════════════════════════════════════

## 12 Sections ของ Sales Page

| Section | Thai | จำนวนคำ | คำอธิบาย |
|---------|------|---------|---------|
| 1. Headline | หัวข้อเรียกแขก | 12-15 | สร้างหัวข้อที่มีประสิทธิภาพ benefit-driven ดึงดูดความสนใจ |
| 2. Sub-headline | คำขยายขายประโยชน์ | 15-20 | สนับสนุนหัวข้อข่าว ตอบโจทย์ปัญหาหลักของกลุ่มเป้าหมาย |
| 3. Introduction | เกริ่นนำต้องทำให้ทันใจ | 20-30 | แนะนำปัญหาที่ผลิตภัณฑ์แก้ไข แสดงความเห็นอกเห็นใจ |
| 4. Product Overview | เน้นจุดขาย ได้ความต่าง | 30-50 | อธิบายผลิตภัณฑ์ คุณสมบัติ วิธีการทำงาน ภาษาเรียบง่าย |
| 5. Social Proof | ใครบ้างที่ใช้แล้วได้ผลลัพธ์ | 30-50 | คำรับรอง บทวิจารณ์ กรณีศึกษา สร้างความไว้วางใจ |
| 6. Benefits & Results | ประโยชน์ตรงใจ ใช้คำบ้านๆ | 50-70 | รายละเอียดประโยชน์และผลลัพธ์เฉพาะ ใช้ bullet points |
| 7. Bonuses/Value Added | คนไทยชอบได้ของแถม | 30-50 | สิ่งจูงใจเพิ่มเติม โบนัส เนื้อหาพิเศษ ส่วนลด |
| 8. Pricing & Payment | ราคาเอาให้ชัด อย่ายัดไส้ดอกจันทน์ | 20-30 | ราคาสินค้า ส่วนลด ช่องทางชำระเงิน การรับประกัน |
| 9. FAQ | คำถามเพื่อเคลียร์ความในใจ | 30-50 | ตอบคำถามและข้อกังวลทั่วไป ช่วยให้เข้าใกล้การซื้อ |
| 10. Risk Reversal | อย่าให้มีความเสี่ยงเพื่อเลี่ยงการจ่าย | 30-50 | การรับประกันคืนเงิน ลดความเสี่ยงที่รับรู้ |
| 11. Call-to-Action (CTA) | ลงมือจ่ายให้ง่าย อย่าใช้ท่าเยอะ | 30-50 | CTA ที่ชัดเจนและน่าสนใจ กระตุ้นให้ดำเนินการ |
| 12. Closing Thoughts | ทิ้งท้ายให้สะกิดใจ ถ้าไม่จ่ายในตอนนี้ | 20-30 | เตือนครั้งสุดท้ายเกี่ยวกับคุณประโยชน์ ข้อเสนอจำกัดเวลา |

> **รวม**: 350-500 คำ สำหรับ Sales Page ที่มีประสิทธิภาพ

### แต่ละ Section มี 8 เทคนิค (8 x 12 = 96 เทคนิค)
เมื่อใช้ `/salespage` ให้เลือกเทคนิคที่เหมาะสมในแต่ละ Section:

**Headline** (8 เทคนิค): ข้อเสนอโดยตรง, อุทธรณ์ทางอารมณ์, ใช้ตัวเลข/สถิติ, กลุ่มเป้าหมายมุ่งเน้น, รูปแบบปัญหา-แก้ปัญหา, การถามคำถาม, ความอยากรู้/การวางอุบาย, USP

**Sub-headline** (8 เทคนิค): เสริมสร้างหัวข้อข่าว, ผลประโยชน์รอง, กลุ่มเป้าหมาย, ความเร่งด่วน/ขาดแคลน, Social Proof, USP, อุทธรณ์ทางอารมณ์, คำถามเชิงวาทศิลป์

**Introduction** (8 เทคนิค): หัวข้อดึงดูด, เปิดด้วยคำถาม, เรื่องราว/เกร็ดเล็กเกร็ดน้อย, ข้อเท็จจริงน่าตกใจ, แก้ Pain Point, สร้างความน่าเชื่อถือ, ทีเซอร์ผลประโยชน์, มุ่งเน้นผลลัพธ์

**Product Overview** (8 เทคนิค): คุณสมบัติ+ประโยชน์, ปัญหา-แก้ปัญหา, USP, คำอธิบายชัดเจน, คำเปรียบเทียบ, ภาพ/มัลติมีเดีย, ระบุกลุ่มเป้าหมาย, วิวัฒนาการสินค้า

**Social Proof** (8 เทคนิค): Testimonials, Case Studies, Influencer Endorsements, สื่อกล่าวถึง, จำนวนผู้ใช้, Before/After, การให้คะแนน/รีวิว, รางวัลอุตสาหกรรม

**Benefits/Results** (8 เทคนิค): รายชื่อประโยชน์หลัก, ผลลัพธ์เชิงปริมาณ, ปัญหา-แก้ปัญหา, ส่วนบุคคล/ปรับแต่ง, ประหยัดเวลา, ประโยชน์ทางอารมณ์, เปรียบเทียบทางเลือก, ผลกระทบระยะยาว

**Bonuses** (8 เทคนิค): ข้อเสนอจำกัดเวลา, การเข้าถึงพิเศษ, สินค้าเสริม, ส่วนลด, การรับประกันเพิ่มเติม, สื่อการฝึกอบรม, การให้คำปรึกษาส่วนตัว, อัปเกรด/คุณสมบัติเพิ่ม

**Pricing** (9 เทคนิค): การกำหนดราคาแบบ Tier, ส่วนลด/โปรโมชั่น, แผนการชำระเงิน, รับประกันคืนเงิน, ราคา Early Bird, Bundle พิเศษ, ข้อเสนอครั้งเดียว, จำนวนจำกัด, Upsell/Cross-sell

**FAQ** (8 เทคนิค): ข้อกังวลทั่วไป, ชี้แจงคุณสมบัติ, เน้น USP, แสดงผลลัพธ์, ข้อโต้แย้ง, ราคา/การชำระเงิน, การสนับสนุน, ความเข้ากันได้

**Risk Reversal** (8 เทคนิค): รับประกันคืนเงิน, ทดลองใช้ฟรี, No-questions-asked, จัดส่งฟรี, ราคาที่ตรงกัน, รับประกันตลอดอายุ, Testimonials/Case Study, รับประกันผลลัพธ์

**CTA** (8 เทคนิค): ชัดเจนตรงไปตรงมา, สร้างความเร่งด่วน, เน้นประโยชน์, ภาษา Action, ปรับแต่ง CTA, เสนอสิ่งจูงใจ, Social Proof, แก้ข้อโต้แย้ง

**Closing** (8 เทคนิค): สรุปข้อเสนอ, เสริมสร้างความเร่งด่วน, ย้ำรับประกัน, ย้ำ CTA, เน้นความขาดแคลน, เรื่องราวส่วนตัว, แก้ข้อโต้แย้งที่เหลือ, เน้นการเปลี่ยนแปลง

---

# ═══════════════════════════════════════
# PERFECT SALES SCRIPT 3.0
# ═══════════════════════════════════════

> สคริปต์การขายที่พิสูจน์แล้วว่าสามารถปิดการขายสินค้ามูลค่าสูง ด้วยการประชุมเชิงกลยุทธ์ ผ่านการโทรศัพท์เพียงแค่ครั้งเดียว โดยไม่ต้องกดดันการขาย

## 6 ขั้นตอนปิดการขาย

### 1. FRAME - กำหนดขอบเขตการสนทนา
- **Rapport**: สร้างความสัมพันธ์ สอบถาม ชื่นชม เชื่อมโยง (ส่วนตัวหรือธุรกิจ)
- **Control**: ระบุระยะเวลาของการพูดคุย
- **Goals**: ระบุเป้าหมายการประชุม → 1. ความชัดเจน (ขั้นตอนจาก A→B) 2. ความช่วยเหลือ (ตัดสินใจว่าจะไปต่อหรือไม่)

### 2. DISCOVER - ค้นหาความต้องการ
- **Audit product roadmap**: ตรวจสอบว่าลูกค้าต้องการตรงกับข้อเสนอ
- **Struggles**: ลูกค้าลงมือแก้ไขอะไรไปแล้วบ้าง ใช้สินค้า/บริการอื่นๆ อุปสรรค อารมณ์
- **Costs**: ช่วยลูกค้าคำนวณค่าเสียหาย (จำนวนเงิน เวลา ความสัมพันธ์) ของการไม่ถึงเป้าหมาย
- **Motivation**: ทำไมลูกค้านัดประชุม ทำไมสำคัญเป็นพิเศษ
- **Intent**: ตั้งใจแก้ปัญหาจริงจังหรือไม่ มีอำนาจตัดสินใจหรือไม่

### 3. PROBLEMS - ระบุปัญหาที่ต้องการแก้ไข
- **Challenge**: ถ้ายังไม่ได้แก้ไข จะเผชิญอะไรในอนาคต อีกนานแค่ไหน ผลกระทบ
- **Product roadmap**: ตรวจสอบว่าปัญหาตรงกับสินค้า/บริการ เชื่อมโยงคุณสมบัติเข้ากับปัญหา
- **Urgency**: "ในสเกล 1-5 คุณให้ความสำคัญกับ_____ มากแค่ไหนในตอนนี้ครับ?"
- **Value**: ถ้ามั่นใจ 100% ลูกค้าจะลงทุนเท่าไหร่เพื่อแก้ปัญหานี้

### 4. PRESCRIPTION - ระบุอาการของโรค
- **Permission**: ผมรับรู้ได้ถึงปัญหา ความยากลำบาก เกี่ยวกับ [ลูกค้าประเภทเดียวกัน]
- **Permission to recommendation**: ผมขออนุญาตให้คำแนะนำ [จำนวน] ขั้นตอน เพื่อพาคุณไปยังเป้าหมาย
- **Million Dollar Message**: ประโยคทองของข้อเสนอคุณ
- **Qualifications**: แนวทางของเราไม่เหมาะกับคนส่วนใหญ่ - เรารู้ชัดเจนว่าเราสามารถช่วยใครได้
- **Accept**: จะรับเป็นลูกค้าเมื่อ (เงื่อนไข 1, 2, 3)
- **Rejects**: จะปฏิเสธลูกค้าเมื่อ (สาเหตุ 1, 2, 3)

### 5. TREATMENT - แนวการรักษาที่แตกต่าง
- **How It Works**: อธิบายข้อเสนอที่ออกแบบมาเป็นพิเศษ สำหรับ [ลูกค้าประเภทเดียวกัน]
- **Steps**: เสต็ปที่พาลูกค้าจาก A→B (1, 2, 3, 4, 5)
- **Differentiation**: ทำไมโปรแกรมนี้ถึงแตกต่างจากสิ่งที่เคยลองและล้มเหลว (ห้ามขายของ ห้ามระบุ features)

### 6. INVITATION - เชิญให้ซื้อบริการ
- **Invitation**: จากสิ่งที่ได้พูดคุยกันมาทั้งหมด ผมอยากจะเชิญชวนให้ลูกค้าเป็นลูกค้ารายต่อไป ในราคา ___
- **Remark**: เสร็จแล้วให้เงียบ ไม่ต้องพูดอะไรต่อ จนกว่าลูกค้าจะเอ่ยปาก

### FAQ (คำถามถามบ่อย)
- **Clear**: ค้นหาว่าลูกค้ากังวลอะไรจริงๆ แยก Fact vs Feeling
- **Confidence**: ช่วยมั่นใจใน 1. System 2. Support 3. Show results
- **Desire**: ทำไมถึงคิดว่าบริการของเราดีกว่า
- **Commitment**: ยืนยันปัญหา ความมุ่งมั่น เป้าหมาย ความเปลี่ยนแปลง

---

# ═══════════════════════════════════════
# 16 BRAND ARCHETYPES (รายละเอียดครบ)
# ═══════════════════════════════════════

## กลุ่ม LEAVE LEGACY (ทิ้งมรดก)

### The Outlaw (กบฏ) - REVOLUTION
- **Quote**: "Rules are made to be broken"
- **Voice**: Disruptive, Rebellious, Combative
- **Message**: You don't have to settle for status quo. First, demand more, second, go out and get it.
- **Drive**: Liberation, Change, Righteousness, Revenge, Independence
- **Fear**: Servitude, Conformity, Complacency, Acceptance, Dependence
- **Strategy**: Denounce Status Quo + Disrupt + Shock
- **Brands**: Virgin, Harley-Davidson, Diesel
- **Colors**: #b15e39, #faf6eb, #55250d, #a56f40, #efd494

### The Magician (นักมายากล) - POWER
- **Quote**: "It can happen"
- **Voice**: Mystical, Informed, Reassuring
- **Message**: Tomorrow is brighter than today and all your dreams can come true if you believe.
- **Drive**: Transformation, Knowledge, Vision, Belief, Discovery
- **Fear**: Consequences, Stagnation, Ignorance, Doubt, Uncertainty
- **Strategy**: Develop A Vision & Live By It + Transformation
- **Brands**: Coca-Cola, Disney, Dyson
- **Colors**: #0070b5, #49b7e9, #8681e8, #fe89be, #fd4431

### The Hero (วีรบุรุษ) - MASTERY
- **Quote**: "Where there's a will theres a way"
- **Voice**: Honest, Candid, Brave
- **Message**: We can make the world better. We have the grit and determination to outwork the rest.
- **Drive**: Mastery, Courageousness, Growth, Development, Defence
- **Fear**: Incompetence, Cowardice, Deterioration, Downfall, Incapability
- **Strategy**: Become Stronger and Better + Prove People Wrong
- **Brands**: Adidas, Nike, FedEx
- **Colors**: #0e0d13, #2b2d41, #ffffff, #c2bcc1, #cc3e2f

## กลุ่ม PURSUE CONNECTION (สร้างความเชื่อมโยง)

### The Lover (คนรัก) - INTIMACY
- **Quote**: "I only have eyes for you"
- **Voice**: Sensual, Empathetic, Soothing
- **Message**: Your Striking Beauty Is Impossible To Ignore.
- **Drive**: Sensuality, Closeness, Indulgence, Affection, Love
- **Fear**: Rejection, Loneliness, Isolation, Invisibility, Contempt
- **Strategy**: Reaffirm Beauty + Red Carpet Treatment
- **Brands**: Alfa Romeo, Chanel, Victoria's Secret

### The Jester (ตัวตลก) - PLEASURE
- **Quote**: "If I cant dance, I'm not part of it"
- **Voice**: Fun Loving, Playful, Optimistic
- **Message**: We're here for a short time, not for a long time. Let your hair down and start living life.
- **Drive**: Fun, Happiness, Laughter, Togetherness, Positivity
- **Fear**: Boredom, Gloom, Sadness, Loneliness, Negativity
- **Strategy**: Promote Good-Times + Make Them Laugh
- **Brands**: M&M's, Old Spice, Dollar Shave Club

### The Everyman (คนธรรมดา) - BELONGING
- **Quote**: "You're Just Like Me And I'm Just Like You"
- **Voice**: Friendly, Humble, Authentic
- **Message**: When we treat each other with honesty and friendliness we can live together in harmony
- **Drive**: Connection, Togetherness, Equality, Fellowship, Inclusion
- **Fear**: Exclusion, Standing Out, Isolation, Hostility, Disassociation
- **Strategy**: Align with Basic Values + Create a Welcoming Community
- **Brands**: IKEA, Target, Lynx

## กลุ่ม PROVIDE STRUCTURE (สร้างโครงสร้าง)

### The Caregiver (นักดูแล) - SERVICE
- **Quote**: "Love Your Neighbour As Yourself"
- **Voice**: Caring, Warm, Reassuring
- **Message**: Everyone deserves care and we must all strive to bestow service upon one another.
- **Drive**: Support, Help, Service, Recognition, Gratitude
- **Fear**: Anguish, Helplessness, Ingratitude, Neglect, Blame
- **Strategy**: Others Before Self + The Greater Good Is Worth Sacrifice
- **Brands**: Unicef, WWF, TOMS

### The Ruler (ผู้ปกครอง) - CONTROL
- **Quote**: "Power isn't everything, It's the only thing"
- **Voice**: Commanding, Refined, Articulate
- **Message**: You are Successful in work and in life. Reward your excellence and your achievements.
- **Drive**: Power, Prosperity, Status, Success, Wealth
- **Fear**: Weakness, Insignificance, Failure, Poverty, Destitution
- **Strategy**: Exert Leadership + Demonstrate Superiority
- **Brands**: Louis Vuitton, Mercedes-Benz, Rolex

### The Creator (นักสร้างสรรค์) - INNOVATION
- **Quote**: "If It Can Be Imagined It Can Be Created"
- **Voice**: Inspirational, Daring, Provocative
- **Message**: See Potential Everywhere and Uncover Originality With Liberated Imagination.
- **Drive**: Creation, Originality, Self-Expression, Vision, Imagination
- **Fear**: Stagnation, Duplication, Familiarity, Disillusion, Indifference
- **Strategy**: Inspire To Unlock Imagination + Encourage The Pursuit of Originality
- **Brands**: LEGO, Apple, Adobe

## กลุ่ม EXPLORE SPIRITUALITY (สำรวจจิตวิญญาณ)

### The Explorer (นักสำรวจ) - FREEDOM
- **Quote**: "Don't Fence Me In"
- **Voice**: Exciting, Fearless, Daring
- **Message**: You Only Get One Life. Get Out And Make It Count.
- **Drive**: Adventure, Exploration, The Unknown, Self Discovery, Liberation
- **Fear**: Confinement, Immobility, Entrapment, Incarceration, Cautiousness
- **Strategy**: Celebrate The Journey + Acknowledge Modern Confinements
- **Brands**: The North Face, Jeep, Patagonia

### The Sage (ปราชญ์) - UNDERSTANDING
- **Quote**: "The Truth Will Set You Free"
- **Voice**: Knowledgeable, Assured, Guiding
- **Message**: Education Is The Path To Wisdom And Wisdom Is Where The Answers Lie.
- **Drive**: Wisdom, Intelligence, Expertise, Information, Influence
- **Fear**: Ignorance, Insanity, Powerlessness, Misinformation, Inaccuracy
- **Strategy**: Show The Path To Wisdom + Celebrate Life-Long Learning
- **Brands**: Google, BBC, Oxford

### The Innocent (ผู้บริสุทธิ์) - SAFETY
- **Quote**: "Life Is Simple And Simplicity Is Elegant"
- **Voice**: Optimistic, Honest, Humble
- **Message**: The Most Wholesome Things in Life are Unadulterated and Pure.
- **Drive**: Happiness, Morality, Simplicity, Honesty, Positivity
- **Fear**: Anguish, Depravity, Complexity, Deceit, Negativity
- **Strategy**: Display Wholesome Virtue + Foster Feel-Good Spirit
- **Brands**: Aveeno, Dove, Innocent

**การใช้ใน Brand House**: Primary 50-70% + Secondary 20-30% + Tertiary 10-20% อ้างอิงจาก Positioning, Promise, Proof

---

# ═══════════════════════════════════════
# 20 TONE OF VOICE STYLES
# ═══════════════════════════════════════

## Playful (สนุกสนาน)
| Tone | English | Thai |
|------|---------|------|
| Humorous | ใช้ไหวพริบและความตลกขบขัน | ตลกขบขัน |
| Cheerful | สดใส มีความสุข มองโลกในแง่ดี | ร่าเริง |
| Enthusiastic | พลังงานและความกระตือรือร้นสูง | กระตือรือร้น |
| Casual | ผ่อนคลาย ไม่เป็นทางการ | สบายๆ |
| Sarcastic | ใช้การประชดหรือเยาะเย้ย | เหน็บแนม |

## Neutral (เป็นกลาง)
| Tone | English | Thai |
|------|---------|------|
| Friendly | อบอุ่น เข้าถึงได้ | เป็นมิตร |
| Direct | ตรงไปตรงมา | ตรงประเด็น |
| Empathetic | แสดงความเข้าใจและเห็นอกเห็นใจ | เห็นอกเห็นใจ |
| Neutral | เป็นกลาง ไม่มีอารมณ์ส่วนตัว | เป็นกลาง |

## Professional (มืออาชีพ)
| Tone | English | Thai |
|------|---------|------|
| Confident | แสดงความมั่นใจ | มั่นใจ |
| Authoritative | ให้ความเคารพ เป็นผู้เชี่ยวชาญ | มีอำนาจ |
| Educated | ใช้คำศัพท์ขั้นสูง | มีการศึกษา |
| Respectful | คำนึงถึงความรู้สึกผู้อื่น | ให้ความเคารพ |
| Professional | สุภาพ จริงจัง แสดงความเชี่ยวชาญ | มืออาชีพ |

## Formal (เป็นทางการ)
| Tone | English | Thai |
|------|---------|------|
| Formal | เป็นไปตามแบบแผน กฎเกณฑ์ | เป็นทางการ |
| Diplomatic | มีไหวพริบ ละเอียดอ่อน | นักการทูต |
| Serious | สื่อถึงความสำคัญและความจริงจัง | จริงจัง |
| Matter-of-Fact | ปราศจากอารมณ์ ตรงไปตรงมา | ตามข้อเท็จจริง |
| Polite | แสดงกิริยาที่ดี ภาษาสุภาพ | สุภาพ |
| Somber | จริงจัง เคร่งขรึม | อึมครึม |

---

# ═══════════════════════════════════════
# DAY 4: ALPHAMIND WORKFLOW
# ═══════════════════════════════════════

## Fact vs Feeling (ถูกต้อง vs ถูกใจ)

### ถูกต้อง (FACT)
จุดแข็งของแบรนด์, ความต้องการลูกค้า, ข้อมูลของสินค้า, ข้อมูลของบริษัท, ข้อมูลคู่แข่ง, งานวิจัย, องค์ความรู้

### ถูกใจ (FEELING)
ถูกอาการ, ถูกอารมณ์, ถูกค่านิยม, ถูกความคาดหวัง, ถูกเวลา, ถูกสถานที่, ถูกเหตุการณ์

> "ถ้าอยากใช้ AI ให้เก่ง คุณควรรู้ว่าทำไมคุณถึงชอบ หรือไม่ชอบ"

## Alphamind Workflow
```
CORTEX → FRAMEWORK → KEYWORDS
(มันสมองของ CEO) → (กรอบการทำงาน) → (การปรับแต่ง)
```

## Level of Expertise

| Level | Thai | สัดส่วน | คำอธิบาย |
|-------|------|---------|---------|
| **CORTEX** | Junior | 50% | พนักงานใหม่เรียนรู้เกี่ยวกับสินค้า/บริษัท/เจ้าของ |
| **FRAMEWORK** | Supervisor | 40% | มาตรฐานและกระบวนการทำงานที่บริษัทใช้ |
| **KEYWORDS** | Manager | 10% | การแก้ไขปัญหาเฉพาะหน้า ปรับปรุงแก้ไข |

### 3 ระดับผู้ใช้ (อ้างอิง Naruto)
- **GENIN** (ระดับนักเรียน): เรียนรู้ เข้าใจ ใช้ประจำ ทำให้คล่อง
- **JONIN** (ระดับอาจารย์): รวดเร็ว ปรับปรุง ผสมผสาน เปลี่ยนแปลงตามสถานการณ์ ใช้งานโดยอัตโนมัติ
- **KAGE** (ระดับผู้สร้าง): รวบรวม เรียบเรียง ทดลอง สร้างสรรค์สิ่งใหม่

---

# ═══════════════════════════════════════
# ONE FUNNEL ONE MILLION PATHWAY
# ═══════════════════════════════════════

## Phase 1: Digital Business Blueprint
- **Brand Cortex**: สร้างสมองที่ 2 ด้วย AI
- **Customer Blueprint**: ลูกค้าแบบไหนกำไรที่สุด
- **Asset Alchemy**: สร้างสินค้าดิจิตอลด้วย AI

## Phase 2: Digital Assets
- **Money Magnet**: หารายชื่อลูกค้าโดยไม่ต้องขายของ
- **Content Alchemy**: เครื่องผลิตคอนเทนต์
- **Authority Builder**: ทำไมลูกค้าถึงควรฟังคุณ

## Phase 3: Conversion Secret
- **Sales PowerPlant**: เครื่องจักรผลิตเงิน
- **Objection Crusher**: ปิดการขายแบบไม่ขาย
- **Traffic TakeOver**: ไม่ต้องดังก็ทำตังค์ได้เดือนละ 100,000

---

# ═══════════════════════════════════════
# SYSTEM PROMPT TEMPLATE
# ═══════════════════════════════════════

เมื่อใช้คำสั่ง `/prompt-alchemy` ให้สร้าง System Prompt ในรูปแบบนี้:

```
# [ชื่อแบรนด์] - AI Marketing Assistant

## บทบาท
คุณคือผู้เชี่ยวชาญด้านการตลาดและการขายของ [ชื่อแบรนด์]

## ข้อมูลบริษัท
[ใส่ข้อมูลจาก Company Cortex]

## ข้อมูลแบรนด์
[ใส่ข้อมูลจาก Brand Cortex]

## ข้อมูลสินค้า
[ใส่ข้อมูลจาก Product Cortex]

## ข้อมูลเจ้าของ
[ใส่ข้อมูลจาก Personal Brand Cortex]

## ข้อมูลลูกค้า
[ใส่ข้อมูลจาก Customer Cortex]

## กฎการสื่อสาร
- น้ำเสียง: [จาก Brand Voice / Tone of Voice 20 แบบ]
- บุคลิก: [จาก Brand Archetype 16 แบบ]
- ภาษา: [Thai Rewriting Variables]
- สิ่งที่ห้ามพูด: [Negative Prompt]
```

---

# OUTPUT FORMAT

**MDM**: ตาราง Brand/Target/Result/Without/Enjoy - สร้าง 5-10 ตัวอย่าง
**Brand House**: ตาราง Framework ครบทุก Field
**Cortex**: ตารางแยกตาม Cortex พร้อมคำตอบ
**Content Wheel**: ตาราง 3 Pillars x 24 เทคนิค = 72 หัวข้อ
**Selling Content**: เลือกเทคนิค 24 แบบ (4 Stages) + สร้างสคริปต์/คอนเทนต์
**Sales Page**: 12 Sections x 8 เทคนิค = 96 ตัวเลือก + สร้าง Sales Page
**Sales Script**: Perfect Sales Script 3.0 (6 ขั้นตอน + FAQ)
**Archetype**: วิเคราะห์จาก 16 Archetypes พร้อม Drive/Fear/Strategy/Voice/Color
**Tone**: เลือกจาก 20 Tone of Voice styles
**System Prompt**: Markdown formatted prompt พร้อมใช้งาน

## LANGUAGE RULES
- ตอบเป็นภาษาไทยเป็นหลัก ยกเว้นคำศัพท์เฉพาะ
- โทนเสียงเป็นมิตร ให้กำลังใจ เหมือนที่ปรึกษาธุรกิจ
- เน้น Clarity เป็นอันดับแรก
- ให้ตัวอย่างจริงเสมอ ไม่ใช่แค่ทฤษฎี
- ใช้ Rule of Three (จัดกลุ่ม 3 ข้อ) เพื่อให้จดจำง่าย
- ตรวจสอบทั้ง Fact (ถูกต้อง) และ Feeling (ถูกใจ) ก่อนส่ง Output