# mrarranger-clone-master

**Source:** `/mnt/skills/user/mrarranger-clone-master/SKILL.md`
**Size:** 8975 bytes

---

---
name: mrarranger-clone-master
description: |
  ระบบ Clone ขั้นเทพ - โคลนได้ทุกอย่าง: คน, แบรนด์, App, เว็บไซต์, Content Creator, ศิลปิน, สไตล์การเขียน
  วิเคราะห์ DNA และ Replicate ได้แม่นยำ รองรับการโคลนข้ามประเภท
  ใช้เมื่อ: (1) โคลนสไตล์คนดัง/Expert (2) โคลนแบรนด์/Voice (3) โคลน App/UX (4) โคลน Content Style (5) โคลนศิลปิน/เพลง (6) วิเคราะห์ DNA ของอะไรก็ได้
  Commands: /clone [type] [target], /dna [target], /replicate [style], /morph [from] [to], /reverse-engineer [target]
---

# MRARRANGER Clone Master

## Quick Commands

```
/clone person [name]        → โคลนสไตล์บุคคล
/clone brand [name]         → โคลน Brand Voice
/clone app [name]           → โคลน App/UX Flow
/clone content [creator]    → โคลนสไตล์ Content
/clone artist [name]        → โคลนศิลปิน/เพลง
/dna [target]               → วิเคราะห์ DNA
/replicate [style]          → สร้างงานในสไตล์นั้น
/reverse-engineer [target]  → ถอดรหัสวิธีทำ
```

## Clone Types

### 1. Person Clone (โคลนบุคคล)

วิเคราะห์และจำลอง:
```
DNA Components:
├── Communication Style
│   ├── Vocabulary (คำที่ใช้บ่อย)
│   ├── Sentence Structure (โครงสร้างประโยค)
│   ├── Tone (formal/casual/provocative)
│   └── Signature Phrases (วลีเด็ด)
├── Thinking Pattern
│   ├── Mental Models ที่ใช้
│   ├── Decision Framework
│   └── Problem-solving Approach
├── Values & Beliefs
│   ├── Core Principles
│   ├── What they advocate
│   └── What they oppose
└── Content Patterns
    ├── Topics they cover
    ├── How they structure arguments
    └── Examples/Analogies they use
```

**Example Clone Process:**
```
Target: Elon Musk

DNA Analysis:
- Communication: Direct, provocative, meme-friendly
- Vocabulary: "First principles", "order of magnitude", "insane"
- Tone: Confident, sometimes trolling, technical yet accessible
- Thinking: Physics-based reasoning, 10x thinking
- Values: Multi-planetary species, sustainable energy, free speech

Output Style:
"Look, the fundamental problem with [X] is that people aren't 
thinking from first principles. They're just iterating on 
existing solutions. What if we 10x this? What's the physics 
limit here?"
```

### 2. Brand Clone (โคลนแบรนด์)

```
DNA Components:
├── Voice & Tone
│   ├── Personality (playful/serious/luxurious)
│   ├── Language Level (simple/sophisticated)
│   └── Emotional Register
├── Visual Identity
│   ├── Color Psychology
│   ├── Typography Style
│   └── Image Treatment
├── Messaging Framework
│   ├── Key Messages
│   ├── Value Propositions
│   └── Taglines/Slogans
└── Content Pillars
    ├── Topics they own
    ├── Stories they tell
    └── Customer relationship style
```

**Brand Clone Examples:**
```
Apple: Minimalist, aspirational, "Think Different"
Nike: Motivational, action-oriented, "Just Do It"
Innocent Drinks: Playful, quirky, conversational
```

### 3. App/Website Clone (โคลน UX)

```
DNA Components:
├── User Flow
│   ├── Onboarding Process
│   ├── Core Loop
│   └── Conversion Funnel
├── UI Patterns
│   ├── Navigation Structure
│   ├── Component Library
│   └── Interaction Patterns
├── Feature Set
│   ├── Core Features
│   ├── Differentiating Features
│   └── Hidden/Power Features
└── Business Model
    ├── Monetization Strategy
    ├── Growth Mechanics
    └── Retention Hooks
```

### 4. Content Creator Clone

```
DNA Components:
├── Format Signature
│   ├── Video/Post Structure
│   ├── Opening Hook Style
│   ├── Pacing/Rhythm
│   └── Closing/CTA Pattern
├── Topic Selection
│   ├── Niche Focus
│   ├── Angle/Perspective
│   └── Trending Topic Approach
├── Engagement Style
│   ├── How they interact with audience
│   ├── Community building tactics
│   └── Controversy handling
└── Production Style
    ├── Visual Aesthetic
    ├── Editing Rhythm
    └── Sound/Music Choices
```

### 5. Artist/Music Clone

```
DNA Components:
├── Musical Signature
│   ├── Genre/Subgenre
│   ├── Tempo Range
│   ├── Key Preferences
│   └── Chord Progressions
├── Production Style
│   ├── Sound Design
│   ├── Mixing Approach
│   ├── Signature Sounds
│   └── Arrangement Patterns
├── Vocal Style (if applicable)
│   ├── Tone/Timbre
│   ├── Delivery Style
│   ├── Lyrical Themes
│   └── Flow/Rhythm
└── Visual Aesthetic
    ├── Album Art Style
    ├── Music Video Themes
    └── Stage Presence
```

## Clone Process Framework

### Step 1: DNA Extraction
```
1. Gather Samples
   - Collect 10-20 examples of their work
   - Note patterns across samples
   
2. Identify Constants
   - What appears in EVERY sample?
   - What makes it recognizably "them"?
   
3. Map Variables
   - What changes between samples?
   - What's their range?
```

### Step 2: Pattern Analysis
```
1. Surface Patterns (Easy to spot)
   - Vocabulary, phrases, formatting
   
2. Structural Patterns (Medium)
   - How they organize ideas
   - Argument flow
   
3. Deep Patterns (Hard to spot)
   - Underlying worldview
   - Mental models
   - Values driving decisions
```

### Step 3: Synthesis
```
1. Create Clone Profile
   - Document all patterns
   - Note do's and don'ts
   
2. Generate Test Output
   - Create sample in their style
   - Compare to originals
   
3. Refine
   - Adjust based on comparison
   - Iterate until authentic
```

## Clone Templates

### Person Clone Template
```
## [Name] Clone Profile

### Quick Stats
- Known for: [primary association]
- Communication style: [1-2 words]
- Signature move: [their trademark]

### Voice Characteristics
- Tone: [description]
- Vocabulary level: [simple/moderate/complex]
- Favorite words: [list]
- Phrases to use: [list]
- Phrases to avoid: [list]

### Thinking Style
- Primary mental model: [model]
- How they frame problems: [description]
- Decision criteria: [what matters to them]

### Content Patterns
- Typical structure: [outline]
- Opening style: [how they start]
- Closing style: [how they end]
- Examples they use: [types]

### Sample Output
[Example text in their style]
```

### Brand Clone Template
```
## [Brand] Clone Profile

### Brand Essence
- One word: [word]
- Personality: [3 traits]
- If this brand were a person: [description]

### Voice Guidelines
- Tone: [description]
- Do say: [examples]
- Don't say: [examples]
- Sentence length: [short/medium/long]

### Visual DNA
- Primary colors: [colors]
- Typography feel: [description]
- Image style: [description]

### Messaging Framework
- Key message 1: [message]
- Key message 2: [message]
- Key message 3: [message]
- Tagline style: [description]

### Sample Outputs
- Social post: [example]
- Email subject: [example]
- Ad headline: [example]
```

## Advanced: Cross-Clone

ผสม DNA จากหลายแหล่ง:
```
/morph [source1] [source2] [ratio]

Example:
/morph "Steve Jobs" "Thai Uncle" 70:30

Result: Visionary thinking + Thai warmth
"ลองคิดดูนะครับ ถ้าเราเริ่มจากศูนย์ ไม่มี assumption เดิมๆ 
เราจะออกแบบ [X] ยังไง? นี่คือสิ่งที่ผมอยากให้ทุกคนถามตัวเอง..."
```

## Reverse Engineering Framework

```
/reverse-engineer [target]

Output:
1. What: สิ่งที่เขาทำ (observable output)
2. How: วิธีที่เขาทำ (process/technique)
3. Why: ทำไมถึงได้ผล (underlying principle)
4. Replicate: วิธี apply กับงานเรา
```

## File References

- `references/person-clones.md` - Clone profiles ของคนดัง 50+ คน
- `references/brand-clones.md` - Clone profiles ของแบรนด์ดัง 30+ แบรนด์
- `references/clone-techniques.md` - เทคนิคการโคลนขั้นสูง