# inception-copywriting

**Source:** `/mnt/skills/user/inception-copywriting/SKILL.md`
**Size:** 22325 bytes

---

---
name: inception-copywriting
description: "Inception Copywriting™ by Paul Nathasit (Alphamind Thailand) - ระบบเขียนขายด้วย AI แบบครบวงจร ใช้ Cortex + Framework + Golden Nugget สร้าง Sales Page, VDO Script, Webinar Script ระดับโลก (Jon Penberthy & Russell Brunson style) พร้อม Hypnosis Techniques. รวม Million Dollar Message, SalesPage Cortex (10 sections/60 questions), Inception Framework (SalesPage/VDO/Webinar x 2 styles), Golden Nugget 36 ข้อ (คาถาสาริกาลิ้นทอง), AI Learning Model 15 เทคนิค, Sales Page Analysis (Dan Koe/Russell Brunson/Jon Penberthy/SaaS). ใช้เมื่อ: (1) เขียน Sales Page/Copy ที่ขายได้ (2) สร้าง VDO Script/Webinar Script (3) ทำ Million Dollar Message (4) กรอก SalesPage Cortex (5) ใช้ Golden Nugget ปรับภาษาให้โดนใจ (6) วิเคราะห์ Sales Page (7) สร้าง CustomGPT สำหรับเขียนขาย (8) Clone สไตล์การเขียนขายของ Expert (9) เขียน Objection Handling (10) สร้าง Conversion Content ภาษาไทย. Commands: /mdm /cortex /salespage /vdo /webinar /nugget /analyze /clone /objection /bot"
---

# Inception Copywriting™ - AI Sales Writing System

> **Creator**: Paul Nathasit (พอล ณัฐศิษฏ์) - Alphamind Thailand
> **Course**: AI Inception Copywriting - เขียนเปลี่ยนชีวิตด้วย AI
> **Philosophy**: "AI ไม่รู้จักธุรกิจเรา → สอนมันด้วย Cortex → ใส่ Framework → ปรับด้วย Golden Nugget"
> **Core Workflow**: CORTEX (สมอง) → FRAMEWORK (โครงสร้าง) → GOLDEN NUGGET (ปรับแต่ง)
> **Inspired by**: "Unlimited Selling Power" + Jon Penberthy + Russell Brunson
> **Copyright**: All rights reserved 2024 - Alphamind Thailand

---

## SYSTEM OVERVIEW

Inception Copywriting ใช้หลักการ 3 ชั้น:

1. **CORTEX** (แกนสมอง) — ชุดข้อมูลธุรกิจ/สินค้า/ลูกค้า ที่สอน AI ให้เข้าใจธุรกิจของเรา
2. **FRAMEWORK** (กรอบการเขียน) — โครงสร้างการเขียนขายระดับโลก (Jon Penberthy / Russell Brunson style)
3. **GOLDEN NUGGET** (คาถาสาริกาลิ้นทอง) — 36 เทคนิคปรับภาษาให้โดนใจ เหมาะกับวัฒนธรรมไทย

**AI Learning Model 15 เทคนิค** (วิธีสอน AI เหมือนสอนพนักงาน):
- **Input (6)**: Chunking, RAG, Data Preprocessing, Synthetic Data, Multi-modal Learning, Context Injection
- **Processing (6)**: Transfer Learning, Active Learning, RLHF, Hyperparameter Tuning, Explainable AI, Few-shot/Zero-shot
- **Output (3)**: Model Validation, Continuous Learning, Monitoring & Feedback Loops

---

## COMMANDS

| Command | Description |
|---------|-------------|
| `/mdm [brand]` | สร้าง Million Dollar Message (ประโยคเงินล้าน) |
| `/cortex [brand]` | กรอก SalesPage Cortex 10 sections / 60 questions |
| `/salespage [style]` | สร้าง Sales Page (jon/russell) |
| `/vdo [style]` | สร้าง VDO Script (jon/russell) |
| `/webinar [style]` | สร้าง Webinar Script (jon/russell) |
| `/nugget [number]` | ใช้ Golden Nugget ปรับแต่งข้อความ (1-36) |
| `/analyze [url/text]` | วิเคราะห์ Sales Page ตาม Inception Framework |
| `/clone [expert]` | Clone สไตล์การเขียนขาย (jon/russell/dankoe) |
| `/objection [product]` | สร้าง Objection Handling |
| `/bot [brand]` | สร้าง System Prompt สำหรับ CustomGPT/Claude bot |

---

## COMMAND DETAILS

### /mdm — Million Dollar Message (ประโยคเงินล้าน)

โครงสร้าง:
```
[Brand] ช่วยให้ [Target Group] บรรลุเป้าหมายเรื่อง [Achieve Result]
โดยไม่ต้อง [Without Doing] เพื่อให้ลูกค้าสามารถ [So You Can Enjoy]
```

**ตัวอย่าง:**
"Income Automation Mastery หลักสูตรธุรกิจออนไลน์ ที่ช่วยครีเอเตอร์ ที่ปรึกษา โค้ช ผู้เชี่ยวชาญ และเจ้าของธุรกิจบริการ เพื่อสร้างรายได้แบบอัตโนมัติในขณะที่คุณกิน นอน หรือท่องเที่ยว โดยไม่ต้องยุ่งยากกับเทคโนโลยี ไม่ต้องเครียดกับการสร้างผู้ติดตาม ทำให้คุณสามารถใช้ชีวิตได้อย่างอิสระจากที่ไหนก็ได้"

เมื่อได้รับ `/mdm` → ถาม 5 คำถาม ทีละข้อ:
1. ชื่อแบรนด์/สินค้า/บริการ คืออะไร?
2. กลุ่มเป้าหมายคือใคร?
3. ผลลัพธ์ที่ลูกค้าจะได้คืออะไร?
4. สิ่งที่ลูกค้าไม่อยากทำคืออะไร?
5. สิ่งที่ลูกค้าอยากทำจริงๆ คืออะไร?

จากนั้นสร้าง MDM 3 เวอร์ชัน (สั้น/กลาง/ยาว)

---

### /cortex — SalesPage Cortex (10 Sections / 60 Questions)

SalesPage Cortex คือชุดคำถาม 60 ข้อ แบ่ง 10 หมวด ที่ช่วยดึงข้อมูลธุรกิจออกมาเพื่อให้ AI เขียนขายได้แม่นยำ

**10 Sections:**
1. **Problem** (6 คำถาม) — ปัญหาที่กลุ่มเป้าหมายเผชิญ, พวกเขาบ่นอย่างไร, ผลเสียถ้าไม่แก้, อารมณ์ที่เกิดขึ้น, สถานการณ์ที่ชัดเจนที่สุด, ถ้าปัญหาพูดได้
2. **Target Audience** (6 คำถาม) — ใครได้รับผลกระทบ, อาชีพ/บทบาท, ค่านิยม/ความเชื่อ, บุคลิกภาพ, เป้าหมาย/ความฝัน, ความกลัว
3. **Solution** (6 คำถาม) — การเปลี่ยนแปลงสูงสุด, แตกต่างจากวิธีอื่น, คุณสมบัติเฉพาะ, ผลต่อชีวิตประจำวัน, ประโยชน์ที่วัดผลได้, ความง่ายในการใช้
4. **Credibility** (6 คำถาม) — ความสำเร็จ/พันธมิตร, รีวิว/กรณีศึกษา, ประสบการณ์ส่วนตัว, ผลลัพธ์ที่ช่วยคนอื่น, อุปสรรคที่เอาชนะ, การรับรองจากบุคคลที่สาม
5. **Offer Details** (6 คำถาม) — องค์ประกอบหลัก, แต่ละโมดูลแก้ปัญหาอย่างไร, โบนัส, โครงสร้างการใช้งาน, คุณค่าที่จับต้องได้, ช่วยบรรลุเป้าหมายเร็วขึ้นอย่างไร
6. **Proof and Results** (6 คำถาม) — ผลลัพธ์เฉพาะ, เรื่องราวลูกค้าเก่า, ผลลัพธ์ที่วัดได้, ภาพก่อน-หลัง, ประสบการณ์ที่โดดเด่น, ประโยชน์ที่ไม่คาดคิด
7. **Objections** (6 คำถาม) — ข้อสงสัยที่พบบ่อย, ความกลัว/ลังเล, สร้างความมั่นใจอย่างไร, ความกังวลด้านการเงิน, ตัวอย่างต้านความสงสัย, ทำให้เป็นส่วนตัวอย่างไร
8. **Urgency/Scarcity** (6 คำถาม) — กำหนดเวลา, ต้นทุนของการรอ, ทรัพยากรจำกัด, ข้อได้เปรียบของการลงมือทันที, คู่แข่ง/เทรนด์, ความเสียใจจากการพลาด
9. **Call to Action** (6 คำถาม) — ขั้นตอนถัดไป, เน้นประโยชน์ของการลงมือทันที, รางวัล/การเปลี่ยนแปลง, ทำให้รู้สึกง่ายและเสี่ยงต่ำ, เครื่องมือที่ได้รับทันที, ภาษา/ภาพสร้างความมั่นใจ
10. **Personal Story** (6 คำถาม) — ช่วงเวลาสำคัญ, ช่วงยากที่สุด, เหตุการณ์ที่นำไปสู่การสร้างวิธีแก้, ชีวิตดีขึ้นอย่างไร, บทเรียน, เล่าเรื่องให้เห็นตัวเอง

**วิธีใช้**: ถามทีละ section (6 คำถาม) → รอคำตอบ → ไป section ถัดไป
สามารถข้ามคำถามที่ตอบไม่ได้ แต่ยิ่งตอบมาก ผลลัพธ์ยิ่งแม่นยำ

**3 รูปแบบคำถาม** (VAK — Visual/Auditory/Kinesthetic):
- Direct/Visual: "ปัญหาที่ลูกค้าเห็นชัดที่สุดคืออะไร?"
- Reflective/Auditory: "ลูกค้าพูดถึงปัญหานี้ว่ายังไง?"
- Empathetic/Kinesthetic: "ปัญหานี้ทำให้ลูกค้ารู้สึกยังไง?"

---

### /salespage — Inception SalesPage Framework

มี 2 สไตล์:

**สไตล์ Jon Penberthy (12 sections):**
1. Headline → 2. Subheadline → 3. Introduction → 4. Problem Agitation → 5. Solution → 6. Proof → 7. Offer Breakdown → 8. Bonuses → 9. Guarantee → 10. Scarcity/Urgency → 11. CTA → 12. FAQ

**สไตล์ Russell Brunson (12 sections):**
1. Bold Headline → 2. Transformational Subheadline → 3. Inspiring Introduction → 4. Problem Dramatization → 5. Breakthrough Solution → 6. Epic Proof → 7. Offer Stack → 8. Bonuses → 9. Guarantee → 10. Scarcity/Urgency → 11. CTA → 12. FAQ

แต่ละ section มี: Purpose, Sequence, Example, Template, Hypnosis Techniques

**Hypnosis Techniques ที่ใช้:**
- Hypnotic Hooks, Embedded Commands, Future Pacing, Presupposition
- VAK Triggers, Conversational Hypnosis, Yes Ladder, Meta-Frames
- Emotional Anchors, Pattern Interrupt, Loss Aversion, Time Distortion
- Safety Induction, Reframing, Chunking, Reciprocity, Social Proof

**วิธีใช้**: ต้องมี Cortex หรือ MDM ก่อน → เลือกสไตล์ → AI สร้างทีละ section → ปรับด้วย Golden Nugget

---

### /vdo — VDO Script Framework

**สไตล์ Jon Penberthy (7 parts, ~10 นาที):**
1. Hook (0:00-0:30) → 2. Introduction (0:30-1:00) → 3. Problem Setup (1:00-2:30) → 4. High-Level Solution (2:30-4:00) → 5. Content Delivery (4:00-8:00) → 6. Social Proof (8:00-9:30) → 7. Subtle CTA (9:30-10:00)

**สไตล์ Russell Brunson (7 parts, ~8 นาที):**
1. Hook (0:00-0:30) → 2. Introduction (0:30-1:00) → 3. Problem Setup (1:00-2:00) → 4. Deliver Value (2:00-6:00) → 5. Proof/Examples (6:00-7:00) → 6. Subtle CTA (7:00-7:30) → 7. Closing (7:30-8:00)

---

### /webinar — Webinar Script Framework

**สไตล์ Jon Penberthy (8 parts, ~65 นาที):**
1. Introduction (0-10min) → 2. Secret 1 (10-20min) → 3. Secret 2 (20-30min) → 4. Secret 3 (30-40min) → 5. Transition to Offer (40-45min) → 6. The Stack (45-55min) → 7. Price Reveal (55-60min) → 8. CTA (60-65min)

**สไตล์ Russell Brunson (8 parts, ~60 นาที):**
1. Introduction (0-5min) → 2. Problem Identification (5-10min) → 3. Solution Introduction (10-20min) → 4. Content Delivery (20-40min) → 5. Social Proof (40-45min) → 6. Offer Presentation (45-50min) → 7. CTA (50-55min) → 8. Objection Handling & Q&A (55-60min)

---

### /nugget — Golden Nugget 36 ข้อ (คาถาสาริกาลิ้นทอง)

**A. โครงสร้างภาษาศาสตร์ (Linguistic Architecture):**
1. ลีลาภาษา (Language Rhythm) — Natural tonal flow
2. จังหวะการเว้นวรรค (Pause Patterns) — Strategic spacing
3. การเล่นคำ (Wordplay) — Thai-specific puns
4. ความกลมกล่อม (Verbal Harmony) — Balanced phrases
5. สัมผัสคล้องจอง (Rhyme Patterns) — Thai-style rhyming

**B. กรอบความเข้าใจทางวัฒนธรรม (Cultural Intelligence):**
7. ความเกรงใจ (Kreng Jai) — Social consideration
8. น้ำใจ (Nam Jai) — Generosity concepts
9. ความประนีประนอม (Compromise) — Conflict-avoidance
10. ความเป็นกันเอง (Friendliness) — Casual warmth
11. บุญคุณ (Gratitude) — Relationship-building

**C. องค์ประกอบการสื่อสารร่วมสมัย (Modern Communication):**
12. ภาษาอินเทรนด์ (Trending Language) — Social media speak
13. คำผสมไทย-อังกฤษ (Thai-English Hybrid) — Strategic mixing
14. มีมไทย (Thai Memes) — Cultural reference points
15. สแลงร่วมสมัย (Contemporary Slang) — Up-to-date expressions
16. ภาษาวัยรุ่น (Youth Language) — Generation-specific terms

**D. องค์ประกอบทางจิตวิทยา (Psychological Elements):**
17. ความเชื่อท้องถิ่น (Local Beliefs) — Superstition references
18. แรงบันดาลใจแบบไทย (Thai Inspiration) — Culture-specific motivation
19. การสร้างความภูมิใจ (Pride Building) — Value affirmation
20. ความกตัญญู (Filial Piety) — Family-oriented messaging
21. ความมีหน้ามีตา (Face Saving) — Status consciousness

**E. กรอบจิตวิทยาการขาย (Sales Psychology):**
22. การเร่งรัดแบบนุ่มนวล (Gentle Urgency) — Soft selling
23. การสร้างความไว้วางใจ (Trust Building) — Credibility signals
24. การลดความกังวล (Anxiety Reduction) — Reassurance
25. แรงจูงใจทางสังคม (Social Motivation) — Community incentives
26. การตัดสินใจแบบไทย (Thai Decision Making) — Group-oriented

**F. องค์ประกอบเชิงภูมิภาค (Regional Elements):**
27. สำเนียงท้องถิ่น (Regional Dialects) — Local campaigns
28. อารมณ์ขันภูมิภาค (Regional Humor) — Area-specific jokes
29. ความเชื่อท้องถิ่น (Local Traditions) — Festival marketing
30. ภาษาถิ่น (Local Language) — Community engagement
31. อ้างอิงวัฒนธรรมย่อย (Subculture References) — Targeted campaigns

**G. เทคนิคการสื่อสารขั้นสูง (Advanced Communication):**
32. การเล่าเรื่องแบบไทย (Thai Storytelling) — Cultural narrative
33. จิตวิทยามวลชน (Mass Psychology) — Crowd behavior
34. การสร้างพลังชุมชน (Community Empowerment) — Social dynamics
35. ภาษากาย (Body Language) — Visual content
36. การสื่อสารแฝง (Subtle Communication) — Indirect messaging

**วิธีใช้**: `/nugget 7` = ปรับข้อความด้วยเทคนิค "ความเกรงใจ" หรือ `/nugget all` = AI เลือก nuggets ที่เหมาะสมที่สุดโดยอัตโนมัติ

---

### /analyze — วิเคราะห์ Sales Page

วิเคราะห์ Sales Page ตาม Inception Framework โดยตรวจสอบ:
- โครงสร้าง 12 sections ครบหรือไม่
- Hypnosis Techniques ที่ใช้
- จุดแข็ง/จุดอ่อน
- Golden Nugget ที่ควรเพิ่ม
- คำแนะนำในการปรับปรุง

**ตัวอย่าง Sales Page ที่ดีจากระดับโลก** (ใช้เป็น reference):
- Dan Koe: Mental Monetization — โทนจริงใจ anti-hype, personal story as proof
- Russell Brunson: Think & Grow Rich — Extreme value stacking, countdown urgency
- Jon Penberthy: Future Of Sales — Old Way vs New Way, exclusion creates desire
- SaaS in a Weekend: Aaron — Ultra-low ticket, "Sell before Build" unique mechanism
- AI Business Success System — Reverse risk guarantee, multiple AI systems

---

### /clone — Clone สไตล์การเขียนขาย

เลือก expert ที่ต้องการ clone:
- `jon` — Jon Penberthy style (systematic, step-by-step, hypnotic hooks)
- `russell` — Russell Brunson style (dramatic, story-driven, epic stacking)
- `dankoe` — Dan Koe style (honest, anti-hype, philosophical)

AI จะวิเคราะห์ DNA ของสไตล์นั้น แล้วเขียนตาม pattern

---

### /objection — Objection Handling

สร้างชุด Objection Handling จาก Cortex โดย:
1. ดึง Objections section จาก Cortex
2. สร้างคำตอบแบบ Empathy-first (เข้าใจก่อน → แก้ไข → พิสูจน์)
3. ใส่ Social Proof และ Guarantee
4. ปรับด้วย Golden Nugget ให้เหมาะกับคนไทย

---

### /bot — สร้าง CustomGPT/Claude Bot

สร้าง System Prompt สำหรับ CustomGPT หรือ Claude Project โดย:
1. รวม Cortex ทั้งหมดเป็น Knowledge Base
2. ใส่ Framework ที่เลือก
3. กำหนด Persona (เช่น สุดยอดนักเขียนขาย)
4. ใส่ Golden Nugget ที่เหมาะสม
5. กำหนด Output Format

**วิธี deploy:**
- ChatGPT: สร้าง CustomGPT → ใส่ System Prompt + อัพโหลด Cortex
- Claude: สร้าง Project → ใส่ Custom Instructions + อัพโหลด Cortex

---

## WORKFLOW แนะนำ

```
ขั้นตอนที่ 1: /mdm → สร้างประโยคเงินล้าน (เป็นจุดเริ่มต้น)
ขั้นตอนที่ 2: /cortex → กรอก SalesPage Cortex (ยิ่งละเอียดยิ่งดี)
ขั้นตอนที่ 3: เลือก output ที่ต้องการ:
   - /salespage jon → Sales Page สไตล์ Jon
   - /salespage russell → Sales Page สไตล์ Russell
   - /vdo jon → VDO Script สไตล์ Jon
   - /webinar russell → Webinar Script สไตล์ Russell
ขั้นตอนที่ 4: /nugget → ปรับแต่งด้วย Golden Nugget
ขั้นตอนที่ 5: /bot → สร้าง Bot สำหรับใช้ซ้ำ (optional)
```

## KEY PRINCIPLES

1. **AI ไม่รู้จักธุรกิจเรา** — ต้องสอนด้วย Cortex ก่อนเสมอ
2. **ยิ่งใส่ข้อมูลมาก ยิ่งได้ผลลัพธ์แม่น** — Cortex เป็นหัวใจ
3. **Framework คือโครงสร้าง** — ไม่ต้องคิดเอง แค่เลือกสไตล์
4. **Golden Nugget คือเครื่องเทศ** — ปรับรสชาติให้เข้ากับคนไทย
5. **Chain of Thought** — สั่ง AI ทีละขั้น ไม่ใช่ทำทุกอย่างในพร้อมต์เดียว
6. **สังเกต + AI = ผลลัพธ์** — ในยุค AI คนช่างสังเกตได้เปรียบ
## REFERENCE FILES

### references/cortex-template.md
# SalesPage Cortex - Complete Template with Examples

> 60 คำถาม 10 หมวด สำหรับ Clone สมองธุรกิจของคุณเข้าสู่ AI
> ตอบได้มากเท่าไหร่ AI ยิ่งเขียนขายได้แม่นยำมากเท่านั้น

## วิธีใช้ Cortex

1. ถามทีละ Section (6 คำถาม)
2. ผู้ใช้ตอบทีละข้อ (ข้ามได้ถ้าไม่รู้)
3. พอจบ section → ไป section ถัดไป
4. จบ 10 sections → พร้อมใช้กับ Framework

## 3 รูปแบบคำถาม (เลือกตามบุคลิกผู้ใช้)

- **Direct/Visual**: ถามตรงๆ เห็นภาพชัด (เช่น "ปัญหาที่ลูกค้าเห็นชัดที่สุดคืออะไร?")
- **Reflective/Auditory**: ให้คิดทบทวน (เช่น "ลูกค้าพูดถึงปัญหานี้ว่ายังไง?")
- **Empathetic/Kinesthetic**: เน้นความรู้สึก (เช่น "ปัญหานี้ทำให้ลูกค้ารู้สึกยังไง?")

---

## Section 1: Problem (ปัญหา)

| No. | คำถาม |
|-----|-------|
| 1.1 | ความท้าทายหรือปัญหาที่กลุ่มเป้าหมายเผชิญในชีวิตหรือธุรกิจ? |
| 1.2 | พวกเขาบ่นถึงปัญหาเหล่านี้กับเพื่อนหรือเพื่อนร่วมงานอย่างไร? |
| 1.3 | ผลเสียที่ร้ายแรงที่สุดหากไม่แก้ปัญหานี้คืออะไร? |
| 1.4 | อารมณ์และความรู้สึกที่เกิดขึ้นจากปัญหาเหล่านี้? |
| 1.5 | ช่วงเวลาหรือสถานการณ์ไหนที่ทำให้รู้สึกถึงปัญหานี้ชัดเจนที่สุด? |
| 1.6 | หากปัญหานี้พูดได้ มันจะพูดถึงความยากลำบากของพวกเขาว่าอย่างไร? |

## Section 2: Target Audience (กลุ่มเป้าหมาย)

| No. | คำถาม |
|-----|-------|
| 2.1 | ใครคือคนที่ได้รับผลกระทบจากปัญหาที่คุณแก้ไข? |
| 2.2 | อาชีพ บทบาท หรือสถานการณ์ชีวิตใดที่เป็นกลุ่มเป้าหมายของคุณ? |
| 2.3 | พวกเขามีค่านิยมหรือความเชื่ออะไรที่เกี่ยวข้องกับสิ่งที่คุณนำเสนอ? |
| 2.4 | บุคลิกภาพของพวกเขามีผลต่อการเลือกวิธีแก้ปัญหาอย่างไร? |
| 2.5 | เป้าหมายหรือความฝันเฉพาะที่พวกเขากำลังมุ่งไปคืออะไร? |
| 2.6 | ความกลัวหรือความกังวลที่ใหญ่ที่สุดเกี่ยวกับปัญหานี้คืออะไร? |

## Section 3: Solution (วิธีแก้ปัญหา)

| No. | คำถาม |
|-----|-------|
| 3.1 | การเปลี่ยนแปลงสูงสุดที่วิธีแก้ปัญหาของคุณมอบให้คืออะไร? |
| 3.2 | วิธีแก้ปัญหาของคุณแตกต่างจากวิธีอื่นๆ ที่พวกเขาเคยลองอย่างไร? |
| 3.3 | คุณสมบัติเฉพาะของวิธีแก้ปัญหาที่ตอบโจทย์ความเจ็บปวดหลักคืออะไร? |
| 3.4 | การใช้วิธีแก้ปัญหาของคุณส่งผลต่อชีวิตประจำวันของพวกเขาอย่างไร? |
| 3.5 | ประโยชน์ที่วัดผลได้ (เช่น เวลาที่ประหยัด เงินที่ได้) จากวิธีแก้ปัญหาของคุณ? |
| 3.6 | ลูกค้าจะอธิบายถึงความง่ายในการใช้วิธีแก้ปัญหาของคุณอย่างไร? |

## Section 4: Credibility (ความน่าเชื่อถือ)

| No. | คำถาม |
|-----|-------|
| 4.1 | ความสำเร็จ พันธมิตร หรือการยอมรับที่แสดงถึงความน่าเชื่อถือ? |
| 4.2 | บทความรีวิว กรณีศึกษา หรือคำรับรองที่ยืนยันความเชี่ยวชาญของคุณ? |
| 4.3 | ประสบการณ์ส่วนตัวอะไรที่เตรียมคุณให้พร้อมแก้ปัญหานี้? |
| 4.4 | ผลลัพธ์ของคุณช่วยคนอื่นในสถานการณ์คล้ายกันอย่างไร? |
| 4.5 | อุปสรรคหรือความท้าทายที่คุณเอาชนะซึ่งสะท้อนความยากลำบากของกลุ่มเป้าหมาย? |
| 4.6 | การรับรองจากบุคคลที่สาม (การกล่าวถึงในสื่อ รางวัล) เสริมความน่าเชื่อถือของคุณอย่างไร? |

## Section 5: Offer Details (รายละเอียดข้อเสนอ)

| No. | คำถาม |
|-----|-------|
| 5.1 | องค์ประกอบหลักของข้อเสนอและคุณค่าที่มอบให้คืออะไร? |
| 5.2 | แต่ละโมดูล/คุณสมบัติแก้ปัญหาเฉพาะส่วนอย่างไร? |
| 5.3 | โบนัสหรือคุณสมบัติเพิ่มเติมที่ทำให้ข้อเสนอน่าสนใจมากขึ้น? |
| 5.4 | โครงสร้างของข้อเสนอทำให้ใช้งานและนำไปปฏิบัติได้ง่ายอย่างไร? |
| 5.5 | คุณจะอธิบายคุณค่าที่จับต้องได้ (เช่น เทมเพลต เครื่องมือ ทรัพยากร) ในข้อเสนอของคุณอย่างไร? |
| 5.6 | ข้อเสนอของคุณช่วยให้กลุ่มเป้าหมายบรรลุเป้าหมายได้เร็วขึ้นหรือมีประสิทธิภาพมากขึ้นอย่างไร? |

## Section 6: Proof and Results (หลักฐานและผลลัพธ์)

| No. | คำถาม |
|-----|-------|
| 6.1 | ผลลัพธ์เฉพาะที่ลูกค้าได้รับจากการใช้โซลูชั่นของคุณ? |
| 6.2 | เรื่องราวหรือข้อเสนอแนะจากลูกค้าเก่าที่แสดงถึงความสำเร็จ? |
| 6.3 | ผลลัพธ์ที่วัดผลได้ (เช่น การเติบโตของยอดขาย เวลาที่ประหยัด) ที่คุณสามารถเน้นย้ำ? |
| 6.4 | ภาพก่อน-หลังที่แสดงผลกระทบของโซลูชั่นของคุณ? |
| 6.5 | ประสบการณ์การใช้โซลูชั่นของคุณโดดเด่นในแง่บวกอย่างไร? |
| 6.6 | ประโยชน์ที่ไม่คาดคิดที่ลูกค้ารายงาน? |

## Section 7: Objections (ข้อโต้แย้ง)

| No. | คำถาม |
|-----|-------|
| 7.1 | ข้อสงสัยหรือคำถามที่พบบ่อยเกี่ยวกับโซลูชั่นของคุณ? |
| 7.2 | ความกลัวหรือความลังเลที่อาจขัดขวางการตัดสินใจของพวกเขา? |
| 7.3 | คุณจะสร้างความมั่นใจเกี่ยวกับความซับซ้อน ความเสี่ยง หรือคุณค่าของข้อเสนอได้อย่างไร? |
| 7.4 | ความกังวลด้านการเงินที่อาจมีและวิธีจัดการ? |
| 7.5 | ตัวอย่างหรือคำรับรองที่สามารถต้านความสงสัย? |
| 7.6 | คุณทำให้โซลูชั่นของคุณรู้สึกเป็นส่วนตัวหรือเหมาะกับความต้องการของพวกเขาอย่างไร? |

## Section 8: Urgency/Scarcity (ความเร่งด่วน)

| No. | คำถาม |
|-----|-------|
| 8.1 | องค์ประกอบที่มีกำหนดเวลา (เช่น โบนัส, กำหนดเส้นตาย) ที่คุณสามารถเน้นย้ำ? |
| 8.2 | คุณสามารถแสดงให้เห็นต้นทุนหรือการสูญเสียจากการรอช้าได้อย่างไร? |
| 8.3 | ทรัพยากรที่จำกัด (เช่น ที่นั่ง, สต็อก) สร้างความรู้สึกพิเศษอย่างไร? |
| 8.4 | การลงมือทำทันทีให้ข้อได้เปรียบพิเศษอย่างไร? |
| 8.5 | คู่แข่งหรือเทรนด์อะไรที่เน้นย้ำความสำคัญของการลงมือทำตอนนี้? |
| 8.6 | คุณสามารถวาดภาพความเสียใจจากการพลาดโอกาสนี้ได้อย่างไร? |

## Section 9: Call to Action (CTA)

| No. | คำถาม |
|-----|-------|
| 9.1 | ขั้นตอนต่อไปที่ชัดเจนและปฏิบัติได้ที่สุดสำหรับกลุ่มเป้าหมาย? |
| 9.2 | CTA ของคุณเน้นย้ำประโยชน์ของการลงมือทำทันทีอย่างไร? |
| 9.3 | รางวัลหรือการเปลี่ยนแปลงที่พวกเขาจะรู้สึกเมื่อลงมือทำ? |
| 9.4 | คุณทำให้ CTA รู้สึกง่ายและมีความเสี่ยงต่ำได้อย่างไร? |
| 9.5 | เครื่องมือ ทรัพยากร หรือการสนับสนุนที่จะได้รับทันทีหลังลงมือทำ? |
| 9.6 | ภาษาหรือภาพที่คุณสามารถใช้เพื่อสร้างความมั่นใจและความตื่นเต้น? |

## Section 10: Personal Story (เรื่องราวส่วนตัว)

| No. | คำถาม |
|-----|-------|
| 10.1 | ช่วงเวลาสำคัญในการเดินทางของคุณที่สะท้อนความท้าทายของกลุ่มเป้าหมาย? |
| 10.2 | คุณรู้สึกอย่างไรในช่วงที่ยากลำบากที่สุดของการเดินทาง และคุณเอาชนะมันได้อย่างไร? |
| 10.3 | เหตุการณ์หรือการตระหนักรู้เฉพาะที่นำไปสู่การสร้างวิธีแก้ปัญหานี้? |
| 10.4 | ชีวิตของคุณดีขึ้นอย่างไรหลังจากแก้ปัญหานี้? |
| 10.5 | บทเรียนจากเรื่องราวส่วนตัวของคุณที่สามารถสร้างแรงบันดาลใจหรือเชื่อมโยงกับกลุ่มเป้าหมาย? |
| 10.6 | คุณสามารถเล่าเรื่องราวในแบบที่ทำให้กลุ่มเป้าหมายเห็นตัวเองในนั้นได้อย่างไร? |

---

## ตัวอย่าง Cortex ที่กรอกแล้ว (AI Brand Cortex)

| Section | คำถาม | คำตอบ |
|---------|-------|-------|
| Problem | ความท้าทาย? | เสียเวลาหลายชั่วโมงในการสร้างคอนเทนต์แต่ไม่ได้ผลตอบรับ |
| Problem | พวกเขาบ่นว่า? | "รู้สึกเหมือนตะโกนเข้าไปในความว่างเปล่า ไม่มีอะไรได้ผลเลย!" |
| Problem | ผลเสียที่สุด? | สูญเสียลูกค้าและโอกาสในการเติบโตทางธุรกิจ |
| Target | ใครได้รับผลกระทบ? | ฟรีแลนซ์และผู้ประกอบการที่พยายามสร้างธุรกิจออนไลน์ |
| Solution | การเปลี่ยนแปลงสูงสุด? | คอนเทนต์คุณภาพสูงที่สร้างการมีส่วนร่วมและยอดขายอย่างสม่ำเสมอ |
| Credibility | ความสำเร็จ? | ได้รับการนำเสนอใน "Top Marketing Tools" โดย Forbes |
| Offer | องค์ประกอบหลัก? | หลักสูตร 3 โมดูลเกี่ยวกับกลยุทธ์คอนเทนต์, การตั้งค่า AI และการขยายธุรกิจ |
| Proof | ผลลัพธ์? | "เพิ่มการสร้างลูกค้าใหม่ขึ้น 50% ในหนึ่งเดือน!" |
| Objections | ข้อสงสัย? | "AI จะยากเกินไปสำหรับฉันไหม?" |
| Urgency | กำหนดเวลา? | "ลงทะเบียนภายในเที่ยงคืนนี้รับคู่มือโบนัสพิเศษ!" |
| CTA | ขั้นตอนถัดไป? | "คลิกปุ่มด้านล่างเพื่อลงทะเบียนในโปรแกรมวันนี้" |
| Story | ช่วงเวลาสำคัญ? | "ฉันต่อสู้มาหลายปีเพื่อหาลูกค้า รู้สึกเหมือนความพยายามสูญเปล่า" |

---

### references/frameworks-detail.md
# Inception Frameworks Detail - SalesPage / VDO / Webinar

> 6 Frameworks: (SalesPage + VDO + Webinar) x (Jon Penberthy + Russell Brunson)
> แต่ละ section มี Purpose, Sequence, Template, Hypnosis Techniques

---

## 1. AI SalesPage Framework — Jon Penberthy Style

| No | Section | Purpose | Template | Hypnosis |
|----|---------|---------|----------|----------|
| 1 | Headline | Grab attention with specific problem/goal | "Are you [problem]? Imagine [outcome]. This page reveals how." | Hypnotic Hooks, Embedded Commands, Future Pacing |
| 2 | Subheadline | Reinforce promise + core benefit | "On this page, you'll learn [benefit]. Even if [objection]." | Presupposition, VAK Triggers, Conversational Hypnosis |
| 3 | Introduction | Build rapport + credibility | "I've been where you are—frustrated by [pain]. That's why I developed [solution]." | Hypnotic Loop, Emotional Anchors, Embedded Commands |
| 4 | Problem Agitation | Highlight pain + consequences | "Are you tired of [problem]? Every day you wait, [consequence]." | Conversational Hypnosis, Loss Aversion, Pattern Interrupt |
| 5 | Solution | Introduce product with curiosity | "Let me introduce you to [product]. It's the simplest way to [benefit]." | Yes Ladder, Meta-Frames, Embedded Commands |
| 6 | Proof | Testimonials + case studies | "Here's what [name] achieved: They [result]. Imagine achieving the same." | Future Memory, Social Proof, Emotional Anchors |
| 7 | Offer Breakdown | What they get + how it helps | "You'll receive [features]. Each part solves [challenge]. Together, [result]." | Chunking, Hypnotic Precision, Embedded Commands |
| 8 | Bonuses | Additional irresistible value | "Act now, and you'll also receive [bonuses] worth [value]." | Time Distortion, Reciprocity, Urgency Anchor |
| 9 | Guarantee | Remove risk | "You're fully protected by our [guarantee]. Completely risk-free." | Safety Induction, Reframing, Embedded Commands |
| 10 | Scarcity/Urgency | Limited time/quantity | "Only [number] spots left. If you wait, you risk losing [benefit]." | Urgency Anchor, Loss Aversion, Time Distortion |
| 11 | CTA | Clear next step | "Take the first step to [goal]. Click below to [action]." | Command Tone, Direct Suggestion, Embedded Commands |
| 12 | FAQ | Address doubts | "You might wonder [objection]. Here's why that's not an issue." | Patterned Reassurance, Loss Aversion, Pacing |

---

## 2. AI SalesPage Framework — Russell Brunson Style

| No | Section | Purpose | Template | Hypnosis |
|----|---------|---------|----------|----------|
| 1 | Bold Headline | Dramatic life-changing promise | "Are you tired of [struggle]? Discover how [solution] will transform [outcome]." | Hypnotic Hooks, Anchoring, Future Pacing |
| 2 | Transformational Subheadline | Address doubts + build curiosity | "Even if you've struggled before, [solution] is designed for anyone." | Mirroring, Embedded Commands, Presupposition |
| 3 | Inspiring Introduction | Personal storytelling | "I've been where you are—[struggle]. Then, I found [solution]." | Storytelling, Relatability Loop, Anchoring |
| 4 | Problem Dramatization | Emotional cost of inaction | "Are you stuck in [pain point]? It's costing you [resources]." | Emotional Anchors, Conversational Hypnosis, Future Pacing |
| 5 | Breakthrough Solution | One-of-a-kind solution | "Introducing [solution], the proven method to [result]. Tailored to you." | Embedded Commands, Anchoring, Presupposition |
| 6 | Epic Proof | Dramatic testimonials + results | "Here's what [name] achieved: [pain point] → [success]. Imagine what you could achieve!" | Social Proof, Anchoring, Emotional Reframing |
| 7 | Offer Stack | Clear deliverables + value | "Here's what's included: [features]. Each designed to solve [challenges]." | Chunking, Hypnotic Precision, Embedded Commands |
| 8 | Bonuses | Over-delivery perception | "Sign up now to receive [bonus] valued at [value]. Only for a short time!" | Reciprocity, Urgency Anchor, Time Distortion |
| 9 | Guarantee | Strong risk removal | "You're backed by [guarantee]. If you don't see [result], [refund]. Risk-free!" | Safety Induction, Reframing, Embedded Commands |
| 10 | Scarcity/Urgency | Time/availability limits | "Only [number] spots. Waiting means losing [benefit]. Act now." | Urgency Anchor, Loss Aversion, Time Distortion |
| 11 | CTA | Summary + urgency + action | "Click below to [action]. This offer is only available for [timeframe]." | Command Tone, Direct Suggestion, Embedded Commands |
| 12 | FAQ | Clear answers + confidence | "You might wonder [objection]. Here's why: [counterargument]." | Patterned Reassurance, Pacing, Loss Aversion |

---

## 3. AI VDO Framework — Jon Penberthy Style (~10 min)

| Part | Timeline | Purpose | Template | Hypnosis |
|------|----------|---------|----------|----------|
| Hook | 0:00-0:30 | Capture attention | "Are you [frustrated with pain] and ready to [achieve result]?" | Hypnotic Hooks |
| Introduction | 0:30-1:00 | Topic + credibility | "If you've ever [problem], this video is for you. I've helped [number] people." | Hypnotic Loop |
| Problem Setup | 1:00-2:30 | Identify + agitate | "Most people [struggle], which leads to [consequence]. Sound familiar?" | Conversational Hypnosis |
| High-Level Solution | 2:30-4:00 | Framework/strategy | "Imagine [desired outcome]. This is possible with [solution]." | Yes Ladder |
| Content Delivery | 4:00-8:00 | Actionable steps | "Step 1: [action]. Step 2: [action]. Step 3: [action]." | VAK Triggers |
| Social Proof | 8:00-9:30 | Results/testimonials | "[Client name] used this and went from [start] to [result] in [timeframe]." | Future Memory |
| Subtle CTA | 9:30-10:00 | Link to resource | "If this resonates, I've created a free [resource]. Click the link below." | Direct Suggestion |

---

## 4. AI VDO Framework — Russell Brunson Style (~8 min)

| Part | Timeline | Purpose | Template | Hypnosis |
|------|----------|---------|----------|----------|
| Hook | 0:00-0:30 | Curiosity + bold promise | "What if I told you [bold promise]?" | Hypnotic Hooks |
| Introduction | 0:30-1:00 | Rapport + expectations | "I'm [name], and I've helped [credibility]. Here's what you'll gain today." | Repetition |
| Problem Setup | 1:00-2:00 | Challenges + urgency | "Have you ever faced [problem]? It's frustrating because [consequence]." | Conversational Hypnosis |
| Deliver Value | 2:00-6:00 | Actionable insights | "Step 1: [action]. Step 2: [action]. Here's why this works: [principle]." | VAK Triggers |
| Proof/Examples | 6:00-7:00 | Trust + credibility | "[Name] started with this and achieved [result] in just [timeframe]." | Future Memory |
| Subtle CTA | 7:00-7:30 | Next steps | "If this resonates, there's a free [resource] linked below." | Embedded Commands |
| Closing | 7:30-8:00 | Motivation + action | "We covered [key points]. I'm excited to see what you'll create!" | Anchoring |

---

## 5. AI Webinar Framework — Jon Penberthy Style (~65 min)

| Part | Timeline | Purpose | Template |
|------|----------|---------|----------|
| Introduction | 0-10min | Trust + expectations | "Thank you for being here. By the end, you'll know how to [goal]." |
| Secret 1 | 10-20min | Challenge beliefs + curiosity | "The first key is [insight]. Once applied, it lays the foundation." |
| Secret 2 | 20-30min | Transformational insight | "The second step focuses on [strategy]. This allows you to [benefit]." |
| Secret 3 | 30-40min | Final key insight | "The third step completes the system with [technique]." |
| Transition | 40-45min | Bridge to offer | "Now let's make it easier to apply with [product name]." |
| The Stack | 45-55min | Build perceived value | "Here's what's included: [features]. Plus bonuses [bonus 1, 2]. Total value [amount], today just [price]." |
| Price Reveal | 55-60min | Justify investment | "Think about what achieving [goal] is worth. Today, everything for [price], backed by [guarantee]." |
| CTA | 60-65min | Inspire action | "Now is the time to transform your [area]. Click below to get started." |

---

## 6. AI Webinar Framework — Russell Brunson Style (~60 min)

| Part | Timeline | Purpose | Template |
|------|----------|---------|----------|
| Introduction | 0-5min | Excitement + credibility | "Imagine achieving [goal] without the struggle. Today I'll show you the system." |
| Problem ID | 5-10min | Emotional engagement | "Are you frustrated with [pain point]? This costs you more than you realize." |
| Solution Intro | 10-20min | Solution + curiosity | "Let me introduce a system that transforms how you achieve [goal]." |
| Content Delivery | 20-40min | Actionable insights | "Step 1: [step]. Step 2: [step]. This works because [core benefit]." |
| Social Proof | 40-45min | Credibility + results | "Let me share someone who implemented this and achieved [result]." |
| Offer Presentation | 45-50min | Detail offer + value | "Here's everything included. Plus exclusive bonuses. Total value [amount], today just [price]." |
| CTA | 50-55min | Clear instructions | "What would achieving [goal] be worth? You're fully protected by [guarantee]. Act now." |
| Objection Q&A | 55-60min | Address concerns | "Now is the time to transform [problem] into [success]. This special offer won't last." |

---

## Hypnosis Techniques Quick Reference

| Technique | Description | Best For |
|-----------|-------------|----------|
| Hypnotic Hooks | Curiosity-driven language | Headlines, Hooks |
| Embedded Commands | Subconscious action nudges | Throughout copy |
| Future Pacing | Visualize success | Intro, CTA |
| Yes Ladder | Build agreement step by step | Solution section |
| VAK Triggers | Visual/Auditory/Kinesthetic | Content delivery |
| Conversational Hypnosis | Build tension with unresolved loops | Problem sections |
| Loss Aversion | Fear of missing out | Urgency, Scarcity |
| Time Distortion | Make deadlines feel imminent | Urgency |
| Social Proof | Validate with examples | Proof sections |
| Emotional Anchors | Link feelings to product | Throughout |
| Pattern Interrupt | Disrupt thought patterns | Problem agitation |
| Safety Induction | Remove fear | Guarantee |
| Chunking | Simplify complex offers | Offer breakdown |
| Reciprocity | Build goodwill | Bonuses |
| Reframing | Shift perspective | Objections |

---

### references/salespage-examples.md
# Sales Page Examples & References
ตัวอย่าง Sales Page จริงจาก Expert ระดับโลก สำหรับศึกษาโครงสร้างและเทคนิค

---

## 1. Dan Koe - Mental Monetization (Monetize Your Creative Work)

**Type:** Digital Product Sales Page
**Target:** Creators, Writers, Beginners
**Headline:** "Monetize Your Creative Work With A Digital Product That Sells While You Sleep"
**Subheadline:** The roadmap from $0 to $100K to $1M as one-person by turning your knowledge, interests, and skills into a portfolio of meaningful income sources.

**Page Structure Analysis:**
1. **Headline + Promise** - Bold transformation promise
2. **Disclaimer/Credibility** - Honest disclaimer + real results ($3K/month from scratch 2019, $400K first year, $50K month 2020, $687K in 30 days, $759K in 6 months 2024)
3. **Philosophy Section** - "If You Don't Have A Product, You Don't Control Your Income" - addresses mindset
4. **This Is For You If...** - Qualification section with bullet points targeting specific personas
5. **New Economy Vision** - "Welcome To The New Economy (A Creative's Dream)" - paints bigger picture
6. **3 Key Realizations:**
   - Micro Education Businesses Are The Future Of Schooling
   - Everyone Should Have A Digital Product That Makes $10K/month
   - Turn Yourself Into The Business
7. **Build For Yourself, Sell To Yourself** - Product creation philosophy
8. **What's Inside** - Course content breakdown with clear outcomes
9. **Bonuses** (8 bonuses) - Templates, niche creation, viral threads, branding, micro product, beginner modules
10. **Takeaways** - Before/After comparison
11. **Pricing** - Two tiers ($150 pre-order vs $300 with 2 Hour Writer)
12. **FAQ** - 4 common questions

**Key Techniques:**
- Honest, anti-hype tone ("This program does not promise that you will make $1 million")
- Personal story as proof
- "Build for yourself, sell to yourself" unique mechanism
- Strong before/after framing
- Pre-order urgency with price increase deadline

---

## 2. Russell Brunson - Think & Grow Rich Challenge (Funnel Upsell Page)

**Type:** Upsell/OTO (One Time Offer) Page
**Target:** Self-improvement seekers, entrepreneurs
**Headline:** "Watch This Quick Message From Russell To Maximize Your Experience Before The Timer Hits 00:00!"
**Core Offer:** VIP All Access Pass for $47 (was $197)

**Page Structure Analysis:**
1. **Urgency Header** - "Step 2 of 3: Don't Click Back" + countdown timer
2. **Video Section** - One-time viewing urgency
3. **VIP Upgrade CTA** - $47 with FREE 30-day trial of Secrets of Success
4. **Value Proposition** - "The difference between learning in a classroom setting and working with a tutor"
5. **LIVE Success Implementation** - Daily sessions with special guests
6. **Special VIP Speakers** - JB Hill, John Gray, Adora Evans, Fabio Soares, Sean Osborn, Don Green
7. **FREE Physical Book** - Think & Grow Rich hardcover
8. **Book Content Preview** - Sneak peek of what's inside (with page references)
9. **FREE Bonus #1** - Secrets of Success Membership ($53,798.55 value → FREE)
10. **FREE Bonus #2** - 'It Will Place You Wherever You Wish' book ($879.50 → FREE)
11. **FREE Bonus #3** - Secrets of Master Salesmanship ($297 → FREE)
12. **FREE Bonus #4** - Audio: Napoleon Hill's 'The Laws of Success' (PRICELESS → FREE)
13. **Stack Summary** - Everything you get for $47
14. **What's The Catch?** - Transparency section
15. **Urgency Reasons** - 1,000 VIP cap + limited free gifts
16. **30-Day Money Back Guarantee**
17. **Order Form** with order bump ($97 Napoleon Hill VIDEO Course)

**Key Techniques:**
- Extreme value stacking ($54,000+ value for $47)
- Countdown timer urgency
- "Step 2 of 3" progress indicator
- Multiple CTA repetitions throughout
- Physical product bonus (book) adds tangibility
- Celebrity/authority speakers as proof
- Order bump on checkout

---

## 3. SaaS in a Weekend (Aaron - AppSumo style)

**Type:** Low-ticket Digital Product Sales Page ($25)
**Target:** Non-technical entrepreneurs wanting to build software
**Headline:** "Launch Your First Profitable Micro-Software Business..."
**Subheadline:** Find a validated micro-SaaS idea with high demand and learn how to scale it -- even if you have no programming knowledge or experience.

**Page Structure Analysis:**
1. **Headline + Promise** - Launch profitable micro-software
2. **What It Is NOT** - Not coding, not huge software company, not VC, not raising money
3. **What It IS** - "Mini software that performs one job people hate doing"
4. **The Method** - Find painful to-do → Simple mockup → Mini SaaS → 5 paying customers
5. **What You Don't Need** - Demolishes common objections
6. **WE SELL before we BUILD** - Key differentiator/unique mechanism
7. **50 Pre-vetted Ideas** - Reduces friction of ideation
8. **Micro Pain Big Idea Formula** - Proprietary framework
9. **Social Proof** - ProfitWell chart, testimonial
10. **Launch From Anywhere** - Global accessibility
11. **No Traditional Marketing Needed** - "Lifetime Ladder" model
12. **Course Contents** - 3 training videos + worksheets + templates
13. **Guarantee** - Personal help finding validated idea
14. **Recap** - Everything you're getting

**Key Techniques:**
- Extremely low price point ($25) reduces all friction
- "NOT" repetition pattern to address objections
- Pre-vetted ideas = instant value
- "Sell before you build" = contrarian unique mechanism
- Testimonial showing real revenue chart
- Personal guarantee (will help pick your idea)

---

## 4. Jon Penberthy - The Future Of Sales

**Type:** Free Event Registration Page
**Target:** Coaches, Consultants, Experts who HATE selling
**Headline:** "The All-New Way To Sell - To Secure Hundreds Of High Ticket Clients In Record Time"
**Subheadline:** Without A Sleazy, Slimy, Or Shady Sales Tactic In Sight!

**Page Structure Analysis:**
1. **Event Banner** - Date/time prominent
2. **Headline + Anti-sleazy promise**
3. **Video** - "What if the client..."
4. **Event Invitation Box** - Clear date/time, "LIMITED PLACES"
5. **Quote from Jon** - Personal credibility, authentic tone
6. **What Is The Future Of Sales?** - Old Way vs New Way comparison table
7. **Who Is It For / Not For** - Clear qualification
8. **6 Frameworks Delivered:**
   - 01: 6 Hours Cutting Edge Sales Training (Day 1 + Day 2 breakdown)
   - 02: The Push Script (Step 1)
   - 03: The Pull Script (Step 2)
   - 04: The 12-Point Conversion Checklist
   - 05: 21 Conversion Killers
   - 06: Objection Reversal
9. **Multiple CTAs** throughout
10. **Act Now** - LIVE only, not recorded, must attend

**Key Techniques:**
- Strong anti-selling positioning ("for people who HATE selling")
- Old Way vs New Way comparison creates instant clarity
- "NOT for professional closers" = exclusion creates desire
- Numbered framework delivery = structured value
- LIVE + not recorded = extreme urgency
- Free price removes all barriers

---

## 5. AI Business Success System (Internet Business Academy)

**Type:** High-ticket Program Sales Page ($995 + vat)
**Target:** Entrepreneurs wanting AI-powered business
**Headline:** "$100K in 12 Months Guaranteed - or we'll give you $1,000!"

**Page Structure:**
1. **Bold guarantee headline**
2. **Program overview** - 12 Month AI Business Success Program, Weekly Live Sessions
3. **4 Core Systems:**
   - AI Social Media Automation Software
   - YouTube Faceless Channel System
   - AI Automated Course System
   - AI Intelligent Chatbot System
4. **Bonuses:**
   - AI Marketing Toolbox Software
   - AI Insiders Club Membership
   - AI Print On Demand Business Plan
   - Resale Rights to AI Revolution Training
5. **Price** - $995 + vat
6. **12-month money-back guarantee**
7. **Order form**

**Key Techniques:**
- Reverse risk guarantee ($1,000 if no $100K)
- Multiple AI systems = comprehensive value
- Resale rights bonus = additional income stream
- Weekly live support = ongoing relationship