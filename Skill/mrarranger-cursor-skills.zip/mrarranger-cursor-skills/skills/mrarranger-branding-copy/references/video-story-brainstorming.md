# video-story-brainstorming

**Source:** Video Story Idea Brainstorming Wizard — Sales Story Secrets / FunnelScripts.com (Jim Edwards)

---

---
name: video-story-brainstorming
description: "Video Story Idea Brainstorming Wizard — ระบบ Brainstorm ไอเดียเรื่องเล่าสำหรับ Video Content จาก Jim Edwards (Sales Story Secrets + FunnelScripts) ใช้ 4 คำถามหลัก (Moral, Meaning, Emotion, Action) เพื่อ Generate เรื่องเล่าหลายสิบเรื่องที่ดึงดูดคนดู สร้าง Engagement ขายของได้ ใช้เมื่อ: (1) Brainstorm Story Ideas สำหรับ Video/Content (2) สร้างเรื่องเล่าสำหรับ Facebook Live/YouTube/TikTok/Reels (3) หา Story Angles จาก Moral/Meaning/Emotion/Action (4) สร้าง Content Calendar จาก Story Ideas (5) เขียน Video Script จาก Story Idea ที่เลือก (6) Brainstorm เรื่องเล่าสำหรับ Sales Video/VSL (7) สร้าง Story Ideas สำหรับ Email Marketing. Commands: /story-brainstorm /story-ideas /story-moral /story-angles /story-to-script"
---

# Video Story Idea Brainstorming Wizard

> **Creator**: Jim Edwards (Sales Story Secrets / FunnelScripts.com)
> **Core Concept**: กรอก 4 คำถามง่ายๆ → ได้ไอเดียเรื่องเล่าหลายสิบเรื่อง
> **ใช้ได้กับ**: Video content, FB Live, YouTube, TikTok, Reels, Email, Blog, Podcast, Sales Videos, VSL

---

## THE 4 CORE QUESTIONS

### Question 1: MORAL — What's the Moral?
**"What's the Moral you want them to get from the Story you'll tell them?"**

Completes the phrase: "The thing I really want you to take away from this is ________."

ตัวอย่าง:
- sometimes we all need someone to see things in us we don't see in ourselves
- ถ้าไม่ลงมือทำวันนี้ พรุ่งนี้ก็สายเกินไป
- ความสำเร็จมาจากการลงมือทำซ้ำๆ ไม่ใช่พรสวรรค์
- Try again (อย่ายอมแพ้)
- Need to detox (ต้องล้างพิษ)
- Find out more about water types (ค้นหาข้อมูลเพิ่ม)

### Question 2: MEANING — What's the Meaning?
**"What's the Meaning of the story for them?"**

Completes the phrase: "So what this means to you is ________."

ตัวอย่าง:
- we all need to have mentors to help us grow and believe in ourselves
- คุณไม่ได้อยู่คนเดียว มีคนพร้อมช่วย
- ถ้าคนอื่นทำได้ คุณก็ทำได้

### Question 3: EMOTION — What Emotion?
**"What is the emotion / feeling you want people to have at the end of your story?"**

Completes the phrase: "By the end of the story you should feel ________."

ตัวอย่าง:
- inspired and wanting a mentor
- มีแรงบันดาลใจอยากลงมือทำ
- กลัวที่จะพลาดโอกาส (FOMO)
- ตื่นเต้นกับความเป็นไปได้ใหม่ๆ
- มั่นใจว่าทำได้

### Question 4: ACTION — What Action?
**"What do you want people to do as a result of hearing your story?"**

Completes the phrase: "Now, as a result of what we just shared here, I want you to consider ________."

ตัวอย่าง:
- joining my executive coaching program so I can be the one who believes in you and shows you how you can be more than you think you can be
- สมัครคอร์สเรียน
- คลิกลิงก์ด้านล่าง
- จองคิว consultation
- ดาวน์โหลด lead magnet

---

## HOW TO USE: BRAINSTORMING PROCESS

### Step 1: กรอก 4 คำถาม
กำหนด Moral → Meaning → Emotion → Action

### Step 2: Brainstorm Stories ที่สอดคล้อง
จากคำตอบ 4 ข้อ → คิดเรื่องเล่าที่:
- สื่อ Moral ที่ต้องการ
- ให้ Meaning ที่เชื่อมกับชีวิตผู้ฟัง
- สร้าง Emotion ที่ตั้งเป้า
- นำไปสู่ Action ที่ต้องการ

### Step 3: เลือก & พัฒนา
เลือก Story Ideas ที่ดีที่สุด → พัฒนาเป็น Script

---

## STORY IDEA GENERATION FRAMEWORK

เมื่อได้ 4 คำตอบแล้ว ให้ Brainstorm จาก 6 แหล่งเรื่องเล่า:

1. **Personal Experience** — เหตุการณ์ในชีวิตตัวเอง
2. **Customer Stories** — เรื่องราวลูกค้า/คนรอบข้าง
3. **Historical/Famous** — เรื่องคนดัง/ประวัติศาสตร์ที่สื่อ Moral เดียวกัน
4. **Analogy/Metaphor** — เปรียบเทียบจากธรรมชาติ/กีฬา/ชีวิตประจำวัน
5. **News/Current Events** — ข่าว/เหตุการณ์ปัจจุบันที่เชื่อมได้
6. **Fictional/Hypothetical** — สถานการณ์สมมุติที่คนเห็นภาพ

สำหรับแต่ละแหล่ง → สร้าง 3-5 ไอเดีย = ได้ 18-30 Story Ideas

---

## COMMANDS

| Command | Description |
|---------|-------------|
| `/story-brainstorm [product/topic]` | Brainstorm โดยถาม 4 คำถาม → Generate 20+ Story Ideas |
| `/story-ideas [moral]` | สร้าง Story Ideas จาก Moral ที่กำหนด |
| `/story-moral [product]` | หา Moral ที่เหมาะกับ Product/Service |
| `/story-angles [topic]` | สร้าง Story Angles หลายมุมจาก 6 แหล่ง |
| `/story-to-script [idea]` | แปลง Story Idea → Video Script พร้อมใช้ |

### /story-brainstorm — Full Brainstorm Mode
1. ถาม 4 คำถาม (Moral, Meaning, Emotion, Action)
2. Generate 20+ Story Ideas จาก 6 แหล่ง
3. จัดอันดับ Top 5 ที่น่าจะ Perform ดีที่สุด
4. เสนอ Content Calendar

→ Output Format:
```
🎬 STORY BRAINSTORM: [Product/Topic]
━━━━━━━━━━━━━━━━━━━━━
🎯 Moral: [คำตอบ Q1]
💡 Meaning: [คำตอบ Q2]
❤️ Emotion: [คำตอบ Q3]
👉 Action: [คำตอบ Q4]

📋 STORY IDEAS (20+):

🔹 Personal Experience:
1. [idea] — [brief description]
2. [idea] — [brief description]
3. [idea] — [brief description]

🔹 Customer Stories:
4. [idea] — [brief description]
5. [idea] — [brief description]
...

⭐ TOP 5 RECOMMENDED:
1. [idea] — ทำไมเรื่องนี้จะ Perform ดี
2. ...

📅 CONTENT CALENDAR (1 สัปดาห์):
Mon: [Story #X] — Platform: [FB/YT/TT]
...
```

### /story-to-script
รับ Story Idea → สร้าง Video Script:
1. Hook (3-5 วินาที)
2. Story Setup (ใครทำอะไร)
3. Conflict/Problem
4. Turning Point
5. Resolution + Moral
6. Transition → CTA (Action)

→ Output: Complete Video Script (สั้น 60s / กลาง 3min / ยาว 10min)

---

## EXAMPLE PROJECTS (จาก FunnelScripts)

### Executive Coaching Program
- **Moral**: We all need a mentor
- **Meaning**: We all need to have mentors to help us grow and believe in ourselves
- **Emotion**: Inspired and wanting a mentor
- **Action**: Joining my executive coaching program so I can be the one who believes in you

### MLM Opportunity
- **Moral**: Try again
- **Meaning**: อย่ายอมแพ้ ลองอีกครั้ง
- **Emotion**: มีกำลังใจอยากลองใหม่
- **Action**: สมัครโอกาสทางธุรกิจ

### Heavy Metal Detox
- **Moral**: Need to detox
- **Meaning**: ร่างกายสะสมสารพิษมากกว่าที่คิด
- **Emotion**: ตกใจ + อยากแก้ไข
- **Action**: สั่งซื้อผลิตภัณฑ์ detox

### Alkaline Water
- **Moral**: Find out more about water types
- **Meaning**: น้ำที่ดื่มทุกวันส่งผลต่อสุขภาพมากกว่าที่คิด
- **Emotion**: อยากรู้เพิ่ม + กังวลเรื่องน้ำที่ดื่ม
- **Action**: ค้นหาข้อมูลเพิ่มเติม / ทดลองใช้เครื่อง

---

## INTEGRATION WITH OTHER SKILLS

- **sales-story-secrets**: ใช้ Story Ideas → พัฒนาเป็น Full Sales Story ด้วย Hero's Journey / 7 Blueprints
- **funnel-scripts-copywriting**: ใช้ Story Ideas → สร้าง Hook-Story-Offer / VSL Script
- **inception-copywriting**: ใช้ Story Ideas → สร้าง VDO Script / Webinar Script
- **perfect-webinar-wizard**: ใช้ Story Ideas → เป็น Epiphany Bridge Stories ใน Q8, Q20, Q26, Q32
- **mrarranger-viral-content**: ใช้ Story Ideas → สร้าง Viral Short Video Content
- **mrarranger-social**: ใช้ Story Ideas → แปลงเป็น Social Posts ทุก Platform

==============================================================
## 🏁 END OF ALL SKILLS
**Total: 48 Skills Combined**