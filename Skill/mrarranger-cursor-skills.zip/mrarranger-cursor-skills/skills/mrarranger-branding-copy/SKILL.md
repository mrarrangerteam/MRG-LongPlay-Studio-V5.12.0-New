---
name: mrarranger-branding-copy
description: "MRARRANGER Branding & Copywriting - รวม 7 Skills: Alphamind Brand Cortex (MDM, Brand House, 16 Archetypes, Tone of Voice, Mega Prompts), Inception Copywriting (Sales Pages, VDO Scripts, Webinar Scripts, Golden Nugget), Funnel Scripts (Jim Edwards, Hook-Story-Offer, OTO, VSL), Sales Story Secrets (Hero's Journey, Epiphany Bridge, 7 Story Blueprints), Perfect Webinar Wizard (Russell Brunson, Stack, Close), Video Story Brainstorming (Story Ideas, Content Brainstorming, Script), Clone Master (Voice Cloning, Style Replication). Commands: /brand /copy /cortex /archetype /tone /mdm /headline /funnel /webinar /story /clone. Triggers: branding, copywriting, sales page, funnel, webinar script, brand strategy, archetypes, sales copy, hook, headline, VDO script"
---

# MRARRANGER Branding & Copywriting — 7 Skills Combined

> Routing table for branding and copywriting skills

## SKILL ROUTING TABLE

| Trigger | Reference File | Use When |
|---------|---------------|----------|
| `/mdm` `/brandhouse` `/cortex` `/archetype` `/tone` | `references/alphamind-brand-cortex.md` | Brand strategy, MDM, Brand House, Archetypes |
| `/copy` `/inception` `/vdo-script` `/golden-nugget` | `references/inception-copywriting.md` | Sales pages, VDO scripts, webinar scripts |
| `/funnel-script` `/hook-story-offer` `/vsl` | `references/funnel-scripts-copywriting.md` | Funnel scripts, Jim Edwards style |
| `/sales-story` `/heros-journey` `/epiphany` | `references/sales-story-secrets.md` | Story-based selling |
| `/webinar` `/stack` `/close` | `references/perfect-webinar-wizard.md` | Perfect Webinar scripts |
| `/story-brainstorm` `/story-ideas` | `references/video-story-brainstorming.md` | Video story brainstorming |
| `/clone` `/voice-clone` `/style` | `references/mrarranger-clone-master.md` | Voice/style cloning |
