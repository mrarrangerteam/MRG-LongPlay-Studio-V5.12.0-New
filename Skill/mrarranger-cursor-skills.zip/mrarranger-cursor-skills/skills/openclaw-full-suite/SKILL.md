---
name: openclaw-full-suite
description: "OpenClaw Full Suite - รวม 8 Skills: Agents (Multi-Agent Routing, Agent Config, Personality, Memory), Automation (Cron Jobs, Webhooks, Event Triggers, Scheduled Tasks), Channels (WhatsApp, Telegram, Slack, Discord, Signal, Line, Zalo), Ecosystem (ClawHub, Community Skills, Marketplace, Integration), Gateway (Core Server, API Gateway, Load Balancing, Auth), MCP (Model Context Protocol Server, Tool Integration, Custom Tools), Office (Document Processing, Meeting Notes, Calendar, Task Management), Skills Dev (Skill Creation, Testing, Publishing, Version Management). Commands: /claw-agent /claw-auto /claw-channel /claw-hub /claw-gateway /claw-mcp /claw-office /claw-skill"
---

# openclaw-full-suite - Combined Skill

> Auto-routing: วิเคราะห์ request แล้วโหลด reference ที่เกี่ยวข้อง

## HOW TO USE
1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง
3. โหลด reference file ที่ตรงกับ request
4. Execute ตาม instructions ใน reference

## SKILL ROUTING TABLE

| Skill | Reference File |
|-------|---------------|
| openclaw-agents | references/openclaw-agents.md |
| openclaw-automation | references/openclaw-automation.md |
| openclaw-channels | references/openclaw-channels.md |
| openclaw-ecosystem | references/openclaw-ecosystem.md |
| openclaw-gateway | references/openclaw-gateway.md |
| openclaw-mcp | references/openclaw-mcp.md |
| openclaw-office | references/openclaw-office.md |
| openclaw-skills-dev | references/openclaw-skills-dev.md |

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ skill ไหนจาก routing table
2. ใช้ `view` tool อ่าน reference file ที่เกี่ยวข้อง
3. ทำตาม instructions ใน reference file นั้นอย่างเคร่งครัด
4. ถ้าเกี่ยวข้องหลาย skills ให้อ่านทุก reference ที่เกี่ยวข้อง
