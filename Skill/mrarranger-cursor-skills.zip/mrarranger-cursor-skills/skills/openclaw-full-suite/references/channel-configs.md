# OpenClaw Channels - Detailed Configuration Guide

Complete setup instructions for all 22+ messaging channels.

---

## 1. WhatsApp

**Setup Time:** 15 min | **Complexity:** High | **Multi-Account:** Yes

### Prerequisites
- Phone number (dedicated recommended, not personal)
- Smartphone with WhatsApp installed
- QR code scanner access

### Setup Steps

```bash
# 1. Start pairing process
openclaw channel add whatsapp

# 2. Scan QR code with WhatsApp Web
# (Follow CLI prompts, a QR code will display)

# 3. Verify connection
openclaw channel status whatsapp
```

### Full Configuration

```yaml
channels:
  whatsapp:
    provider: "whatsapp"
    phone: "+66812345678"        # E.164 format required
    account_name: "Customer Service"

    # DM Policy
    allowFrom: "open"             # accept all DMs

    # Pairing
    pairing:
      require_approval: false     # auto-approve after initial pairing
      max_retries: 3
      timeout: 120s

    # Media
    media:
      max_size: "16MB"            # Documents up to 100MB
      allowed_types:
        - "image/jpeg"
        - "image/png"
        - "video/mp4"
        - "audio/mpeg"
        - "application/pdf"

    # Credentials
    credentials_path: "~/.openclaw/whatsapp/phone/+66812345678.session"

    # VoIP Warning
    # WhatsApp may restrict VoIP numbers
    # Avoid: Google Voice, Twilio, Vonage
    # Use: Physical phone number or business account

    # Reconnection
    reconnect:
      enabled: true
      max_retries: 5
      backoff: "exponential"

    # Rate limiting
    rate_limit:
      messages_per_second: 1
      group_messages_per_second: 2
```

### VoIP Number Issues

**Problem:** WhatsApp blocks VoIP numbers (Google Voice, Twilio)
**Solution:**
1. Use physical SIM card number
2. Or use WhatsApp Business Account (requires verification)

```bash
# Check phone type
openclaw channel whatsapp phone-type "+66812345678"

# Register business account (if eligible)
openclaw channel whatsapp register-business
```

### Multi-Account Setup

```yaml
channels:
  whatsapp:
    accounts:
      - phone: "+66812345678"
        agent: "customer_service"
        allowFrom: "open"

      - phone: "+66987654321"
        agent: "support_team"
        allowFrom: "paired"
```

### Credentials Path

```bash
# Credentials stored here (encrypted):
~/.openclaw/whatsapp/phone/+66812345678.session

# Multiple accounts:
~/.openclaw/whatsapp/phone/+66812345678.session
~/.openclaw/whatsapp/phone/+66987654321.session

# Never edit directly - use CLI
```

### Troubleshooting

```bash
# Connection lost
openclaw channel reconnect whatsapp

# Code 401 (expired session)
openclaw channel whatsapp re-authenticate

# "Phone number invalid"
# Verify: +1 (country code) + area code + number (no spaces/dashes)

# "VoIP not supported"
# Switch to physical SIM or Business Account
```

---

## 2. Telegram

**Setup Time:** 5 min | **Complexity:** Low | **Multi-Account:** Yes

### Prerequisites
- Telegram account
- BotFather chat access (@BotFather on Telegram)

### Setup Steps

```bash
# 1. Create bot with BotFather
# Message @BotFather: /newbot
# BotFather will give you a token: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11

# 2. Add to OpenClaw
openclaw channel add telegram

# 3. Paste bot token when prompted
# Or via config:
openclaw channel telegram set-token "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
```

### Full Configuration

```yaml
channels:
  telegram:
    provider: "telegram"
    bot_token: "${TELEGRAM_BOT_TOKEN}"  # Store in env var!
    bot_username: "@mybot"              # Display name

    # DM Policy
    allowFrom: "open"

    # Group support
    group_support:
      enabled: true
      auto_join: false                  # Don't auto-join new groups

    # Inline mode (buttons, keyboards)
    inline_mode:
      enabled: true
      max_results: 50

    # Media
    media:
      max_size: "50MB"
      allowed_types: ["image", "video", "audio", "document"]

    # Webhooks (if using webhook mode instead of polling)
    webhook:
      enabled: false
      url: "https://yoursite.com/telegram"
      certificate: null

    # Polling (default)
    polling:
      enabled: true
      timeout: 30s
      allowed_updates: ["message", "callback_query"]
```

### Group Chat Setup

```bash
# Add bot to group
# 1. Create group or select existing
# 2. Add @mybot to group
# 3. Give permissions: send messages, read all group messages

# Check group ID
openclaw channel telegram list-groups

# Output:
# -1001234567890: "Customer Support Group"
# -1009876543210: "Team Chat"

# Bind agent to group
openclaw channel bind telegram:-1001234567890 @customer_service_agent
```

### Inline Mode

```python
# Enable buttons and keyboards in responses
from openclaw.channels import Telegram

telegram = Telegram(bot_token="YOUR_TOKEN")

await telegram.send_message(
    chat_id=12345,
    text="Choose an option:",
    reply_markup={
        "inline_keyboard": [
            [
                {"text": "Option 1", "callback_data": "opt1"},
                {"text": "Option 2", "callback_data": "opt2"}
            ]
        ]
    }
)
```

### Token Security

```bash
# WRONG - exposed in config file
bot_token: "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"

# RIGHT - use environment variable
bot_token: "${TELEGRAM_BOT_TOKEN}"

# In .env file (never commit!)
TELEGRAM_BOT_TOKEN="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
```

---

## 3. Discord

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Discord server (guild)
- Developer Portal access
- Bot token

### Setup Steps

```bash
# 1. Go to Discord Developer Portal
# https://discord.com/developers/applications

# 2. Create New Application
# Name: "OpenClaw Bot"

# 3. Go to "Bot" section
# Click "Add Bot"
# Copy TOKEN

# 4. Add to OpenClaw
openclaw channel add discord

# 5. Enter token and guild ID when prompted
```

### Full Configuration

```yaml
channels:
  discord:
    provider: "discord"
    bot_token: "${DISCORD_BOT_TOKEN}"

    # Server (Guild)
    guild_id: "1234567890"

    # Intents (CRITICAL - controls what bot receives)
    intents:
      - "guilds"                    # Guild updates
      - "guild_messages"            # Messages in channels
      - "direct_messages"           # DM support
      - "message_content"           # Read message content
      - "guild_members"             # Member join/leave

    # Channels to monitor
    channels:
      - "1234567890"               # Channel ID
      - "#general"                 # Or channel name
      - "#support"

    # DM Policy
    allowFrom: "paired"             # Require DM pairing

    # Media
    media:
      max_size: "10MB"              # 100MB if server boosted
      allowed_types: ["all"]

    # Intents explanation:
    # REQUIRED: message_content (to read message text)
    # OPTIONAL: guild_members (track members)
    # OPTIONAL: presences (track online status)
```

### Intent Configuration

**Critical:** Discord requires explicit intents. Missing `message_content` means bot can't read messages!

```python
# In Discord Developer Portal:
# Bot > Intent > REQUIRED: Message Content Intent (toggle ON)
#              > REQUIRED: Server Members Intent (toggle ON if needed)
```

### Guild Setup

```bash
# List all guilds bot has access to
openclaw channel discord list-guilds

# Output:
# Guild ID: 1234567890 (Server Name)
# Guild ID: 0987654321 (Another Server)

# Bind specific guild
openclaw channel bind discord:1234567890 @agent_name

# Bind specific channel in guild
openclaw channel bind discord:1234567890#general @agent_name
```

### Permissions Setup

In Discord Server Settings:
1. Go to Server Settings > Bot/App > Select Bot
2. Required Permissions:
   - Send Messages
   - Read Messages
   - Send Embeds
   - Attach Files
   - Read Message History

```bash
# Generate invite link with correct permissions
openclaw channel discord generate-invite --guild-id 1234567890
```

### Multi-Account

```yaml
channels:
  discord:
    bots:
      - bot_token: "${DISCORD_BOT_TOKEN_1}"
        guild_id: "1234567890"
        agent: "customer_service"

      - bot_token: "${DISCORD_BOT_TOKEN_2}"
        guild_id: "0987654321"
        agent: "support_team"
```

---

## 4. Slack

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Slack workspace
- Admin access or app approval from admin
- Slack App created

### Setup Steps

```bash
# 1. Go to Slack API
# https://api.slack.com/apps

# 2. Create New App
# From scratch > App name & workspace

# 3. Features: Incoming Webhooks
# Add New Webhook to Workspace

# 4. Features: OAuth & Permissions
# Scopes: chat:write, im:write, channels:read

# 5. Install to workspace
# Copy Bot User OAuth Token

# 6. Add to OpenClaw
openclaw channel add slack
```

### Full Configuration

```yaml
channels:
  slack:
    provider: "slack"
    bot_token: "${SLACK_BOT_TOKEN}"
    app_id: "A1234567890"

    # Workspace
    workspace: "mycompany"          # or full URL
    workspace_url: "https://mycompany.slack.com"

    # Channels to monitor
    channels:
      - "C1234567890"               # Channel ID
      - "#general"                  # Or channel name
      - "#random"
      - "#support"

    # DM Policy
    allowFrom: "open"               # Accept DMs

    # Events
    events:
      enabled: true
      message_events: true
      app_mention: true

    # Media
    media:
      max_size: "1GB"               # Per workspace
      allowed_types: ["all"]
```

### OAuth Scopes

Required scopes for OpenClaw bot:

```
chat:write          # Send messages
im:write            # Send DMs
channels:read       # List channels
groups:read         # List groups/DMs
reactions:read      # Read reactions
files:read          # Read files
```

### Webhook Setup (Legacy)

For older integrations or one-way messaging:

```yaml
incoming_webhooks:
  - url: "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX"
    channel: "#notifications"
```

### Troubleshooting

```bash
# Check connection
openclaw channel status slack

# List channels bot can access
openclaw channel slack list-channels

# Test message
openclaw channel slack test-message "#general" "Hello from OpenClaw"
```

---

## 5. Signal

**Setup Time:** 20 min | **Complexity:** High | **Multi-Account:** No

### Prerequisites
- Real phone number (not VoIP)
- Signal CLI installed
- Phone running Signal app

### Setup Steps

```bash
# 1. Install Signal CLI
brew install signal-cli          # macOS
sudo apt-get install signal-cli  # Linux

# 2. Register phone
signal-cli --config ~/.signal register --phone "+66812345678"

# 3. Verify with code sent to phone
signal-cli --config ~/.signal verify --phone "+66812345678" --verification-code "123456"

# 4. Add to OpenClaw
openclaw channel add signal

# 5. Phone number when prompted
openclaw channel signal set-phone "+66812345678"
```

### Full Configuration

```yaml
channels:
  signal:
    provider: "signal"
    phone: "+66812345678"           # E.164 format
    account_name: "Secure Channel"

    # Signal CLI config path
    signal_config_path: "~/.signal"

    # DM Policy (Signal is E2E encrypted always)
    allowFrom: "paired"             # Always require pairing

    # Group support
    group_support:
      enabled: true
      max_groups: 10

    # Media (encrypted locally)
    media:
      max_size: "100MB"             # Limited by device
      allowed_types: ["image", "video", "audio", "document"]

    # Security
    security:
      e2e_encryption: true          # Always on
      disappearing_messages: 0      # None by default
```

### Signal CLI Integration

```python
from openclaw.channels import Signal

signal = Signal(phone="+66812345678", config_path="~/.signal")

# Send secure message
await signal.send_message(
    recipient="+66887654321",
    text="Secure message"
)

# List groups
await signal.list_groups()

# Send to group
await signal.send_message(
    group_id="abc123def456...",
    text="Group message"
)
```

### Real Phone Number Requirement

**Why:** Signal requires real phone number to verify identity
**Limitations:**
- Cannot use VoIP (Google Voice, Twilio)
- Cannot use landlines
- Phone must be active when registering

**Solution if stuck:**
1. Use temporary phone service (Twillio, Vonage with real number)
2. Or use physical SIM card

---

## 6. iMessage / BlueBubbles

**Setup Time:** 5 min | **Complexity:** High* | **Multi-Account:** No*

*Requires macOS hardware with iMessage account

### Prerequisites
- macOS machine (Catalina or later)
- iMessage account (Apple ID)
- BlueBubbles server running on Mac (optional, for remote access)

### Setup Steps

```bash
# 1. macOS Setup (direct)
# OpenClaw must run on Mac with iMessage
# OR use BlueBubbles server

# 2. Configure
openclaw channel add imessage

# 3. Verify connection
openclaw channel status imessage
```

### Full Configuration - Direct (macOS only)

```yaml
channels:
  imessage:
    provider: "imessage"
    mode: "direct"                  # Runs on macOS
    account_type: "individual"      # Apple ID account

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "500MB"
      allowed_types: ["all"]
```

### Full Configuration - BlueBubbles (Remote)

```yaml
channels:
  imessage:
    provider: "imessage"
    mode: "bluebubbles"

    # BlueBubbles server connection
    server:
      host: "192.168.1.100"
      port: 1234
      password: "${BLUEBUBBLES_PASSWORD}"

    # Account
    account_name: "iMessage"

    # DM Policy
    allowFrom: "open"
```

### BlueBubbles Server Setup

```bash
# 1. On Mac with iMessage:
# Download BlueBubbles server from bluebubbles.app

# 2. Start server
# Server will run on localhost:1234

# 3. Generate password in Settings

# 4. On remote machine:
# Configure OpenClaw with server IP and password
```

### Limitations

- **No multi-account** (one iMessage account per Mac)
- **macOS only** for direct mode (BlueBubbles allows remote)
- **Apple ID required** (personal accounts only, no business)
- **Group chat support:** Yes, but limited features

---

## 7. Microsoft Teams

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Microsoft 365 tenant access
- Admin approval for app installation

### Setup Steps

```bash
# 1. Go to Teams admin portal
# https://admin.teams.microsoft.com

# 2. Create bot in Azure
# Azure > Bot Services > Create New Bot

# 3. Register bot
# App ID (from Azure) + Password

# 4. Add to OpenClaw
openclaw channel add teams
```

### Full Configuration

```yaml
channels:
  teams:
    provider: "teams"

    # Bot credentials (from Azure)
    app_id: "${TEAMS_APP_ID}"
    app_password: "${TEAMS_APP_PASSWORD}"

    # Tenant
    tenant: "${TEAMS_TENANT_ID}"

    # Teams to monitor
    teams:
      - team_id: "T123456"
        channels:
          - "general"
          - "announcements"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "20GB"
      allowed_types: ["all"]

    # Plugin support
    plugins:
      enabled: true
```

### Plugin Setup

```bash
# Create Teams plugin
# Manifest: manifest.json

{
  "version": "1.0",
  "manifestVersion": "1.4",
  "name": "OpenClaw",
  "description": "AI Agent Bot",
  "bots": [
    {
      "botId": "YOUR_APP_ID",
      "scopes": ["personal", "groupChat", "team"],
      "commandLists": [
        {
          "scopes": ["personal", "groupChat", "team"],
          "commands": [
            {
              "title": "Help",
              "description": "Get help"
            }
          ]
        }
      ]
    }
  ]
}
```

---

## 8. Google Chat

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Google Workspace account
- Service account created

### Setup Steps

```bash
# 1. Create service account
# Google Cloud Console > Service Accounts

# 2. Create key (JSON)
# Download credentials.json

# 3. Share Google Chat space with service account

# 4. Add to OpenClaw
openclaw channel add google-chat
```

### Full Configuration

```yaml
channels:
  google_chat:
    provider: "google_chat"

    # Service account credentials
    credentials_path: "${GOOGLE_CREDENTIALS}"
    credentials_json: "${GOOGLE_CREDENTIALS_JSON}"

    # Spaces to monitor
    spaces:
      - "spaces/AAAABBBBCCCC"       # Space ID
      - "spaces/DDDDEEEEFFFFG"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "1GB"
      allowed_types: ["all"]
```

### Service Account Setup

```bash
# Generate service account key
gcloud iam service-accounts keys create ~/key.json \
  --iam-account=openclaw@project-id.iam.gserviceaccount.com

# Share Chat space with service account
# Settings > People > Add service account email
```

---

## 9. Matrix / Synapse

**Setup Time:** 15 min | **Complexity:** High | **Multi-Account:** Yes

### Prerequisites
- Matrix homeserver (self-hosted or public)
- Matrix account on homeserver
- Access token or password

### Setup Steps

```bash
# 1. Create account on homeserver
# https://matrix.org (public) or self-hosted

# 2. Get access token
curl -XPOST http://localhost:8008/_matrix/client/r0/login \
  -d '{"type":"m.login.password","user":"botname","password":"password"}'

# 3. Add to OpenClaw
openclaw channel add matrix
```

### Full Configuration

```yaml
channels:
  matrix:
    provider: "matrix"

    # Homeserver
    homeserver_url: "https://matrix.org"
    user_id: "@openclaw:matrix.org"

    # Authentication
    access_token: "${MATRIX_ACCESS_TOKEN}"
    # OR
    password: "${MATRIX_PASSWORD}"
    device_name: "OpenClaw"

    # Rooms to monitor
    rooms:
      - "!AAAAAA:matrix.org"        # Room ID
      - "#general:matrix.org"       # Room alias

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "500MB"             # Depends on server
      allowed_types: ["all"]
```

### Synapse Server Config

If self-hosting Matrix:

```yaml
# homeserver.yaml configuration
server_name: "matrix.example.com"

# Enable registration for bot accounts
registration_allow_guest: false

# Database
database:
  name: "psycopg2"
  args:
    database: "synapse"

# Listeners
listeners:
  - port: 8008
    bind_addresses: ['::1', '127.0.0.1']
    type: http
    x_forwarded: true
```

---

## 10. Zalo & Zalo Personal

**Setup Time:** 15 min | **Complexity:** High | **Multi-Account:** Yes

### Prerequisites
- Zalo Developer Account
- Official Account (Zalo API) or Personal Account (Zalo Personal)

### Setup - Zalo API (Official Account)

```bash
# 1. Register Zalo Developer
# https://developers.zalo.me

# 2. Create Official Account
# Get Access Token and Server Key

# 3. Add to OpenClaw
openclaw channel add zalo
```

### Full Configuration - Zalo Official

```yaml
channels:
  zalo:
    provider: "zalo"
    mode: "official"                # Official Account

    # Credentials
    access_token: "${ZALO_ACCESS_TOKEN}"
    server_key: "${ZALO_SERVER_KEY}"
    official_account_id: "YOUR_OA_ID"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "50MB"
      allowed_types: ["image", "video", "file", "audio"]

    # Webhook
    webhook:
      enabled: true
      url: "https://yoursite.com/zalo"
      verify_token: "${ZALO_VERIFY_TOKEN}"
```

### Setup - Zalo Personal

For personal account bot integration:

```yaml
channels:
  zalo:
    provider: "zalo"
    mode: "personal"                # Personal Account

    # Account credentials
    phone: "+66812345678"

    # DM Policy
    allowFrom: "paired"

    # Media
    media:
      max_size: "50MB"
```

### Webhook Verification

```python
from openclaw.channels import Zalo

zalo = Zalo(access_token="YOUR_TOKEN")

# Verify webhook
@app.route("/zalo", methods=["GET"])
def verify_webhook():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if token == VERIFY_TOKEN:
        return challenge
    return "Forbidden", 403

# Receive messages
@app.route("/zalo", methods=["POST"])
def handle_webhook():
    data = request.json
    await zalo.handle_message(data)
```

---

## 11. LINE (Line Messaging API)

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- LINE Developer Account
- LINE Official Account

### Setup Steps

```bash
# 1. Go to LINE Developers
# https://developers.line.biz

# 2. Create LINE Official Account

# 3. Create channel in LINE Console
# Type: Messaging API

# 4. Get Channel ID and Access Token

# 5. Add to OpenClaw
openclaw channel add line
```

### Full Configuration

```yaml
channels:
  line:
    provider: "line"

    # Credentials
    channel_id: "${LINE_CHANNEL_ID}"
    channel_secret: "${LINE_CHANNEL_SECRET}"
    access_token: "${LINE_ACCESS_TOKEN}"

    # Webhook
    webhook:
      enabled: true
      url: "https://yoursite.com/line"
      path: "/line/callback"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "200MB"
      allowed_types: ["image", "video", "audio", "file"]

    # Rich menus (UI buttons)
    rich_menu:
      enabled: true
```

### Webhook Setup

```python
from flask import Flask, request
from openclaw.channels import Line

app = Flask(__name__)
line = Line(access_token="YOUR_TOKEN")

@app.route("/line/callback", methods=["POST"])
def callback():
    signature = request.headers.get("X-Line-Signature")

    # Verify signature
    if not line.verify_signature(request.data, signature):
        return "Unauthorized", 403

    # Handle messages
    body = request.get_json()
    for event in body.get("events", []):
        await line.handle_event(event)

    return "OK"
```

### Rich Menu Example

```python
rich_menu = {
    "size": {"width": 2500, "height": 1686},
    "selected": True,
    "name": "Main Menu",
    "areas": [
        {
            "bounds": {"x": 0, "y": 0, "width": 1250, "height": 843},
            "action": {"type": "message", "text": "Option 1"}
        },
        {
            "bounds": {"x": 1250, "y": 0, "width": 1250, "height": 843},
            "action": {"type": "message", "text": "Option 2"}
        }
    ]
}
```

---

## 12. Mattermost

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Mattermost instance (self-hosted or cloud)
- Admin access or bot creation permission

### Setup Steps

```bash
# 1. Create bot account
# System Console > Integrations > Bot Accounts

# 2. Get bot token
# Copy Access Token

# 3. Add to OpenClaw
openclaw channel add mattermost
```

### Full Configuration

```yaml
channels:
  mattermost:
    provider: "mattermost"

    # Server connection
    server_url: "https://mattermost.company.com"

    # Bot credentials
    bot_token: "${MATTERMOST_BOT_TOKEN}"
    bot_username: "openclaw"

    # Channels to monitor
    channels:
      - "town-square"
      - "general"
      - "support"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "100MB"
      allowed_types: ["all"]

    # Webhook
    webhook:
      enabled: true
      url: "https://yoursite.com/mattermost"
```

### Webhook Integration

```python
@app.route("/mattermost", methods=["POST"])
def mattermost_webhook():
    data = request.json

    # Process incoming webhook
    # data contains: type, channel, user_id, text, etc.

    # Send response
    return {
        "text": "Response message",
        "attachments": [{
            "text": "Attachment text"
        }]
    }
```

---

## 13. Feishu (Lark)

**Setup Time:** 15 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Feishu/Lark account
- Workspace access
- Bot/App creation permission

### Setup Steps

```bash
# 1. Create bot in Feishu Dev Console
# https://open.feishu.cn

# 2. Create app
# Name: "OpenClaw Bot"
# Type: "Bot"

# 3. Get app_id and app_secret

# 4. Add to OpenClaw
openclaw channel add feishu
```

### Full Configuration

```yaml
channels:
  feishu:
    provider: "feishu"
    region: "cn"                    # "cn" or "com" for international

    # App credentials
    app_id: "${FEISHU_APP_ID}"
    app_secret: "${FEISHU_APP_SECRET}"

    # Verification
    encrypt_key: "${FEISHU_ENCRYPT_KEY}"
    verification_token: "${FEISHU_VERIFICATION_TOKEN}"

    # Chat groups to monitor
    chat_groups:
      - "oc_abc123def456"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "500MB"
      allowed_types: ["all"]

    # Webhook
    webhook:
      enabled: true
      url: "https://yoursite.com/feishu"
```

### Message Card Example

```python
card = {
    "msg_type": "interactive",
    "card": {
        "elements": [
            {
                "tag": "div",
                "text": {
                    "content": "Hello from OpenClaw",
                    "tag": "lark_md"
                }
            },
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {
                            "content": "Click me",
                            "tag": "lark_md"
                        },
                        "type": "primary",
                        "value": "action_value"
                    }
                ]
            }
        ]
    }
}
```

---

## 14. Nextcloud Talk

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Nextcloud instance with Talk app
- Bot/service account access

### Setup Steps

```bash
# 1. Create service account in Nextcloud
# Settings > Users > Add User

# 2. Create app password for bot
# Security > App Passwords

# 3. Add to OpenClaw
openclaw channel add nextcloud-talk
```

### Full Configuration

```yaml
channels:
  nextcloud_talk:
    provider: "nextcloud-talk"

    # Server
    nextcloud_url: "https://nextcloud.company.com"

    # Bot account
    username: "openclaw-bot"
    app_password: "${NEXTCLOUD_APP_PASSWORD}"

    # Rooms to monitor
    rooms:
      - "support-channel"
      - "general"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "1GB"
      allowed_types: ["all"]
```

---

## 15. Nostr

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Nostr keypair (public/private key)
- Relay connection info

### Setup Steps

```bash
# 1. Generate Nostr keypair
openclaw channel nostr generate-key

# Output:
# Public Key (npub): npub1abcd1234...
# Private Key (nsec): nsec1wxyz9876... (KEEP SECRET!)

# 2. Save private key securely

# 3. Configure relays
openclaw channel nostr add-relay "wss://relay.example.com"
```

### Full Configuration

```yaml
channels:
  nostr:
    provider: "nostr"

    # Keys (NEVER expose private key)
    public_key: "npub1abcd1234..."
    private_key: "${NOSTR_PRIVATE_KEY}"  # From secure storage

    # Relays
    relays:
      - "wss://relay.damus.io"
      - "wss://relay.example.com"
      - "wss://nos.lol"

    # DM Policy
    allowFrom: "paired"              # Nostr is semi-anonymous

    # Media (limited, references external)
    media:
      max_size: "10MB"
      allowed_types: ["image", "video"]  # Embedded references
```

### Key Management

```bash
# Generate keypair (one-time)
openclaw channel nostr generate-key

# Export public key
openclaw channel nostr export-pubkey

# Import existing key
openclaw channel nostr import-key "nsec1wxyz..."

# NEVER:
# - Commit private key to git
# - Share private key
# - Use in plain text config files
```

---

## 16. Synology Chat

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Synology NAS with Chat app
- Admin access

### Setup Steps

```bash
# 1. Go to Synology Chat Admin
# https://nas.local:5001 > Chat

# 2. Create bot
# Settings > Bot Integration > Create

# 3. Get Webhook URL

# 4. Add to OpenClaw
openclaw channel add synology-chat
```

### Full Configuration

```yaml
channels:
  synology_chat:
    provider: "synology-chat"

    # Server
    server_url: "https://nas.local:5001"

    # Bot webhook
    webhook_url: "${SYNOLOGY_WEBHOOK_URL}"

    # Channels
    channels:
      - "general"
      - "support"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "500MB"
      allowed_types: ["all"]
```

---

## 17. Tlon (Urbit)

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** Yes

### Prerequisites
- Urbit planet or star
- Tlon group access

### Setup Steps

```bash
# 1. Create bot identity in Urbit

# 2. Configure Tlon group

# 3. Add to OpenClaw
openclaw channel add tlon
```

### Full Configuration

```yaml
channels:
  tlon:
    provider: "tlon"

    # Urbit identity
    ship: "~sampel-palnet"
    code: "${URBIT_CODE}"

    # Tlon group
    group: "~sampel-palnet/test-group"

    # DM Policy
    allowFrom: "paired"

    # Media
    media:
      max_size: "100MB"
      allowed_types: ["all"]
```

---

## 18. Twitch

**Setup Time:** 10 min | **Complexity:** Medium | **Multi-Account:** No

### Prerequisites
- Twitch account
- Twitch Developer Console access
- Channel ownership

### Setup Steps

```bash
# 1. Register app in Twitch Dev Console
# https://dev.twitch.tv/console

# 2. Create OAuth app
# Get Client ID and Client Secret

# 3. Authenticate
# Get OAuth token via login flow

# 4. Add to OpenClaw
openclaw channel add twitch
```

### Full Configuration

```yaml
channels:
  twitch:
    provider: "twitch"

    # App credentials
    client_id: "${TWITCH_CLIENT_ID}"
    client_secret: "${TWITCH_CLIENT_SECRET}"
    access_token: "${TWITCH_ACCESS_TOKEN}"

    # Channel
    channel_name: "mychannel"
    channel_id: "123456789"

    # Bot config
    bot_username: "openclaw_bot"

    # DM Policy (No DMs, channel only)
    allowFrom: "none"

    # Chat settings
    chat:
      auto_join: true
      log_messages: true
      respond_to_mentions: true
```

### Bot Moderation

```bash
# Moderate bot
# Twitch > Your Channel > Moderation

# Permissions needed:
# - Send messages
# - Moderate users
# - Read chat
```

---

## 19. IRC

**Setup Time:** 5 min | **Complexity:** Low | **Multi-Account:** Yes

### Prerequisites
- IRC server (Freenode, Libera, etc.)
- Channel on server

### Setup Steps

```bash
# 1. Connect to IRC server
openclaw channel add irc

# 2. Provide server details
# Server: irc.libera.chat
# Port: 6697 (SSL)
# Nick: openclaw
# Channels: #general #support
```

### Full Configuration

```yaml
channels:
  irc:
    provider: "irc"

    # Server
    server: "irc.libera.chat"
    port: 6697                      # 6667 non-SSL, 6697 SSL
    use_ssl: true

    # Identity
    nick: "openclaw"
    username: "openclaw-bot"
    realname: "OpenClaw Bot"

    # Channels to join
    channels:
      - "#general"
      - "#support"
      - "#random"

    # Authentication
    password: "${IRC_PASSWORD}"     # Server password (if needed)
    sasl:
      enabled: true
      username: "openclaw"
      password: "${IRC_SASL_PASSWORD}"

    # DM Policy
    allowFrom: "open"

    # Media (text only)
    media:
      max_size: "512B"              # IRC line limit
      allowed_types: ["text"]
```

### Reconnection for IRC

```bash
# IRC is prone to connection issues
# Auto-reconnect is essential

reconnect:
  enabled: true
  max_retries: 10
  backoff: "exponential"
  timeout: 60s
```

---

## 20. WebChat

**Setup Time:** 5 min | **Complexity:** Low | **Multi-Account:** Yes

### Prerequisites
- Website with HTML/JavaScript integration
- CORS configured properly

### Setup Steps

```bash
# 1. Generate webchat widget
openclaw channel add webchat

# 2. Get embed code

# 3. Add to website
# <script src="https://openclaw.com/webchat.js"></script>
```

### Full Configuration

```yaml
channels:
  webchat:
    provider: "webchat"

    # Widget settings
    widget:
      title: "Customer Support"
      theme_color: "#007bff"
      position: "bottom-right"

    # Server connection
    server_url: "https://openclaw.com"
    widget_id: "unique_widget_id"

    # DM Policy
    allowFrom: "open"

    # Media
    media:
      max_size: "10MB"
      allowed_types: ["image", "document"]

    # Port (for self-hosted)
    port: 3000
```

### Widget Embed Code

```html
<!-- Add to your website -->
<script>
  window.OpenClawConfig = {
    widgetId: "unique_widget_id",
    serverUrl: "https://openclaw.com",
    title: "Chat with us",
    theme: {
      primary: "#007bff"
    }
  };
</script>
<script src="https://openclaw.com/webchat.js"></script>
```

### Self-Hosted WebChat

```bash
# Run OpenClaw WebChat server
openclaw webchat start --port 3000

# Access at: http://localhost:3000/chat
```

---

## 21-23. Native Mobile & Desktop

### macOS Native

**Setup Time:** 5 min | **Complexity:** Low* | **Multi-Account:** No

*Requires macOS running OpenClaw

```yaml
channels:
  macos_native:
    provider: "macos"

    # Uses system Messages app
    # OR native notifications

    # Account
    icloud_account: "user@icloud.com"
```

### iOS Native

**Setup Time:** 5 min | **Complexity:** Low* | **Multi-Account:** No

*Requires iOS running OpenClaw

```yaml
channels:
  ios_native:
    provider: "ios"

    # Native Messages integration
    # Apple ID required
```

### Android Native

**Setup Time:** 5 min | **Complexity:** Low* | **Multi-Account:** No

*Requires Android running OpenClaw

```yaml
channels:
  android_native:
    provider: "android"

    # Native SMS/messaging integration
    # Phone number required
```

---

## Channel Health Monitoring

Monitor all channels:

```bash
# Quick status
openclaw channel health

# Detailed monitoring
openclaw channel health --detailed

# Watch in real-time
openclaw channel monitor --watch

# Export metrics
openclaw channel health --export json > health.json
```

### Health Metrics

```
Connection Status: Connected/Disconnected
Uptime: 99.5%
Message Queue: 123 pending
Last Heartbeat: 2 min ago
Error Rate: 0.1%
Average Latency: 450ms
```

---

## Troubleshooting Cross-Channel

```bash
# Check all channels
openclaw channel status --all

# View recent errors
openclaw channel logs --tail 100 --filter error

# Test channel connectivity
openclaw channel test-connection whatsapp

# Simulate sending message
openclaw channel test-message discord "#general" "Hello test"
```

---

## Security Checklist

- [ ] Store all tokens in environment variables
- [ ] Never commit `.env` files
- [ ] Rotate tokens every 3-6 months
- [ ] Enable DM pairing for sensitive channels
- [ ] Monitor logs for suspicious activity
- [ ] Use HTTPS for webhooks
- [ ] Verify webhook signatures
- [ ] Keep OpenClaw updated
- [ ] Review channel permissions monthly

---

## Next Steps

1. Choose channels to implement
2. Follow per-channel setup guide above
3. Test with `openclaw channel test-connection`
4. Monitor health with `openclaw channel health`
5. Configure DM policy per requirements
6. Set up alerts for disconnections
