# OpenClaw Office - Implementation Reference

## Table of Contents

1. [Project Structure](#project-structure)
2. [Installation & Setup](#installation--setup)
3. [WebSocket Integration](#websocket-integration)
4. [Frontend Components](#frontend-components)
5. [State Management (Zustand)](#state-management-zustand)
6. [2D Isometric Visualization](#2d-isometric-visualization)
7. [3D React Three Fiber](#3d-react-three-fiber)
8. [Standup/Scrum Protocol](#standupscrum-protocol)
9. [Agent Avatar System](#agent-avatar-system)
10. [Console Management APIs](#console-management-apis)
11. [Performance Optimization](#performance-optimization)
12. [Security Considerations](#security-considerations)
13. [Deployment Guide](#deployment-guide)

---

## Project Structure

```
openclaw-office/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── page.tsx                # Main office view
│   ├── dashboard/
│   │   ├── page.tsx            # Dashboard metrics
│   │   ├── agents/
│   │   │   └── page.tsx        # Agents management
│   │   ├── channels/
│   │   │   └── page.tsx        # Channels management
│   │   ├── skills/
│   │   │   └── page.tsx        # Skills management
│   │   ├── cron-jobs/
│   │   │   └── page.tsx        # Scheduled tasks
│   │   └── settings/
│   │       └── page.tsx        # Configuration
│   └── api/
│       ├── agents/
│       ├── channels/
│       ├── skills/
│       ├── cron-jobs/
│       └── gateway/
├── components/
│   ├── office/
│   │   ├── IsometricOffice.tsx  # 2D isometric floor plan
│   │   ├── OfficeZone.tsx       # Individual zones
│   │   └── AgentAvatar.tsx      # Agent visualization
│   ├── visualization/
│   │   ├── Office3D.tsx         # React Three Fiber 3D
│   │   ├── CollaborationLine.tsx # Inter-agent lines
│   │   └── SpeechBubble.tsx     # Message bubbles
│   ├── sidepanel/
│   │   ├── AgentDetails.tsx     # Agent info panel
│   │   ├── TokenChart.tsx       # Token consumption chart
│   │   ├── CostChart.tsx        # Cost breakdown
│   │   ├── ActivityHeatmap.tsx  # Usage heatmap
│   │   └── SubAgentGraph.tsx    # Dependency graph
│   ├── standup/
│   │   ├── StandupBoard.tsx     # Standup UI
│   │   ├── SpeakingIndicator.tsx # Waveform/animation
│   │   └── TaskReport.tsx       # Individual report
│   ├── chat/
│   │   ├── ChatDock.tsx         # Bottom chat interface
│   │   ├── AgentSelector.tsx    # Agent dropdown
│   │   └── MessageHistory.tsx   # Chat history drawer
│   └── console/
│       ├── DashboardPage.tsx
│       ├── AgentsTable.tsx
│       ├── ChannelsTable.tsx
│       ├── SkillsTable.tsx
│       └── CronJobsTable.tsx
├── lib/
│   ├── websocket.ts             # WebSocket client
│   ├── store.ts                 # Zustand store
│   ├── office-layout.ts         # Zone definitions
│   ├── avatar-generator.ts      # Avatar generation
│   ├── theme.ts                 # Theme configuration
│   ├── api-client.ts            # API helper functions
│   └── utils.ts                 # Utility functions
├── types/
│   ├── agent.ts                 # Agent types
│   ├── message.ts               # Message types
│   ├── office.ts                # Office visualization types
│   ├── gateway.ts               # Gateway protocol types
│   └── console.ts               # Console API types
├── styles/
│   ├── globals.css              # Global styles
│   ├── office.module.css        # Office-specific styles
│   └── animations.css           # SVG/CSS animations
├── public/
│   ├── avatars/                 # Avatar SVG templates
│   └── icons/                   # UI icons
├── next.config.js               # Next.js configuration
├── tailwind.config.ts           # Tailwind configuration
├── tsconfig.json                # TypeScript configuration
└── package.json
```

---

## Installation & Setup

### Step 1: Initial Setup

```bash
# Global installation
npx @ww-ai-lab/openclaw-office

# Or clone for development
git clone https://github.com/WW-AI-Lab/openclaw-office.git
cd openclaw-office
npm install

# Create environment file
cp .env.example .env.local
```

### Step 2: Configure Gateway Connection

```bash
# .env.local
NEXT_PUBLIC_GATEWAY_URL=ws://localhost:8080
NEXT_PUBLIC_GATEWAY_TIMEOUT=30000
NEXT_PUBLIC_AUTO_CONNECT=true

# Remote gateway (optional)
NEXT_PUBLIC_GATEWAY_ENV=production
OPENCLAW_API_KEY=sk_live_xxxxxxxxxxxxx
```

### Step 3: Start Development Server

```bash
npm run dev
# Open http://localhost:3000
```

### Step 4: Verify Connection

```javascript
// lib/websocket.ts
export class GatewayClient {
  private ws: WebSocket | null = null;

  connect(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(url);

        this.ws.onopen = () => {
          console.log('✓ Connected to OpenClaw Gateway');
          resolve();
        };

        this.ws.onerror = (error) => {
          console.error('✗ Gateway connection failed:', error);
          reject(error);
        };

        this.ws.onmessage = (event) => {
          this.handleMessage(JSON.parse(event.data));
        };
      } catch (error) {
        reject(error);
      }
    });
  }
}
```

---

## WebSocket Integration

### Message Flow Architecture

```
Client App (OpenClaw Office)
     ↓ (WebSocket)
Gateway Router
     ├─→ Agent Dispatcher
     ├─→ Channel Manager
     ├─→ Tool Executor
     └─→ State Synchronizer
     ↓ (Broadcast updates back)
Client Updates (Agent Status, Messages, Tool Results)
```

### Client Implementation

```typescript
// lib/websocket.ts
import { create } from 'zustand';

type MessageHandler = (message: GatewayMessage) => void;

export class GatewayClient {
  private ws: WebSocket | null = null;
  private messageHandlers: Map<string, MessageHandler[]> = new Map();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 3000;

  async connect(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(url);

        this.ws.onopen = () => {
          this.reconnectAttempts = 0;
          this.emit('connected');
          resolve();
        };

        this.ws.onmessage = (event) => {
          const message = JSON.parse(event.data);
          this.handleMessage(message);
        };

        this.ws.onerror = (error) => {
          this.emit('error', error);
          reject(error);
        };

        this.ws.onclose = () => {
          this.emit('disconnected');
          this.attemptReconnect(url);
        };
      } catch (error) {
        reject(error);
      }
    });
  }

  private attemptReconnect(url: string): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => this.connect(url), this.reconnectDelay);
    }
  }

  private handleMessage(message: GatewayMessage): void {
    const handlers = this.messageHandlers.get(message.type) || [];
    handlers.forEach(handler => handler(message));
  }

  on(type: string, handler: MessageHandler): void {
    if (!this.messageHandlers.has(type)) {
      this.messageHandlers.set(type, []);
    }
    this.messageHandlers.get(type)!.push(handler);
  }

  send(message: GatewayMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  private emit(event: string, ...args: unknown[]): void {
    this.handleMessage({ type: event, data: args } as any);
  }
}

export const gatewayClient = new GatewayClient();
```

### Message Types & Handlers

```typescript
// types/gateway.ts
export interface GatewayMessage {
  type: 'agent_status' | 'agent_message' | 'tool_call' | 'session_update';
  agentId?: string;
  sessionId?: string;
  data: unknown;
  timestamp: string;
}

export interface AgentStatusMessage extends GatewayMessage {
  type: 'agent_status';
  agentId: string;
  status: 'idle' | 'working' | 'speaking' | 'tool_calling' | 'error';
  zone: 'desk' | 'meeting_room' | 'lounge' | 'server_room';
  currentTask: string;
  inputTokens: number;
  outputTokens: number;
}

export interface AgentMessageMessage extends GatewayMessage {
  type: 'agent_message';
  agentId: string;
  content: string; // Markdown
  messageType: 'streaming' | 'complete';
  metadata: {
    duration: number;
    toolCalls: number;
  };
}

export interface ToolCallMessage extends GatewayMessage {
  type: 'tool_call';
  agentId: string;
  toolName: string;
  status: 'pending' | 'executing' | 'complete' | 'error';
  input: Record<string, unknown>;
  result: unknown;
  duration: number;
}

export interface SessionUpdateMessage extends GatewayMessage {
  type: 'session_update';
  sessionId: string;
  totalTokens: number;
  totalCost: number;
  agentCount: number;
  activeAgents: number;
  uptime: number;
}
```

### Event Handlers Setup

```typescript
// lib/gateway-handlers.ts
import { gatewayClient } from './websocket';
import { useStore } from './store';

export function setupGatewayHandlers(): void {
  // Agent Status Updates
  gatewayClient.on('agent_status', (message: AgentStatusMessage) => {
    const store = useStore();
    store.updateAgentStatus(message.agentId, {
      status: message.status,
      zone: message.zone,
      currentTask: message.currentTask,
      inputTokens: message.inputTokens,
      outputTokens: message.outputTokens,
      lastUpdate: new Date(message.timestamp)
    });
  });

  // Agent Messages (with streaming support)
  gatewayClient.on('agent_message', (message: AgentMessageMessage) => {
    const store = useStore();

    if (message.messageType === 'streaming') {
      store.appendAgentMessage(message.agentId, message.content);
    } else {
      store.completeAgentMessage(message.agentId, message.content);
    }

    // Track message metadata
    store.addMessageMetadata({
      agentId: message.agentId,
      duration: message.metadata.duration,
      toolCalls: message.metadata.toolCalls
    });
  });

  // Tool Call Events
  gatewayClient.on('tool_call', (message: ToolCallMessage) => {
    const store = useStore();
    store.updateToolCall(message.agentId, {
      name: message.toolName,
      status: message.status,
      input: message.input,
      result: message.result,
      duration: message.duration
    });
  });

  // Session Updates
  gatewayClient.on('session_update', (message: SessionUpdateMessage) => {
    const store = useStore();
    store.updateSessionStats({
      totalTokens: message.totalTokens,
      totalCost: message.totalCost,
      agentCount: message.agentCount,
      activeAgents: message.activeAgents,
      uptime: message.uptime
    });
  });

  // Connection Status
  gatewayClient.on('connected', () => {
    const store = useStore();
    store.setGatewayConnected(true);
    console.log('📡 Gateway connected');
  });

  gatewayClient.on('disconnected', () => {
    const store = useStore();
    store.setGatewayConnected(false);
    console.log('📡 Gateway disconnected - attempting reconnect...');
  });

  gatewayClient.on('error', (error) => {
    const store = useStore();
    store.addError({
      type: 'gateway_error',
      message: error.message,
      timestamp: new Date()
    });
  });
}
```

---

## Frontend Components

### IsometricOffice Component

```typescript
// components/office/IsometricOffice.tsx
'use client';

import React, { useEffect, useRef } from 'react';
import { useStore } from '@/lib/store';
import OfficeZone from './OfficeZone';
import AgentAvatar from './AgentAvatar';
import CollaborationLine from '@/components/visualization/CollaborationLine';

export default function IsometricOffice() {
  const agents = useStore(state => state.agents);
  const zones = useStore(state => state.officeLayout);
  const svgRef = useRef<SVGSVGElement>(null);

  // Calculate isometric projection
  const toIsometric = (x: number, y: number) => {
    const isX = x - y;
    const isY = (x + y) / 2;
    return { isX, isY };
  };

  return (
    <svg
      ref={svgRef}
      width="1200"
      height="700"
      viewBox="0 0 1200 700"
      className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-gray-200 rounded-lg"
    >
      {/* Background grid */}
      <defs>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="1200" height="700" fill="url(#grid)" opacity="0.3" />

      {/* Office zones */}
      {Object.entries(zones).map(([zoneId, zone]) => (
        <OfficeZone key={zoneId} zone={zone} zoneId={zoneId} />
      ))}

      {/* Collaboration lines between agents */}
      {agents.map((agent, idx) => {
        const collaboratingWith = agents
          .slice(idx + 1)
          .filter(other =>
            agent.collaborationHistory?.includes(other.id)
          );

        return collaboratingWith.map(other => (
          <CollaborationLine
            key={`${agent.id}-${other.id}`}
            from={agent.position}
            to={other.position}
            active={agent.status === 'speaking' || other.status === 'speaking'}
          />
        ));
      })}

      {/* Agent avatars */}
      {agents.map(agent => (
        <AgentAvatar
          key={agent.id}
          agent={agent}
          position={toIsometric(agent.position.x, agent.position.y)}
        />
      ))}

      {/* Overlay info */}
      <text x="10" y="25" className="text-xs font-semibold" fill="#1f2937">
        OpenClaw Office - Agent Monitor
      </text>
    </svg>
  );
}
```

### AgentAvatar Component

```typescript
// components/office/AgentAvatar.tsx
import React from 'react';
import { Agent } from '@/types/agent';
import { generateAgentColor } from '@/lib/avatar-generator';

interface AgentAvatarProps {
  agent: Agent;
  position: { isX: number; isY: number };
}

export default function AgentAvatar({ agent, position }: AgentAvatarProps) {
  const color = generateAgentColor(agent.id);
  const statusColor = {
    idle: '#6B7280',
    working: '#F59E0B',
    speaking: '#10B981',
    tool_calling: '#3B82F6',
    error: '#EF4444'
  }[agent.status];

  const statusAnimation = {
    idle: 'animate-pulse',
    working: 'animate-bounce',
    speaking: 'animate-wiggle',
    tool_calling: 'animate-spin',
    error: 'animate-shake'
  }[agent.status];

  return (
    <g
      className="agent-avatar cursor-pointer hover:opacity-80 transition"
      transform={`translate(${position.isX}, ${position.isY})`}
    >
      {/* Glow effect */}
      <circle
        cx="0"
        cy="0"
        r="25"
        fill={statusColor}
        opacity="0.1"
        className={statusAnimation}
      />

      {/* Avatar circle */}
      <circle
        cx="0"
        cy="0"
        r="20"
        fill={color.primary}
        stroke={statusColor}
        strokeWidth="2"
      />

      {/* Agent icon */}
      <text
        x="0"
        y="0"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="16"
        fill="white"
        fontWeight="bold"
      >
        {agent.icon || '🤖'}
      </text>

      {/* Status indicator dot */}
      <circle
        cx="16"
        cy="-16"
        r="4"
        fill={statusColor}
        stroke="white"
        strokeWidth="1"
      />

      {/* Agent name label */}
      <text
        x="0"
        y="35"
        textAnchor="middle"
        fontSize="12"
        fill="#1f2937"
        fontWeight="500"
      >
        {agent.name.slice(0, 8)}
      </text>
    </g>
  );
}
```

### SpeechBubble Component

```typescript
// components/visualization/SpeechBubble.tsx
import React from 'react';
import ReactMarkdown from 'react-markdown';

interface SpeechBubbleProps {
  agentId: string;
  content: string;
  toolCalls: Array<{ name: string; status: string; result?: unknown }>;
  streaming?: boolean;
  position: { x: number; y: number };
}

export default function SpeechBubble({
  agentId,
  content,
  toolCalls,
  streaming = false,
  position
}: SpeechBubbleProps) {
  return (
    <div
      className="speech-bubble absolute bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-xs"
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      {/* Markdown content */}
      <div className="prose prose-sm max-w-none text-gray-800 mb-3">
        <ReactMarkdown>{content}</ReactMarkdown>
        {streaming && <span className="animate-pulse">▌</span>}
      </div>

      {/* Tool calls display */}
      {toolCalls.length > 0 && (
        <div className="border-t pt-2">
          <div className="text-xs font-semibold text-gray-600 mb-2">Tools:</div>
          {toolCalls.map((call, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 text-xs text-gray-700 mb-1"
            >
              <span className={`w-3 h-3 rounded-full ${
                call.status === 'complete' ? 'bg-green-500' :
                call.status === 'executing' ? 'bg-yellow-500 animate-pulse' :
                call.status === 'error' ? 'bg-red-500' :
                'bg-gray-300'
              }`} />
              <span className="font-mono">{call.name}</span>
              {call.result && (
                <span className="text-gray-500">✓</span>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Pointer */}
      <div className="absolute -bottom-2 left-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white" />
    </div>
  );
}
```

---

## State Management (Zustand)

### Main Store Definition

```typescript
// lib/store.ts
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { Agent, AgentStatus } from '@/types/agent';
import { OfficeZone } from '@/types/office';

export interface AppState {
  // Gateway & Connection
  gatewayConnected: boolean;
  gatewayUrl: string;
  sessionId: string | null;

  // Agents
  agents: Agent[];
  selectedAgentId: string | null;
  updateAgentStatus: (agentId: string, status: Partial<AgentStatus>) => void;
  updateAgentMessage: (agentId: string, message: string) => void;
  addAgent: (agent: Agent) => void;
  removeAgent: (agentId: string) => void;
  setSelectedAgent: (agentId: string) => void;

  // Office Layout
  officeLayout: Record<string, OfficeZone>;
  updateOfficeLayout: (zones: Record<string, OfficeZone>) => void;

  // Messages & History
  agentMessages: Record<string, string[]>;
  appendAgentMessage: (agentId: string, content: string) => void;
  clearAgentMessages: (agentId: string) => void;

  // Tool Calls
  toolCalls: Array<{ agentId: string; toolName: string; status: string }>;
  updateToolCall: (agentId: string, toolInfo: any) => void;

  // Session Stats
  sessionStats: {
    totalTokens: number;
    totalCost: number;
    agentCount: number;
    activeAgents: number;
    uptime: number;
  };
  updateSessionStats: (stats: Partial<typeof sessionStats>) => void;

  // UI State
  sidePanel: {
    open: boolean;
    activeTab: 'details' | 'tokens' | 'cost' | 'heatmap' | 'graph';
  };
  toggleSidePanel: () => void;
  setSidePanelTab: (tab: any) => void;

  chatDock: {
    open: boolean;
    selectedAgent: string | null;
  };
  toggleChatDock: () => void;
  setChatDockAgent: (agentId: string) => void;

  // Standup State
  standupActive: boolean;
  currentSpeaker: string | null;
  startStandup: () => void;
  endStandup: () => void;
  rotateSpeaker: (nextAgentId: string) => void;

  // Errors
  errors: Array<{ type: string; message: string; timestamp: Date }>;
  addError: (error: any) => void;
  clearErrors: () => void;

  // Connection
  setGatewayConnected: (connected: boolean) => void;
  setSessionId: (sessionId: string) => void;
}

export const useStore = create<AppState>()(
  devtools(
    persist(
      (set, get) => ({
        gatewayConnected: false,
        gatewayUrl: process.env.NEXT_PUBLIC_GATEWAY_URL || 'ws://localhost:8080',
        sessionId: null,

        agents: [],
        selectedAgentId: null,

        officeLayout: {},

        agentMessages: {},
        toolCalls: [],

        sessionStats: {
          totalTokens: 0,
          totalCost: 0,
          agentCount: 0,
          activeAgents: 0,
          uptime: 0
        },

        sidePanel: {
          open: true,
          activeTab: 'details'
        },

        chatDock: {
          open: false,
          selectedAgent: null
        },

        standupActive: false,
        currentSpeaker: null,

        errors: [],

        // Implementations
        updateAgentStatus: (agentId, status) =>
          set(state => ({
            agents: state.agents.map(agent =>
              agent.id === agentId
                ? { ...agent, ...status, lastUpdate: new Date() }
                : agent
            )
          })),

        addAgent: (agent) =>
          set(state => ({
            agents: [...state.agents, agent],
            agentMessages: { ...state.agentMessages, [agent.id]: [] }
          })),

        removeAgent: (agentId) =>
          set(state => ({
            agents: state.agents.filter(a => a.id !== agentId),
            agentMessages: {
              ...state.agentMessages,
              [agentId]: undefined
            }
          })),

        setSelectedAgent: (agentId) =>
          set({ selectedAgentId: agentId }),

        appendAgentMessage: (agentId, content) =>
          set(state => ({
            agentMessages: {
              ...state.agentMessages,
              [agentId]: [...(state.agentMessages[agentId] || []), content]
            }
          })),

        clearAgentMessages: (agentId) =>
          set(state => ({
            agentMessages: {
              ...state.agentMessages,
              [agentId]: []
            }
          })),

        updateSessionStats: (stats) =>
          set(state => ({
            sessionStats: { ...state.sessionStats, ...stats }
          })),

        toggleSidePanel: () =>
          set(state => ({
            sidePanel: { ...state.sidePanel, open: !state.sidePanel.open }
          })),

        setSidePanelTab: (tab) =>
          set(state => ({
            sidePanel: { ...state.sidePanel, activeTab: tab }
          })),

        toggleChatDock: () =>
          set(state => ({
            chatDock: { ...state.chatDock, open: !state.chatDock.open }
          })),

        setChatDockAgent: (agentId) =>
          set(state => ({
            chatDock: { ...state.chatDock, selectedAgent: agentId }
          })),

        startStandup: () =>
          set(state => ({
            standupActive: true,
            currentSpeaker: state.agents[0]?.id || null
          })),

        endStandup: () =>
          set({
            standupActive: false,
            currentSpeaker: null
          }),

        rotateSpeaker: (nextAgentId) =>
          set({ currentSpeaker: nextAgentId }),

        addError: (error) =>
          set(state => ({
            errors: [...state.errors, { ...error, timestamp: new Date() }].slice(-20)
          })),

        clearErrors: () =>
          set({ errors: [] }),

        setGatewayConnected: (connected) =>
          set({ gatewayConnected: connected }),

        setSessionId: (sessionId) =>
          set({ sessionId }),

        updateOfficeLayout: (zones) =>
          set({ officeLayout: zones }),

        updateToolCall: (agentId, toolInfo) =>
          set(state => ({
            toolCalls: [
              ...state.toolCalls.filter(
                tc => !(tc.agentId === agentId && tc.toolName === toolInfo.name)
              ),
              { agentId, toolName: toolInfo.name, status: toolInfo.status }
            ]
          }))
      }),
      {
        name: 'openclaw-office-store'
      }
    )
  )
);
```

---

## 2D Isometric Visualization

### Isometric Math & Projection

```typescript
// lib/isometric.ts
export class IsometricProjection {
  static project(x: number, y: number, z: number = 0): { screenX: number; screenY: number } {
    // Standard isometric projection
    const screenX = (x - y) * Math.cos(Math.PI / 6);
    const screenY = (x + y) * Math.sin(Math.PI / 6) - z;

    return {
      screenX: screenX * 1.2, // Scale factor
      screenY: screenY * 1.2
    };
  }

  static unproject(screenX: number, screenY: number): { x: number; y: number } {
    // Reverse projection
    const scale = 1.2;
    const x = screenX / scale / Math.cos(Math.PI / 6);
    const y = screenY / scale / Math.sin(Math.PI / 6);

    return {
      x: (x + y) / 2,
      y: (y - x) / 2
    };
  }

  // Draw isometric cube (for zone representation)
  static drawCube(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    size: number,
    color: string
  ): void {
    const w = size / 2;
    const h = size / 4;

    const [x1, y1] = [x, y - h];
    const [x2, y2] = [x + w, y];
    const [x3, y3] = [x, y + h];
    const [x4, y4] = [x - w, y];

    // Draw top
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x4, y4);
    ctx.fill();

    // Draw sides
    ctx.fillStyle = adjustBrightness(color, -20);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x3, y3 + h);
    ctx.lineTo(x2, y2 + h);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x4, y4);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x3, y3 + h);
    ctx.lineTo(x4, y4 + h);
    ctx.fill();
  }
}

function adjustBrightness(color: string, percent: number): string {
  // Adjust color brightness
  const hex = color.replace('#', '');
  const num = parseInt(hex, 16);
  const amt = Math.round(2.55 * percent);
  const R = Math.max(0, Math.min(255, (num >> 16) + amt));
  const G = Math.max(0, Math.min(255, (num >> 8 & 0x00FF) + amt));
  const B = Math.max(0, Math.min(255, (num & 0x0000FF) + amt));
  return '#' + [R, G, B].map(x => x.toString(16).padStart(2, '0')).join('');
}
```

### Animation Keyframes

```css
/* styles/animations.css */

@keyframes agent-working {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
}

@keyframes agent-speaking {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-5px);
  }
}

@keyframes agent-tool-calling {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes agent-error {
  0%, 100% {
    transform: translateX(0);
  }
  25% {
    transform: translateX(-5px);
  }
  75% {
    transform: translateX(5px);
  }
}

@keyframes collaboration-line-pulse {
  0%, 100% {
    opacity: 0.5;
    stroke-width: 2;
  }
  50% {
    opacity: 1;
    stroke-width: 3;
  }
}

.agent-working {
  animation: agent-working 1s ease-in-out infinite;
}

.agent-speaking {
  animation: agent-speaking 0.6s ease-in-out infinite;
}

.agent-tool-calling {
  animation: agent-tool-calling 1s linear infinite;
}

.agent-error {
  animation: agent-error 0.5s ease-in-out infinite;
}

.collaboration-line-active {
  animation: collaboration-line-pulse 1.5s ease-in-out infinite;
}
```

---

## 3D React Three Fiber

### Basic 3D Office Setup

```typescript
// components/visualization/Office3D.tsx
'use client';

import React, { useEffect, useRef } from 'react';
import { Canvas, useFrame, ThreeElements } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';
import { useStore } from '@/lib/store';

function Office3DContent() {
  const agents = useStore(state => state.agents);
  const floorRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    // Smooth camera animation
    state.camera.position.lerp(
      new THREE.Vector3(10, 8, 10),
      0.05
    );
  });

  return (
    <>
      <PerspectiveCamera
        makeDefault
        position={[10, 8, 10]}
        fov={50}
      />
      <OrbitControls
        autoRotate
        autoRotateSpeed={2}
        enableDamping
        dampingFactor={0.05}
      />

      {/* Lighting */}
      <ambientLight intensity={0.6} />
      <directionalLight
        position={[10, 20, 10]}
        intensity={0.8}
        castShadow
      />
      <hemisphereLight
        skyColor="#87CEEB"
        groundColor="#D2B48C"
        intensity={0.4}
      />

      {/* Ground plane */}
      <mesh
        ref={floorRef}
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
      >
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#f0f0f0" />
      </mesh>

      {/* Grid helper */}
      <gridHelper args={[20, 20]} position={[0, 0.01, 0]} />

      {/* Render agents as 3D spheres */}
      {agents.map(agent => (
        <Agent3D key={agent.id} agent={agent} />
      ))}

      {/* Office zones as boxes */}
      <OfficeZone3D />
    </>
  );
}

function Agent3D({ agent }: { agent: any }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const groupRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (groupRef.current) {
      // Floating animation based on status
      groupRef.current.position.y += Math.sin(Date.now() * 0.002) * 0.01;
    }
  });

  const statusColor = {
    idle: '#888888',
    working: '#FFA500',
    speaking: '#00AA00',
    tool_calling: '#0066FF',
    error: '#FF0000'
  }[agent.status];

  return (
    <group
      ref={groupRef}
      position={[agent.position.x * 0.1, 1, agent.position.y * 0.1]}
    >
      <mesh ref={meshRef} castShadow receiveShadow>
        <sphereGeometry args={[0.3, 32, 32]} />
        <meshStandardMaterial color={statusColor} emissive={statusColor} emissiveIntensity={0.3} />
      </mesh>

      {/* Agent label */}
      <TextLabel text={agent.name} />
    </group>
  );
}

function OfficeZone3D() {
  return (
    <>
      {/* Desk area */}
      <mesh position={[0, 0.5, 0]} receiveShadow>
        <boxGeometry args={[8, 1, 4]} />
        <meshStandardMaterial color="#D2B48C" />
      </mesh>

      {/* Meeting room */}
      <mesh position={[8, 1, 0]} receiveShadow>
        <boxGeometry args={[4, 2, 4]} />
        <meshStandardMaterial color="#87CEEB" />
      </mesh>

      {/* Lounge */}
      <mesh position={[-8, 0.8, 0]} receiveShadow>
        <boxGeometry args={[3, 1.6, 3]} />
        <meshStandardMaterial color="#FFB6C1" />
      </mesh>
    </>
  );
}

function TextLabel({ text }: { text: string }) {
  // Text rendering would use THREE.TextGeometry or canvas texture
  return null;
}

export default function Office3D() {
  return (
    <Canvas
      style={{ width: '100%', height: '100%' }}
      shadows
      gl={{ antialias: true }}
    >
      <Office3DContent />
    </Canvas>
  );
}
```

---

## Standup/Scrum Protocol

### Protocol State Machine

```typescript
// lib/standup-protocol.ts
import { useStore } from './store';

type StandupPhase = 'gathering' | 'in_progress' | 'complete';

export interface StandupState {
  phase: StandupPhase;
  participants: string[];
  currentSpeaker: string | null;
  timePerAgent: number; // seconds
  startTime: Date;
  speakerOrder: string[];
  tasksReported: Record<string, string>;
  blockers: string[];
}

export class StandupProtocol {
  private state: StandupState;
  private timers: Map<string, NodeJS.Timeout> = new Map();

  constructor(participants: string[]) {
    this.state = {
      phase: 'gathering',
      participants,
      currentSpeaker: null,
      timePerAgent: 60,
      startTime: new Date(),
      speakerOrder: participants,
      tasksReported: {},
      blockers: []
    };
  }

  startGathering(): void {
    this.state.phase = 'gathering';

    // Move all agents to meeting room
    const store = useStore();
    this.state.participants.forEach(agentId => {
      store.updateAgentStatus(agentId, {
        zone: 'meeting_room',
        status: 'idle'
      });
    });

    // Transition to in_progress after 5 seconds
    const timer = setTimeout(() => {
      this.startSpeaking();
    }, 5000);

    this.timers.set('gathering', timer);
  }

  private startSpeaking(): void {
    this.state.phase = 'in_progress';
    const store = useStore();
    const firstSpeaker = this.state.speakerOrder[0];

    store.updateAgentStatus(firstSpeaker, { status: 'speaking' });
    this.state.currentSpeaker = firstSpeaker;

    this.scheduleNextSpeaker();
  }

  private scheduleNextSpeaker(): void {
    const currentIndex = this.state.speakerOrder.indexOf(
      this.state.currentSpeaker!
    );

    if (currentIndex < this.state.speakerOrder.length - 1) {
      const timer = setTimeout(() => {
        this.rotateSpeaker();
      }, this.state.timePerAgent * 1000);

      this.timers.set('speaker-rotation', timer);
    } else {
      // All speakers done
      const timer = setTimeout(() => {
        this.complete();
      }, this.state.timePerAgent * 1000);

      this.timers.set('standup-complete', timer);
    }
  }

  private rotateSpeaker(): void {
    const store = useStore();
    const currentIndex = this.state.speakerOrder.indexOf(
      this.state.currentSpeaker!
    );

    // Mark current as idle
    store.updateAgentStatus(this.state.currentSpeaker!, {
      status: 'idle'
    });

    // Move to next
    const nextSpeaker = this.state.speakerOrder[currentIndex + 1];
    store.updateAgentStatus(nextSpeaker, { status: 'speaking' });
    this.state.currentSpeaker = nextSpeaker;

    this.scheduleNextSpeaker();
  }

  private complete(): void {
    this.state.phase = 'complete';
    const store = useStore();

    // Mark all as idle
    this.state.participants.forEach(agentId => {
      store.updateAgentStatus(agentId, {
        status: 'idle',
        zone: 'desk'
      });
    });

    store.endStandup();
  }

  addTaskReport(agentId: string, task: string): void {
    this.state.tasksReported[agentId] = task;
  }

  addBlocker(blocker: string): void {
    this.state.blockers.push(blocker);
  }

  getState(): StandupState {
    return this.state;
  }

  cleanup(): void {
    this.timers.forEach(timer => clearTimeout(timer));
    this.timers.clear();
  }
}
```

### Standup Board UI Component

```typescript
// components/standup/StandupBoard.tsx
'use client';

import React, { useEffect, useState } from 'react';
import { useStore } from '@/lib/store';
import { StandupProtocol } from '@/lib/standup-protocol';

export default function StandupBoard() {
  const agents = useStore(state => state.agents);
  const standupActive = useStore(state => state.standupActive);
  const currentSpeaker = useStore(state => state.currentSpeaker);
  const [protocol, setProtocol] = useState<StandupProtocol | null>(null);
  const [standupState, setStandupState] = useState<any>(null);

  const startStandup = () => {
    const agentIds = agents.map(a => a.id);
    const proto = new StandupProtocol(agentIds);
    proto.startGathering();
    setProtocol(proto);
    setStandupState(proto.getState());

    const interval = setInterval(() => {
      setStandupState(proto.getState());
    }, 1000);

    return () => clearInterval(interval);
  };

  if (!standupActive) {
    return (
      <div className="flex items-center justify-center p-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
        <button
          onClick={startStandup}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
        >
          🎯 Start Daily Standup
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-6 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold text-gray-800">Daily Standup</h2>
      <div className="text-sm text-gray-600">
        Phase: <span className="font-semibold">{standupState?.phase || 'gathering'}</span>
      </div>

      <div className="space-y-2">
        {agents.map(agent => (
          <div
            key={agent.id}
            className={`p-4 rounded-lg border-2 transition ${
              currentSpeaker === agent.id
                ? 'border-green-500 bg-green-50'
                : 'border-gray-200 bg-gray-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-4 h-4 rounded-full ${
                currentSpeaker === agent.id ? 'bg-green-500 animate-pulse' : 'bg-gray-400'
              }`} />
              <span className="font-semibold text-gray-800">{agent.name}</span>
              {currentSpeaker === agent.id && (
                <span className="text-sm bg-green-500 text-white px-2 py-1 rounded">
                  Speaking Now
                </span>
              )}
            </div>

            {/* Task report */}
            <div className="mt-2 pl-7 text-sm text-gray-700">
              {standupState?.tasksReported[agent.id] && (
                <p>✓ {standupState.tasksReported[agent.id]}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
```

---

## Agent Avatar System

### Deterministic Avatar Generation

```typescript
// lib/avatar-generator.ts
export interface AvatarConfig {
  agentId: string;
  seed?: number;
  size?: 'small' | 'medium' | 'large';
  style?: 'minimal' | 'detailed';
}

export interface GeneratedAvatar {
  svg: string;
  color: { primary: string; secondary: string };
  icon: string;
  seed: number;
}

export function generateAgentAvatar(config: AvatarConfig): GeneratedAvatar {
  const seed = config.seed ?? hashString(config.agentId);
  const rng = seededRandom(seed);

  // Generate deterministic colors
  const hue = rng() * 360;
  const saturation = 65 + rng() * 20;
  const lightness = 45 + rng() * 20;
  const primaryColor = `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  const secondaryColor = `hsl(${(hue + 180) % 360}, ${saturation}%, ${(lightness + 15) % 100}%)`;

  // Generate avatar SVG
  const size = config.size === 'large' ? 200 : config.size === 'small' ? 80 : 120;
  const svg = generateAvatarSVG({
    primaryColor,
    secondaryColor,
    size,
    style: config.style || 'minimal',
    rng
  });

  return {
    svg,
    color: { primary: primaryColor, secondary: secondaryColor },
    icon: selectIcon(seed),
    seed
  };
}

function generateAvatarSVG(options: {
  primaryColor: string;
  secondaryColor: string;
  size: number;
  style: 'minimal' | 'detailed';
  rng: () => number;
}): string {
  const { primaryColor, secondaryColor, size, style, rng } = options;
  const center = size / 2;

  if (style === 'minimal') {
    return `
      <svg viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
        <circle cx="${center}" cy="${center}" r="${center - 5}" fill="${primaryColor}" />
        <circle cx="${center - 20}" cy="${center - 15}" r="10" fill="${secondaryColor}" />
        <circle cx="${center + 20}" cy="${center - 15}" r="10" fill="${secondaryColor}" />
        <path d="M ${center - 15} ${center + 20} Q ${center} ${center + 35} ${center + 15} ${center + 20}"
              stroke="${secondaryColor}" stroke-width="3" fill="none" />
      </svg>
    `;
  }

  // Detailed style with more features
  const shapes = generateRandomShapes(rng, size);
  return `
    <svg viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
      ${shapes.map(shape => `
        <${shape.type}
          ${Object.entries(shape.attrs).map(([k, v]) => `${k}="${v}"`).join(' ')}
          fill="${shape.fill || primaryColor}"
        />
      `).join('')}
    </svg>
  `;
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

function seededRandom(seed: number) {
  return function() {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
}

function selectIcon(seed: number): string {
  const icons = ['🤖', '🧠', '⚙️', '🔧', '💼', '📊', '🎯', '🚀'];
  return icons[seed % icons.length];
}

function generateRandomShapes(rng: () => number, size: number): any[] {
  const count = 3 + Math.floor(rng() * 4);
  const shapes = [];

  for (let i = 0; i < count; i++) {
    shapes.push({
      type: 'circle',
      attrs: {
        cx: size * (0.2 + rng() * 0.6),
        cy: size * (0.2 + rng() * 0.6),
        r: size * (0.05 + rng() * 0.15)
      }
    });
  }

  return shapes;
}

export function generateAgentColor(agentId: string): { primary: string; secondary: string } {
  const avatar = generateAgentAvatar({ agentId });
  return avatar.color;
}
```

---

## Console Management APIs

### API Routes Implementation

```typescript
// app/api/agents/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { gatewayClient } from '@/lib/websocket';

export async function GET(req: NextRequest) {
  try {
    // Fetch agents from gateway
    const message = {
      type: 'api_request',
      action: 'list_agents',
      timestamp: new Date().toISOString()
    };

    gatewayClient.send(message);

    // Wait for response (in production, use proper async handling)
    return NextResponse.json({
      agents: [
        {
          id: 'agent-001',
          name: 'DataProcessor',
          status: 'active',
          capabilities: ['database', 'file_io'],
          lastActive: new Date().toISOString(),
          performance: { successRate: 99.2, avgResponseTime: 245 }
        }
      ]
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch agents' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const message = {
      type: 'api_request',
      action: 'create_agent',
      payload: body,
      timestamp: new Date().toISOString()
    };

    gatewayClient.send(message);

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create agent' },
      { status: 500 }
    );
  }
}
```

```typescript
// app/api/agents/[id]/route.ts
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await req.json();

    const message = {
      type: 'api_request',
      action: 'update_agent',
      agentId: params.id,
      payload: body,
      timestamp: new Date().toISOString()
    };

    gatewayClient.send(message);

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update agent' },
      { status: 500 }
    );
  }
}
```

---

## Performance Optimization

### Memoization & Code Splitting

```typescript
// components/office/IsometricOffice.tsx
import dynamic from 'next/dynamic';
import { memo } from 'react';

const AgentAvatar = dynamic(() => import('./AgentAvatar'), {
  loading: () => <div className="bg-gray-200 rounded" />,
  ssr: false
});

const CollaborationLine = memo(({ from, to, active }) => {
  return (
    <line
      x1={from.x}
      y1={from.y}
      x2={to.x}
      y2={to.y}
      className={active ? 'collaboration-line-active' : ''}
      stroke={active ? '#10B981' : '#D1D5DB'}
      strokeWidth={2}
    />
  );
});

// Optimize re-renders with useMemo
import { useMemo } from 'react';

export default function IsometricOffice() {
  const agents = useStore(state => state.agents);

  const collaboration = useMemo(() => {
    return agents.flatMap((agent, idx) =>
      agents.slice(idx + 1).map(other => ({
        from: agent.position,
        to: other.position,
        active: agent.status === 'speaking'
      }))
    );
  }, [agents]);

  return (
    <svg>
      {collaboration.map((line, idx) => (
        <CollaborationLine key={idx} {...line} />
      ))}
    </svg>
  );
}
```

### Virtual Scrolling for Large Agent Lists

```typescript
// components/console/AgentsTable.tsx
import { FixedSizeList } from 'react-window';

export function AgentsTable({ agents }: { agents: Agent[] }) {
  const Row = ({ index, style }) => (
    <div style={style} className="flex items-center gap-4 p-2 border-b">
      <span>{agents[index].id}</span>
      <span>{agents[index].status}</span>
      <span>{agents[index].lastActive}</span>
    </div>
  );

  return (
    <FixedSizeList
      height={600}
      itemCount={agents.length}
      itemSize={50}
      width="100%"
    >
      {Row}
    </FixedSizeList>
  );
}
```

---

## Security Considerations

### Environment Variables & Secrets

```bash
# .env.local (NEVER commit!)
# WebSocket Configuration
NEXT_PUBLIC_GATEWAY_URL=wss://gateway.example.com:443
NEXT_PUBLIC_GATEWAY_TIMEOUT=30000

# API Keys (server-side only)
OPENCLAW_API_KEY=sk_live_xxxxxxxxxxxxx
OPENCLAW_SECRET_KEY=sk_secret_xxxxxxxxxxxxx

# Authentication
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=http://localhost:3000

# Third-party APIs
GITHUB_API_TOKEN=ghp_xxxxxxxxxxxxx
JIRA_API_TOKEN=xxxxxxxxxxxxx
```

### WebSocket Security

```typescript
// lib/websocket.ts
export class SecureGatewayClient extends GatewayClient {
  private authToken: string | null = null;

  async authenticate(token: string): Promise<void> {
    this.authToken = token;

    const message = {
      type: 'auth_request',
      token: token,
      timestamp: new Date().toISOString()
    };

    this.send(message);
  }

  protected send(message: GatewayMessage): void {
    if (!this.authToken) {
      throw new Error('Not authenticated');
    }

    const signed = {
      ...message,
      auth: this.authToken,
      nonce: generateNonce()
    };

    super.send(signed);
  }
}

function generateNonce(): string {
  return Math.random().toString(36).substr(2, 9);
}
```

---

## Deployment Guide

### Docker Deployment

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application
COPY . .

# Build Next.js
RUN npm run build

# Expose port
EXPOSE 3000

# Start server
CMD ["npm", "start"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  openclaw-office:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NEXT_PUBLIC_GATEWAY_URL=ws://gateway:8080
      - NODE_ENV=production
    depends_on:
      - gateway

  gateway:
    image: ww-ai-lab/openclaw-gateway:latest
    ports:
      - "8080:8080"
    environment:
      - LOG_LEVEL=info
```

### Vercel Deployment

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel deploy

# Set environment variables
vercel env add NEXT_PUBLIC_GATEWAY_URL
vercel env add OPENCLAW_API_KEY
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| WebSocket timeout | Increase `NEXT_PUBLIC_GATEWAY_TIMEOUT` |
| Agents not visible | Check gateway connection in console |
| High memory usage | Enable virtual scrolling for large lists |
| Avatar generation slow | Pre-generate avatars on server |
| Real-time lag | Reduce animation frame rate or use `requestIdleCallback` |

---

*Last Updated: March 2026 | OpenClaw Office Implementation v1.0.0*
