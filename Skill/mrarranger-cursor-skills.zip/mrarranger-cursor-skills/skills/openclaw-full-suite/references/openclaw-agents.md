---
name: openclaw-agents
description: |
  OpenClaw Agents - ระบบ Agent Identity, Personality, Memory และ Multi-Agent Routing ครบวงจร
  SOUL.md, AGENTS.md, USER.md, MEMORY.md, IDENTITY.md, TOOLS.md
  Multi-Agent Workspace, Routing, Delegation, Personality Design
  ใช้เมื่อ: (1) สร้าง Agent Personality (2) ตั้งค่า SOUL.md (3) Multi-Agent routing
  (4) Agent Memory management (5) Agent Templates (6) Inter-Agent communication
commands:
  - /soul
  - /agent
  - /persona
  - /memory
  - /routing
  - /template
version: 2.0
lastUpdated: 2026-03-15
---

# OpenClaw Agents Skill Guide

**OpenClaw Agents** ระบบจัดการ Agent Identity และ Multi-Agent System ที่ครบวงจร ให้ control เต็มที่ต่อ personality, memory, tools, และ inter-agent communication.

## Quick Start

### 1. Create Your First Agent

```bash
# List all agents in system
openclaw agent list

# Create new agent with identity
mkdir -p ~/.openclaw/agents/my-agent
cd ~/.openclaw/agents/my-agent

# Create core config files
touch SOUL.md AGENTS.md USER.md IDENTITY.md MEMORY.md TOOLS.md
```

### 2. SOUL.md - Agent Behavioral Foundation

**SOUL.md** คือ core personality file ที่ถูก inject เข้า system prompt ทุกครั้ง wake agent.

```markdown
# SOUL - Behavioral Philosophy

## Core Identity
- Name: CodeMaster Agent
- Purpose: Code analysis, review, optimization
- Expertise: Python, TypeScript, architecture patterns

## Values & Philosophy
- Clarity over cleverness
- Test-driven reasoning
- Explain edge cases always
- Ask before major changes

## Tone & Voice
- Technical but accessible
- Curious, not condescending
- Direct feedback with reasons
- Encouraging on improvements

## Boundaries
- No unverified security claims
- No generation without reasoning
- Stop before production changes
- Always explain implications

## Response Patterns
- Start: Understand the problem
- Middle: Show reasoning steps
- End: Summary + next steps
- Errors: Root cause analysis
```

**ส่วนที่ Inject ลงไป System Prompt:**
```
[SYSTEM PERSONALITY LAYER]
{content of SOUL.md}
[END PERSONALITY]
```

### 3. AGENTS.md - Default Behaviors & Tool Preferences

```yaml
# Agent Configuration - Default Behaviors
agent:
  id: codemaster-agent
  displayName: "Code Master"
  description: "Code analysis and optimization specialist"

behavior:
  # Thinking depth
  thinking: extended  # extended|normal|minimal
  responseLength: detailed  # concise|normal|detailed
  explainSteps: true
  
  # Tool usage preferences
  toolPreferences:
    - type: filesystem
      priority: high
      maxCallsPerSession: 50
    - type: analysis
      priority: high
    - type: web
      priority: low
      
  # Coding style defaults
  codingStyle:
    language: typescript
    formatter: prettier
    linter: eslint
    testFramework: vitest
    
  # Communication patterns
  communication:
    - assumeContext: true
    - confirmLargeChanges: true
    - showReasoningPath: true
    - suggestImprovements: true

capabilities:
  - codeAnalysis
  - architectureReview
  - testGeneration
  - documentation
  - refactoring
```

### 4. IDENTITY.md - Presentation Layer

```yaml
# Agent Presentation & Channel Display

identity:
  name: "Code Master"
  avatar: "🧙‍♂️"
  
  # Channel display configuration
  channels:
    slack:
      displayName: "Code Master"
      statusEmoji: "💻"
      color: "#0066FF"
    
    discord:
      username: "CodeMaster#8888"
      roles: ["Agent", "Code-Review"]
    
    web:
      profileUrl: "/agents/codemaster"

  # Public bio
  bio: |
    Expert code analyst and architecture reviewer.
    Specializes in Python, TypeScript, system design.
    Focuses on clarity, testing, and maintainability.
    
  # Skills tags
  skills:
    - "Python"
    - "TypeScript"
    - "Architecture"
    - "Code Review"
    - "Testing"
```

### 5. USER.md - User Context & Preferences

```yaml
# User Context & Communication Preferences

user:
  name: "Development Team"
  timezone: "Asia/Bangkok"
  
  communication:
    # How agent should communicate with this user
    tone: technical
    detail: comprehensive
    language: "en-US"
    formatting: markdown
    
  preferences:
    # Output formatting
    maxLineLength: 100
    useCodeBlocks: true
    includeLinks: true
    
    # Interaction style
    askBeforeLargeChanges: true
    suggestAlternatives: true
    explainTradeoffs: true
    
  constraints:
    # Domain-specific constraints
    noExternalAPIs: false
    noDataModification: true
    requiresApprovalFor: ["deployment", "database_changes"]
    
  recurringPreferences:
    # Patterns that recur per project
    projectsUseTypeScript: true
    alwaysIncludeTests: true
    documentPublicAPIs: true
```

### 6. MEMORY.md - Long-Term Memory

```yaml
# Agent Memory - Learned Patterns & Key Takeaways

memory:
  version: 1
  lastUpdated: 2026-03-15

  # Learning from projects
  learnings:
    - pattern: "TypeScript migration at scale"
      project: "project-alpha"
      key_takeaway: "Incremental adoption with strict types > big bang"
      resources:
        - "docs/typescript-migration-guide.md"
    
    - pattern: "Multi-agent coordination"
      project: "multi-service-refactor"
      key_takeaway: "Clear delegation + async handoff = success"
      bestPractices:
        - define handoff protocols early
        - use state machines for complex flows
        - document assumptions

  # Expertise scope
  expertiseMap:
    architecture:
      level: advanced
      domains: ["microservices", "event-driven", "api-design"]
    
    codeQuality:
      level: expert
      domains: ["testing", "refactoring", "performance"]

  # Known limitations
  limitations:
    - "Real-time debugging requires human oversight"
    - "Security review needs domain expert review"
    - "Deployment decisions require human approval"

  # Context from previous sessions
  sessionNotes:
    - date: 2026-03-14
      project: project-alpha
      focus: typescript-strict-mode
      outcome: "Successfully enabled strict mode in 80% of codebase"
```

### 7. TOOLS.md - Capability Declarations

```yaml
# Agent Tools & Capabilities Declaration

tools:
  enabled:
    - id: filesystem
      name: "File System Operations"
      capabilities:
        - read
        - write
        - analyze
      limits:
        maxFileSize: "10MB"
        maxOperationsPerHour: 100
      
    - id: codeAnalysis
      name: "Code Analysis"
      capabilities:
        - staticAnalysis
        - typeAnalysis
        - securityCheck
      languages: ["python", "typescript", "javascript", "go"]
      
    - id: search
      name: "Search & Navigate"
      capabilities:
        - codeSearch
        - patternMatching
      maxResults: 100

  disabled:
    - id: deployment
      reason: "Requires manual review"
    - id: externalAPI
      reason: "User constraint"

  custom:
    - id: custom-analyzer
      type: "python-script"
      path: "~/.openclaw/agents/my-agent/tools/custom-analyzer.py"
      signature: "analyze(code: str) -> Report"
```

## Multi-Agent System Setup

### Agent List Configuration

```yaml
# ~/.openclaw/agents.list
agents:
  - id: codemaster
    name: "Code Master"
    role: "code-review"
    enabled: true
    
  - id: docwriter
    name: "Doc Writer"
    role: "documentation"
    enabled: true
    
  - id: researcher
    name: "Researcher"
    role: "research"
    enabled: true

# Channel bindings
channels:
  slack:
    codemaster: "#code-review"
    docwriter: "#documentation"
    researcher: "#research"
  
  discord:
    codemaster: "code-review-channel"
    docwriter: "docs-channel"
```

### Agent State Management

Agent state บันทึกใน `~/.openclaw/agents/<id>/`:

```
~/.openclaw/agents/codemaster/
├── SOUL.md              # Behavioral foundation
├── AGENTS.md            # Configuration & defaults
├── USER.md              # User context
├── IDENTITY.md          # Presentation layer
├── MEMORY.md            # Long-term memory
├── TOOLS.md             # Tool declarations
├── skills/              # Agent-specific skills
│   ├── code-analyzer.skill/
│   └── test-generator.skill/
├── sessions/            # Session history
│   ├── 2026-03-15_session1.json
│   └── 2026-03-15_session2.json
└── auth/                # Auth profiles
    └── github.token
```

### Agent CLI Commands

```bash
# List agents
openclaw agent list
openclaw agent list --detailed
openclaw agent list --bindings

# Interact with agent
openclaw agent --id codemaster --message "Review this code"
openclaw agent --id codemaster --deliver "task.md"
openclaw agent --id codemaster --thinking

# Agent configuration
openclaw agent --id codemaster --config show
openclaw agent --id codemaster --config set behavior.thinking extended

# Agent memory
openclaw agent --id codemaster --memory show
openclaw agent --id codemaster --memory add "New learning from project"

# Agent workspace
openclaw agent --id codemaster --workspace status
openclaw agent --id codemaster --workspace reset
```

## Agent Communication Patterns

### Inter-Agent Delegation

```markdown
# Multi-Agent Handoff Pattern

## Scenario: Code Review → Documentation

1. **Codemaster Agent** (Code Review role)
   - Analyzes code
   - Identifies improvements
   - Delegates documentation to DocWriter

Delegation message structure:
agent: codemaster
delegates_to: docwriter
task: code-review-123
context:
  code_location: /path/to/file.ts
  changes: [refactored function X, added feature Y]
  requirements:
    - updateAPIDocumentation
    - includeExamples

2. **DocWriter Agent** (Documentation role)
   - Receives context from Codemaster
   - Creates documentation
   - Returns to Codemaster for review

3. **Completion**
   - Both agents update MEMORY.md
   - Task marked as complete
```

### Peer Matching & Routing

```yaml
# Peer matching in multi-agent system

routing:
  # By task type
  taskRouting:
    code-review: codemaster
    documentation: docwriter
    research: researcher
    testing: testbot
  
  # By expertise
  expertiseRouting:
    - expertise: "typescript"
      agents: [codemaster, testbot]
      primary: codemaster
    
    - expertise: "api-design"
      agents: [codemaster, researcher]
      primary: codemaster

  # By accountId (enterprise)
  accountRouting:
    "account-123": [codemaster, researcher]
    "account-456": [docwriter, testbot]
```

## Agent Personality Design

### Tone Matrix

```yaml
personality:
  tone:
    # Spectrum definitions
    formality: technical  # friendly|neutral|technical|formal
    confidence: measured  # cautious|measured|assertive|confident
    humor: minimal  # none|minimal|moderate|frequent
    
  specialty:
    # Depth vs breadth
    focus: "deep-specialist"  # generalist|specialist|deep-specialist
    perspectives: "technical"  # business|technical|creative|pragmatic
    
  boundary:
    # What agent won't do
    refusals:
      - "make unreviewed deployments"
      - "modify without test coverage"
      - "skip security review"
    
    escalations:
      - production_changes: "always human review"
      - security: "domain_expert_required"
```

### Expertise Scoping

```yaml
expertise:
  # Define clear scope boundaries
  
  core:
    - python
    - typescript
    - system_design
    level: expert
    
  secondary:
    - devops
    - database_design
    level: intermediate
    
  excluded:
    - mobile_development
    - machine_learning
    - blockchain
    reason: "Outside current training"
```

## Real-World Agent Templates

### 1. Code Review Agent Template

```yaml
---
name: code-review-agent
version: 1.0
template: true
---

# SOUL.md qualities
## Core Identity
- Specializes in code quality and architecture
- Thoughtful, principled approach
- Explains reasoning behind feedback
- Collaborative, not critical

## Tone
- Technical and direct
- Constructive feedback
- Curious about tradeoffs
- Growth-oriented

# AGENTS.md config
agent:
  id: code-reviewer
  displayName: "Code Review Bot"
  
behavior:
  thinking: extended
  toolPreferences:
    - type: codeAnalysis
      priority: high

# IDENTITY.md setup
identity:
  name: "Code Reviewer"
  avatar: "👀"
  skills:
    - "Code Review"
    - "Architecture"
    - "Testing"
    - "Performance"
```

### 2. Documentation Writer Template

```yaml
# SOUL.md
- Transforms complex code into clear docs
- Audience-first approach
- Examples over abstractions

# AGENTS.md
agent:
  id: docwriter
  displayName: "Doc Writer"
  
behavior:
  thinking: normal
  responseLength: detailed

# IDENTITY.md
identity:
  name: "Doc Writer"
  avatar: "📚"
  skills:
    - "Technical Writing"
    - "Example Creation"
    - "API Documentation"
```

### 3. Research Agent Template

```yaml
# SOUL.md
- Deep research and pattern discovery
- Evidence-based reasoning
- Multiple perspectives

# AGENTS.md
behavior:
  thinking: extended
  explainSteps: true

# IDENTITY.md
identity:
  name: "Researcher"
  avatar: "🔍"
  skills:
    - "Research"
    - "Analysis"
    - "Pattern Discovery"
```

## Validation & Verification

### Check Agent Bindings

```bash
# Verify all agents properly configured
openclaw agents list --bindings --verify

# Output:
# ✓ codemaster: properly configured
#   - SOUL.md: present
#   - AGENTS.md: valid YAML
#   - IDENTITY.md: present
#
# ⚠ docwriter: missing USER.md
# ✗ researcher: invalid SOUL.md (line 15)
```

### Validate Configuration Files

```bash
# Validate single agent
openclaw agent --id codemaster --validate

# Validate all agents
openclaw agent --validate --all

# Output validation report
openclaw agent --validate --output json > validation-report.json
```

## Best Practices

### ✅ Do's

- Define SOUL.md first before adding tools
- Use explicit boundaries and refusal patterns
- Test inter-agent communication before production
- Keep MEMORY.md current with learnings
- Version track AGENTS.md configurations
- Document escalation protocols clearly

### ❌ Don'ts

- Don't make SOUL.md too restrictive (prevents problem-solving)
- Don't skip MEMORY.md (lose organizational learning)
- Don't overlook USER.md (miss preferences)
- Don't mix personality with tooling concerns
- Don't auto-approve dangerous operations

## Advanced Topics

### Conditional Tool Access

```yaml
# TOOLS.md - Conditional tool enablement
tools:
  enabled:
    - id: deployment
      enabled: true
      conditions:
        - environment: "staging"  # only in staging
        - hasApproval: true  # needs approval flag
        - timeOfDay: "09:00-17:00"  # business hours only
```

### Agent State Snapshots

```bash
# Save agent state for reproducibility
openclaw agent --id codemaster --snapshot save "pre-deployment"

# Restore agent state
openclaw agent --id codemaster --snapshot restore "pre-deployment"

# List snapshots
openclaw agent --id codemaster --snapshot list
```

### Multi-Model Agent Selection

```yaml
# Use different models for different tasks
agent:
  id: hybrid-agent
  models:
    default: claude-opus
    tasks:
      codeAnalysis: claude-opus
      documentation: claude-sonnet
      brainstorming: claude-sonnet
      research: claude-opus
```

## See Also

- **References**: See `agent-deep-dive.md` for detailed architecture
- **Examples**: Check `references/` for real config examples

---

**Last Updated**: 2026-03-15 | **Skill Version**: 2.0
