# OpenClaw Gateway - Advanced Deployment Guide

**Reference Document:** Detailed patterns, troubleshooting, and advanced configurations

---

## Table of Contents

1. [Architecture Deep Dive](#architecture-deep-dive)
2. [Installation Patterns](#installation-patterns)
3. [Docker Advanced Configurations](#docker-advanced-configurations)
4. [Kubernetes Advanced Patterns](#kubernetes-advanced-patterns)
5. [Reverse Proxy Configurations](#reverse-proxy-configurations)
6. [SSL/TLS Setup](#ssltls-setup)
7. [Monitoring & Observability](#monitoring--observability)
8. [Performance Tuning](#performance-tuning)
9. [Security Hardening](#security-hardening)
10. [Troubleshooting Guide](#troubleshooting-guide)
11. [Migration & Upgrades](#migration--upgrades)
12. [Backup & Disaster Recovery](#backup--disaster-recovery)

---

## Architecture Deep Dive

### Hub-and-Spoke Pattern Explained

The OpenClaw Gateway implements a **hub-and-spoke architecture** where:

**Hub (Gateway):**
- Single control plane managing all messaging integrations
- Always-on process listening for incoming webhooks
- Maintains session state and credential management
- Routes messages between platforms and AI agents
- Handles rate limiting, security, and authentication

**Spokes (Messaging Platforms):**
- Telegram, Discord, Slack, Teams, etc.
- Each platform communicates via standardized webhook protocol
- Gateway maintains independent connection state per platform
- Automatic reconnection and failover handling

### State Management

```
┌─────────────────────────────────────┐
│  OpenClaw Gateway Process           │
├─────────────────────────────────────┤
│ ┌──────────────────────────────┐    │
│ │ Redis Cache Layer            │    │
│ │ - Session tokens             │    │
│ │ - Rate limit counters        │    │
│ │ - User preferences           │    │
│ └──────────────────────────────┘    │
├─────────────────────────────────────┤
│ ┌──────────────────────────────┐    │
│ │ Local State Directory        │    │
│ │ ~/.openclaw/                 │    │
│ │ - credentials/               │    │
│ │ - sessions/                  │    │
│ │ - config.json                │    │
│ │ - message-queue/             │    │
│ └──────────────────────────────┘    │
└─────────────────────────────────────┘
```

### Data Flow

```
Incoming Message:
  Webhook → Gateway Receiver → Validate Token
    → Route to Agent → Process
    → Send Response → Platform

Outgoing Message:
  Agent → Gateway Send Queue → Platform API
    → Retry on failure → Log result
```

---

## Installation Patterns

### Pattern 1: Development Environment

For local development with hot-reload:

```bash
# Clone and setup
git clone https://github.com/openclaw/openclaw-gateway.git
cd openclaw-gateway
npm install
npm run dev

# Creates local state directory
# ~/.openclaw/dev/credentials
# Runs on port 3000 with auto-reload
```

### Pattern 2: Single VPS (Production)

Minimal production setup on single VPS:

```bash
# 1. System setup
ssh root@vps-ip
apt-get update && apt-get upgrade -y
apt-get install -y curl wget git build-essential

# 2. Node.js installation
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# 3. Create application user
useradd -m -s /bin/bash openclaw
sudo -u openclaw ssh-keygen -t ed25519 -N "" -f /home/openclaw/.ssh/id_ed25519

# 4. Clone application
cd /opt
git clone https://github.com/openclaw/openclaw-gateway.git
chown -R openclaw:openclaw /opt/openclaw
cd openclaw

# 5. Install dependencies
sudo -u openclaw npm install --production

# 6. Create systemd service
cat > /etc/systemd/system/openclaw.service << 'EOF'
[Unit]
Description=OpenClaw Gateway
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=openclaw
Group=openclaw
WorkingDirectory=/opt/openclaw
EnvironmentFile=/etc/openclaw/env
ExecStart=/usr/bin/node src/index.js
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
StandardInput=null

# Security
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
NoNewPrivileges=yes
ProtectKernelTunables=yes
ProtectControlGroups=yes
ProtectKernelModules=yes
ProtectKernelLogs=yes

[Install]
WantedBy=multi-user.target
EOF

# 7. Start service
systemctl daemon-reload
systemctl enable openclaw
systemctl start openclaw

# 8. Verify
systemctl status openclaw
openclaw health
```

### Pattern 3: Docker Swarm Deployment

For multiple nodes with shared state:

```bash
# Initialize Swarm
docker swarm init

# Create overlay network
docker network create -d overlay openclaw-net

# Deploy stack
docker stack deploy -c docker-compose.swarm.yml openclaw
```

**docker-compose.swarm.yml:**

```yaml
version: '3.8'

services:
  openclaw-gateway:
    image: openclaw/gateway:latest
    deploy:
      mode: global
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
    volumes:
      - openclaw-state:/root/.openclaw
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      NODE_ENV: production
      REDIS_URL: redis://redis:6379
    networks:
      - openclaw-net
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    deploy:
      placement:
        constraints: [node.role == manager]
      restart_policy:
        condition: on-failure
    volumes:
      - redis-data:/data
    networks:
      - openclaw-net

volumes:
  openclaw-state:
    driver: local
  redis-data:
    driver: local

networks:
  openclaw-net:
    driver: overlay
    driver_opts:
      com.docker.network.driver.mtu: 1450
```

---

## Docker Advanced Configurations

### Multi-Architecture Build (ARM/AMD64)

```bash
# Setup buildx
docker buildx create --name multiarch
docker buildx use multiarch

# Build for multiple architectures
docker buildx build \
  --platform linux/amd64,linux/arm64,linux/arm/v7 \
  -t openclaw/gateway:latest \
  --push .
```

### Build with Cache Optimization

```dockerfile
# Dockerfile.optimized
FROM node:22-alpine AS base
RUN apk add --no-cache curl dumb-init tini
WORKDIR /app

FROM base AS dependencies
COPY package*.json ./
RUN npm ci --only=production --ignore-scripts && \
    npm cache clean --force

FROM base AS development
COPY package*.json ./
RUN npm ci

FROM base AS production
COPY --from=dependencies /app/node_modules ./node_modules
COPY --chown=1000:1000 . .
RUN apk add --no-cache dumb-init && \
    addgroup -g 1000 openclaw && \
    adduser -D -u 1000 -G openclaw openclaw
USER openclaw
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s \
  CMD curl -f http://localhost:3000/health || exit 1
ENTRYPOINT ["tini", "--"]
CMD ["node", "src/index.js"]
```

### Health Check with Custom Script

```dockerfile
COPY healthcheck.js /app/
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
  CMD node /app/healthcheck.js
```

**healthcheck.js:**

```javascript
const http = require('http');

const req = http.get('http://localhost:3000/health', (res) => {
  if (res.statusCode === 200) {
    console.log('Health check passed');
    process.exit(0);
  } else {
    console.log('Health check failed:', res.statusCode);
    process.exit(1);
  }
});

req.on('error', (err) => {
  console.error('Health check error:', err);
  process.exit(1);
});

req.setTimeout(5000, () => {
  req.abort();
  process.exit(1);
});
```

### Volume Backup Strategy

```bash
# Create backup volume
docker volume create openclaw-backup

# Backup container
docker run --rm \
  -v openclaw-state:/source:ro \
  -v openclaw-backup:/backup \
  alpine tar czf /backup/openclaw-$(date +%s).tar.gz -C /source .

# Restore from backup
docker run --rm \
  -v openclaw-state:/target \
  -v openclaw-backup:/backup \
  alpine tar xzf /backup/openclaw-latest.tar.gz -C /target
```

---

## Kubernetes Advanced Patterns

### StatefulSet for Persistent State

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: openclaw-gateway
  namespace: openclaw
spec:
  serviceName: openclaw-gateway
  replicas: 2
  selector:
    matchLabels:
      app: openclaw-gateway
  template:
    metadata:
      labels:
        app: openclaw-gateway
    spec:
      affinity:
        podAntiAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
          - labelSelector:
              matchExpressions:
              - key: app
                operator: In
                values:
                - openclaw-gateway
            topologyKey: kubernetes.io/hostname
      terminationGracePeriodSeconds: 30
      containers:
      - name: gateway
        image: openclaw/gateway:latest
        ports:
        - containerPort: 3000
        volumeMounts:
        - name: openclaw-state
          mountPath: /root/.openclaw
        - name: openclaw-config
          mountPath: /app/openclaw.json
          subPath: openclaw.json
        lifecycle:
          preStop:
            exec:
              command: ["/bin/sh", "-c", "sleep 15"]
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
  volumeClaimTemplates:
  - metadata:
      name: openclaw-state
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 10Gi
```

### HorizontalPodAutoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: openclaw-gateway-hpa
  namespace: openclaw
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: openclaw-gateway
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 50
        periodSeconds: 15
    scaleUp:
      stabilizationWindowSeconds: 0
      policies:
      - type: Percent
        value: 100
        periodSeconds: 15
      - type: Pods
        value: 2
        periodSeconds: 60
      selectPolicy: Max
```

### NetworkPolicy for Security

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: openclaw-gateway-netpolicy
  namespace: openclaw
spec:
  podSelector:
    matchLabels:
      app: openclaw-gateway
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    - podSelector:
        matchLabels:
          app: openclaw-gateway
    ports:
    - protocol: TCP
      port: 3000
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          name: openclaw
    ports:
    - protocol: TCP
      port: 6379
  - to:
    - namespaceSelector: {}
    ports:
    - protocol: TCP
      port: 443
    - protocol: TCP
      port: 80
```

---

## Reverse Proxy Configurations

### Nginx with Request Buffering

```nginx
http {
    client_body_buffer_size 128k;
    client_max_body_size 10m;
    proxy_buffering on;
    proxy_buffer_size 128k;
    proxy_buffers 4 256k;
    proxy_busy_buffers_size 512k;

    upstream openclaw {
        least_conn;
        server gateway1:3000 weight=5 max_fails=2 fail_timeout=30s;
        server gateway2:3000 weight=5 max_fails=2 fail_timeout=30s;
        server gateway3:3000 weight=5 max_fails=2 fail_timeout=30s;
        keepalive 32;
    }

    server {
        listen 443 ssl http2;
        server_name gateway.example.com;

        ssl_certificate /etc/letsencrypt/live/gateway.example.com/fullchain.pem;
        ssl_certificate_key /etc/letsencrypt/live/gateway.example.com/privkey.key;
        ssl_protocols TLSv1.3 TLSv1.2;
        ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
        ssl_session_cache shared:SSL:10m;
        ssl_session_timeout 10m;

        # Gzip compression
        gzip on;
        gzip_types text/plain text/css application/json application/javascript;
        gzip_min_length 1000;

        # Rate limiting by IP
        limit_req_zone $binary_remote_addr zone=ip_limit:10m rate=100r/s;

        # Rate limiting by user (API key)
        limit_req_zone $http_x_api_key zone=api_limit:10m rate=1000r/s;

        location / {
            limit_req zone=ip_limit burst=200 nodelay;
            limit_req zone=api_limit burst=2000 nodelay;

            proxy_pass http://openclaw;
            proxy_http_version 1.1;
            proxy_set_header Connection "";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header X-Request-ID $request_id;

            # Timeouts
            proxy_connect_timeout 30s;
            proxy_send_timeout 30s;
            proxy_read_timeout 30s;

            # Logging
            access_log /var/log/nginx/openclaw_access.log combined;
            error_log /var/log/nginx/openclaw_error.log;
        }

        location /metrics {
            # Restrict metrics to internal IPs
            allow 10.0.0.0/8;
            allow 172.16.0.0/12;
            allow 192.168.0.0/16;
            deny all;

            proxy_pass http://openclaw;
        }

        location /health {
            access_log off;
            proxy_pass http://openclaw;
            proxy_read_timeout 5s;
        }
    }
}
```

### HAProxy Configuration

```haproxy
global
    maxconn 65535
    log stdout local0
    mode http
    option httplog
    option forwardfor
    timeout connect 5000ms
    timeout client 50000ms
    timeout server 50000ms

frontend openclaw_frontend
    bind *:80
    bind *:443 ssl crt /etc/haproxy/openclaw.pem
    mode http
    option httplog
    option forwardfor
    option http-server-close

    # Redirect HTTP to HTTPS
    redirect scheme https code 301 if !{ ssl_fc }

    # Compress responses
    compression algo gzip
    compression type text/html text/plain text/css application/json

    # Rate limiting
    stick-table type ip size 100k expire 30s store http_req_rate(10s)
    http-request track-sc0 src
    http-request deny if { sc_http_req_rate(0) gt 100 }

    # Route to backend
    default_backend openclaw_backend

backend openclaw_backend
    mode http
    option httplog
    option httpchk GET /health HTTP/1.1\r\nHost:\ gateway.example.com
    balance leastconn

    server gateway1 10.0.1.10:3000 check inter 5s fall 3 rise 2 weight 5
    server gateway2 10.0.1.11:3000 check inter 5s fall 3 rise 2 weight 5
    server gateway3 10.0.1.12:3000 check inter 5s fall 3 rise 2 weight 5
```

---

## SSL/TLS Setup

### Let's Encrypt with Auto-Renewal

```bash
#!/bin/bash
# setup-letsencrypt.sh

# Install certbot
apt-get install -y certbot python3-certbot-nginx

# Obtain certificate
certbot certonly --standalone \
  -d gateway.example.com \
  --non-interactive \
  --agree-tos \
  -m admin@example.com

# Setup auto-renewal
systemctl enable certbot.timer
systemctl start certbot.timer

# Verify auto-renewal
certbot renew --dry-run

# Hook for reloading services
cat > /etc/letsencrypt/renewal-hooks/post/reload-services.sh << 'EOF'
#!/bin/bash
systemctl reload nginx
systemctl reload openclaw
EOF
chmod +x /etc/letsencrypt/renewal-hooks/post/reload-services.sh
```

### Self-Signed Certificate for Development

```bash
# Generate key
openssl genrsa -out openclaw.key 4096

# Generate certificate
openssl req -new -x509 -key openclaw.key -out openclaw.crt -days 365 \
  -subj "/C=TH/ST=Bangkok/L=Bangkok/O=OpenClaw/CN=localhost"

# Copy to location
cp openclaw.crt openclaw.key /etc/ssl/private/

# Nginx configuration
ssl_certificate /etc/ssl/private/openclaw.crt;
ssl_certificate_key /etc/ssl/private/openclaw.key;
```

---

## Monitoring & Observability

### Prometheus Integration

```yaml
# /etc/prometheus/openclaw.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'openclaw-gateway'
    static_configs:
      - targets: ['localhost:3000']
    metrics_path: '/metrics'
    scrape_interval: 30s
    scrape_timeout: 10s
```

### Grafana Dashboard Query Examples

```sql
-- CPU Usage
rate(container_cpu_usage_seconds_total{job="openclaw-gateway"}[5m])

-- Memory Usage
container_memory_usage_bytes{job="openclaw-gateway"}

-- Request Rate
rate(openclaw_requests_total[5m])

-- Error Rate
rate(openclaw_errors_total[5m]) / rate(openclaw_requests_total[5m])

-- Message Processing Time
histogram_quantile(0.95, openclaw_message_duration_seconds)
```

### ELK Stack Configuration

```yaml
# filebeat.yml
filebeat.inputs:
- type: log
  enabled: true
  paths:
    - /var/log/openclaw/*.log
    - /var/log/syslog
  fields:
    service: openclaw-gateway
    environment: production

output.elasticsearch:
  hosts: ["elasticsearch:9200"]
  index: "openclaw-%{[agent.version]}-%{+yyyy.MM.dd}"

processors:
  - add_kubernetes_metadata:
      in_cluster: true
  - add_host_metadata:
  - drop_fields:
      fields: ["agent.ephemeral_id"]
```

---

## Performance Tuning

### Node.js Optimization

```bash
# Large heap size for high throughput
export NODE_OPTIONS="--max-old-space-size=4096 --max-semi-space-size=2048"

# Increase file descriptors
ulimit -n 65535

# Enable clustering
export NODE_CLUSTER_SCHED_POLICY=rr
export UV_THREADPOOL_SIZE=128

# Run with NODE_ENV=production
export NODE_ENV=production
export NODE_DEBUG_NATIVE=""  # Disable debug output

node src/index.js
```

### Database Connection Pooling

```javascript
// config.js
module.exports = {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
    enableOfflineQueue: false,
    lazyConnect: true,
    retryStrategy: (times) => Math.min(times * 50, 2000),
    reconnectOnError: (err) => {
      const targetError = 'READONLY';
      if (err.message.includes(targetError)) {
        return true;
      }
      return false;
    }
  },
  pool: {
    min: 5,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
  }
};
```

### Load Testing

```bash
# Apache Bench
ab -n 10000 -c 100 https://gateway.example.com/health

# Vegeta
echo "GET https://gateway.example.com/health" | \
  vegeta attack -duration=30s -rate=1000 | \
  vegeta report -type=text

# K6 (Advanced)
k6 run - <<'EOF'
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  vus: 100,
  duration: '10m',
  thresholds: {
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
    http_req_failed: ['rate<0.1'],
  },
};

export default function () {
  let res = http.get('https://gateway.example.com/health');
  check(res, {
    'status is 200': (r) => r.status === 200,
  });
  sleep(1);
}
EOF
```

---

## Security Hardening

### AppArmor Profile

```bash
# /etc/apparmor.d/openclaw-gateway
#include <tunables/global>

profile openclaw-gateway {
  #include <abstractions/base>
  #include <abstractions/nameservice>

  /opt/openclaw/** r,
  /opt/openclaw/src/** r,
  /opt/openclaw/node_modules/** r,
  /home/openclaw/** rw,
  /home/openclaw/.openclaw/** rw,
  /var/log/openclaw/** w,
  /proc/*/stat r,
  /proc/*/fd/ r,

  # Network access
  network inet stream,
  network inet dgram,

  # Deny direct file writes outside home
  deny /root/** w,
  deny /etc/** w,
  deny /usr/** w,
}
```

### SELinux Policy

```bash
# openclaw.te
module openclaw 1.0;

require {
  type openclaw_t;
  type openclaw_exec_t;
  type openclaw_var_t;
  type http_port_t;
  type redis_port_t;
}

allow openclaw_t http_port_t:tcp_socket name_bind;
allow openclaw_t redis_port_t:tcp_socket name_bind;
allow openclaw_t openclaw_var_t:dir { write remove_name add_name };
allow openclaw_t openclaw_var_t:file create;
```

### Rate Limiting Strategies

```javascript
// Advanced rate limiting
const rateLimit = {
  // Per IP
  ip: { windowMs: 60000, max: 100 },

  // Per API key
  apiKey: { windowMs: 60000, max: 1000 },

  // Per endpoint
  endpoints: {
    '/webhooks/telegram': { windowMs: 1000, max: 100 },
    '/api/send': { windowMs: 60000, max: 500 },
    '/health': { windowMs: 0, max: -1 }  // No limit
  },

  // Distributed (Redis)
  store: new RedisStore({
    client: redis,
    prefix: 'rl:',
    sendCommand: async (...args) => {
      return redis.sendCommand(new Command(...args));
    },
  }),

  skip: (req, res) => {
    // Skip rate limiting for internal IPs
    return ['127.0.0.1', '::1'].includes(req.ip);
  },

  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many requests',
      retryAfter: req.rateLimit.resetTime
    });
  }
};
```

---

## Troubleshooting Guide

### Common Issues

**Issue: Gateway not receiving webhooks**

```bash
# 1. Check if running
systemctl status openclaw
ps aux | grep openclaw

# 2. Check logs
journalctl -u openclaw -f

# 3. Verify webhook URL configuration
cat ~/.openclaw/config.json | jq '.messaging'

# 4. Test webhook endpoint
curl -X POST http://localhost:3000/webhooks/telegram \
  -H "Content-Type: application/json" \
  -d '{"update_id": 1, "message": {"text": "test"}}'

# 5. Check firewall rules
iptables -L -n | grep 3000
ufw status | grep 3000

# 6. Check reverse proxy logs
tail -f /var/log/nginx/error.log
```

**Issue: High memory usage**

```bash
# Check memory usage
openclaw stats --detailed | grep memory

# Profile heap usage
node --inspect-brk=127.0.0.1:9229 src/index.js
# Connect with Chrome DevTools

# Check for memory leaks
node-memwatch-standalone src/index.js

# Adjust Node.js options
export NODE_OPTIONS="--max-old-space-size=2048 --expose-gc"
node --expose-gc src/index.js
```

**Issue: Slow message processing**

```bash
# Enable debug logging
OPENCLAW_LOG_LEVEL=debug openclaw daemon

# Check Redis connection
redis-cli ping
redis-cli info stats

# Monitor database query performance
redis-cli --stat

# Profile application
node --prof src/index.js
# Process results: node --prof-process isolate-*.log > profile.txt
```

---

## Migration & Upgrades

### Blue-Green Deployment

```bash
#!/bin/bash
# Blue-Green deployment script

# Current version (blue)
BLUE_VERSION="21.9.5"
# New version (green)
GREEN_VERSION="22.0.0"

# 1. Start green environment
docker run -d \
  --name openclaw-green \
  --restart always \
  -p 3001:3000 \
  -v openclaw-state:/root/.openclaw:ro \
  openclaw/gateway:$GREEN_VERSION

# 2. Run smoke tests
sleep 10
curl http://localhost:3001/health || exit 1

# 3. Switch traffic
docker stop openclaw-blue
docker rename openclaw-green openclaw-blue
docker run -d \
  --name openclaw-green \
  --restart always \
  -p 3001:3000 \
  openclaw/gateway:$BLUE_VERSION

# 4. Monitor for 5 minutes
for i in {1..30}; do
  sleep 10
  curl http://localhost:3000/health || {
    # Rollback
    docker stop openclaw-blue
    docker rename openclaw-green openclaw-blue
    exit 1
  }
done

# 5. Clean up old container
docker rm -f openclaw-green
```

### Canary Deployment (Kubernetes)

```yaml
apiVersion: flagger.app/v1beta1
kind: Canary
metadata:
  name: openclaw-gateway
  namespace: openclaw
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: openclaw-gateway
  progressDeadlineSeconds: 60
  service:
    port: 3000
    targetPort: 3000
  analysis:
    interval: 1m
    threshold: 5
    maxWeight: 50
    stepWeight: 10
    metrics:
    - name: request-success-rate
      thresholdRange:
        min: 99
      interval: 1m
    - name: request-duration
      thresholdRange:
        max: 500
      interval: 1m
  webhooks:
  - name: smoke-tests
    url: http://localhost:5000/smoke
    timeout: 5s
    metadata:
      test: "basic-sanity"
```

---

## Backup & Disaster Recovery

### Automated Backup Strategy

```bash
#!/bin/bash
# backup-script.sh

BACKUP_DIR="/backups/openclaw"
RETENTION_DAYS=30
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# 1. Backup credentials and config
tar czf $BACKUP_DIR/openclaw-config-$TIMESTAMP.tar.gz \
  -C /home/openclaw .openclaw \
  2>/dev/null || true

# 2. Backup application
tar czf $BACKUP_DIR/openclaw-app-$TIMESTAMP.tar.gz \
  -C /opt openclaw \
  --exclude="node_modules" \
  --exclude=".git" \
  2>/dev/null || true

# 3. Backup database
redis-cli BGSAVE
cp /var/lib/redis/dump.rdb $BACKUP_DIR/redis-$TIMESTAMP.rdb

# 4. Cleanup old backups
find $BACKUP_DIR -type f -mtime +$RETENTION_DAYS -delete

# 5. Verify backup integrity
tar tzf $BACKUP_DIR/openclaw-config-$TIMESTAMP.tar.gz > /dev/null || {
  echo "Backup verification failed"
  exit 1
}

echo "Backup completed: $TIMESTAMP"
```

### Recovery Procedure

```bash
#!/bin/bash
# recover-script.sh

BACKUP_FILE=$1

if [ -z "$BACKUP_FILE" ]; then
  echo "Usage: recover-script.sh <backup-file>"
  exit 1
fi

# 1. Stop service
systemctl stop openclaw

# 2. Backup current state
cp -r /home/openclaw/.openclaw /home/openclaw/.openclaw.backup

# 3. Restore from backup
tar xzf $BACKUP_FILE -C /home/openclaw

# 4. Restore permissions
chown -R openclaw:openclaw /home/openclaw/.openclaw

# 5. Start service
systemctl start openclaw

# 6. Verify
systemctl status openclaw
openclaw health

# If failed, restore backup
if [ $? -ne 0 ]; then
  rm -rf /home/openclaw/.openclaw
  cp -r /home/openclaw/.openclaw.backup /home/openclaw/.openclaw
  systemctl start openclaw
  echo "Recovery failed, restored backup"
  exit 1
fi

echo "Recovery successful"
```

---

## References

- OpenClaw Gateway: https://github.com/openclaw/openclaw-gateway
- Docker Compose: https://docs.docker.com/compose/
- Kubernetes: https://kubernetes.io/docs/
- Nginx: https://nginx.org/en/docs/
- Let's Encrypt: https://letsencrypt.org/
- Prometheus: https://prometheus.io/docs/
- Grafana: https://grafana.com/docs/
