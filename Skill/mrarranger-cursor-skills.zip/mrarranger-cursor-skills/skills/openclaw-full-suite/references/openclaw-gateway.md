---
name: openclaw-gateway
description: |
  OpenClaw Gateway - Deep Dive ระบบ Deployment และ Production Setup ครบวงจร
  Docker, Kubernetes, VPS, Cloud Hosting, Reverse Proxy, SSL, Monitoring
  ใช้เมื่อ: (1) Deploy OpenClaw Production (2) Docker/K8s setup (3) VPS hosting
  (4) Security hardening (5) Scaling (6) Monitoring (7) Backup/Recovery
  Commands: /deploy, /docker, /k8s, /production, /monitor, /backup
---

# OpenClaw Gateway - Deployment & Production Guide

## Architecture Overview

### Hub-and-Spoke Model
OpenClaw Gateway ใช้ **hub-and-spoke architecture** ที่ gateway เป็นจุดศูนย์กลาง (hub) ที่เชื่อมต่อ messaging apps หลายตัว (spokes):

```
┌─────────────────────────────────────────┐
│     OpenClaw Gateway (Hub)              │
│  - Single control plane                 │
│  - Always-on bridge process             │
│  - Multi-app orchestration              │
└─────────────────────────────────────────┘
        │          │          │
        ↓          ↓          ↓
    ┌────────┬────────┬────────┐
    │Telegram│ Discord│ Slack  │ (Messaging Apps)
    └────────┴────────┴────────┘
```

**Key Characteristics:**
- Single control plane: ทุก messaging app ผ่าน gateway เดียว
- Always-on process: ต้อง run 24/7 เพื่อรับ messages
- Stateful system: เก็บ session, credentials, state
- Event-driven: รับ webhooks จาก messaging platforms

---

## Installation Methods

### 1. NPM Installation

```bash
# Global installation
npm install -g openclaw

# Project local
npm install openclaw --save

# Verify installation
openclaw --version
openclaw health
```

**Pros:** Quick, cross-platform, easy updates
**Cons:** Requires Node.js environment

### 2. Docker Container

```bash
# Run with default config
docker run -d \
  --name openclaw-gateway \
  --restart always \
  -p 3000:3000 \
  -v openclaw-state:/root/.openclaw \
  openclaw/gateway:latest

# With custom config file
docker run -d \
  --name openclaw-gateway \
  -p 3000:3000 \
  -v openclaw-state:/root/.openclaw \
  -v $(pwd)/openclaw.json:/app/openclaw.json:ro \
  openclaw/gateway:latest
```

**Image Variants:**
- `openclaw/gateway:latest` - Stable release
- `openclaw/gateway:latest-beta` - Beta features
- `openclaw/gateway:dev` - Development build

### 3. Docker Compose Deployment

```yaml
# docker-compose.yml
version: '3.8'

services:
  openclaw-gateway:
    image: openclaw/gateway:latest
    container_name: openclaw-gateway
    restart: always
    ports:
      - "3000:3000"
    volumes:
      - openclaw-state:/root/.openclaw
      - ./openclaw.json:/app/openclaw.json:ro
      - ./logs:/app/logs
    environment:
      NODE_ENV: production
      OPENCLAW_PORT: 3000
      OPENCLAW_VERBOSE: "false"
    networks:
      - openclaw-net
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  redis:
    image: redis:7-alpine
    container_name: openclaw-redis
    restart: always
    volumes:
      - redis-data:/data
    networks:
      - openclaw-net
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  openclaw-state:
    driver: local
  redis-data:
    driver: local

networks:
  openclaw-net:
    driver: bridge
```

**Deploy:**
```bash
docker-compose up -d
docker-compose logs -f openclaw-gateway
```

### 4. Kubernetes Deployment

**Helm Installation (Recommended):**
```bash
helm repo add openclaw https://charts.openclaw.io
helm repo update

helm install openclaw-gateway openclaw/openclaw-gateway \
  --namespace openclaw \
  --create-namespace \
  --values values.yaml
```

### 5. Nix Installation

```nix
# flake.nix
{
  description = "OpenClaw Gateway Environment";
  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
  };
  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem (system:
      let pkgs = nixpkgs.legacyPackages.${system};
      in {
        devShells.default = pkgs.mkShell {
          buildInputs = with pkgs; [
            nodejs_22
            redis
            postgresql
          ];
        };
      }
    );
}
```

### 6. Build from Source

```bash
git clone https://github.com/openclaw/openclaw-gateway.git
cd openclaw-gateway
npm install
npm run build

# Run locally
npm start

# Or build Docker image
docker build -t openclaw-gateway:custom .
```

---

## Docker Deployment Deep Dive

### Multi-Stage Dockerfile

```dockerfile
# Dockerfile.prod
FROM node:22-alpine AS builder
WORKDIR /build
COPY package*.json ./
RUN npm ci --only=production

FROM node:22-alpine AS app
RUN apk add --no-cache curl dumb-init
RUN addgroup -g 1000 openclaw && adduser -D -u 1000 -G openclaw openclaw

WORKDIR /app
COPY --from=builder /build/node_modules ./node_modules
COPY --chown=openclaw:openclaw . .

USER openclaw
EXPOSE 3000
ENTRYPOINT ["/usr/bin/dumb-init", "--"]
CMD ["node", "src/index.js"]
```

### Docker Compose with Nginx Reverse Proxy

```yaml
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
      - nginx-cache:/var/cache/nginx
    depends_on:
      - openclaw-gateway
    networks:
      - openclaw-net

  openclaw-gateway:
    build:
      context: .
      dockerfile: Dockerfile.prod
    restart: always
    expose:
      - "3000"
    volumes:
      - openclaw-state:/home/openclaw/.openclaw
      - ./openclaw.json:/app/openclaw.json:ro
    environment:
      NODE_ENV: production
      OPENCLAW_PORT: 3000
    networks:
      - openclaw-net
    depends_on:
      - redis

  redis:
    image: redis:7-alpine
    restart: always
    volumes:
      - redis-data:/data
    networks:
      - openclaw-net

volumes:
  openclaw-state:
  redis-data:
  nginx-cache:

networks:
  openclaw-net:
```

---

## Kubernetes Deployment

### ConfigMap & Secrets

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: openclaw-gateway-config
  namespace: openclaw
data:
  openclaw.json: |
    {
      "port": 3000,
      "verbose": false,
      "daemon": true,
      "stateDir": "/root/.openclaw",
      "redis": {
        "host": "openclaw-redis",
        "port": 6379
      }
    }
---
apiVersion: v1
kind: Secret
metadata:
  name: openclaw-credentials
  namespace: openclaw
type: Opaque
data:
  telegram-token: base64-encoded-token
  discord-token: base64-encoded-token
```

### Deployment & Ingress

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: openclaw-gateway
  namespace: openclaw
spec:
  replicas: 2
  selector:
    matchLabels:
      app: openclaw-gateway
  template:
    metadata:
      labels:
        app: openclaw-gateway
    spec:
      containers:
      - name: gateway
        image: openclaw/gateway:latest
        ports:
        - containerPort: 3000
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: openclaw-gateway-ingress
  namespace: openclaw
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - gateway.example.com
    secretName: openclaw-tls
  rules:
  - host: gateway.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: openclaw-gateway
            port:
              number: 3000
```

**Scale replicas:**
```bash
kubectl scale deployment openclaw-gateway -n openclaw --replicas=5
```

---

## VPS/Cloud Deployment

### DigitalOcean Droplet (Ubuntu 22.04)

```bash
#!/bin/bash
# setup.sh - One-click deployment script

apt-get update && apt-get upgrade -y

# Install Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
apt-get install -y nodejs

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh

# Clone and setup
git clone https://github.com/openclaw/openclaw-gateway.git /opt/openclaw
cd /opt/openclaw && npm install

# Create systemd service
sudo tee /etc/systemd/system/openclaw.service > /dev/null <<EOL
[Unit]
Description=OpenClaw Gateway
After=network.target

[Service]
Type=simple
User=openclaw
WorkingDirectory=/opt/openclaw
ExecStart=/usr/bin/node src/index.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOL

systemctl daemon-reload && systemctl enable openclaw && systemctl start openclaw
```

### AWS EC2 + ALB

```bash
#!/bin/bash
set -e

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# Install OpenClaw
npm install -g openclaw

# Create service
sudo tee /etc/systemd/system/openclaw.service > /dev/null <<'EOF'
[Unit]
Description=OpenClaw Gateway
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/openclaw daemon --port 3000 --state-dir /var/openclaw
Restart=always
User=ubuntu
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload && systemctl enable openclaw && systemctl start openclaw
```

---

## Production Hardening

### Nginx Reverse Proxy

```nginx
# /etc/nginx/sites-available/openclaw
upstream openclaw_backend {
    least_conn;
    server 127.0.0.1:3000 max_fails=3 fail_timeout=30s;
    server 127.0.0.1:3001 max_fails=3 fail_timeout=30s;
    keepalive 32;
}

server {
    listen 80;
    server_name gateway.example.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name gateway.example.com;

    ssl_certificate /etc/letsencrypt/live/gateway.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/gateway.example.com/privkey.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=webhooks:10m rate=100r/s;

    location / {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://openclaw_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /webhooks {
        limit_req zone=webhooks burst=100 nodelay;
        proxy_pass http://openclaw_backend;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /health {
        access_log off;
        proxy_pass http://openclaw_backend;
    }
}
```

### Caddy (Simpler Alternative)

```caddy
# Caddyfile
gateway.example.com {
    reverse_proxy 127.0.0.1:3000 127.0.0.1:3001 {
        health_uri /health
        health_interval 30s
    }
    encode gzip
}
```

### Firewall Rules

```bash
# UFW (Ubuntu)
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable

# Fail2Ban
apt-get install fail2ban
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600

[sshd]
enabled = true
maxretry = 5

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 5
EOF
```

---

## Gateway Configuration

### openclaw.json Format

```json
{
  "port": 3000,
  "host": "0.0.0.0",
  "verbose": false,
  "daemon": true,
  "stateDir": "/root/.openclaw",
  "logLevel": "info",
  "logFormat": "json",
  "tls": {
    "enabled": true,
    "cert": "/etc/ssl/certs/openclaw.crt",
    "key": "/etc/ssl/private/openclaw.key"
  },
  "redis": {
    "host": "redis",
    "port": 6379,
    "db": 0,
    "password": "secure-password"
  },
  "messaging": {
    "telegram": {
      "token": "${TELEGRAM_TOKEN}",
      "webhookUrl": "https://gateway.example.com/webhooks/telegram"
    },
    "discord": {
      "token": "${DISCORD_TOKEN}",
      "webhookUrl": "https://gateway.example.com/webhooks/discord"
    }
  },
  "rateLimit": {
    "enabled": true,
    "windowMs": 60000,
    "maxRequests": 100
  },
  "security": {
    "apiKey": "${OPENCLAW_API_KEY}",
    "corsOrigins": ["https://example.com"],
    "sandbox": true
  }
}
```

---

## Health Monitoring

### Health Check Commands

```bash
# Basic health check
openclaw health

# Detailed status
openclaw status --all

# Full diagnostic report
openclaw doctor

# Watch real-time status
openclaw status --watch

# JSON output for monitoring
openclaw status --json | jq .
```

### Systemd Journal Monitoring

```bash
# Follow logs
journalctl -u openclaw -f

# Last 100 lines
journalctl -u openclaw -n 100

# Since specific time
journalctl -u openclaw --since "2 hours ago"

# Only errors
journalctl -u openclaw -p err
```

### Prometheus Metrics Export

```bash
# Enable metrics endpoint
curl http://localhost:3000/metrics

# Format for Prometheus:
# openclaw_connections_total{type="telegram"}
# openclaw_messages_processed_total
# openclaw_error_rate
# openclaw_uptime_seconds
```

---

## Headless Server Setup

### OAuth Token Transfer (No Browser)

```bash
# 1. Get OAuth flow URL on trusted device
openclaw oauth-flow --service telegram

# 2. Complete OAuth on trusted device, get token
# Copy token securely

# 3. Transfer to headless server
ssh user@headless-server
openclaw auth add \
  --service telegram \
  --token "copied-token" \
  --encryption-key "generated-key"

# 4. Verify
openclaw auth list
```

### Environment Variables (No Browser)

```bash
export OPENCLAW_TELEGRAM_TOKEN="token-here"
export OPENCLAW_DISCORD_TOKEN="token-here"
export OPENCLAW_API_KEY="api-key-here"

openclaw daemon
```

---

## Scaling Strategies

### Horizontal Scaling

```bash
# Docker Compose
docker-compose up -d --scale openclaw-gateway=3

# Kubernetes
kubectl scale deployment openclaw-gateway -n openclaw --replicas=5
```

### Vertical Scaling

```bash
# Monitor resource usage
openclaw stats --detailed

# Adjust Docker limits
docker update --memory 2g --cpus 2 openclaw-gateway

# Tune Node.js
export NODE_OPTIONS="--max-old-space-size=2048"
openclaw daemon
```

---

## Backup & Recovery

### Credential Backup

```bash
# Backup encrypted credentials
openclaw backup --output /backup/credentials.tar.gz

# Restore
openclaw restore --input /backup/credentials.tar.gz --force

# List backup contents
tar -tzf /backup/credentials.tar.gz
```

### Configuration Backup

```bash
# Backup config
cp -r ~/.openclaw /backup/openclaw-$(date +%s)

# Rotate old backups
find /backup -name "openclaw-*" -mtime +30 -delete
```

---

## Logging

### Configure Log Levels

```bash
# Set via environment
export OPENCLAW_LOG_LEVEL=debug
openclaw daemon

# Or via config
{
  "logLevel": "debug",
  "logFormat": "json",
  "logDestination": "/var/log/openclaw/gateway.log"
}
```

### Structured Logging

```bash
# JSON logs for ELK/Splunk
journalctl -u openclaw -o json | jq .
```

---

## System Requirements

- **Node.js:** ≥22.0.0
- **RAM:** 8GB minimum (4GB for single instance, 8GB+ for prod)
- **Disk:** 20GB SSD minimum
- **CPU:** 2 cores minimum (4+ cores recommended)
- **Network:** 100Mbps+ upstream, low-latency
- **KVM Virtualization:** Required for cloud VPS
- **TLS/SSL:** Required for production

---

## Security Best Practices

- Enable sandbox mode in production
- Use strong API keys (32+ characters)
- Rotate credentials every 90 days
- Enable network isolation (firewalls)
- Use secrets manager (Vault, AWS Secrets Manager)
- Enable audit logging
- Regular security updates

---

## Gateway API Endpoints

```bash
GET /health          # Quick health check
GET /ready           # Readiness probe
GET /status          # Detailed status
POST /webhooks/:service  # Receive messages
GET /api/services    # List connected services
GET /api/messages    # Message history
POST /api/send       # Send messages
```

---

## Process Management

### Systemd (Linux)

```bash
systemctl start openclaw
systemctl stop openclaw
systemctl restart openclaw
systemctl status openclaw
systemctl enable openclaw
```

### Launchd (macOS)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>io.openclaw.gateway</string>
    <key>Program</key>
    <string>/usr/local/bin/openclaw</string>
    <key>Arguments</key>
    <array>
        <string>daemon</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
</dict>
</plist>
```

### PM2 (Node.js)

```bash
pm2 start openclaw --name "gateway" --instances max
pm2 save
pm2 startup
```

---

## Updating

### Version Management

```bash
# Check current version
openclaw --version

# Upgrade to latest stable
npm upgrade -g openclaw

# Beta channel
npm install -g openclaw@beta

# Development builds
npm install -g openclaw@dev

# Specific version
npm install -g openclaw@22.1.0
```

### Rollback Strategy

```bash
# Keep previous version
npm install -g openclaw@22.0.0

# Test
openclaw health

# If failing, revert
npm install -g openclaw@21.9.5
systemctl restart openclaw
```

---

## See Also

- `/references/deployment-guide.md` - Detailed deployment patterns
- OpenClaw Documentation: https://docs.openclaw.io
- Community: https://github.com/openclaw/openclaw-gateway
