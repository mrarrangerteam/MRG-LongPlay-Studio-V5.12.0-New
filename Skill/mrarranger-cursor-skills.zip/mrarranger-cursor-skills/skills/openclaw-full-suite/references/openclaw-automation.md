---
name: openclaw-automation
description: |
  OpenClaw Automation ระบบ Cron Jobs, Webhooks, Browser Control, Voice, Canvas ครบวงจร
  Scheduled Tasks, External Triggers, Gmail Pub/Sub, GitHub Integration, Browser Automation
  ใช้เมื่อ: (1) ตั้ง Cron Job (2) สร้าง Webhook (3) Browser Automation
  (4) Voice/Talk Mode (5) Canvas (6) Session Management (7) Workflow Automation
  Commands: /cron, /webhook, /browser, /voice, /canvas, /session, /recipe
keywords:
  - automation
  - cron-jobs
  - webhooks
  - browser-automation
  - voice-mode
  - task-scheduling
  - email-integration
  - github-integration
---

# OpenClaw Automation - ระบบ Automation ครบวงจร

ระบบ Automation ของ OpenClaw ให้คุณสามารถออกแบบ Agent ที่ทำงานอัตโนมัติตามตารางเวลา (Cron) ตอบสนองต่อ Webhook ควบคุมเบราว์เซอร์ และใช้ Voice Mode ได้อย่างสมบูรณ์

## Table of Contents

1. [Cron Jobs](#cron-jobs)
2. [Webhooks](#webhooks)
3. [Browser Automation](#browser-automation)
4. [Canvas & Visual Content](#canvas--visual-content)
5. [Voice & Talk Mode](#voice--talk-mode)
6. [Sessions Management](#sessions-management)
7. [Nodes & Workflows](#nodes--workflows)
8. [Discord/Slack Actions](#discordslack-actions)
9. [Integration Platforms](#integration-platforms)
10. [Real-world Recipes](#real-world-recipes)

---

## Cron Jobs

### Configuration Structure

Cron Jobs จัดตารางงานให้ Agent ทำงานอัตโนมัติตามเวลาที่กำหนด ตั้งค่าใน `openclaw.json` ภายใต้ `automation.cron`

```jsonc
{
  "automation": {
    "cron": [
      {
        "schedule": "0 9 * * *",           // Cron expression (min hour day month weekday)
        "message": "สรุปข่าววันนี้",         // Message/prompt for agent
        "channel": "whatsapp",              // Target channel: whatsapp, discord, slack, telegram
        "agent": "general",                 // Agent name to execute
        "description": "Daily news summary" // Optional description
      }
    ]
  }
}
```

### Cron Expression Syntax

**Format:** `minute hour day-of-month month day-of-week`

- **minute** (0-59): ลาดับที่ของนาที
- **hour** (0-23): ชั่วโมง (24-hour format)
- **day** (1-31): วันของเดือน
- **month** (1-12): เดือน
- **weekday** (0-6): วันในสัปดาห์ (0=Sunday, 1=Monday, ... 6=Saturday)

### Common Patterns

```jsonc
"0 9 * * *"        // Every day at 9:00 AM
"0 9 * * 1-5"      // Weekdays (Monday-Friday) at 9:00 AM
"0 12 * * 0"       // Every Sunday at 12:00 noon
"*/15 * * * *"     // Every 15 minutes
"0 */6 * * *"      // Every 6 hours
"0 9,17 * * *"     // At 9:00 AM and 5:00 PM daily
"0 0 1 * *"        // First day of each month at midnight
"0 9 * * MON"      // Every Monday at 9:00 AM (named)
```

### Multi-Agent Cron Configuration

```jsonc
{
  "automation": {
    "cron": [
      {
        "schedule": "0 9 * * *",
        "message": "สรุปข่าววันนี้",
        "channel": "whatsapp",
        "agent": "general"
      },
      {
        "schedule": "0 17 * * *",
        "message": "ตรวจสอบ PR ใหม่บน GitHub",
        "channel": "discord",
        "agent": "coder"
      },
      {
        "schedule": "0 0 * * 0",
        "message": "รายงานสัปดาห์: สรุปสถิติการใช้งาน",
        "channel": "slack",
        "agent": "analytics"
      }
    ]
  }
}
```

### Cron With Context

ส่งข้อมูล context พิเศษให้ Agent:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "ดึงข่าวเกี่ยวกับ {topic}",
  "channel": "whatsapp",
  "agent": "news",
  "context": {
    "topic": "เทคโนโลยี",
    "language": "th",
    "sources": ["techcrunch", "medium"]
  }
}
```

---

## Webhooks

### Overview

Webhooks เป็นจุดเข้าทางชั่วโมงสำหรับการเรียก Agent จากระบบภายนอก เช่น GitHub Gmail หรือการแจ้งเตือนจากแพลตฟอร์มอื่น

### Basic Webhook Configuration

```jsonc
{
  "automation": {
    "webhooks": {
      "enabled": true,
      "endpoints": [
        {
          "path": "/webhook/github",
          "secret": "your-github-secret-key",
          "agent": "coder",
          "events": ["push", "pull_request", "issues"]
        },
        {
          "path": "/webhook/gmail",
          "secret": "your-gmail-secret",
          "agent": "email-handler"
        }
      ]
    }
  }
}
```

### GitHub Webhook Integration

ตั้ง GitHub Webhook เพื่อให้ OpenClaw Agent ตอบสนองต่อเหตุการณ์ GitHub:

```jsonc
{
  "path": "/webhook/github",
  "secret": "my-github-webhook-secret",
  "agent": "coder",
  "events": ["push", "pull_request", "issues", "release"],
  "handlers": {
    "push": {
      "message": "ตรวจสอบ commits: {repository} - {branch}",
      "channel": "discord"
    },
    "pull_request": {
      "message": "PR ใหม่: {title} โดย {author}",
      "channel": "slack"
    }
  }
}
```

### Gmail Pub/Sub Webhook

ใช้ Gmail Pub/Sub เพื่อรับการแจ้งเตือนอีเมลแบบ real-time:

```jsonc
{
  "path": "/webhook/gmail",
  "secret": "gmail-pubsub-key",
  "agent": "email-processor",
  "config": {
    "projectId": "your-gcp-project",
    "topicName": "projects/your-project/topics/gmail-notifications",
    "labels": ["important", "action-required"],
    "auto-respond": true
  }
}
```

### Custom Webhook Endpoints

สร้าง endpoint ที่กำหนดเองได้:

```jsonc
{
  "path": "/webhook/custom/process-order",
  "secret": "custom-secret-123",
  "agent": "order-handler",
  "method": ["POST", "PUT"],
  "auth": "bearer-token",
  "rateLimit": {
    "maxRequests": 100,
    "windowMs": 60000
  }
}
```

### Webhook Security Best Practices

1. **Secret Management**: เก็บ secret ไว้ใน environment variables
2. **HTTPS Only**: ใช้ HTTPS สำหรับ webhook endpoints ทั้งหมด
3. **Signature Verification**: ตรวจสอบลายเซ็น HMAC
4. **Rate Limiting**: ตั้งค่า rate limits เพื่อป้องกัน abuse
5. **Payload Validation**: ตรวจสอบเนื้อหา webhook payload

---

## Browser Automation

### Dedicated OpenClaw Browser

OpenClaw ใช้ Chrome/Chromium แบบ dedicated สำหรับ automation tasks:

```jsonc
{
  "browser": {
    "enabled": true,
    "headless": false,
    "timeout": 30000,
    "viewport": {
      "width": 1280,
      "height": 720
    }
  }
}
```

### Common Automation Patterns

**Form Filling:**
```
1. Navigate to URL
2. Find form fields (CSS selector or XPath)
3. Fill fields with data
4. Submit form
5. Capture result/screenshot
```

**Web Scraping:**
```
1. Navigate to target page
2. Execute JavaScript to extract data
3. Parse HTML with selectors
4. Store/return structured data
5. Handle pagination if needed
```

**Screenshot & Snapshots:**
- `.snapshot()` - Capture current page state
- `.takeScreenshot()` - Save image file
- Canvas push for visual feedback

**Browser Profile Management:**
- Store authentication cookies
- Maintain user sessions
- Cache credentials securely

---

## Canvas & Visual Content

### Push & Reset

**A2UI Push** - ส่งเนื้อหาไปยัง UI:

```
canvas.push({
  type: "image",
  url: "data:image/png;base64,...",
  title: "Result Screenshot"
})
```

**Reset Canvas** - ล้าง Canvas state:

```
canvas.reset()
```

### Eval & Snapshot

**Eval** - ประเมินค่า JavaScript:

```
result = canvas.eval("document.title")
```

**Snapshot** - บันทึก current state:

```
state = canvas.snapshot()
```

### Rendering Visual Content

- HTML rendering with custom CSS
- Chart generation (Chart.js, D3.js)
- PDF generation
- SVG graphics
- Live updates via WebSocket

---

## Voice & Talk Mode

### Wake Words (macOS/iOS)

ตั้งค่า wake words เพื่อเริ่มต้นการสนทนา:

```jsonc
{
  "voice": {
    "enabled": true,
    "wakeWords": [
      "Hey OpenClaw",
      "OpenClaw",
      "สวัสดีเคลาว์"
    ],
    "languages": ["en-US", "th-TH"],
    "continuous": false
  }
}
```

### Continuous Voice (Android)

สำหรับ Android ใช้ Continuous Voice Mode:

```jsonc
{
  "voice": {
    "enabled": true,
    "platform": "android",
    "continuousMode": true,
    "silenceTimeout": 2000,
    "maxDuration": 60000
  }
}
```

### Text-to-Speech (TTS) Integration

**ElevenLabs TTS** (Premium voices):

```jsonc
{
  "tts": {
    "provider": "elevenlabs",
    "apiKey": "your-elevenlabs-key",
    "voiceId": "21m00Tcm4TlvDq8ikWAM",
    "language": "th"
  }
}
```

**System TTS Fallback**:

```jsonc
{
  "tts": {
    "provider": "system",
    "language": "th-TH",
    "rate": 1.0,
    "pitch": 1.0
  }
}
```

### Voice Commands

Define voice command handlers:

```jsonc
{
  "voiceCommands": [
    {
      "command": "read news",
      "agent": "news-reader",
      "tts": true
    },
    {
      "command": "create reminder",
      "agent": "reminder",
      "context": "reminder"
    }
  ]
}
```

---

## Sessions Management

### Session Creation & Routing

```jsonc
{
  "sessions": {
    "autoCreate": true,
    "persist": true,
    "ttl": 3600,
    "channels": {
      "whatsapp": {
        "sessionPrefix": "wa_",
        "persistMemory": true
      },
      "discord": {
        "sessionPrefix": "dc_",
        "threadBased": true
      }
    }
  }
}
```

### Session Memory & Context

ประเมินโครงสร้าง session:

```
{
  "sessionId": "wa_1234567890",
  "userId": "user123",
  "channel": "whatsapp",
  "createdAt": "2026-03-15T10:30:00Z",
  "lastActivity": "2026-03-15T10:45:30Z",
  "memory": {
    "userName": "สมชาย",
    "language": "th",
    "preferences": { "timezone": "Asia/Bangkok" }
  },
  "context": {
    "agent": "general",
    "topic": "news"
  }
}
```

### Cross-Channel Sessions

ให้ Agent ทำงานข้าม channels:

```jsonc
{
  "crossChannel": {
    "enabled": true,
    "linkedChannels": ["whatsapp", "discord", "telegram"],
    "shareMemory": true,
    "syncInterval": 5000
  }
}
```

---

## Nodes & Workflows

### Node-Based Execution

ใช้ Node system เพื่อสร้าง workflow:

```jsonc
{
  "nodes": [
    {
      "id": "node1",
      "type": "agent",
      "agent": "data-fetcher",
      "input": "fetch_news"
    },
    {
      "id": "node2",
      "type": "agent",
      "agent": "summarizer",
      "input": "${node1.output}"
    },
    {
      "id": "node3",
      "type": "send",
      "channel": "whatsapp",
      "message": "${node2.output}"
    }
  ]
}
```

### Agent Chaining

ต่อ agent เข้าด้วยกัน:

```
node1 (fetch data) → node2 (process) → node3 (send)
                  ↓
            parallel execution
                  ↓
            merge results
```

---

## Discord/Slack Actions

### Platform-Specific Automation

**Discord:**

```jsonc
{
  "discord": {
    "actions": {
      "reaction": {
        "emoji": "👍",
        "trigger": "message_created"
      },
      "threadCreate": {
        "onKeyword": "question",
        "archiveAfter": 86400000
      },
      "roleAssign": {
        "trigger": "react_join",
        "role": "members"
      }
    }
  }
}
```

**Slack:**

```jsonc
{
  "slack": {
    "actions": {
      "reaction": {
        "emoji": "thumbsup",
        "trigger": "message"
      },
      "threadReply": {
        "parent": true,
        "broadcast": false
      },
      "channelOps": {
        "create": "auto_create_channels",
        "archive": "auto_archive_old"
      }
    }
  }
}
```

---

## Integration Platforms

### Webhook Triggers from n8n/Make/Zapier

ใช้ external automation platforms:

```jsonc
{
  "integrations": {
    "n8n": {
      "webhookUrl": "https://your-n8n.com/webhook/openclaw",
      "enabled": true,
      "authentication": "api-key"
    },
    "make": {
      "webhookUrl": "https://hook.integromat.com/...",
      "enabled": true
    },
    "zapier": {
      "webhookUrl": "https://hooks.zapier.com/...",
      "enabled": true
    }
  }
}
```

### Response Routing

ส่งผลลัพธ์กลับไปยัง platform:

```jsonc
{
  "routing": {
    "returnToSender": true,
    "formats": {
      "n8n": "json",
      "make": "json",
      "zapier": "json"
    }
  }
}
```

---

## Real-World Recipes

### 1. Daily News Digest → WhatsApp

ส่งบทสรุปข่าวประจำวันไปยัง WhatsApp:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "ส่งสรุปข่าวประจำวันจากแหล่งข้อมูลที่เชื่อถือได้ในภาษาไทย ควรมีหัวข้อ วันที่ และลิงก์",
  "channel": "whatsapp",
  "agent": "news-summarizer"
}
```

### 2. GitHub PR Notifications → Discord

ได้รับแจ้งเตือนเมื่อมี PR ใหม่:

```jsonc
{
  "path": "/webhook/github",
  "secret": "github-secret",
  "agent": "code-reviewer",
  "events": ["pull_request"],
  "handlers": {
    "pull_request": {
      "message": "@here: PR ใหม่ #{number}: {title}\nauthor: {author}\nfiles changed: {changed_files}",
      "channel": "discord"
    }
  }
}
```

### 3. Email Auto-Response via Gmail Webhook

ตอบอีเมลโดยอัตโนมัติ:

```jsonc
{
  "path": "/webhook/gmail",
  "agent": "email-responder",
  "config": {
    "labels": ["auto-response"],
    "message": "ขอบคุณสำหรับอีเมลของคุณ เราจะติดต่อคุณกลับในเร็ว ๆ นี้"
  }
}
```

### 4. Scheduled Social Media Posting

โพสต์ไป social media ตามตารางเวลา:

```jsonc
{
  "schedule": "0 10,14,18 * * *",
  "message": "สร้างและโพสต์เนื้อหา social media ที่ดึงดูดสำหรับปัจจุบัน",
  "agent": "social-media",
  "context": {
    "platforms": ["twitter", "linkedin", "facebook"],
    "contentType": "engaging-content"
  }
}
```

### 5. Meeting Reminder with Agenda

ส่งเตือนการประชุมพร้อมวาระการประชุม:

```jsonc
{
  "schedule": "0 9 * * 1",
  "message": "ตรวจสอบวาระการประชุมสัปดาห์นี้ ส่งเตือนไปยังผู้เข้าร่วม",
  "agent": "meeting-manager",
  "channel": "slack"
}
```

### 6. Code Review Automation

วิเคราะห์ PR โดยอัตโนมัติ:

```jsonc
{
  "path": "/webhook/github",
  "agent": "code-reviewer",
  "events": ["pull_request"],
  "config": {
    "autoReview": true,
    "checkList": ["tests", "documentation", "performance", "security"]
  }
}
```

### 7. Customer Support Auto-Routing

ส่งอีเมลสนับสนุนไปยัง agent ที่เหมาะสม:

```jsonc
{
  "path": "/webhook/support",
  "agent": "support-router",
  "routing": {
    "billing": "billing-agent",
    "technical": "tech-agent",
    "general": "general-agent"
  }
}
```

### 8. Data Backup Reminders

เตือนการสำรองข้อมูลเป็นประจำ:

```jsonc
{
  "schedule": "0 22 * * 0",
  "message": "ตรวจสอบและตั้งสำรองข้อมูลฐานข้อมูล ส่งรายงานสถานะ",
  "agent": "backup-manager",
  "channel": "slack"
}
```

### 9. Health Check Monitoring

ตรวจสอบสถานะเซิร์ฟเวอร์เป็นประจำ:

```jsonc
{
  "schedule": "*/5 * * * *",
  "message": "ตรวจสอบสถานะเซิร์ฟเวร์และบริการ ส่งการแจ้งเตือนหากมีปัญหา",
  "agent": "health-monitor",
  "channel": "discord",
  "silent": true
}
```

### 10. Weekly Analytics Report

สร้างรายงานวิเคราะห์รายสัปดาห์:

```jsonc
{
  "schedule": "0 8 * * 1",
  "message": "สรุปข้อมูลการวิเคราะห์สัปดาห์ที่ผ่านมา: การเข้าชม ผู้ใช้ คลิก การแปลง",
  "agent": "analytics-reporter",
  "channel": "email",
  "recipients": ["team@example.com"]
}
```

---

## Best Practices

### Security

1. ใช้ environment variables สำหรับ secrets
2. ตรวจสอบลายเซ็น webhook
3. ใช้ HTTPS สำหรับ endpoints ทั้งหมด
4. จำกัดสิทธิ์ agent ตามความเป็นไป

### Performance

1. ตั้งค่า timeout สำหรับ long-running tasks
2. ใช้ async processing เมื่อมีการ
3. Batch operations สำหรับการประมวลผลจำนวนมาก
4. Monitor execution logs และ errors

### Monitoring

1. Implement logging สำหรับ cron jobs
2. Alert on failures
3. Track execution metrics
4. Audit automation actions

---

## Commands Reference

```
/cron              - Manage cron job schedules
/cron list         - List all active cron jobs
/cron add          - Add new cron job
/cron remove       - Remove cron job

/webhook           - Manage webhooks
/webhook list      - List active webhooks
/webhook test      - Test webhook endpoint

/browser           - Browser automation commands
/browser screenshot - Take screenshot
/browser navigate  - Navigate to URL

/voice             - Voice control commands
/voice start       - Start voice input
/voice stop        - Stop voice input

/canvas            - Canvas manipulation
/canvas push       - Push content to canvas
/canvas reset      - Reset canvas state

/session           - Session management
/session list      - List active sessions
/session memory    - View session memory

/recipe            - Automation recipes
/recipe list       - List available recipes
/recipe create     - Create custom recipe
```

---

สำหรับรายละเอียดเพิ่มเติม ดูไฟล์ `references/automation-patterns.md` สำหรับรูปแบบขั้นสูง ตัวอย่างการใช้งาน และการแก้ไขปัญหา
