# Agent Deep Dive - Architecture & Implementation

## Table of Contents

1. Agent Architecture
2. File Structure & Hierarchy
3. System Prompt Injection
4. State Management
5. Communication Protocols
6. Workspace Isolation
7. Memory Persistence
8. Tool Lifecycle
9. Multi-Agent Orchestration
10. Enterprise Considerations

---

## 1. Agent Architecture

### System Layers

```
┌─────────────────────────────────────────────┐
│  OpenClaw CLI Interface                     │
│  (agent list, agent --message, etc.)        │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│  Agent Dispatcher & Router                  │
│  - Task routing by type/expertise           │
│  - Channel binding resolution               │
│  - Load balancing (multi-instance)          │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│  Agent State Manager                        │
│  - Load SOUL.md, AGENTS.md, etc.            │
│  - Merge configs from multiple sources      │
│  - Apply user constraints                   │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│  System Prompt Constructor                  │
│  - Base model instructions                  │
│  - SOUL.md personality injection            │
│  - USER.md preferences                      │
│  - Tool declarations from TOOLS.md          │
│  - Context from MEMORY.md                   │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│  Model Execution                            │
│  (Claude API with constructed prompt)       │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│  Output Processing & Response Handler       │
│  - Tool invocation handling                 │
│  - Response formatting (per USER.md)        │
│  - Memory updates from session              │
│  - Channel delivery (Slack/Discord/etc.)    │
└─────────────────────────────────────────────┘
```

### Personality Injection Stack

When an agent is instantiated, system prompt is built in this order:

```
1. BASE_SYSTEM_PROMPT
   └─ Core Claude behavior

2. AGENT_SYSTEM_ROLE
   └─ Agent's defined role and capabilities

3. <<<SOUL.MD>>>
   └─ Personality, values, tone, boundaries
   └─ Overrides base instructions on behavioral patterns

4. <<<USER.MD>>>
   └─ Communication preferences
   └─ Output formatting requirements
   └─ Project-specific constraints

5. <<<MEMORY.MD>>>
   └─ Previous learnings
   └─ Expertise map
   └─ Known limitations

6. <<<TOOLS.MD>>>
   └─ Available tools and tool usage rules
   └─ Tool-specific constraints

7. CURRENT_CONTEXT
   └─ Conversation history
   └─ Task-specific briefing
```

**Result**: Fully personalized system prompt unique to each agent-user pair.

---

## 2. File Structure & Hierarchy

### Complete Agent Directory Structure

```
~/.openclaw/agents/
├── agents.list                 # Registry of all agents
├── agents.config               # Global agent settings
│
├── codemaster/                 # Agent instance
│   ├── SOUL.md                 # Personality foundation (PRIMARY)
│   ├── AGENTS.md               # Behavior config & defaults
│   ├── USER.md                 # User context & preferences
│   ├── IDENTITY.md             # Presentation & channel info
│   ├── MEMORY.md               # Long-term learning & context
│   ├── TOOLS.md                # Tool capabilities & limits
│   │
│   ├── skills/                 # Agent-specific skill files
│   │   ├── code-analyzer.skill/
│   │   │   ├── SKILL.md
│   │   │   └── tools/
│   │   ├── test-generator.skill/
│   │   └── refactor-suggester.skill/
│   │
│   ├── sessions/               # Session history
│   │   ├── 2026-03-15_090000.json
│   │   ├── 2026-03-15_150000.json
│   │   └── index.json          # Session index
│   │
│   ├── memory/                 # Memory storage
│   │   ├── projects.json       # Project learnings
│   │   ├── patterns.json       # Discovered patterns
│   │   └── metrics.json        # Performance metrics
│   │
│   ├── auth/                   # Authentication profiles
│   │   ├── github.token
│   │   ├── slack.token
│   │   └── anthropic.key
│   │
│   ├── workspace/              # Runtime workspace
│   │   ├── temp/               # Temporary files
│   │   ├── cache/              # Cache directory
│   │   └── log/                # Agent logs
│   │
│   └── snapshots/              # State snapshots
│       ├── pre-deployment.snapshot
│       └── baseline.snapshot
│
├── docwriter/
│   ├── SOUL.md
│   ├── AGENTS.md
│   ├── USER.md
│   ├── IDENTITY.md
│   ├── MEMORY.md
│   ├── TOOLS.md
│   ├── skills/
│   ├── sessions/
│   ├── memory/
│   └── workspace/
│
└── researcher/
    └── [similar structure]
```

### File Responsibilities

| File | Purpose | Scope | Frequency |
|------|---------|-------|-----------|
| **SOUL.md** | Core personality & values | Agent-wide | Load on wake |
| **AGENTS.md** | Behavior config & defaults | Agent-wide | Load on wake |
| **USER.md** | User preferences & constraints | User + Agent | Load per message |
| **IDENTITY.md** | Display & channel config | Agent-wide | Load on init |
| **MEMORY.md** | Learned patterns & context | Agent-wide | Update end of session |
| **TOOLS.md** | Tool declarations & limits | Agent-wide | Load on wake |

---

## 3. System Prompt Injection

### SOUL.md Injection Example

**Input SOUL.md:**
```markdown
# SOUL - Core Identity

## Values
- Clarity over cleverness
- Test-driven development
- Explain all edge cases

## Tone
- Technical and direct
- Curious about tradeoffs
- Growth-oriented

## Boundaries
- Never approve deployment without review
- Always include test coverage reasoning
- Stop before production changes
```

**Result in System Prompt:**
```
[PERSONALITY LAYER START]

# SOUL - Core Identity

## Values
- Clarity over cleverness
- Test-driven development
- Explain all edge cases

## Tone
- Technical and direct
- Curious about tradeoffs
- Growth-oriented

## Boundaries
- Never approve deployment without review
- Always include test coverage reasoning
- Stop before production changes

[PERSONALITY LAYER END]

You are operating within this personality framework. All responses must align 
with the values, tone, and boundaries defined above.
```

### Multi-Config Merging

When multiple configs apply, resolution order is:

```
1. SOUL.md values (highest priority - personality)
2. USER.md preferences (user-specific overrides)
3. AGENTS.md defaults (fallback)
4. Global settings (lowest priority)

Example: Tool usage decision
├─ SOUL.md says: "Explain reasoning before using tools"
├─ USER.md says: "Be concise in outputs"
├─ AGENTS.md says: "Use tools liberally"
└─ Result: Concise explanations before tool use
```

---

## 4. State Management

### Agent State Lifecycle

```
INITIALIZATION
  ↓
Load agent from ~/.openclaw/agents/<id>
  ├─ Read SOUL.md
  ├─ Read AGENTS.md
  ├─ Read IDENTITY.md
  ├─ Read TOOLS.md
  └─ Load last snapshot (if exists)
  ↓
BUILD SYSTEM PROMPT
  ├─ Inject SOUL.md
  ├─ Merge with USER.md
  ├─ Add MEMORY.md context
  ├─ Load available TOOLS.md
  └─ Construct final prompt
  ↓
EXECUTION
  ├─ Receive message from user/system
  ├─ Process with all tools available
  ├─ Make decisions per SOUL.md
  ├─ Follow USER.md formatting
  └─ Maintain session context
  ↓
SESSION END
  ├─ Extract learnings from conversation
  ├─ Update MEMORY.md if needed
  ├─ Save session to sessions/
  ├─ Update workspace metadata
  └─ Persist final state
```

### State Storage

**Persistent State** (survives agent restart):
- SOUL.md, AGENTS.md, USER.md, IDENTITY.md, TOOLS.md (config)
- MEMORY.md (learned patterns)
- auth/ (credentials)
- sessions/ (conversation history)

**Ephemeral State** (lost on restart):
- workspace/temp/ (temporary files)
- workspace/cache/ (runtime cache)
- Current conversation context
- Tool invocation state

---

## 5. Communication Protocols

### Intra-Agent Message Format

```json
{
  "messageId": "msg-20260315-001",
  "timestamp": "2026-03-15T10:30:00Z",
  "fromAgent": "codemaster",
  "toAgent": "docwriter",
  "messageType": "delegation",
  "taskId": "code-review-task-123",
  "priority": "high",
  
  "context": {
    "codeLocation": "/path/to/modified/files",
    "changes": [
      "refactored authentication module",
      "added type safety improvements",
      "implemented error handling"
    ],
    "requirements": [
      "document API changes",
      "provide migration guide",
      "include examples"
    ],
    "deadline": "2026-03-16T09:00:00Z"
  },
  
  "handoffData": {
    "fileStructure": {...},
    "functionSignatures": [...],
    "breakingChanges": [...],
    "performanceNotes": [...]
  },
  
  "acknowledgment": {
    "required": true,
    "timeout": 300
  }
}
```

### Task Handoff Protocol

**Phase 1: Delegation Request**
```
codemaster → docwriter
  message: "I've reviewed and refactored auth module"
  expectation: "Create API documentation"
  deadline: "2 hours"
```

**Phase 2: Acknowledgment**
```
docwriter → codemaster
  status: "acknowledged"
  estimatedCompletion: "1.5 hours"
  questions: [...]
```

**Phase 3: Execution**
```
docwriter processes task with full context
  - Uses codemaster's SOUL.md learning if applicable
  - Updates own MEMORY.md with new patterns
  - Tracks task progress
```

**Phase 4: Handoff Return**
```
docwriter → codemaster
  result: "Documentation completed"
  artifacts: ["API_DOCS.md", "MIGRATION_GUIDE.md"]
  feedback: "Suggested refactoring in auth types"
```

**Phase 5: Completion**
```
Both agents update MEMORY.md:
  - Pattern learned
  - Execution metrics
  - Effectiveness notes
Task marked complete in task log
```

---

## 6. Workspace Isolation

### Per-Agent Workspace

Each agent has isolated workspace to prevent interference:

```
Agent A Workspace                  Agent B Workspace
├── workspace/                     ├── workspace/
│   ├── temp/                      │   ├── temp/
│   │   └── analysis_a.tmp         │   │   └── analysis_b.tmp
│   ├── cache/                     │   ├── cache/
│   └── lock files                 │   └── lock files
│
├── sessions/                      ├── sessions/
│   └── current_session.json       │   └── current_session.json
│
└── memory/                        └── memory/
    └── learned_patterns.json          └── learned_patterns.json
```

### Resource Limits

```yaml
# Per-agent resource constraints (in AGENTS.md)

resourceLimits:
  memory:
    maxSessionMemory: "512MB"
    maxMemoryFileSize: "50MB"
    
  disk:
    maxWorkspaceSize: "1GB"
    maxSessionHistory: "500"
    
  api:
    maxTokensPerRequest: 100000
    maxRequestsPerHour: 1000
    maxConcurrentRequests: 3
    
  execution:
    maxToolCallsPerSession: 100
    maxExecutionTime: "1 hour"
    timeoutPerTool: "30 seconds"
```

---

## 7. Memory Persistence

### MEMORY.md Structure

```yaml
memory:
  version: 2
  lastUpdated: 2026-03-15T10:30:00Z
  
  # Episodic memory - what happened
  episodes:
    - id: "project-alpha-v1-migration"
      timestamp: 2026-03-10
      projectName: "project-alpha"
      task: "TypeScript migration"
      outcome: "success"
      keyLearning: "Strict mode adoption works best incrementally"
      metrics:
        duration: "5 days"
        filesModified: 234
        testCoverage: "85%"
      artifacts:
        - "docs/typescript-strategy.md"
        - "scripts/migration-helpers.ts"
  
  # Semantic memory - what we know
  patterns:
    - pattern: "incremental-migration"
      applicableTo: ["typescript", "dependency-upgrades", "api-changes"]
      bestPractices:
        - Start with non-critical modules
        - Maintain backwards compatibility phase
        - Use feature flags for gradual rollout
      cautionPoints:
        - Timeline estimates often 1.5x longer
        - Requires clear communication with team
    
    - pattern: "code-review-effectiveness"
      finding: "Early architectural feedback > late implementation feedback"
      evidence:
        - Reduced rework by 40%
        - Improved team velocity
        - Higher code quality metrics
  
  # Expertise map
  expertise:
    typescript:
      level: 5  # 1-5 scale
      domains: ["type-systems", "strict-mode", "generics"]
      recentProjects: ["project-alpha", "project-beta"]
      confidence: "high"
    
    architectureDesign:
      level: 4
      domains: ["microservices", "event-driven", "api-design"]
      recentProjects: ["multi-service-refactor"]
      confidence: "medium"
    
    devOps:
      level: 2
      domains: ["ci-cd", "docker"]
      recentProjects: []
      confidence: "low"
  
  # Known limitations
  boundaries:
    - "Cannot make deployment decisions alone"
    - "Security review requires domain expert"
    - "Production database changes out of scope"
    - "Real-time system debugging limited"
  
  # Session notes (working memory)
  currentSessionNotes:
    - "Discussed token optimization in code-review-task-123"
    - "Learned: team prefers early feedback over detailed analysis"
    - "Action item: update response generation strategy"
```

### Memory Update Triggers

```
Session ends → Extract insights:
  ├─ New patterns discovered?
  │   └─ Add to patterns: section
  ├─ Expertise areas touched?
  │   └─ Update expertise levels + recentProjects
  ├─ New boundaries discovered?
  │   └─ Add to boundaries: section
  ├─ Task outcomes?
  │   └─ Record in episodes:
  └─ Critical learnings?
      └─ Flag for team review
```

---

## 8. Tool Lifecycle

### Tool Declaration (TOOLS.md)

```yaml
tools:
  enabled:
    - id: "codeAnalysis"
      name: "Code Analysis Tool"
      description: "Analyzes code for quality, performance, security"
      
      # Capabilities this agent can access
      capabilities:
        - staticAnalysis
        - typeAnalysis
        - securityScan
        - performanceProfile
      
      # Tool-specific constraints
      constraints:
        maxFilesPerCall: 10
        maxFileSizeBytes: 1048576  # 1MB
        supportedLanguages: ["typescript", "python", "javascript"]
      
      # Rate limiting
      rateLimit:
        callsPerHour: 100
        burstLimit: 10
      
      # Accuracy/freshness requirements
      requirements:
        minConfidenceThreshold: 0.8
        requiresHumanValidation: false
      
      # When to use this tool
      triggers:
        - "code quality questions"
        - "performance investigation"
        - "security concerns"
      
      # When NOT to use
      exclusions:
        - "no external code"
        - "no production data"
        - "no unvetted third-party libs"
```

### Tool Invocation Flow

```
Agent receives query
  ↓
Check TOOLS.md for enabled tools
  ├─ Tool enabled?
  ├─ Within rate limits?
  ├─ Has required capabilities?
  └─ Meets constraints?
  ↓
Invoke tool with safety wrappers
  ├─ Validate input parameters
  ├─ Check file access permissions
  ├─ Apply size/scope limits
  └─ Execute with timeout
  ↓
Process results
  ├─ Validate output
  ├─ Merge with SOUL.md guidance
  ├─ Apply USER.md formatting
  └─ Return to conversation
  ↓
Track usage
  ├─ Update tool invocation count
  ├─ Record success/failure
  ├─ Update MEMORY.md metrics
  └─ Check against limits
```

### Custom Tool Registration

```yaml
# Custom tools in agent's tools/ directory

customTools:
  - id: "company-api"
    type: "http"
    endpoint: "https://api.company.internal/v1"
    authentication: "bearer-token"
    tokenPath: "~/.openclaw/agents/my-agent/auth/company.token"
    
    operations:
      - name: "getProjectMetrics"
        method: "GET"
        path: "/projects/{projectId}/metrics"
        parameters:
          - name: projectId
            type: string
            required: true
    
    rateLimit:
      requestsPerSecond: 10
    
    errorHandling:
      retryableErrors: [429, 503]
      maxRetries: 3
```

---

## 9. Multi-Agent Orchestration

### Routing Configuration

```yaml
# ~/.openclaw/agents.config

routing:
  # Route by task type
  byTaskType:
    "code-review": "codemaster"
    "documentation": "docwriter"
    "research": "researcher"
    "testing": "testbot"
    "devops": "devopsbot"
  
  # Route by expertise (when primary unavailable)
  byExpertise:
    "typescript":
      primary: "codemaster"
      fallback: ["testbot", "devopsbot"]
      
    "system-design":
      primary: "architect"
      fallback: ["codemaster", "researcher"]
  
  # Route by account (multi-tenant)
  byAccount:
    "acme-corp":
      agents: ["codemaster-acme", "docwriter-acme", "researcher-acme"]
      exclusive: true  # use only these agents
    
    "tech-startup":
      agents: ["codemaster", "docwriter", "researcher"]
      exclusive: false  # can use shared agents
  
  # Load balancing
  loadBalancing:
    strategy: "least-busy"  # least-busy|round-robin|weighted
    
    weights:
      codemaster: 1.0
      testbot: 0.8
      docwriter: 1.0
  
  # Fallback chain
  fallback:
    - primary agent unavailable
    - try agents with similar expertise
    - use general-purpose agent
    - queue and wait
```

### Agent Discovery & Selection

```
User submits task: "Review this TypeScript file"
  ↓
Dispatcher analyzes task
  ├─ Task type: code-review
  ├─ Primary language: typescript
  ├─ Complexity: high
  └─ Deadline: none
  ↓
Consult routing config
  ├─ Task type → codemaster
  ├─ Check availability
  ├─ Check workload
  └─ Verify has typescript expertise
  ↓
Route to codemaster
  ├─ Load SOUL.md (personality)
  ├─ Load AGENTS.md (config)
  ├─ Load MEMORY.md (context)
  └─ Construct system prompt
  ↓
Execute with full context
  └─ Return results to user
```

### Agent Collaboration Pattern

```
Team task: "Implement auth module"

1. Codemaster (architect)
   └─ Designs structure, creates skeleton

2. CodeMaster → Testbot (delegation)
   └─ Generates test suite

3. Testbot → Codemaster (feedback)
   └─ Reports on design issues

4. Codemaster (refactor)
   └─ Updates design based on test insights

5. Codemaster → DocWriter (delegation)
   └─ Requests documentation

6. DocWriter → Codemaster (clarification)
   └─ Asks for usage examples

7. Codemaster (update)
   └─ Provides examples and migration guide

8. All agents update MEMORY.md
   └─ Patterns learned, metrics recorded
```

---

## 10. Enterprise Considerations

### Multi-Tenant Setup

```yaml
# Enterprise configuration with multiple teams

tenants:
  acme-corp:
    id: "tenant-acme-123"
    name: "ACME Corporation"
    
    agents:
      codemaster-acme:
        baseAgent: "codemaster"
        customizations:
          - SOUL.md: append ACME-specific values
          - TOOLS.md: restrict to approved tools
          - USER.md: apply ACME preferences
      
      docwriter-acme:
        baseAgent: "docwriter"
        customizations:
          - IDENTITY.md: use ACME branding
          - TOOLS.md: limit to internal wiki
    
    constraints:
      noExternalAPIs: true
      requiresApprovalFor: ["documentation_publication", "code_sharing"]
      encryptionRequired: true
      auditLogging: "verbose"
    
    resources:
      agentWorkspaceQuota: "5GB per agent"
      monthlyTokenLimit: 1000000
      concurrentAgents: 5

  tech-startup:
    id: "tenant-startup-456"
    name: "Tech Startup Inc"
    
    agents: [default pool]
    constraints:
      noExternalAPIs: false
      requiresApprovalFor: []
    
    resources:
      agentWorkspaceQuota: "1GB per agent"
      monthlyTokenLimit: 100000
      concurrentAgents: 2
```

### Audit & Compliance

```yaml
# Audit trail configuration

auditConfig:
  # What to track
  tracking:
    agentActions: true
    toolInvocations: true
    memoryUpdates: true
    configChanges: true
    accessLog: true
  
  # Where to store
  storage:
    backend: "elasticsearch"  # or "local", "cloud-storage"
    retention: "2 years"
    encryption: "AES-256"
  
  # What to report
  reportingRequirements:
    - type: "daily_summary"
      recipient: "ops-team@company.com"
      includes: ["agent_activity", "error_rates", "usage_metrics"]
    
    - type: "compliance_audit"
      frequency: "monthly"
      recipient: "security@company.com"
      includes: ["access_patterns", "data_modifications", "tool_usage"]

# Audit log entry
auditLog:
  - timestamp: 2026-03-15T10:30:00Z
    agentId: "codemaster"
    userId: "engineer@acme.com"
    action: "memory_update"
    details: "Updated expertise level for typescript"
    affectedResources: ["MEMORY.md"]
    result: "success"
    ipAddress: "192.168.1.100"
```

### Governance & Approval

```yaml
# Approval workflows for sensitive operations

approvalWorkflows:
  
  agentCreation:
    required: true
    approvers: ["team-lead", "security-lead"]
    deadline: "24 hours"
    
  soulMdModification:
    required: false  # agent can self-evolve
    auditRequired: true
    
  toolAddition:
    required: true
    approvers: ["security-lead"]
    reviewChecklist:
      - tool_security_assessment
      - permission_requirements
      - rate_limit_justification
  
  memoryDeletion:
    required: true
    approvers: ["agent-owner", "compliance"]
    retentionPeriod: "30 days"  # grace period
```

---

## Advanced Architecture

### Agent Plugin System

```
~/.openclaw/agents/<id>/plugins/
├── authentication/
│   ├── oauth2-provider.plugin.js
│   ├── jwt-validator.plugin.js
│   └── mfa-handler.plugin.js
│
├── memory/
│   ├── vector-store.plugin.js
│   └── semantic-search.plugin.js
│
└── communication/
    ├── slack-formatter.plugin.js
    └── discord-formatter.plugin.js

# Plugin registration in AGENTS.md
plugins:
  enabled:
    - id: oauth2-provider
      type: authentication
      version: 1.0.0
    - id: semantic-search
      type: memory
      version: 2.1.0
```

### Distributed Agent Execution

```yaml
# For high-volume deployments

distribution:
  mode: "distributed"
  
  # Deploy agents across multiple servers
  deployment:
    - server: "agent-primary-1.company.com"
      agents: ["codemaster", "testbot"]
      loadTarget: 75%
    
    - server: "agent-primary-2.company.com"
      agents: ["docwriter", "researcher"]
      loadTarget: 75%
    
    - server: "agent-secondary.company.com"
      agents: ["codemaster", "docwriter"]  # hot standby
      loadTarget: 0%
  
  # Communication between distributed agents
  meshConfig:
    protocol: "grpc"
    tlsEnabled: true
    handshakeTimeout: "5s"
    healthCheckInterval: "10s"
```

---

## Performance Optimization

### Memory & Cache Strategy

```
Session Start
  ├─ Load SOUL.md (cached after first load)
  ├─ Load AGENTS.md (cached)
  ├─ Load TOOLS.md (cached)
  ├─ Load MEMORY.md (full load, large file)
  │   └─ Build expertise index for fast lookup
  └─ Initialize session context cache
       └─ Cache user preferences from USER.md

During Execution
  ├─ Cache tool lookup results
  ├─ Keep expertise map in hot memory
  ├─ LRU cache for frequently accessed files
  └─ Compress large MEMORY.md episodes not accessed

Session End
  ├─ Flush changes to disk
  ├─ Compress unused data
  └─ Clean temporary files
```

### Token Efficiency

```yaml
# In AGENTS.md

tokenOptimization:
  # Compress repetitive instructions in SOUL.md
  soul:
    compression: true
    checksum: "abc123def"  # include hash to detect changes
  
  # Use references instead of repeating
  memory:
    useReferences: true  # reference previous episodes by ID
    summarizeOldEpisodes: true  # compress old sessions
    maxMemoryTokens: 20000
  
  # Batch operations to reduce prompts
  batchOperations: true
  maxBatchSize: 10
```

---

## Summary

The OpenClaw Agents system provides:

1. **Complete Personality Control**: SOUL.md + supporting files
2. **State Persistence**: Across sessions and teams
3. **Scalability**: From single agent to enterprise multi-agent
4. **Safety & Governance**: Approvals, auditing, boundaries
5. **Integration**: Plugins, custom tools, distributed execution
6. **Learning**: MEMORY.md for continuous improvement

Each agent is a full system with its own identity, workspace, and long-term memory.

---

**Last Updated**: 2026-03-15
**Architecture Version**: 2.0
