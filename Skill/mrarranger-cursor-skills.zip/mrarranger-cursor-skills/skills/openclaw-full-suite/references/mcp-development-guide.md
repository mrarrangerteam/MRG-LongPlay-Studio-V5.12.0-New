# OpenClaw MCP Development Guide - Complete Reference

## Table of Contents

1. [Protocol Deep Dive](#protocol-deep-dive)
2. [Advanced Server Patterns](#advanced-server-patterns)
3. [Integration Examples](#integration-examples)
4. [API Wrapping](#api-wrapping)
5. [Docker Sandboxing](#docker-sandboxing)
6. [Testing & Debugging](#testing--debugging)
7. [Performance Optimization](#performance-optimization)
8. [Security Best Practices](#security-best-practices)
9. [Troubleshooting](#troubleshooting)

---

## Protocol Deep Dive

### JSON-RPC 2.0 Over Stdio

MCP uses JSON-RPC 2.0 for all communication. Every message is newline-delimited JSON.

#### Request Format
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "read_file",
    "arguments": {
      "path": "/etc/hosts"
    }
  }
}
```

#### Response Format
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "127.0.0.1 localhost"
      }
    ]
  }
}
```

#### Error Response
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32603,
    "message": "Internal error",
    "data": {
      "details": "File not found"
    }
  }
}
```

### MCP Lifecycle Messages

**Initialization**
```json
{"jsonrpc": "2.0", "id": 0, "method": "initialize", "params": {}}
```

**Tool Listing**
```json
{"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}
```

**Resource Listing**
```json
{"jsonrpc": "2.0", "id": 2, "method": "resources/list", "params": {}}
```

**Tool Invocation**
```json
{"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
  "name": "my_tool",
  "arguments": {"key": "value"}
}}
```

---

## Advanced Server Patterns

### Pattern 1: Multi-Tool Server with State

```typescript
import { Server, Tool } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

interface AppState {
  userId: string;
  sessionData: Map<string, any>;
  cache: Map<string, any>;
}

class StatefulMCPServer {
  private state: AppState;
  private server: Server;

  constructor() {
    this.state = {
      userId: "",
      sessionData: new Map(),
      cache: new Map(),
    };

    this.server = new Server({
      name: "stateful-server",
      version: "1.0.0",
    });

    this.registerTools();
  }

  private registerTools() {
    // Tool 1: Initialize session
    this.server.tool("init_session", "Initialize user session", {
      type: "object",
      properties: {
        user_id: { type: "string" },
        options: { type: "object" },
      },
      required: ["user_id"],
    });

    // Tool 2: Cache data
    this.server.tool("cache_set", "Cache data in session", {
      type: "object",
      properties: {
        key: { type: "string" },
        value: {},
        ttl: { type: "number", description: "TTL in seconds" },
      },
      required: ["key", "value"],
    });

    // Tool 3: Retrieve cached data
    this.server.tool("cache_get", "Retrieve cached data", {
      type: "object",
      properties: {
        key: { type: "string" },
      },
      required: ["key"],
    });

    // Handle all tool calls
    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        switch (name) {
          case "init_session":
            this.state.userId = args.user_id;
            this.state.sessionData.set("init_time", Date.now());
            return {
              content: [
                {
                  type: "text",
                  text: `Session initialized for user: ${args.user_id}`,
                },
              ],
            };

          case "cache_set":
            const ttl = args.ttl || 3600;
            const expiresAt = Date.now() + ttl * 1000;
            this.state.cache.set(args.key, {
              value: args.value,
              expiresAt,
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Cached: ${args.key}`,
                },
              ],
            };

          case "cache_get":
            const cached = this.state.cache.get(args.key);
            if (!cached) {
              return {
                content: [
                  {
                    type: "text",
                    text: "Cache miss",
                    isError: true,
                  },
                ],
              };
            }
            if (Date.now() > cached.expiresAt) {
              this.state.cache.delete(args.key);
              return {
                content: [
                  {
                    type: "text",
                    text: "Cache expired",
                    isError: true,
                  },
                ],
              };
            }
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify(cached.value),
                },
              ],
            };

          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      }
    );
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Stateful MCP Server started");
  }
}

new StatefulMCPServer().start().catch(console.error);
```

### Pattern 2: Async Long-Running Operations

```typescript
class AsyncOperationServer {
  private server: Server;
  private operations: Map<string, OperationState> = new Map();

  constructor() {
    this.server = new Server({
      name: "async-operations",
      version: "1.0.0",
    });
    this.registerTools();
  }

  private registerTools() {
    // Start async operation
    this.server.tool("start_analysis", "Start long-running analysis", {
      type: "object",
      properties: {
        data_source: { type: "string" },
        analysis_type: { type: "string" },
      },
      required: ["data_source", "analysis_type"],
    });

    // Check operation status
    this.server.tool("check_status", "Check operation status", {
      type: "object",
      properties: {
        operation_id: { type: "string" },
      },
      required: ["operation_id"],
    });

    // Get results
    this.server.tool("get_results", "Get operation results", {
      type: "object",
      properties: {
        operation_id: { type: "string" },
      },
      required: ["operation_id"],
    });

    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        if (name === "start_analysis") {
          const operationId = `op_${Date.now()}`;
          const state: OperationState = {
            id: operationId,
            status: "running",
            progress: 0,
            startTime: Date.now(),
          };

          this.operations.set(operationId, state);

          // Start async work
          this.performAnalysis(operationId, args).catch((err) => {
            state.status = "failed";
            state.error = err.message;
          });

          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({ operation_id: operationId }),
              },
            ],
          };
        }

        if (name === "check_status") {
          const op = this.operations.get(args.operation_id);
          if (!op) {
            return {
              content: [
                {
                  type: "text",
                  text: "Operation not found",
                  isError: true,
                },
              ],
            };
          }

          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  status: op.status,
                  progress: op.progress,
                  elapsed: Date.now() - op.startTime,
                }),
              },
            ],
          };
        }

        if (name === "get_results") {
          const op = this.operations.get(args.operation_id);
          if (!op || op.status !== "completed") {
            return {
              content: [
                {
                  type: "text",
                  text: "Results not ready",
                  isError: true,
                },
              ],
            };
          }

          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(op.results),
              },
            ],
          };
        }

        throw new Error(`Unknown tool: ${name}`);
      }
    );
  }

  private async performAnalysis(opId: string, args: any): Promise<void> {
    const op = this.operations.get(opId)!;

    // Simulate long-running work
    for (let i = 0; i <= 100; i += 10) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      op.progress = i;
    }

    op.status = "completed";
    op.results = {
      summary: "Analysis complete",
      data: { sample: "result" },
    };
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
  }
}

interface OperationState {
  id: string;
  status: "running" | "completed" | "failed";
  progress: number;
  startTime: number;
  error?: string;
  results?: any;
}
```

### Pattern 3: Streaming Content

```typescript
class StreamingServer {
  private server: Server;

  constructor() {
    this.server = new Server({
      name: "streaming-server",
      version: "1.0.0",
    });

    this.server.tool("stream_data", "Stream large dataset", {
      type: "object",
      properties: {
        source: { type: "string" },
        chunk_size: { type: "number" },
      },
      required: ["source"],
    });

    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        if (request.params.name === "stream_data") {
          const chunks: string[] = [];
          const chunkSize = request.params.arguments.chunk_size || 1000;

          // Generate chunks
          for (let i = 0; i < 10; i++) {
            chunks.push(`Chunk ${i}: ${JSON.stringify({ data: Array(chunkSize).fill("x") })}`);
          }

          return {
            content: chunks.map((chunk) => ({
              type: "text",
              text: chunk,
            })),
          };
        }

        throw new Error("Unknown tool");
      }
    );
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
  }
}
```

---

## Integration Examples

### Example 1: GitHub Integration via MCP

```typescript
import { Octokit } from "@octokit/rest";

class GitHubMCPServer {
  private github: Octokit;
  private server: Server;

  constructor(token: string) {
    this.github = new Octokit({ auth: token });
    this.server = new Server({
      name: "github-tools",
      version: "1.0.0",
    });
    this.registerTools();
  }

  private registerTools() {
    this.server.tool("create_issue", "Create GitHub issue", {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        title: { type: "string" },
        body: { type: "string" },
        labels: { type: "array", items: { type: "string" } },
      },
      required: ["owner", "repo", "title"],
    });

    this.server.tool("list_issues", "List repository issues", {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        state: {
          type: "string",
          enum: ["open", "closed", "all"],
        },
      },
      required: ["owner", "repo"],
    });

    this.server.tool("create_pull_request", "Create pull request", {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        title: { type: "string" },
        head: { type: "string", description: "Branch with changes" },
        base: { type: "string", description: "Target branch" },
        body: { type: "string" },
      },
      required: ["owner", "repo", "title", "head", "base"],
    });

    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        try {
          if (name === "create_issue") {
            const response = await this.github.issues.create({
              owner: args.owner,
              repo: args.repo,
              title: args.title,
              body: args.body || "",
              labels: args.labels || [],
            });
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({
                    issue_number: response.data.number,
                    url: response.data.html_url,
                  }),
                },
              ],
            };
          }

          if (name === "list_issues") {
            const response = await this.github.issues.listForRepo({
              owner: args.owner,
              repo: args.repo,
              state: args.state || "open",
              per_page: 30,
            });
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify(
                    response.data.map((issue) => ({
                      number: issue.number,
                      title: issue.title,
                      state: issue.state,
                      url: issue.html_url,
                    }))
                  ),
                },
              ],
            };
          }

          if (name === "create_pull_request") {
            const response = await this.github.pulls.create({
              owner: args.owner,
              repo: args.repo,
              title: args.title,
              head: args.head,
              base: args.base,
              body: args.body || "",
            });
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({
                    pr_number: response.data.number,
                    url: response.data.html_url,
                  }),
                },
              ],
            };
          }

          throw new Error(`Unknown tool: ${name}`);
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `Error: ${error.message}`,
                isError: true,
              },
            ],
          };
        }
      }
    );
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
  }
}

const token = process.env.GITHUB_TOKEN || "";
new GitHubMCPServer(token).start().catch(console.error);
```

### Example 2: Database Query via MCP

```typescript
import { Client } from "pg";

class DatabaseMCPServer {
  private client: Client;
  private server: Server;

  constructor(connectionString: string) {
    this.client = new Client({ connectionString });
    this.server = new Server({
      name: "database-tools",
      version: "1.0.0",
    });
    this.registerTools();
  }

  private registerTools() {
    this.server.tool("execute_query", "Execute SQL query", {
      type: "object",
      properties: {
        query: { type: "string" },
        params: { type: "array", description: "Query parameters" },
      },
      required: ["query"],
    });

    this.server.tool("get_schema", "Get table schema", {
      type: "object",
      properties: {
        table: { type: "string" },
      },
      required: ["table"],
    });

    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        try {
          await this.client.connect();

          if (name === "execute_query") {
            const result = await this.client.query(
              args.query,
              args.params || []
            );
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({
                    rows: result.rows,
                    rowCount: result.rowCount,
                  }),
                },
              ],
            };
          }

          if (name === "get_schema") {
            const result = await this.client.query(
              `SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_name = $1`,
              [args.table]
            );
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify(result.rows),
                },
              ],
            };
          }

          throw new Error(`Unknown tool: ${name}`);
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `Database error: ${error.message}`,
                isError: true,
              },
            ],
          };
        } finally {
          await this.client.end();
        }
      }
    );
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
  }
}

const connStr = process.env.DATABASE_URL || "";
new DatabaseMCPServer(connStr).start().catch(console.error);
```

---

## API Wrapping

### REST API to MCP Server

Convert any REST API into an MCP server:

```typescript
import axios from "axios";

class RESTToMCPAdapter {
  private server: Server;
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
    this.server = new Server({
      name: "rest-api-adapter",
      version: "1.0.0",
    });
    this.registerDynamicTools();
  }

  private registerDynamicTools() {
    // Generic GET tool
    this.server.tool("get_resource", "Fetch resource via GET", {
      type: "object",
      properties: {
        path: { type: "string" },
        params: { type: "object" },
      },
      required: ["path"],
    });

    // Generic POST tool
    this.server.tool("post_resource", "Create resource via POST", {
      type: "object",
      properties: {
        path: { type: "string" },
        data: { type: "object" },
      },
      required: ["path", "data"],
    });

    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        try {
          if (name === "get_resource") {
            const response = await axios.get(`${this.baseUrl}${args.path}`, {
              params: args.params || {},
            });
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify(response.data),
                },
              ],
            };
          }

          if (name === "post_resource") {
            const response = await axios.post(
              `${this.baseUrl}${args.path}`,
              args.data
            );
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify(response.data),
                },
              ],
            };
          }

          throw new Error(`Unknown tool: ${name}`);
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `API Error: ${error.response?.data || error.message}`,
                isError: true,
              },
            ],
          };
        }
      }
    );
  }

  async start() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
  }
}
```

---

## Docker Sandboxing

Run MCP servers in Docker for security:

**Dockerfile**
```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --only=production

COPY server.js .

ENV NODE_ENV=production
ENTRYPOINT ["node", "server.js"]
```

**openclaw.json with Docker**
```jsonc
{
  "mcpServers": {
    "sandboxed-server": {
      "command": "docker",
      "args": [
        "run",
        "--rm",
        "-i",
        "-e", "API_KEY=secret",
        "my-mcp-server:latest"
      ]
    }
  }
}
```

---

## Testing & Debugging

### Unit Testing MCP Tools

```typescript
import { describe, it, expect } from "@jest/globals";

describe("MCP Tools", () => {
  it("should convert text to uppercase", async () => {
    const server = new CustomMCPServer();
    const result = await server.callTool("convert_to_uppercase", {
      text: "hello world",
    });
    expect(result).toContain("HELLO WORLD");
  });

  it("should handle errors gracefully", async () => {
    const server = new CustomMCPServer();
    const result = await server.callTool("process_file", {
      path: "/nonexistent/file",
    });
    expect(result).toContain("Error");
  });
});
```

### Debug Logging

```typescript
class DebugMCPServer {
  private server: Server;
  private debug: boolean;

  constructor(debug = false) {
    this.debug = debug;
    this.server = new Server({
      name: "debug-server",
      version: "1.0.0",
    });
  }

  private log(message: string, data?: any) {
    if (this.debug) {
      console.error(`[DEBUG] ${message}`, data || "");
    }
  }

  private registerTools() {
    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        this.log("Tool called", request.params);

        const startTime = Date.now();
        try {
          // Execute tool
          const result = "success";

          const duration = Date.now() - startTime;
          this.log(`Tool completed in ${duration}ms`);

          return { content: [{ type: "text", text: result }] };
        } catch (error: any) {
          this.log("Tool error", error);
          throw error;
        }
      }
    );
  }
}
```

---

## Performance Optimization

### Connection Pooling

```typescript
import { Pool } from "pg";

class PooledDatabaseServer {
  private pool: Pool;

  constructor(connectionString: string) {
    this.pool = new Pool({
      connectionString,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });
  }

  async query(sql: string, params: any[]) {
    const client = await this.pool.connect();
    try {
      return await client.query(sql, params);
    } finally {
      client.release();
    }
  }
}
```

### Caching Strategy

```typescript
class CachedMCPServer {
  private cache: Map<string, { value: any; expiry: number }> = new Map();
  private cacheTTL = 60000; // 60 seconds

  private getCached(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;
    if (Date.now() > cached.expiry) {
      this.cache.delete(key);
      return null;
    }
    return cached.value;
  }

  private setCached(key: string, value: any) {
    this.cache.set(key, {
      value,
      expiry: Date.now() + this.cacheTTL,
    });
  }

  private async fetchWithCache(key: string, fetcher: () => Promise<any>) {
    const cached = this.getCached(key);
    if (cached) return cached;

    const value = await fetcher();
    this.setCached(key, value);
    return value;
  }
}
```

---

## Security Best Practices

### Input Validation

```typescript
import { z } from "zod";

class ValidatedMCPServer {
  private server: Server;

  constructor() {
    this.server = new Server({
      name: "validated-server",
      version: "1.0.0",
    });
    this.registerTools();
  }

  private registerTools() {
    this.server.setRequestHandler(
      { method: "tools/call" },
      async (request: any) => {
        const { name, arguments: args } = request.params;

        try {
          // Define schema
          const querySchema = z.object({
            query: z.string().max(1000),
            limit: z.number().min(1).max(1000).default(100),
          });

          // Validate
          const validated = querySchema.parse(args);

          // Execute
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({ query: validated.query }),
              },
            ],
          };
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `Validation error: ${error.message}`,
                isError: true,
              },
            ],
          };
        }
      }
    );
  }
}
```

### Credential Management

```typescript
class SecureMCPServer {
  private credentials: Map<string, string> = new Map();

  constructor() {
    // Load from environment only
    const apiKey = process.env.API_KEY;
    const dbPass = process.env.DB_PASSWORD;

    if (apiKey) this.credentials.set("api_key", apiKey);
    if (dbPass) this.credentials.set("db_password", dbPass);
  }

  private getCredential(key: string): string {
    const value = this.credentials.get(key);
    if (!value) {
      throw new Error(`Credential not configured: ${key}`);
    }
    return value;
  }

  // Never return credentials to agent
  private async executeSecureOperation(operation: string) {
    const apiKey = this.getCredential("api_key");
    // Use apiKey internally, don't return it
    return { success: true };
  }
}
```

---

## Troubleshooting

### Common Issues

**Issue**: MCP server not starting
```bash
# Check logs
cat openclaw.log | grep "mcp"

# Test server directly
node ./server.js < /dev/null
```

**Issue**: Tool not discovered
```json
// Verify openclaw.json syntax
// Restart Gateway
// Check server startup output
```

**Issue**: Timeout errors
```jsonc
// Increase timeout in openclaw.json
{
  "mcpServers": {
    "slow-server": {
      "command": "node",
      "args": ["./server.js"],
      "timeout": 30000  // 30 seconds
    }
  }
}
```

**Issue**: Resource exhaustion
- Use connection pooling
- Implement caching
- Set request limits
- Monitor memory usage

---

**Last Updated**: 2026-03-15
**OpenClaw MCP SDK Version**: 1.25.3
