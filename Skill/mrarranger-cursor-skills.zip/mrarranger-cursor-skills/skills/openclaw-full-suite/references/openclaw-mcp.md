---
name: openclaw-mcp
description: |
  OpenClaw MCP Integration - Complete Model Context Protocol System
  Create MCP Servers, Custom Tools, JSON-RPC Protocol, SDK Development
  Connect External APIs, Database, File System via MCP
  Use when: (1) Create Custom MCP Server (2) Connect MCP Tools (3) Wrap API as MCP
  (4) Debug MCP Server (5) Publish MCP Skill (6) Multi-MCP configuration
  Commands: /mcp-create, /mcp-config, /mcp-debug, /mcp-publish, /mcp-tools
tags:
  - mcp
  - model-context-protocol
  - sdk
  - json-rpc
  - tools
  - integration
---

# OpenClaw MCP Integration Guide

## What is MCP (Model Context Protocol)?

**MCP** is a standardized JSON-RPC protocol that runs over stdio (stdin/stdout) for bidirectional communication between agents and external services. OpenClaw uses MCP to expose unlimited custom tools, resources, and capabilities to agents.

### Key Architecture
- **Protocol**: JSON-RPC 2.0 over stdio (no network required)
- **Process Management**: OpenClaw spawns/manages MCP server processes
- **Message Format**: Newline-delimited JSON
- **Security**: Isolation via process boundaries, no network access by default

```
┌─────────────────────┐
│   OpenClaw Agent    │
│    (AI Agent)       │
└──────────┬──────────┘
           │ JSON-RPC
           │ (stdio)
┌──────────▼──────────┐
│   MCP Server        │
│  (Custom Code)      │
│  - Tools            │
│  - Resources        │
│  - Prompts          │
└─────────────────────┘
```

## MCP Server Configuration

Edit `openclaw.json` to register MCP servers:

```jsonc
{
  "mcpServers": {
    "github-tools": {
      "command": "node",
      "args": ["./servers/github-server.js"],
      "env": {
        "GITHUB_TOKEN": "ghp_xxxxxxxxxxxx",
        "GITHUB_OWNER": "myorg"
      }
    },
    "postgres-db": {
      "command": "node",
      "args": ["./servers/postgres-server.js"],
      "env": {
        "DATABASE_URL": "postgresql://user:pass@localhost/db",
        "DB_POOL_SIZE": "10"
      }
    },
    "custom-api": {
      "command": "python3",
      "args": ["./servers/api_server.py"],
      "env": {
        "API_KEY": "sk-xxxxxxxxxxxx"
      }
    }
  }
}
```

**Important**: After editing `openclaw.json`, restart the OpenClaw Gateway. Agents auto-discover all MCP tools on startup.

## Building Custom MCP Servers

### TypeScript Implementation

Install SDK:
```bash
npm install @modelcontextprotocol/sdk@1.25.3
```

Basic MCP server with tools:

```typescript
import {
  Server,
  Tool,
  TextContent,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const server = new Server({
  name: "custom-tools",
  version: "1.0.0",
});

// Define a tool
const convertToUppercase: Tool = {
  name: "convert_to_uppercase",
  description: "Converts text to uppercase",
  inputSchema: {
    type: "object" as const,
    properties: {
      text: {
        type: "string",
        description: "Text to convert",
      },
    },
    required: ["text"],
  },
};

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "convert_to_uppercase") {
    return {
      content: [
        {
          type: "text",
          text: args.text.toUpperCase(),
        } as TextContent,
      ],
    };
  }

  throw new Error(`Unknown tool: ${name}`);
});

// Register tool
server.tool("convert_to_uppercase", convertToUppercase.description,
  convertToUppercase.inputSchema);

// Start server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Custom Tools MCP Server running on stdio");
}

main().catch(console.error);
```

### Python Implementation

Install SDK:
```bash
pip install mcp mcp-sdk
```

Python MCP server:

```python
import asyncio
import json
from mcp.server.models import InitializationOptions
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

server = Server("custom-tools")

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> str:
    if name == "query_database":
        db_id = arguments.get("query")
        # Execute database query
        result = {"rows": [], "count": 0}
        return json.dumps(result)

    elif name == "process_image":
        image_path = arguments.get("path")
        # Process image
        return json.dumps({"status": "processed"})

    raise ValueError(f"Unknown tool: {name}")

async def main():
    async with stdio_server(server) as server_instance:
        await server_instance.run()

if __name__ == "__main__":
    asyncio.run(main())
```

## Tool Definitions

Tools expose functions to agents. Each tool requires:

```typescript
interface ToolDefinition {
  name: string;                    // Unique identifier
  description: string;             // Human-readable purpose
  inputSchema: JSONSchema;         // Defines parameters
}

// Example: File operations tool
const readFile: Tool = {
  name: "read_file",
  description: "Read contents of a file",
  inputSchema: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Absolute file path",
      },
      lines: {
        type: "object",
        properties: {
          start: { type: "number", description: "Start line (0-indexed)" },
          end: { type: "number", description: "End line (inclusive)" },
        },
      },
    },
    required: ["path"],
  },
};
```

## Resources and Prompts

Beyond tools, MCP supports **resources** and **prompts**:

### Resources
Expose files, templates, or data structures:

```typescript
server.resource(
  "file:///templates/email",
  "Email templates",
  { uri: "file:///templates/*" }
);

server.resource(
  "config://settings",
  "Configuration files",
  { uri: "config://*" }
);
```

### Prompts
Provide reusable agent instructions:

```typescript
server.prompt(
  "analyze-code",
  "Analyze code for issues",
  {
    arguments: [
      {
        name: "language",
        description: "Programming language",
        required: true,
      },
    ],
  }
);
```

## Server Lifecycle Management

OpenClaw manages MCP server processes:

1. **Startup**: Process spawned with configured command/args
2. **Discovery**: Agent queries available tools/resources
3. **Request Routing**: JSON-RPC calls forwarded to server
4. **Error Handling**: Timeouts, crashes, recoveries
5. **Shutdown**: Process terminated on Gateway stop

### Handling Errors

```typescript
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  try {
    const result = await executeToolLogic(request.params);
    return { content: [{ type: "text", text: result }] };
  } catch (error) {
    return {
      content: [
        {
          type: "text",
          text: `Error: ${error.message}`,
          isError: true,
        },
      ],
    };
  }
});
```

## Multiple MCP Servers

Configure multiple servers for different capabilities:

```jsonc
{
  "mcpServers": {
    "fs": {
      "command": "node",
      "args": ["@modelcontextprotocol/server-filesystem"],
      "env": { "ROOT_DIR": "/workspace" }
    },
    "github": {
      "command": "node",
      "args": ["@modelcontextprotocol/server-github"],
      "env": { "GITHUB_TOKEN": "ghp_xxx" }
    },
    "postgres": {
      "command": "node",
      "args": ["@modelcontextprotocol/server-postgres"],
      "env": { "DATABASE_URL": "postgresql://..." }
    }
  }
}
```

Agents access all tools from all servers seamlessly.

## Popular Community MCP Servers

| Server | Purpose | Package |
|--------|---------|---------|
| @modelcontextprotocol/server-filesystem | File operations | npm |
| @modelcontextprotocol/server-github | GitHub API access | npm |
| @modelcontextprotocol/server-postgres | PostgreSQL queries | npm |
| @modelcontextprotocol/server-sqlite | SQLite databases | npm |
| @modelcontextprotocol/server-bash | Shell commands | npm |
| @modelcontextprotocol/server-fetch | HTTP requests | npm |
| community-mcp/aws | AWS services | npm |
| community-mcp/stripe | Stripe API | npm |
| community-mcp/slack | Slack integration | npm |

## MCP Skills on ClawHub

Publish custom MCP servers as OpenClaw skills:

```yaml
name: my-database-mcp
description: PostgreSQL access via MCP
version: 1.0.0
author: company
tags: [database, postgres, mcp]
```

Skills encapsulate:
- MCP server implementation
- Configuration templates
- Credential management
- Documentation

## Debugging MCP Servers

Enable logging:

```jsonc
{
  "mcpServers": {
    "debug-server": {
      "command": "node",
      "args": ["./server.js"],
      "env": {
        "DEBUG": "mcp:*",
        "LOG_LEVEL": "debug"
      }
    }
  }
}
```

Test MCP server locally:

```bash
# Direct stdio communication
node ./server.js

# Send JSON-RPC request:
# {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}
```

## Security Considerations

- **Isolation**: Stdio/process isolation, no network by default
- **Credentials**: Use `env` in `openclaw.json`, never hardcode
- **Sandboxing**: Run untrusted code in Docker containers
- **Validation**: Validate all tool inputs and outputs
- **Timeouts**: Configure request timeouts for resource limits

## Next Steps

1. Review the comprehensive **mcp-development-guide.md** for advanced patterns
2. Explore **OpenClaw SDK documentation** for full API reference
3. Study **integration examples** for real-world MCP usage
4. Join **OpenClaw Community** for support and shared MCP servers

---

**Last Updated**: 2026-03-15
**SDK Version**: @modelcontextprotocol/sdk@1.25.3
