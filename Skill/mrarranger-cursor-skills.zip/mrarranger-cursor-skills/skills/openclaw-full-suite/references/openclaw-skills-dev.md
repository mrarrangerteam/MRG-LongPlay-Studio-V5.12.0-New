---
name: openclaw-skills-dev
description: |
  OpenClaw Skills Development - คู่มือสร้าง ทดสอบ Publish Skills ไปยัง ClawHub ครบวงจร
  Skill Architecture, YAML Frontmatter, Three-Tier Loading, Testing, Publishing
  ClawHub Registry 13,700+ Skills, Security Auditing, MCP Skills
  ใช้เมื่อ: (1) สร้าง Custom Skill (2) Publish ไป ClawHub (3) ทดสอบ Skill
  (4) Security audit skill (5) MCP skill development (6) Skill architecture design
emoji: 🔧
requires:
  bins: ["node", "python3", "git"]
  envVars: ["CLAWHUB_TOKEN", "GITHUB_TOKEN"]
category: development
tags: ["skills", "openclaw", "clawhub", "development", "security"]
version: "1.0.0"
author: "OpenClaw DevTeam"
---

# OpenClaw Skills Development

Complete guide to creating, testing, publishing, and securing OpenClaw Skills for ClawHub registry.

## Quick Start: Create Your First Skill

```bash
# Create skill from template
openclaw skill create my-awesome-skill --template basic

# Validate structure
openclaw skill validate ./my-awesome-skill

# Test locally
openclaw skill test ./my-awesome-skill --verbose

# Publish to ClawHub
clawhub publish ./my-awesome-skill \
  --slug "my-awesome-skill" \
  --name "My Awesome Skill" \
  --version "1.0.0"
```

## Skill Folder Structure

Standard OpenClaw skill organization:

```
my-skill/
├── SKILL.md                    # Main skill definition (YAML + instructions)
├── references/                 # Detailed documentation & guides
│   ├── architecture.md         # Design decisions & patterns
│   ├── api-reference.md        # Command/function documentation
│   └── troubleshooting.md      # Common issues & solutions
├── scripts/                    # Supporting executables
│   ├── validate.py            # Validation script
│   ├── setup.js               # Initialization logic
│   └── requirements.txt        # Python dependencies
├── configs/                    # Configuration templates
│   ├── openclaw.json          # Skill configuration schema
│   └── default-config.yaml    # Default settings
├── tests/                      # Test suite
│   ├── unit/
│   └── integration/
└── LICENSE                     # Software license
```

## YAML Frontmatter Reference

Essential fields in SKILL.md frontmatter (between `---` delimiters):

```yaml
---
name: skill-name                    # Unique identifier (kebab-case)
description: |                      # 30-50 tokens for Tier 1 discovery
  One-line summary with keywords.
  Second paragraph for Tier 2 detail.
  Use keywords: skill-trigger-words
emoji: 🎯                          # Single emoji for UI representation
version: "1.0.0"                   # Semantic versioning (MAJOR.MINOR.PATCH)
requires:
  bins: ["node", "python3"]        # Binary dependencies
  envVars: ["API_KEY", "TOKEN"]    # Environment variables required
category: "development"            # Category for discovery (31 categories)
tags:                              # Search tags (max 10)
  - keyword1
  - keyword2
author: "Your Name"
license: "MIT"
repository: "https://github.com/user/skill"
---
```

### Tier 1 Loading (Discovery)
Only `name`, `description` (first 30-50 tokens), and `emoji` loaded for search/list operations.
- Keep description concise with trigger keywords
- Example: "Database query builder. Execute SQL with validation. Supports: PostgreSQL, MySQL, SQLite"

### Tier 2 Loading (Preview)
Full YAML frontmatter + inline instruction text from SKILL.md body.
- Include practical examples and quick usage
- Reference detailed guides with: "See {baseDir}/references/full-guide.md"

### Tier 3 Loading (Full Context)
All files including references/, scripts/, configs/ loaded when skill selected.
- Detailed implementation guides
- Supporting code and utilities
- Security audit reports

## Creating Skills: SKILL.md Format

### Structure Template

```markdown
---
name: example-skill
description: Brief description with keywords
version: "1.0.0"
---

# Skill Name

Introduction paragraph explaining what this skill does.

## Usage

Quick examples showing how to use this skill.

### Command Format

\`\`\`
/command-name [options]
\`\`\`

## Installation

\`\`\`bash
openclaw skill install ./example-skill --local
\`\`\`

## Configuration

See {baseDir}/references/configuration.md for advanced setup.

## Features

- Feature 1: Description
- Feature 2: Description
- Feature 3: Description

## Support Scripts

This skill includes supporting tools in {baseDir}/scripts/:
- `validate.py`: Validation logic
- `setup.js`: Initialization

For implementation details, see {baseDir}/references/architecture.md
For API reference, see {baseDir}/references/api-reference.md
For troubleshooting, see {baseDir}/references/troubleshooting.md
```

### Description Best Practices

**Tier 1 (30-50 tokens for search):**
- Start with action verb: "Execute", "Parse", "Transform", "Validate"
- Include trigger keywords for discovery
- Be specific about what the skill does

**Example (45 tokens):**
> "Execute secure SQL queries with validation. Build parametrized statements safely. Supports PostgreSQL, MySQL, SQLite. Prevents SQL injection. Includes transaction management, connection pooling, and query profiling. Perfect for: database operations, analytics, data export."

**Avoid:** Generic descriptions, unclear keywords, vague functionality.

## Creating Skills: Code Organization

### Python Scripts (scripts/validate.py)

```python
#!/usr/bin/env python3
"""
Validation logic for skill.
Run: python3 scripts/validate.py --config config.json
"""

import sys
import json
import argparse
from pathlib import Path

def validate_skill(skill_dir: str) -> dict:
    """Validate skill structure and manifest."""
    skill_path = Path(skill_dir)

    errors = []
    warnings = []

    # Check SKILL.md exists
    if not (skill_path / "SKILL.md").exists():
        errors.append("Missing SKILL.md")

    # Check references/ exists
    if not (skill_path / "references").exists():
        warnings.append("No references/ directory found")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=False)
    args = parser.parse_args()

    result = validate_skill(".")
    print(json.dumps(result, indent=2))
    sys.exit(0 if result["valid"] else 1)
```

### Node.js Scripts (scripts/setup.js)

```javascript
#!/usr/bin/env node

/**
 * Skill initialization script
 * Run: node scripts/setup.js --env production
 */

const fs = require('fs');
const path = require('path');

function setupSkill(options = {}) {
  const skillDir = process.env.SKILL_DIR || '.';
  const config = {
    initialized: true,
    timestamp: new Date().toISOString(),
    environment: options.env || 'development'
  };

  const configPath = path.join(skillDir, 'skill-config.json');
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

  console.log(`✓ Skill initialized in ${options.env || 'development'} mode`);
  return true;
}

module.exports = { setupSkill };

if (require.main === module) {
  const args = process.argv.slice(2);
  const env = args.includes('--env')
    ? args[args.indexOf('--env') + 1]
    : 'development';

  setupSkill({ env });
}
```

## Testing & Validation

### Validate Skill Structure

```bash
# Full validation with verbose output
openclaw skill validate ./my-skill --verbose

# Output shows:
# ✓ SKILL.md structure valid
# ✓ YAML frontmatter valid
# ✓ Required fields present
# ✓ References directory: references/ found
# ✓ Scripts executable
# ✓ No security issues detected
```

### Run Tests

```bash
# Run all tests with coverage
openclaw skill test ./my-skill --verbose --coverage

# Run specific test suite
openclaw skill test ./my-skill --suite "unit"

# Test specific command
openclaw skill test ./my-skill --command "my-command"
```

### Testing Strategies

1. **Unit Tests**: Test individual functions/commands in isolation
2. **Integration Tests**: Test skill interactions with OpenClaw system
3. **Prompt Tests**: Test skill response to various user inputs
4. **Security Tests**: Check for injection vulnerabilities, permission issues

## Publishing to ClawHub

### Prerequisites

- GitHub account (≥1 week old for security)
- `clawhub` CLI installed (`npm install -g clawhub`)
- Skill validated locally

### Authentication

```bash
# Login with GitHub
clawhub login
# Opens browser for GitHub OAuth authentication
# Stores token in ~/.clawhub/credentials.json

# Verify authentication
clawhub whoami
# Output: You are logged in as: username (token active)
```

### Publish Skill

```bash
# First-time publish
clawhub publish ./my-skill \
  --slug "my-awesome-skill" \
  --name "My Awesome Skill" \
  --version "1.0.0" \
  --description "Detailed description here"

# Update existing skill (new version)
clawhub publish ./my-skill --version "1.1.0"

# Dry-run to verify before publishing
clawhub publish ./my-skill --dry-run
```

### Versioning Strategy

Use semantic versioning (MAJOR.MINOR.PATCH):
- `1.0.0` → Initial release
- `1.1.0` → New feature added
- `1.1.1` → Bug fix
- `2.0.0` → Breaking changes

## ClawHub Registry Overview

**Registry Stats (Feb 2026):**
- 13,729+ published skills
- 31 skill categories
- Semantic search enabled
- Security scanning integrated (VirusTotal)

### Search & Discovery

```bash
# Search by keyword
clawhub search "database" --limit 10

# Search with semantic query
clawhub search "SQL database validation" --semantic

# Filter by category
clawhub search --category "development" --sort "downloads"

# Inspect specific skill
clawhub inspect user/skill-name --version "1.0.0"
```

### Installation from Registry

```bash
# Install latest version
clawhub install my-awesome-skill

# Install specific version
clawhub install my-awesome-skill@1.0.0

# Install with local override
clawhub install my-awesome-skill --local ./my-skill

# Pin version in openclaw.json
clawhub install my-awesome-skill@1.0.0 --pin
```

## Security & Trust

### ClawHavoc Incident (2025)

**Timeline:**
- Feb 2025: 341 malicious skills detected in registry
- Security review triggered across all published skills
- Incident escalated: 824 total malicious skills identified
- Automated removal + manual verification initiated

**Lessons Learned:**
- VirusTotal scanning now mandatory for all publishes
- Code obfuscation triggers automatic review
- External prerequisites require explicit declaration
- Sandbox mode for untrusted/unsigned skills

### Security Review Checklist

Before publishing, validate:

```bash
# 1. No hardcoded secrets
grep -r "token\|secret\|password\|key" .

# 2. No obfuscated code
openclaw skill validate ./my-skill --check-obfuscation

# 3. External dependencies declared
grep -r "fetch\|curl\|http" . | wc -l
# Document in requires.externalEndpoints

# 4. No privilege escalation
grep -r "chmod\|sudo\|setuid" .

# 5. Code review for injection vulnerabilities
# Check user input validation in all scripts
```

### Red Flags in Skills

Do NOT publish if:
- ✗ Undeclared external HTTP calls
- ✗ Obfuscated/minified code without explanation
- ✗ Hardcoded credentials (even test ones)
- ✗ Shell commands constructed from user input
- ✗ Excessive file system permissions
- ✗ No clear explanation of functionality

Do DOCUMENT if:
- ✓ Uses external APIs (specify in frontmatter)
- ✓ Requires specific binary versions
- ✓ Modifies system configuration
- ✓ Handles sensitive data
- ✓ Requires special permissions

## Advanced Patterns

### MCP Skills (Wrapping MCP Servers)

Convert MCP (Model Context Protocol) servers to OpenClaw skills:

```yaml
---
name: mcp-wrapped-skill
description: Wrapped MCP server as OpenClaw skill
mcp:
  server: "@anthropic/mcp-server-example"
  tools:
    - name: example-tool
      description: Tool from MCP server
---
```

### Multi-Tool Skills

Expose multiple tools from single skill:

```yaml
---
name: multi-tool-skill
tools:
  - name: tool1
    description: First tool
    command: /tool1
  - name: tool2
    description: Second tool
    command: /tool2
---
```

### Docker-Sandboxed Skills

Skills that run in isolated container:

```yaml
---
name: sandboxed-skill
sandbox:
  type: docker
  image: python:3.11-slim
  mounts:
    - source: "/tmp"
      target: "/workspace"
      readonly: false
---
```

### Skills with Config Management

Store configuration in openclaw.json:

```json
{
  "skills": {
    "my-skill": {
      "version": "1.0.0",
      "config": {
        "timeout": 30,
        "retries": 3,
        "environment": "production"
      },
      "env": {
        "API_KEY": "${VAULT_API_KEY}",
        "LOG_LEVEL": "info"
      }
    }
  }
}
```

## {baseDir} Variable

Reference files within your skill using the `{baseDir}` variable:

```markdown
For implementation details, see {baseDir}/references/architecture.md
For API docs, see {baseDir}/references/api-reference.md
For troubleshooting, see {baseDir}/references/troubleshooting.md
Run validator: {baseDir}/scripts/validate.py
```

When skill loads, `{baseDir}` resolves to skill's root directory path.

## Skill Locations & Resolution

Skills are searched in this order:

1. **Workspace Skills** (highest priority)
   - Path: `workspace/skills/my-skill/`
   - Scope: Current project only
   - Usage: Development & testing

2. **User Skills** (medium priority)
   - Path: `~/.openclaw/skills/my-skill/`
   - Scope: Current user
   - Usage: Personal utilities

3. **Bundled Skills** (lowest priority)
   - Path: `/opt/openclaw/skills/my-skill/`
   - Scope: System-wide
   - Usage: Core functionality

**First match wins** - workspace skill overrides user skill overrides bundled skill.

## Command Reference

See {baseDir}/references/skill-development-guide.md for:
- Detailed three-tier loading explanation
- Complete MCP skill examples
- Security audit workflows
- Advanced testing patterns
- ClawHub integration examples

---

Last updated: 2026-03-15
Maintained by: OpenClaw DevTeam
