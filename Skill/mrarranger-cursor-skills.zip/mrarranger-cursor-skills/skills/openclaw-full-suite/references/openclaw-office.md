---
name: openclaw-office
description: |
  OpenClaw Office - Virtual Office สำหรับ Monitor Multi-Agent System
  Isometric 2D/3D Visualization, Standup/Scrum Protocol, WebSocket Integration, Console Management
  ใช้เมื่อ: (1) ติดตั้ง OpenClaw Office (2) Customize Virtual Office Layout (3) Monitor Multi-Agent Activities
  (4) Setup Standup/Scrum Protocol (5) Configure WebSocket & Remote Gateway (6) Manage Console
  Commands: /office-install, /office-config, /standup, /monitor, /console, /customize-avatar
tags:
  - openclaw
  - multi-agent
  - visualization
  - monitoring
  - real-time
  - websocket
  - standup
  - virtual-office
version: 1.0.0
---

# OpenClaw Office - Skill Guide

## Overview

**OpenClaw Office** คือ visual monitoring frontend สำหรับ **OpenClaw Multi-Agent System** ที่ประสิทธิ์ที่สุด
- Isometric 2D + React Three Fiber 3D visualization
- Real-time Agent collaboration monitoring via WebSocket
- Standup/Scrum protocol support
- Full console management (agents, channels, skills, cron jobs)
- npm package: `@ww-ai-lab/openclaw-office`
- GitHub: https://github.com/WW-AI-Lab/openclaw-office

**Architecture:**
```
┌─────────────────────────────┐
│  Frontend (Next.js + React) │
│  - 2D Isometric SVG         │
│  - 3D React Three Fiber     │
│  - Standup Board            │
│  - Console Dashboard        │
└──────────┬──────────────────┘
           │ WebSocket
┌──────────▼──────────────────┐
│  OpenClaw Gateway           │
│  (WebSocket Server)         │
└──────────┬──────────────────┘
           │
┌──────────▼──────────────────┐
│  AI Agents + Integrations   │
│  (Tool Calling, LLM APIs)   │
└─────────────────────────────┘
```

---

## Installation

### Global Installation
```bash
npx @ww-ai-lab/openclaw-office
# Automatically opens at http://localhost:3000
```

### Package Installation
```bash
npm install -g @ww-ai-lab/openclaw-office
openclaw-office
```

### Local Development
```bash
git clone https://github.com/WW-AI-Lab/openclaw-office.git
cd openclaw-office
npm install
npm run dev
# Open http://localhost:3000
```

**Requirements:**
- Node.js 18+
- WebSocket server (OpenClaw Gateway)
- Modern browser (Chrome, Safari, Firefox)

---

## Core Features

### 1. Virtual Office Visualization (2D/3D)

**2D Isometric SVG Floor Plan**
```
Server Room ┌─────────┐
            │ 📡 Servers │
            └─────────┘
Meeting Room ┌──────────┐   Lounge ┌───────┐
             │💼Meetings│           │🛋️  Break │
             └──────────┘           └───────┘
Desk Zone ┌──────────────────────────┐
          │ 🧑‍💻 Agent1  🧑‍💻 Agent2  │
          │ 🧑‍💻 Agent3  🧑‍💻 Agent4  │
          └──────────────────────────┘
```

**Office Zones (Customizable):**
- `desk`: Primary work area (agents at desks)
- `meeting_room`: Collaboration space
- `lounge`: Idle/break area
- `server_room`: System monitoring

**Agent Avatar System**
```javascript
// Deterministic SVG generation based on agent ID
const avatar = generateAgentAvatar({
  agentId: 'agent-001',
  status: 'working', // idle, working, speaking, tool_calling, error
  seed: hashAgentId('agent-001') // Consistent colors
});

// Output: <svg>...</svg> with unique color & icon
```

**Status Animations:**
```
idle          → Static avatar at desk
working       → Pulsing glow, keyboard animation
speaking      → Mouth movement, speech bubble
tool_calling  → Spinning tool icon overlay
error         → Red shake animation
```

### 2. Agent Visualization

**Collaboration Lines**
```
Agent A ════════════════════ Agent B
(Requesting)              (Responding)
  ↓ Inter-agent message flow
  Speech bubble with tool calls
```

**Real-time Speech Bubbles**
```javascript
// Streaming Markdown + Tool Calls
const message = {
  agentId: 'agent-001',
  type: 'message',
  content: '# Task Report\nProcessing data...',
  status: 'streaming', // streaming | complete | error
  toolCalls: [
    { name: 'database_query', status: 'pending' },
    { name: 'file_write', status: 'complete', result: '✓' }
  ]
};
```

**Token Consumption Tracking**
```javascript
{
  agentId: 'agent-001',
  inputTokens: 1250,
  outputTokens: 856,
  estimatedCost: '$0.0234',
  costPerMillion: {
    input: '15/M',
    output: '60/M'
  }
}
```

### 3. Side Panels

**Agent Details Panel**
```
┌─ Agent: DataProcessor ─────────┐
│ Status: 🟢 Working             │
│ Uptime: 2h 34m 12s             │
│ Current Task: Processing CSV   │
│ Tool Calls This Session: 12    │
│ Errors: 0                      │
└────────────────────────────────┘
```

**Charts & Analytics**
```javascript
// Token Line Chart (Real-time)
<TokenChart
  data={agentTokenHistory}
  metric="inputTokens"
/>

// Cost Pie Chart
<CostChart
  breakdown={{
    'API Calls': 65,
    'Data Processing': 20,
    'Storage': 15
  }}
/>

// Activity Heatmap
<ActivityHeatmap
  data={24hActivityData}
  timezone="Asia/Bangkok"
/>
```

**SubAgent Dependency Graph**
```
Master Agent
├─ SubAgent-1 (Data Collector)
│  ├─ SubAgent-1a (Web Scraper)
│  └─ SubAgent-1b (API Client)
├─ SubAgent-2 (Analyzer)
│  └─ SubAgent-2a (ML Model)
└─ SubAgent-3 (Reporter)
```

### 4. Chat Dock

**Bottom-Docked Chat Interface**
```
┌────────────────────────────────────────────┐
│ OpenClaw Office - Agent Monitor            │
│                                            │
│         [Virtual Office 2D/3D View]        │
│                                            │
├────────────────────────────────────────────┤
│ Chat Dock [v]                              │
├────────────────────────────────────────────┤
│ Agent: [Select Agent ▼]                    │
│ ┌──────────────────────────────────────┐  │
│ │ Agent-001: Task completed ✓          │  │
│ │ 14:23:45                            │  │
│ └──────────────────────────────────────┘  │
│ Message Input: [Type message...        ] │
└────────────────────────────────────────────┘
```

**Features:**
- Real-time message streaming
- Markdown rendering
- Tool call visualization
- Message history drawer
- Agent selector dropdown

---

## Standup/Scrum Protocol

**Protocol Phases:**

```javascript
// 1. GATHERING - Agents move to meeting room
{
  phase: 'gathering',
  participants: ['agent-001', 'agent-002', 'agent-003'],
  duration: '5s'
}

// 2. IN_PROGRESS - Standup begins, rotation starts
{
  phase: 'in_progress',
  currentSpeaker: 'agent-001',
  timePerAgent: 60, // seconds
  queue: ['agent-002', 'agent-003']
}

// 3. COMPLETE - All agents finished reporting
{
  phase: 'complete',
  duration: '3m 45s',
  summary: {
    tasksCompleted: 5,
    blockers: 1,
    nextSteps: 'Database migration'
  }
}
```

**Standup Board UI**
```
┌─────────────────────────────────┐
│  🎯 Daily Standup               │
├─────────────────────────────────┤
│ 🔴 Agent-001 (Speaking)        │
│  └─ Today: Fixed login bug      │
│  └─ Blocker: Waiting on API fix │
│  └─ Tomorrow: Write tests       │
│                                 │
│ ⚪ Agent-002 (Pending)         │
│                                 │
│ ⚪ Agent-003 (Pending)         │
└─────────────────────────────────┘
```

**GitHub & Jira Integration**
```javascript
{
  agent: 'agent-001',
  githubCommits: [
    'fix: login authentication bug',
    'chore: update dependencies'
  ],
  jiraTickets: [
    'PROJ-123 ✓ (Completed)',
    'PROJ-124 🔄 (In Progress)',
    'PROJ-125 📋 (Ready)'
  ]
}
```

---

## WebSocket Protocol

**Connection Setup**
```javascript
// Client-side connection
const ws = new WebSocket('ws://localhost:8080');

ws.onopen = () => {
  console.log('Connected to OpenClaw Gateway');
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  handleMessage(message);
};
```

**Message Types**

1. **Agent Status Update**
```javascript
{
  type: 'agent_status',
  agentId: 'agent-001',
  status: 'working',
  zone: 'desk',
  currentTask: 'Processing data...',
  inputTokens: 1250,
  outputTokens: 856,
  timestamp: '2026-03-15T14:23:45Z'
}
```

2. **Agent Message**
```javascript
{
  type: 'agent_message',
  agentId: 'agent-001',
  content: '# Task Status\nCompleting data validation...',
  messageType: 'streaming', // streaming | complete
  metadata: {
    duration: 1250, // ms
    toolCalls: 3
  }
}
```

3. **Tool Call Event**
```javascript
{
  type: 'tool_call',
  agentId: 'agent-001',
  toolName: 'database_query',
  status: 'pending', // pending | executing | complete | error
  input: { query: 'SELECT * FROM users' },
  result: null, // Populated when complete
  duration: 1234 // ms
}
```

4. **Session Update**
```javascript
{
  type: 'session_update',
  sessionId: 'session-abc123',
  totalTokens: 15234,
  totalCost: '$0.45',
  agentCount: 4,
  activeAgents: 3,
  uptime: '2h 34m'
}
```

---

## Console Management

### Dashboard
```
Key Metrics:
- Active Agents: 4/5
- Total Tokens: 15,234
- Session Cost: $0.45
- Uptime: 2h 34m 12s
- Error Rate: 0.2%
```

### Agents Management
```javascript
// View all agents
GET /api/agents
→ [
  {
    id: 'agent-001',
    name: 'DataProcessor',
    status: 'active',
    capabilities: ['database', 'file_io'],
    lastActive: '2026-03-15T14:23:45Z',
    performance: { successRate: 99.2, avgResponseTime: 245 }
  },
  ...
]

// Update agent
PATCH /api/agents/agent-001
→ { systemPrompt, tools, temperature, ... }
```

### Channels Management
```javascript
// Create channel
POST /api/channels
→ {
  name: 'data-pipeline',
  description: 'ETL operations',
  members: ['agent-001', 'agent-002'],
  permissions: 'private'
}
```

### Skills Management
```javascript
// List available skills
GET /api/skills
→ [
  { id: 'web_scrape', category: 'data', version: '2.1.0' },
  { id: 'email_send', category: 'communication', version: '1.5.2' },
  ...
]
```

### Cron Jobs
```javascript
// Create scheduled task
POST /api/cron-jobs
→ {
  id: 'daily-report',
  schedule: '0 9 * * *', // 9 AM daily
  agentId: 'agent-001',
  action: 'generateDailyReport',
  enabled: true
}
```

---

## Remote Gateway Configuration

**Connect to Remote OpenClaw Gateway**

```javascript
// settings/gateway.ts
export const gatewayConfig = {
  // Local
  local: {
    url: 'ws://localhost:8080',
    timeout: 30000
  },

  // Aliyun (阿里云)
  aliyun: {
    url: 'wss://openclaw-gateway.aliyun.example.com:443',
    auth: {
      type: 'api-key',
      key: process.env.ALIYUN_API_KEY
    },
    ssl: true,
    timeout: 45000
  },

  // Tencent Cloud (腾讯云)
  tencent: {
    url: 'wss://openclaw-gateway.tencentcloud.example.com:443',
    auth: {
      type: 'oauth',
      clientId: process.env.TENCENT_CLIENT_ID,
      clientSecret: process.env.TENCENT_CLIENT_SECRET
    },
    ssl: true,
    timeout: 45000,
    region: 'ap-shanghai'
  },

  // Custom Server
  custom: {
    url: process.env.CUSTOM_GATEWAY_URL,
    auth: {
      type: 'bearer-token',
      token: process.env.CUSTOM_GATEWAY_TOKEN
    },
    ssl: process.env.CUSTOM_GATEWAY_SSL === 'true',
    timeout: 30000
  }
};
```

**Environment Setup:**
```bash
# .env.local
NEXT_PUBLIC_GATEWAY_URL=wss://gateway.example.com:443
NEXT_PUBLIC_GATEWAY_TIMEOUT=45000
OPENCLAW_AUTH_TYPE=api-key
OPENCLAW_API_KEY=sk_live_xxxxxxxxxxxxx
OPENCLAW_ENVIRONMENT=production
```

---

## Customization Guide

### 1. Office Layout Customization

```javascript
// lib/office-layout.ts
export const officeZones = {
  desk: {
    position: { x: 100, y: 200 },
    size: { width: 400, height: 200 },
    maxAgents: 8,
    animation: 'desk-work',
    icon: '🧑‍💻'
  },
  meeting_room: {
    position: { x: 600, y: 100 },
    size: { width: 250, height: 250 },
    maxAgents: 6,
    animation: 'collaboration',
    icon: '💼'
  },
  lounge: {
    position: { x: 900, y: 200 },
    size: { width: 150, height: 150 },
    maxAgents: 4,
    animation: 'idle',
    icon: '🛋️'
  },
  server_room: {
    position: { x: 100, y: 50 },
    size: { width: 150, height: 100 },
    maxAgents: 0,
    animation: 'server',
    icon: '📡'
  }
};
```

### 2. Agent Avatar Customization

```javascript
// lib/avatar-generator.ts
export function generateCustomAvatar(agentId: string, options = {}) {
  const hash = hashFunction(agentId);
  const hue = hash % 360;
  const saturation = 65 + (hash % 20);
  const lightness = 45 + (hash % 20);

  return {
    color: `hsl(${hue}, ${saturation}%, ${lightness}%)`,
    icon: options.icon || getDefaultIcon(agentId),
    size: options.size || 'medium',
    animate: options.animate !== false,
    seed: hash
  };
}
```

### 3. Theme Customization

```javascript
// tailwind.config.ts
export default {
  theme: {
    colors: {
      'openclaw-primary': '#3B82F6',
      'openclaw-secondary': '#10B981',
      'agent-idle': '#6B7280',
      'agent-working': '#F59E0B',
      'agent-error': '#EF4444',
    }
  },
  // Light & Dark mode support
  darkMode: 'class'
};
```

---

## Commands Reference

| Command | Description | Usage |
|---------|-------------|-------|
| `/office-install` | Install OpenClaw Office | `npx @ww-ai-lab/openclaw-office` |
| `/office-config` | Configure gateway & settings | Interactive CLI setup |
| `/standup` | Start standup/scrum meeting | Shows board UI |
| `/monitor` | Monitor agent activities | Real-time dashboard |
| `/console` | Access full console | All management features |
| `/customize-avatar` | Customize agent avatars | UI form |

---

## Tech Stack

- **Frontend Framework:** Next.js 14+ + React 19
- **Styling:** Tailwind CSS + CSS-in-JS
- **State Management:** Zustand
- **3D Visualization:** React Three Fiber (R3F)
- **WebSocket:** native WebSocket API
- **SVG Rendering:** React SVG + D3.js (optional)
- **Charts:** Recharts, Chart.js
- **Icons:** Lucide React, Heroicons
- **Build Tool:** Turbopack (Next.js)

---

## Tips & Best Practices

✅ **DO:**
- Monitor token consumption regularly to manage costs
- Use Standup protocol for team coordination
- Configure remote gateway for production
- Customize office layout for team size
- Set up cron jobs for recurring tasks

❌ **DON'T:**
- Leave WebSocket connections open indefinitely
- Set agent timeout too short (< 5 seconds)
- Expose API keys in frontend code
- Use local gateway for production
- Ignore error rates in console

---

## Troubleshooting

**WebSocket Connection Failed**
```
→ Check OpenClaw Gateway is running
→ Verify URL in NEXT_PUBLIC_GATEWAY_URL
→ Check firewall/network settings
```

**Agents Not Appearing**
```
→ Refresh page (F5)
→ Check agents are registered with gateway
→ Verify WebSocket message format
```

**High Token Usage**
```
→ Review agent system prompts
→ Check tool call frequency
→ Optimize batch processing
```

---

## Resources

- **GitHub:** https://github.com/WW-AI-Lab/openclaw-office
- **OpenClaw Docs:** https://docs.openclaw.ai
- **Discord Community:** https://discord.gg/openclaw
- **Issue Tracker:** https://github.com/WW-AI-Lab/openclaw-office/issues

---

*Last Updated: March 2026 | OpenClaw Office v1.0.0*
