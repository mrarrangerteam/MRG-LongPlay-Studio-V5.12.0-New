---
name: openclaw-channels
description: |
  OpenClaw Channels - Complete Messaging Platform Setup Guide (22+ channels)

  ช่องทาง Messaging: WhatsApp, Telegram, Discord, Slack, Signal, iMessage, Teams,
  Google Chat, Matrix, Zalo, LINE, Mattermost, Feishu, Twitch, IRC, WebChat,
  Nextcloud Talk, Nostr, Synology Chat, Tlon, macOS/iOS/Android native + more

  อ้างอิง: DM Policy, Group Routing, Multi-Account, Pairing Security, Media Handling,
  Channel Health, Reconnection Strategies

  ใช้เมื่อ: (1) ตั้งค่า Channel ใหม่ (2) แก้ปัญหา Channel (3) Multi-Account setup
  (4) DM Security (5) Group chat config (6) Media handling & reconnection

  Commands: /channel, /pairing, /whatsapp, /telegram, /discord, /slack
tags: [channels, messaging, integration, setup, security]
---

# OpenClaw Channels: Complete Setup Guide

## Overview

OpenClaw supports 22+ messaging channels with unified API. Each channel has unique setup requirements, security models, and capabilities.

**Quick Start:**
```bash
# List available channels
openclaw channel list

# Show channel status
openclaw channel status

# List pairings (DM security)
openclaw pairing list

# Approve new DM pairing
openclaw pairing approve <user_id>
```

---

## Core Concepts

### DM Policy & Pairing

OpenClaw implements **pairing system** to control who can send DMs:

```bash
# Pairing modes (per channel)
allowFrom: "open"        # Anyone can DM (default for public channels)
allowFrom: "paired"      # Only paired users can DM
allowFrom: "contacts"    # Only saved contacts
allowFrom: "none"        # No DMs allowed
```

**DM Pairing Flow:**
1. User sends DM → OpenClaw receives pairing request
2. System notifies channel admin
3. Admin approves: `openclaw pairing approve <id>`
4. User can now send DMs

**Security Implications:**
- `paired` mode: blocks spam, requires manual approval
- `open` mode: accepts all DMs, useful for customer service
- `none` mode: silent drop of all incoming DMs

### Group Routing

OpenClaw routes messages based on context:

```
DM → agent.handle_dm()
Group → agent.handle_group()
```

**Group Message Handling:**
```python
@channel.on("message")
def handle_message(msg):
    if msg.is_group:
        return handle_group_chat(msg)
    else:
        return handle_dm(msg)
```

### Multi-Account Support

Multiple accounts per channel (e.g., 2 WhatsApp numbers):

```yaml
channels:
  whatsapp:
    - account: "+66812345678"
      agent: "customer_service"
    - account: "+66887654321"
      agent: "support_team"
```

### Channel Binding

Bind specific channels to specific agents:

```bash
openclaw channel bind discord:#general @agent_customer_service
openclaw channel bind telegram @mybot @agent_automation
```

---

## Channel Configuration Reference

**See: `references/channel-configs.md` for detailed per-channel setup**

### Quick Channel Matrix

| Channel | Setup Time | Complexity | DM Support | Media | Multi-Account |
|---------|-----------|-----------|-----------|-------|---------------|
| WhatsApp | 15 min | High | Yes | Full | Yes |
| Telegram | 5 min | Low | Yes | Full | Yes |
| Discord | 10 min | Medium | Yes | Full | Yes |
| Slack | 10 min | Medium | Yes | Full | Yes |
| Signal | 20 min | High | Yes | Limited | No |
| iMessage | 5 min | High* | Yes | Full | No* |
| Teams | 10 min | Medium | Yes | Full | Yes |
| Google Chat | 10 min | Medium | Yes | Full | Yes |
| Matrix | 15 min | High | Yes | Full | Yes |
| Zalo | 15 min | High | Yes | Full | Yes |
| LINE | 10 min | Medium | Yes | Full | Yes |
| IRC | 5 min | Low | Yes | Text only | Yes |
| WebChat | 5 min | Low | Yes | Full | Yes |
| Mattermost | 10 min | Medium | Yes | Full | Yes |
| Feishu | 15 min | Medium | Yes | Full | Yes |
| Twitch | 10 min | Medium | No | Moderate | No |
| Nextcloud Talk | 10 min | Medium | Yes | Full | Yes |
| Nostr | 10 min | Medium | Yes | Limited | Yes |
| Synology Chat | 10 min | Medium | Yes | Full | Yes |
| Tlon | 10 min | Medium | Yes | Full | Yes |
| macOS Native | 5 min | Low* | Yes | Full | No |
| iOS Native | 5 min | Low* | Yes | Full | No |
| Android Native | 5 min | Low* | Yes | Full | No |

*macOS/iOS require specific hardware/OS

---

## Common Setup Patterns

### Pattern 1: Customer Service Multichannel

Setup WhatsApp + Telegram + WebChat for customer service:

```yaml
agents:
  customer_service:
    channels:
      - whatsapp:
          account: "+66812345678"
          allowFrom: "open"
      - telegram:
          bot_token: "YOUR_BOT_TOKEN"
          allowFrom: "open"
      - webchat:
          endpoint: "https://yoursite.com"
          allowFrom: "open"
```

**Health Check:**
```bash
openclaw channel health customer_service
# Output: WhatsApp: OK, Telegram: OK, WebChat: OK
```

### Pattern 2: Team Communication (Discord + Slack)

```yaml
team_comms:
  channels:
    discord:
      guild_id: "123456789"
      intents: ["message_content", "guild_messages"]
    slack:
      workspace: "your-workspace"
      channels: ["#general", "#random"]
```

### Pattern 3: Privacy-First (Signal + Matrix)

```yaml
secure_comms:
  channels:
    signal:
      phone: "+66812345678"  # Must be real phone
      allowFrom: "paired"     # Only paired users
    matrix:
      homeserver: "https://matrix.org"
      allowFrom: "paired"
```

---

## Troubleshooting

### Channel Not Responding

```bash
# Check connection status
openclaw channel status whatsapp

# View recent logs
openclaw channel logs whatsapp --tail 50

# Reconnect
openclaw channel reconnect whatsapp

# Force reconnect (clears state)
openclaw channel reconnect whatsapp --force
```

### DM Pairing Issues

```bash
# List pending pairings
openclaw pairing list --pending

# Reject pairing
openclaw pairing reject <user_id>

# Clear all pairings (dangerous!)
openclaw pairing clear whatsapp
```

### Message Not Sending

1. Check media size: Most channels have limits (e.g., WhatsApp 16MB)
2. Verify format: Some channels don't support certain media types
3. Check rate limits: Telegram allows ~30 msg/sec, WhatsApp ~1 msg/sec
4. Verify credentials: Token expired, phone disconnected, etc.

---

## Media Handling

### Per-Channel Capabilities

**Full Media Support** (images, video, audio, documents):
WhatsApp, Telegram, Discord, Slack, Teams, iMessage, Signal, Google Chat, Matrix, Zalo, LINE, Mattermost, Feishu, Twitch, Nextcloud Talk, Synology Chat, Tlon, iOS/Android native

**Limited Media** (images only):
IRC, Nostr, WebChat (depends on embed)

**Text Only:**
Some legacy systems, certain IRC networks

### Media Size Limits

```
WhatsApp:     100 MB (documents), 16 MB (media)
Telegram:     2 GB (documents), 50 MB (normal upload)
Discord:      10 MB (free tier), 100 MB (boosted)
Slack:        1 GB per workspace (total)
Signal:       Unlimited (local encryption)
Teams:        20 GB per file
Google Chat:  1 GB per file
Matrix:       500 MB (depends on server)
```

### Upload Example

```python
from openclaw.channels import WhatsApp

whatsapp = WhatsApp(phone="+66812345678")

# Auto-compress if needed
await whatsapp.send_media(
    chat_id="66812345678",
    media_path="/path/to/video.mp4",
    compress=True,  # Auto-compress if > 16MB
    caption="Check this out!"
)
```

---

## Reconnection Strategies

**Automatic Reconnection** (enabled by default):

```yaml
reconnect:
  enabled: true
  max_retries: 5
  backoff: "exponential"  # 1s, 2s, 4s, 8s, 16s
  timeout: 30s
```

**Manual Reconnection:**

```bash
# Soft reconnect (keeps messages)
openclaw channel reconnect whatsapp

# Hard reconnect (clears state, re-authenticates)
openclaw channel reconnect whatsapp --force

# Restart with debug logs
openclaw channel reconnect whatsapp --debug
```

### Detecting Connection Issues

```bash
# Monitor in real-time
openclaw channel monitor whatsapp

# Shows:
# - Connection state changes
# - Message queue size
# - Last heartbeat
# - Error rate
```

---

## Health Monitoring

```bash
# Check all channels
openclaw channel health --all

# Sample output:
# WhatsApp: ✓ Connected (1234 pending)
# Telegram: ✓ Connected (0 pending)
# Discord: ✗ Disconnected (last: 2 min ago)
# Slack: ✓ Connected (5 pending)

# Get detailed health
openclaw channel health whatsapp --detailed
```

---

## Security Best Practices

1. **Never commit credentials** to version control
   ```bash
   # Use environment variables
   export WHATSAPP_PHONE="+66812345678"
   export TELEGRAM_BOT_TOKEN="123456:ABC..."
   ```

2. **Enable DM pairing** for sensitive channels
   ```yaml
   channels:
     whatsapp:
       allowFrom: "paired"  # Require approval
   ```

3. **Regular token rotation** (3-6 months)
   ```bash
   openclaw channel rotate-token telegram
   openclaw channel rotate-token discord
   ```

4. **Monitor message logs** for suspicious activity
   ```bash
   openclaw channel logs whatsapp --filter "error" --tail 100
   ```

---

## Next Steps

- **Setup specific channel:** See `references/channel-configs.md`
- **Troubleshoot issue:** See Troubleshooting section above
- **Monitor health:** Use `openclaw channel health`
- **Security:** Follow security best practices above
