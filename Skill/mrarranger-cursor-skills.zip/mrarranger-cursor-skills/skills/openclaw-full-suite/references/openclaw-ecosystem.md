---
name: openclaw-ecosystem
description: |
  OpenClaw Ecosystem - รวมทุกโปรเจคในระบบนิเวศ OpenClaw ครบวงจร
  Core: openclaw/openclaw (247K+ stars)
  Official Tools: ClawHub, Office, Mission Control
  Community: Nanobot, ClawWork, NanoClaw, CLAW3D, soul.md
  Use when: (1) Select right tool (2) Compare OpenClaw vs alternatives
  (3) Integration patterns (4) Community resources (5) Migration guide
  Commands: /ecosystem, /compare, /migrate, /resources, /community
maintainer: OpenClaw Community
version: 1.0.0
tags: [opensourcse, ai-agents, ecosystem, tools, integration, comparison]
---

# OpenClaw Ecosystem Guide

## Quick Overview

**OpenClaw** (formerly Clawdbot → Moltbot) is an open-source AI Agent framework created by Peter Steinberger (PSPDFKit founder). The ecosystem includes the main project plus 10+ official and community tools designed for different use cases.

```
┌─────────────────────────────────────────────────────────┐
│         OpenClaw Ecosystem (Jan 2026 Rename)            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Core: openclaw/openclaw (247K+ stars, MIT)            │
│  ├─ Gateway + Agent Runtime + Skills + Channels        │
│  └─ 100K+ lines TypeScript, 22+ channels               │
│                                                         │
│  Official Tools:                                        │
│  ├─ ClawHub (Skill Registry, 13,729+ skills)           │
│  ├─ OpenClaw Office (Visual monitoring, 2D/3D)         │
│  └─ Mission Control (Orchestration dashboard)          │
│                                                         │
│  Community Projects:                                    │
│  ├─ Nanobot (Ultra-lightweight, 4K lines Python)       │
│  ├─ ClawWork (AI Coworker, economic tracking)          │
│  ├─ NanoClaw (Container-based, 6 channels)             │
│  ├─ CLAW3D (3D virtual office)                         │
│  └─ soul.md (Agent personality framework)              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Core Project: openclaw/openclaw

### Overview
- **Repository:** openclaw/openclaw
- **Stars:** 247,000+
- **License:** MIT
- **Creator:** Peter Steinberger (PSPDFKit founder)
- **Language:** TypeScript
- **Size:** 100K+ lines of code

### History
| Date | Name | Event |
|------|------|-------|
| 2024 | Clawdbot | Original project launch |
| 2025 | Moltbot | Intermediate name |
| Jan 2026 | OpenClaw | Current official name |

### Architecture
```
┌──────────────┐
│   Channels   │  (22+ integrations)
│  (Slack,     │
│   Discord,   │
│   Email...)  │
└──────┬───────┘
       │
┌──────▼────────────┐
│   Agent Runtime   │  Core execution engine
│   + Gateway       │
└──────┬────────────┘
       │
┌──────▼────────────┐
│     Skills        │  Task executors
│  (ClawHub 13K+)   │
└───────────────────┘
```

### Core Components
1. **Gateway** - HTTP/WebSocket interface for agents
2. **Agent Runtime** - Execution engine with context management
3. **Skills System** - Modular task handlers (13,729+ available)
4. **Channel Adapters** - 22+ integrations (Slack, Discord, Email, etc.)
5. **Middleware** - Authentication, logging, rate limiting

---

## Official Tools

### 1. ClawHub - Skill Directory & Registry

**Repository:** openclaw/clawhub  
**Purpose:** Centralized marketplace for OpenClaw skills  
**Stats:** 13,729+ skills, 31 categories  

#### Features
- **Skill Search** - Browse by category, rating, downloads
- **CLI Tool** - `clawhub` command for install/search/publish
- **Registry API** - Programmatic access to skill metadata
- **Security** - VirusTotal scanning after ClawHavoc incident
- **Categories** - Data, Integration, Automation, AI, Cloud, etc.

#### CLI Usage
```bash
# Search skills
clawhub search "database"

# Install skill
clawhub install username/skill-name

# Publish skill
clawhub publish ./my-skill --public

# List installed
clawhub list
```

#### Integration with OpenClaw
```yaml
# openclaw-config.yaml
skills:
  registry: https://clawhub.io/api
  auto_update: true
  security_scan: true
```

---

### 2. OpenClaw Office - Visual Monitoring

**Repository:** WW-AI-Lab/openclaw-office  
**NPM Package:** @ww-ai-lab/openclaw-office  
**Purpose:** Real-time agent monitoring with visual representation  

#### Features
- **Isometric 2D/3D Visualization** - Virtual office metaphor
- **Real-Time Monitoring** - Live agent status updates
- **WebSocket Gateway** - Direct connection to OpenClaw Gateway
- **Interactive Dashboard** - Agent management UI
- **Task Visualization** - See running tasks in real-time

#### Architecture
```
┌─────────────────┐
│  OpenClaw Office│
│   (React App)   │
└────────┬────────┘
         │ WebSocket
┌────────▼────────────┐
│  OpenClaw Gateway   │
└─────────────────────┘
```

#### Installation
```bash
npm install @ww-ai-lab/openclaw-office

# In React component
import { ClawOffice } from '@ww-ai-lab/openclaw-office'

export default function Dashboard() {
  return <ClawOffice gatewayUrl="ws://localhost:3000" />
}
```

---

### 3. OpenClaw Mission Control - Orchestration

**Repository:** abhi1693/openclaw-mission-control  
**Purpose:** Multi-agent orchestration and management  

#### Features
- **Agent Discovery** - Auto-detects OpenClaw setup
- **Task Assignment** - Distribute work across agents
- **Multi-Agent Coordination** - Sync between agents
- **Real-Time Monitoring** - System health dashboard
- **Resource Management** - CPU, memory, bandwidth tracking

#### Key Capabilities
1. **Agent Lifecycle** - Deploy, monitor, scale agents
2. **Task Queue** - Distribute tasks with priority
3. **Inter-Agent Communication** - Message passing between agents
4. **Error Handling** - Retry logic, fallback strategies
5. **Analytics** - Task completion metrics, performance stats

#### Integration Example
```typescript
import { MissionControl } from 'openclaw-mission-control'

const control = new MissionControl({
  gatewayUrl: 'http://localhost:3000',
  autoDiscover: true
})

// Assign task across agents
await control.assignTask({
  task: 'process_invoice',
  agents: ['agent-1', 'agent-2'],
  priority: 'high'
})
```

---

## Community Projects

### 4. Nanobot - Ultra-Lightweight Alternative

**Repository:** HKUDS/nanobot  
**Stars:** 26,800+  
**Language:** Python  
**Size:** ~4,000 lines  
**Tagline:** "OpenClaw in 4K lines of Python"  

#### When to Use Nanobot
- ✅ Learning OpenClaw concepts
- ✅ Lightweight deployments (edge, embedded)
- ✅ 99% fewer lines than OpenClaw
- ✅ Python-first environments
- ❌ Need 22+ channels (only 10+)
- ❌ Complex multi-agent orchestration

#### Core Features
- Agent runtime in pure Python
- Basic skill system
- 10+ channel integrations
- Minimal dependencies
- Easy to fork and modify

#### Quick Start
```bash
git clone https://github.com/HKUDS/nanobot.git
cd nanobot
pip install -r requirements.txt
python -m nanobot
```

---

### 5. ClawWork - Economic Agent System

**Repository:** HKUDS/ClawWork  
**Tagline:** "OpenClaw as Your AI Coworker - $15K earned in 11 Hours"  
**Purpose:** Drop-in monetization layer for Nanobot  

#### Key Features
- **Economic Tracking** - Earnings per task
- **Professional Tasks** - 220+ pre-built task templates
- **Sector Coverage** - 44 professional sectors
- **Domain Support** - 4 business domains (Sales, Support, Data, Ops)
- **Marketplace** - Connect agents to task sources

#### Sectors Supported
- Finance & Accounting
- Sales & Business Development
- Customer Support
- Data & Analytics
- Human Resources
- Marketing & Communications
- Legal & Compliance
- Operations & Logistics

#### Integration with Nanobot
```python
from nanobot import Agent
from clawwork import EconomicLayer

agent = Agent()
economic = EconomicLayer(agent)

# Track earnings
async def handle_task(task):
    result = await agent.execute(task)
    earning = economic.calculate_reward(task, result)
    await economic.log_earning(task.id, earning)
    return result
```

#### Real-World Example
ClawWork agents have demonstrated:
- **$15,000 earned** in 11 hours
- Average task completion time: 8 minutes
- Success rate: 94%+
- Revenue distribution: Transparent, per-task

---

### 6. NanoClaw - Container-Based Deployment

**Repository:** qwibitai/nanoclaw  
**Stars:** 1K+  
**Foundation:** Anthropic's Agents SDK  
**Purpose:** Lightweight containerized OpenClaw alternative  

#### Features
- **Docker-Ready** - Pre-configured containers
- **6 Channel Integrations** - WhatsApp, Telegram, Slack, Discord, Gmail, Web
- **Anthropic Native** - Built on Agents SDK directly
- **Minimal Resource Usage** - ~2K lines Python
- **Cloud-Optimized** - Kubernetes deployment ready

#### Supported Channels
1. WhatsApp Business API
2. Telegram Bot API
3. Slack Bot Framework
4. Discord.py Intents
5. Gmail API
6. Web REST API

#### Docker Setup
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
CMD ["python", "-m", "nanoclaw"]
```

#### Environment Configuration
```bash
# .env
NANOCLAW_GATEWAY=http://localhost:3000
SLACK_BOT_TOKEN=xoxb-...
TELEGRAM_BOT_TOKEN=...
WHATSAPP_API_KEY=...
DISCORD_TOKEN=...
GMAIL_CREDENTIALS=...
```

---

### 7. CLAW3D - 3D Virtual Office

**Website:** claw3d.ai  
**Purpose:** Immersive 3D visualization of agent ecosystem  

#### Features
- **Full 3D Environment** - Virtual office for agents
- **Real-Time Visualization** - Live agent activities
- **Agent Communication Display** - Visual message flows
- **Task Visualization** - 3D representation of workflows
- **Interactive Dashboard** - Control agents in 3D space

#### Use Cases
- **Team Monitoring** - See all agents working in real-time
- **Demo/Presentation** - Impressive visualizations for stakeholders
- **Learning** - Better understand agent interactions
- **Analytics** - Visual performance metrics

---

### 8. soul.md - Agent Personality Framework

**Repository:** aaronjmars/soul.md  
**Purpose:** Define and build agent personality  

#### Philosophy
"The best way to build an agent personality is to let Claude Code/OpenClaw ingest data and build the AI soul"

#### Key Concepts
1. **Personality Definition** - Markdown-based soul definition
2. **Data Ingestion** - Feed training data to shape behavior
3. **Claude Integration** - Let Claude build the personality
4. **soul.md Format** - Standardized personality specification

#### soul.md Format Example
```markdown
# Agent Personality

## Core Values
- Empathy
- Transparency
- Efficiency

## Communication Style
- Friendly but professional
- Clear and concise
- Proactive in suggestions

## Decision-Making
- Data-driven
- User-focused
- Ethical by default

## Knowledge Base
[Ingest docs, PDFs, examples]
```

#### Integration with OpenClaw
```yaml
# agent-config.yaml
agent:
  name: "Emma"
  soul_file: ./soul.md
  personality:
    warmth: 8/10
    technical_depth: 7/10
    humor: 6/10
```

---

## Awesome OpenClaw Skills

**Repository:** VoltAgent/awesome-openclaw-skills  
**Content:** 5,490+ curated community skills  
**Organization:** 31 categories, community-filtered  

#### Top Categories
- **Data Processing** - ETL, transformation, cleaning
- **Integration** - API clients, webhook handlers
- **Automation** - Scheduling, workflow, RPA
- **AI Services** - LLM integration, embeddings
- **Cloud** - AWS, GCP, Azure operations
- **Communication** - Email, messaging, notifications
- **Databases** - SQL, NoSQL, analytics
- **Development** - Code generation, testing, CI/CD

#### Quality Metrics
- Star rating (community feedback)
- Download count
- Maintenance status
- Security scan results
- Documentation completeness

---

## Explain OpenClaw - Multi-AI Documentation

**Repository:** centminmod/explain-openclaw  
**Purpose:** Comprehensive OpenClaw documentation from multiple AI perspectives  

#### Contents
1. **Architecture Documentation**
   - Gateway design patterns
   - Agent runtime internals
   - Skill system architecture
   - Channel adapter patterns

2. **Security Audits**
   - Authentication mechanisms
   - Skill sandboxing
   - Rate limiting
   - Data isolation

3. **Deployment Guides**
   - Docker deployment
   - Kubernetes orchestration
   - Cloud platform setup (AWS, GCP, Azure)
   - Self-hosted infrastructure

4. **Advanced Topics**
   - Custom skill development
   - Multi-agent coordination
   - Performance optimization
   - Scaling strategies

---

## Documentation Resources

### Official Resources
| Resource | URL | Content |
|----------|-----|---------|
| **Official Docs** | docs.openclaw.ai | Complete API reference |
| **DeepWiki** | deepwiki.com/openclaw/openclaw | Community documentation |
| **Learn OpenClaw** | learnclawdbot.org | Tutorials and courses |
| **Blog** | openclawblog.space | News, updates, insights |
| **Launch Site** | openclawlaunch.com | Latest releases |

### Community Channels
- **Discord** - "Friends of the Crustacean" community
- **GitHub Discussions** - Technical Q&A
- **Reddit** - r/openclaw community

---

## Comparison Matrix

### Feature Comparison

```
┌──────────────┬──────────────┬────────────┬──────────────┬────────────┐
│ Feature      │ OpenClaw     │ Nanobot    │ NanoClaw     │ ClawWork   │
├──────────────┼──────────────┼────────────┼──────────────┼────────────┤
│ Stars        │ 247K         │ 26.8K      │ 1K+          │ 5K+        │
│ Language     │ TypeScript   │ Python     │ Python       │ Python     │
│ Lines        │ 100K+        │ 4K         │ 2K           │ 8K         │
│ Channels     │ 22+          │ 10+        │ 6            │ via Nanobot│
│ Skills       │ ClawHub 13K+ │ Basic      │ Basic        │ Economic   │
│ Complexity   │ High         │ Low        │ Low          │ Medium     │
│ Performance  │ Enterprise   │ Lightweight│ Docker       │ Economic   │
│ Deployment   │ Multi-agent  │ Single     │ Container    │ Single     │
│ Learning     │ Steeper      │ Easy       │ Easy         │ Moderate   │
└──────────────┴──────────────┴────────────┴──────────────┴────────────┘
```

### Use Case Recommendations

| Scenario | Recommended | Reason |
|----------|-------------|--------|
| **Enterprise system** | OpenClaw | 22+ channels, ClawHub ecosystem |
| **Learning AI agents** | Nanobot | Simple, 4K lines, educational |
| **Monetary rewards** | ClawWork | Economic tracking, $15K/11h example |
| **Lightweight deployment** | NanoClaw | Container-native, minimal resources |
| **3D visualization demo** | CLAW3D | Impressive for stakeholders |
| **Agent personality** | soul.md | Best personality definition tool |
| **Quick prototyping** | Nanobot | Fast to understand and modify |
| **Production at scale** | OpenClaw + Mission Control | Full orchestration support |

---

## Integration Patterns

### Pattern 1: OpenClaw + Mission Control + Office
**Best for:** Enterprise agent teams

```
┌───────────────────────────────┐
│    OpenClaw Office (UI)       │
│   (Visual monitoring - 2D/3D) │
└──────────┬────────────────────┘
           │
┌──────────▼──────────────────────────┐
│  Mission Control (Orchestration)    │
│  (Task assignment, coordination)    │
└──────────┬───────────────────────────┘
           │
┌──────────▼──────────────────────────┐
│     OpenClaw Gateway/Runtime        │
│     (Agent execution, 22+ channels) │
└───────────────────────────────────┘
```

**Workflow:**
1. Office shows real-time agent status
2. Mission Control assigns tasks across agents
3. OpenClaw executes with all channels available

### Pattern 2: Nanobot + ClawWork
**Best for:** Monetized lightweight agents

```python
Agent (Nanobot)
    ↓
Tasks (from marketplace)
    ↓
Economic Layer (ClawWork)
    ↓
Earnings tracking & distribution
```

### Pattern 3: NanoClaw + Multiple Channels
**Best for:** Multi-channel bot without OpenClaw complexity

```
WhatsApp ──┐
Telegram ──┤
Slack ─────┼─→ NanoClaw Container ─→ Core Logic
Discord ───┤
Gmail ─────┤
Web ───────┘
```

### Pattern 4: OpenClaw + soul.md
**Best for:** Personality-driven agents

```yaml
Agent
  ├─ soul.md (personality)
  ├─ skills (behavior)
  └─ channels (interface)
```

---

## Migration Guide

### From Nanobot to OpenClaw
**Difficulty:** Medium | **Time:** 1-2 weeks

**Steps:**
1. Export Nanobot skills to ClawHub format
2. Set up OpenClaw Gateway
3. Migrate channel configs (10+ → 22+)
4. Integrate with Mission Control
5. Add Office for monitoring

**Benefit:** Access 13K+ skills, better orchestration

### From Nanobot to ClawWork
**Difficulty:** Low | **Time:** 1-2 days

**Steps:**
1. Install ClawWork on existing Nanobot
2. Define task categories (44 sectors)
3. Configure reward structure
4. Enable marketplace connection

**Benefit:** Monetize agent work

### From NanoClaw to OpenClaw
**Difficulty:** Medium | **Time:** 2-3 weeks

**Steps:**
1. Export channel configs
2. Deploy OpenClaw instead
3. Migrate 6 channels to 22+
4. Add ClawHub integration
5. Set up Mission Control

**Benefit:** Enterprise features, more channels

---

## Selection Decision Tree

```
Start: Need AI Agent System?
│
├─ Learning mode?
│  └─ Yes → Nanobot (easy, educational)
│
├─ Need monetization?
│  └─ Yes → ClawWork (add to Nanobot/OpenClaw)
│
├─ Container-first deployment?
│  └─ Yes → NanoClaw (Docker-native)
│
├─ Need 20+ channels + enterprise scale?
│  └─ Yes → OpenClaw + Mission Control + Office
│
├─ Need 3D visualization?
│  └─ Yes → Add CLAW3D to any setup
│
├─ Need custom personality?
│  └─ Yes → Use soul.md framework
│
└─ Default recommendation → OpenClaw
```

---

## Key Contacts & Resources

### Creator & Leadership
- **Peter Steinberger** - OpenClaw creator (PSPDFKit founder)
- **WW-AI-Lab** - Office & visualization tools
- **HKUDS Team** - Nanobot & ClawWork creators
- **Community Maintainers** - soul.md, Awesome Skills, Explain docs

### External Dependencies
- **Anthropic Agents SDK** - Foundation for some tools
- **VirusTotal API** - Skill security scanning
- **Various Cloud Providers** - Cloud skill integrations

---

## Quick Command Reference

```bash
# ClawHub
clawhub search "keyword"
clawhub install user/skill
clawhub publish ./skill --public

# Nanobot
python -m nanobot --config config.yaml

# NanoClaw
docker run -e SLACK_TOKEN=xxx nanoclaw

# OpenClaw CLI (hypothetical)
openclaw agent create my-agent
openclaw skill install clawhub:user/skill
openclaw gateway start
```

---

## Summary

The OpenClaw Ecosystem provides multiple tools for different needs:

- **OpenClaw** - Full-featured enterprise solution
- **Nanobot** - Lightweight learning & quick prototyping
- **ClawWork** - Monetization layer
- **NanoClaw** - Container-first deployment
- **Mission Control** - Multi-agent orchestration
- **Office** - Visual monitoring
- **CLAW3D** - 3D visualization
- **soul.md** - Personality framework

**Choose based on:** Scale, language preference, deployment constraints, learning vs. production, monetization needs.

---

## Further Reading

- `/references/ecosystem-guide.md` - Detailed reference documentation
- `docs.openclaw.ai` - Official OpenClaw documentation
- `deepwiki.com/openclaw/openclaw` - Community wiki
- GitHub repositories for each tool

---

*Last updated: March 2026 | OpenClaw v1.0 (Post-Rename)*
