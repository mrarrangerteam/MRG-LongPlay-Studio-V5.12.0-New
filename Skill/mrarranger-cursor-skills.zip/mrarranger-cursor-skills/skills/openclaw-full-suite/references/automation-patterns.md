# OpenClaw Automation Patterns - Detailed Reference

Advanced patterns, troubleshooting, and deep-dive examples for OpenClaw Automation system.

## Table of Contents

1. [Advanced Cron Configuration](#advanced-cron-configuration)
2. [Webhook Implementation Details](#webhook-implementation-details)
3. [Browser Automation Recipes](#browser-automation-recipes)
4. [Canvas Advanced Patterns](#canvas-advanced-patterns)
5. [Voice Integration Deep-Dive](#voice-integration-deep-dive)
6. [Session State Management](#session-state-management)
7. [Node Workflow Patterns](#node-workflow-patterns)
8. [Error Handling & Recovery](#error-handling--recovery)
9. [Performance Optimization](#performance-optimization)
10. [Integration Examples](#integration-examples)
11. [Troubleshooting Guide](#troubleshooting-guide)

---

## Advanced Cron Configuration

### Timezone-Aware Scheduling

กำหนดตารางเวลาเฉพาะโซนเวลา:

```jsonc
{
  "automation": {
    "timezone": "Asia/Bangkok",
    "cron": [
      {
        "schedule": "0 9 * * *",
        "timezone": "Asia/Bangkok",        // Local timezone
        "message": "สวัสดีชาวไทย",
        "channel": "whatsapp",
        "agent": "greeter"
      },
      {
        "schedule": "0 8 * * *",
        "timezone": "America/New_York",    // Different timezone
        "message": "Good morning America",
        "channel": "discord",
        "agent": "us-greeter"
      }
    ]
  }
}
```

### Conditional Cron Execution

รันตามเงื่อนไขที่กำหนด:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "ตรวจสอบอุณหภูมิและส่งประเมิน",
  "agent": "weather-monitor",
  "channel": "whatsapp",
  "conditions": {
    "skipOn": ["holidays", "weekends"],
    "requireContext": {
      "tempAbove": 35,
      "humidityAbove": 80
    },
    "executeOnly": {
      "dayOfMonth": [1, 15]
    }
  }
}
```

### Staggered Execution

ป้องกัน thundering herd โดยกระจายเวลาการทำงาน:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "ดำเนินการบน",
  "agent": "processor",
  "execution": {
    "stagger": {
      "enabled": true,
      "minDelay": 0,
      "maxDelay": 300000,  // Max 5 minutes
      "distribution": "random"
    }
  }
}
```

### Retryable Cron Jobs

ลองใหม่อัตโนมัติ:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "ดึงข้อมูลจาก API",
  "agent": "data-fetcher",
  "retry": {
    "maxAttempts": 3,
    "backoffMs": 5000,
    "backoffMultiplier": 2,
    "onlyRetryOn": [408, 429, 500, 502, 503, 504]
  }
}
```

### Monitoring Cron Execution

ติดตามผลการทำงาน:

```jsonc
{
  "schedule": "0 9 * * *",
  "message": "task content",
  "agent": "worker",
  "monitoring": {
    "enabled": true,
    "logLevel": "info",
    "onSuccess": {
      "action": "log",
      "format": "Cron job {jobId} completed at {timestamp}"
    },
    "onFailure": {
      "action": "alert",
      "channel": "slack",
      "message": "Cron job failed: {error}"
    }
  }
}
```

---

## Webhook Implementation Details

### HMAC Signature Verification

ตรวจสอบลายเซ็น webhook:

```javascript
// ตัวอย่าง: Node.js verification
const crypto = require('crypto');

function verifyWebhookSignature(payload, signature, secret) {
  const hash = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(hash),
    Buffer.from(signature)
  );
}

// Usage
const isValid = verifyWebhookSignature(
  JSON.stringify(body),
  req.headers['x-webhook-signature'],
  process.env.WEBHOOK_SECRET
);
```

### Rate Limiting Pattern

จำกัดอัตราการเรียก webhook:

```jsonc
{
  "path": "/webhook/github",
  "secret": "secret",
  "agent": "handler",
  "rateLimit": {
    "type": "sliding-window",
    "maxRequests": 1000,
    "windowMs": 60000,
    "keyGenerator": "ip|userId",
    "onRateLimit": {
      "statusCode": 429,
      "message": "Too many requests"
    }
  }
}
```

### Webhook Payload Transformation

แปลง payload ก่อนส่งให้ agent:

```jsonc
{
  "path": "/webhook/github",
  "secret": "secret",
  "agent": "handler",
  "transform": {
    "enabled": true,
    "transformations": [
      {
        "path": "$.action",
        "type": "uppercase"
      },
      {
        "path": "$.pull_request.title",
        "type": "trim"
      },
      {
        "path": "$.repository.name",
        "type": "replace",
        "pattern": "/-/g",
        "replacement": "_"
      }
    ]
  }
}
```

### Conditional Webhook Routing

ส่ง webhook ไปยัง agent ต่างกันตามเนื้อหา:

```jsonc
{
  "path": "/webhook/github",
  "secret": "secret",
  "routing": [
    {
      "condition": "event === 'push' && branch === 'main'",
      "agent": "deploy-manager"
    },
    {
      "condition": "event === 'pull_request' && labels.includes('urgent')",
      "agent": "urgent-reviewer"
    },
    {
      "condition": "event === 'issues'",
      "agent": "issue-handler"
    }
  ]
}
```

### Webhook Retries

จัดการการลองใหม่สำหรับ webhook:

```jsonc
{
  "path": "/webhook/github",
  "webhook": {
    "retryPolicy": {
      "enabled": true,
      "maxRetries": 3,
      "initialDelayMs": 1000,
      "maxDelayMs": 60000,
      "backoffMultiplier": 2,
      "retryOnStatusCodes": [408, 429, 500, 502, 503, 504]
    }
  }
}
```

### Webhook Deduplication

หลีกเลี่ยงการประมวลผล webhook ซ้ำ:

```jsonc
{
  "path": "/webhook/github",
  "secret": "secret",
  "deduplication": {
    "enabled": true,
    "idempotencyKey": "X-GitHub-Delivery",
    "ttlSeconds": 300,
    "onDuplicate": "skip"
  }
}
```

---

## Browser Automation Recipes

### Form Submission with Validation

```javascript
// Automated form filling pattern
async function fillAndSubmitForm(formData) {
  // 1. Navigate
  await page.goto('https://example.com/form');

  // 2. Wait for form
  await page.waitForSelector('form');

  // 3. Fill fields
  for (const [selector, value] of Object.entries(formData)) {
    await page.click(selector);
    await page.type(selector, value);
  }

  // 4. Handle validation
  try {
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ timeout: 5000 });
    return { success: true, message: 'Form submitted' };
  } catch (error) {
    const errorMsg = await page.$eval(
      '.error-message',
      el => el.textContent
    );
    return { success: false, error: errorMsg };
  }
}
```

### Multi-Page Data Extraction

```javascript
// Extract data across multiple pages
async function extractPaginatedData() {
  const allData = [];
  let pageNum = 1;

  while (true) {
    // Navigate to page
    await page.goto(`https://example.com/items?page=${pageNum}`);

    // Extract data
    const pageData = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('.item')).map(el => ({
        title: el.querySelector('.title').textContent,
        price: el.querySelector('.price').textContent,
        link: el.querySelector('a').href
      }));
    });

    allData.push(...pageData);

    // Check for next page
    const hasNext = await page.$('.next-page') !== null;
    if (!hasNext) break;

    pageNum++;
  }

  return allData;
}
```

### Dynamic Content Wait Pattern

```javascript
// Wait for dynamic content to load
async function waitForDynamicContent() {
  // Wait for specific element
  await page.waitForSelector('.dynamic-content', { timeout: 10000 });

  // Wait for network to be idle
  await page.waitForNavigation({ waitUntil: 'networkidle2' });

  // Wait for specific condition
  await page.waitForFunction(() => {
    return document.querySelectorAll('.item').length > 0;
  }, { timeout: 5000 });
}
```

### Session Persistence

```javascript
// Save and restore browser session
async function persistSession() {
  // Save cookies
  const cookies = await page.cookies();
  fs.writeFileSync('cookies.json', JSON.stringify(cookies));

  // Save local storage
  const localStorage = await page.evaluate(() => {
    return Object.keys(window.localStorage).reduce((acc, key) => {
      acc[key] = window.localStorage.getItem(key);
      return acc;
    }, {});
  });
  fs.writeFileSync('localStorage.json', JSON.stringify(localStorage));
}

async function restoreSession() {
  // Restore cookies
  const cookies = JSON.parse(fs.readFileSync('cookies.json'));
  await page.setCookie(...cookies);

  // Restore localStorage
  const localStorage = JSON.parse(fs.readFileSync('localStorage.json'));
  await page.evaluate((data) => {
    Object.entries(data).forEach(([key, value]) => {
      window.localStorage.setItem(key, value);
    });
  }, localStorage);
}
```

### Screenshot Comparison

```javascript
// Compare screenshots for visual regression
async function compareScreenshots(name) {
  const screenshot = await page.screenshot();
  const baseline = fs.readFileSync(`baseline/${name}.png`);

  const diff = new Jimp(screenshot).diff(new Jimp(baseline));
  const diffPercent = (diff.percent * 100).toFixed(2);

  if (diffPercent > 5) {
    console.warn(`Visual difference: ${diffPercent}%`);
    return { different: true, diffPercent };
  }
  return { different: false };
}
```

---

## Canvas Advanced Patterns

### Dynamic Chart Generation

```javascript
// Create charts programmatically
async function generateChart(data) {
  const canvas = new Canvas(800, 600);
  const ctx = canvas.getContext('2d');

  // Draw chart using Chart.js
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.dates,
      datasets: [{
        label: 'Performance',
        data: data.values,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    }
  });

  canvas.push({
    type: 'image',
    url: canvas.toDataURL(),
    title: 'Performance Chart'
  });
}
```

### Live Update Pattern

```javascript
// Push real-time updates to canvas
async function liveUpdate(dataStream) {
  for await (const data of dataStream) {
    canvas.push({
      type: 'json',
      data: data,
      metadata: {
        timestamp: new Date().toISOString(),
        source: 'stream'
      }
    });

    // Update UI
    await sleep(1000);
  }
}
```

### HTML Template Rendering

```javascript
// Render HTML templates to canvas
async function renderTemplate(template, data) {
  const html = templateEngine.render(template, data);

  canvas.push({
    type: 'html',
    content: html,
    css: `
      body { font-family: Arial; }
      .title { color: #333; font-size: 24px; }
    `,
    width: 1000,
    height: 600
  });
}
```

---

## Voice Integration Deep-Dive

### Voice Command Recognition

```jsonc
{
  "voice": {
    "recognition": {
      "language": "th-TH",
      "confidence": 0.8,
      "maxAlternatives": 3,
      "continuous": false,
      "interimResults": true
    },
    "commands": [
      {
        "pattern": "^(ส่งข้อความ|แชท)",
        "action": "open_chat",
        "confidence": 0.7
      },
      {
        "pattern": "^(เปิด|แสดง)",
        "action": "open_app",
        "requiresConfirmation": true
      }
    ]
  }
}
```

### Multi-Language Voice

```jsonc
{
  "voice": {
    "languages": {
      "primary": "th-TH",
      "fallback": ["en-US"],
      "autoDetect": true
    },
    "tts": {
      "responseLanguage": "auto",
      "accent": "native"
    }
  }
}
```

### Voice Context Building

```javascript
// Build context from voice interactions
class VoiceContext {
  constructor() {
    this.history = [];
    this.entities = {};
  }

  addUtterance(text, lang) {
    this.history.push({
      text,
      lang,
      timestamp: new Date(),
      entities: this.extractEntities(text)
    });
  }

  getContext() {
    return {
      lastUtterance: this.history[this.history.length - 1],
      recentEntities: this.entities,
      conversationLength: this.history.length
    };
  }
}
```

---

## Session State Management

### Memory Persistence

```jsonc
{
  "sessions": {
    "memory": {
      "backend": "redis",
      "ttl": 86400,
      "encryption": {
        "enabled": true,
        "algorithm": "aes-256-gcm"
      },
      "compression": "gzip"
    }
  }
}
```

### State Sync Across Channels

```javascript
// Synchronize state between channels
class CrossChannelSync {
  async syncState(sessionId, updates) {
    const channels = ['whatsapp', 'discord', 'slack'];

    await Promise.all(channels.map(channel =>
      this.updateChannelState(sessionId, channel, updates)
    ));
  }

  async resolveConflict(sessionId, stateConflict) {
    // Last-write-wins strategy
    const resolution = stateConflict.sort(
      (a, b) => b.timestamp - a.timestamp
    )[0];

    return resolution;
  }
}
```

### Session Cleanup

```jsonc
{
  "sessions": {
    "cleanup": {
      "enabled": true,
      "idleTimeout": 3600000,
      "maxSessionDuration": 86400000,
      "archiveOldSessions": true,
      "scheduleCleanup": "0 3 * * *"
    }
  }
}
```

---

## Node Workflow Patterns

### Conditional Branching

```jsonc
{
  "nodes": [
    {
      "id": "check-user",
      "type": "agent",
      "agent": "validator"
    },
    {
      "id": "branch",
      "type": "conditional",
      "input": "${check-user.output}",
      "branches": {
        "authenticated": "process-request",
        "guest": "request-login",
        "blocked": "reject-request"
      }
    }
  ]
}
```

### Parallel Execution

```jsonc
{
  "nodes": [
    {
      "id": "fetch-email",
      "type": "agent",
      "agent": "email-fetcher",
      "parallel": true
    },
    {
      "id": "fetch-calendar",
      "type": "agent",
      "agent": "calendar-fetcher",
      "parallel": true
    },
    {
      "id": "merge",
      "type": "merge",
      "input": ["${fetch-email.output}", "${fetch-calendar.output}"]
    }
  ]
}
```

### Error Recovery

```jsonc
{
  "nodes": [
    {
      "id": "main-task",
      "type": "agent",
      "onError": {
        "type": "retry",
        "maxAttempts": 3,
        "backoff": "exponential"
      }
    },
    {
      "id": "fallback",
      "type": "agent",
      "executeOnNodeError": "main-task"
    }
  ]
}
```

---

## Error Handling & Recovery

### Global Error Handler

```jsonc
{
  "automation": {
    "errorHandling": {
      "globalHandler": true,
      "onError": {
        "log": true,
        "alert": {
          "channels": ["slack", "email"],
          "severity": "critical"
        },
        "retry": {
          "maxAttempts": 3,
          "backoffMs": 5000
        },
        "fallback": {
          "agent": "fallback-handler",
          "message": "An error occurred: {error}"
        }
      }
    }
  }
}
```

### Error Classification

```javascript
// Classify errors for intelligent handling
class ErrorClassifier {
  classify(error) {
    if (error.code === 'TIMEOUT') return 'temporary';
    if (error.code === 'AUTH_FAILED') return 'authentication';
    if (error.code === 'RATE_LIMIT') return 'rate-limit';
    if (error.code === 'NOT_FOUND') return 'permanent';
    return 'unknown';
  }

  shouldRetry(classification) {
    return ['temporary', 'rate-limit'].includes(classification);
  }
}
```

### Graceful Degradation

```javascript
// Degrade gracefully on error
async function processWithFallback(data) {
  try {
    return await premiumProcessing(data);
  } catch (error) {
    console.warn('Premium processing failed, using fallback');
    return await basicProcessing(data);
  }
}
```

---

## Performance Optimization

### Caching Strategy

```jsonc
{
  "automation": {
    "cache": {
      "enabled": true,
      "backend": "redis",
      "ttl": 3600,
      "patterns": [
        {
          "key": "news:*",
          "ttl": 1800
        },
        {
          "key": "user:*",
          "ttl": 7200
        }
      ]
    }
  }
}
```

### Request Batching

```javascript
// Batch multiple requests
class RequestBatcher {
  constructor(flushInterval = 1000) {
    this.queue = [];
    this.flushInterval = flushInterval;
    this.timer = setInterval(() => this.flush(), flushInterval);
  }

  add(request) {
    this.queue.push(request);
    if (this.queue.length >= 100) {
      this.flush();
    }
  }

  async flush() {
    if (this.queue.length === 0) return;

    const batch = this.queue.splice(0);
    await this.processBatch(batch);
  }
}
```

### Connection Pooling

```jsonc
{
  "automation": {
    "connections": {
      "pool": {
        "maxConnections": 50,
        "minConnections": 5,
        "maxIdleTime": 300000,
        "acquireTimeout": 10000
      }
    }
  }
}
```

---

## Integration Examples

### OpenClaw + n8n

```jsonc
{
  "integrations": {
    "n8n": {
      "webhookUrl": "https://n8n.example.com/webhook/openclaw",
      "mappings": [
        {
          "source": "agent.output",
          "target": "n8n.input"
        },
        {
          "source": "n8n.output",
          "target": "agent.input"
        }
      ]
    }
  }
}
```

### OpenClaw + Zapier

```jsonc
{
  "integrations": {
    "zapier": {
      "webhookUrl": "https://hooks.zapier.com/hooks/catch/...",
      "eventMapping": {
        "cron_fired": "trigger_workflow",
        "webhook_received": "process_in_zapier"
      }
    }
  }
}
```

### OpenClaw + Make

```jsonc
{
  "integrations": {
    "make": {
      "webhookUrl": "https://hook.integromat.com/...",
      "dataTransform": {
        "format": "json",
        "includeMetadata": true
      }
    }
  }
}
```

---

## Troubleshooting Guide

### Cron Jobs Not Running

**Problem:** Cron jobs scheduled but not executing

**Solutions:**
1. Verify cron expression syntax: `0 9 * * *`
2. Check agent exists and is enabled
3. Review timezone settings
4. Check logs for errors

```bash
# Check cron job status
openclaw automation cron status

# View recent executions
openclaw automation cron logs --limit 10

# Test cron expression
openclaw automation cron test "0 9 * * *"
```

### Webhook Not Triggering

**Problem:** Webhook endpoint configured but not receiving requests

**Solutions:**
1. Verify secret key matches
2. Check network connectivity
3. Confirm endpoint path is correct
4. Review firewall rules

```bash
# Test webhook endpoint
curl -X POST https://your-openclaw.com/webhook/github \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Signature: $(openssl dgst -sha256 -hmac 'secret' payload.json)" \
  -d @payload.json
```

### Browser Automation Timeouts

**Problem:** Browser operations timing out

**Solutions:**
1. Increase timeout values
2. Wait for elements more explicitly
3. Handle network delays
4. Check browser resources

```javascript
// Increase timeout
await page.goto(url, { timeout: 30000 });

// Wait for element explicitly
await page.waitForSelector('.element', { timeout: 10000 });

// Wait for network
await page.waitForNavigation({ waitUntil: 'networkidle0' });
```

### Voice Recognition Issues

**Problem:** Voice commands not being recognized

**Solutions:**
1. Check microphone permissions
2. Verify language setting matches spoken language
3. Test with clearer audio
4. Adjust confidence threshold

```jsonc
{
  "voice": {
    "recognition": {
      "confidence": 0.7,
      "language": "th-TH",
      "interimResults": true
    }
  }
}
```

### Session State Conflicts

**Problem:** Inconsistent state across channels

**Solutions:**
1. Enable session sync
2. Use conflict resolution strategy
3. Monitor sync latency
4. Implement state validation

```jsonc
{
  "sessions": {
    "sync": {
      "enabled": true,
      "interval": 5000,
      "conflictResolution": "last-write-wins",
      "validation": "strict"
    }
  }
}
```

---

## Appendix: Configuration Templates

### Minimal Automation Setup

```jsonc
{
  "automation": {
    "enabled": true,
    "cron": [
      {
        "schedule": "0 9 * * *",
        "message": "Hello",
        "channel": "whatsapp",
        "agent": "default"
      }
    ],
    "webhooks": {
      "enabled": false
    }
  }
}
```

### Full-Featured Setup

```jsonc
{
  "automation": {
    "timezone": "Asia/Bangkok",
    "cron": [
      {
        "schedule": "0 9 * * *",
        "message": "Daily task",
        "channel": "whatsapp",
        "agent": "general",
        "monitoring": { "enabled": true }
      }
    ],
    "webhooks": {
      "enabled": true,
      "endpoints": [
        {
          "path": "/webhook/github",
          "secret": "secret",
          "agent": "coder"
        }
      ]
    },
    "browser": {
      "enabled": true,
      "headless": false,
      "timeout": 30000
    },
    "voice": {
      "enabled": true,
      "languages": ["th-TH", "en-US"]
    },
    "sessions": {
      "autoCreate": true,
      "persist": true
    }
  }
}
```

---

**Last Updated:** 2026-03-15
**OpenClaw Version:** 1.0+
**Compatible Agents:** All channel agents
