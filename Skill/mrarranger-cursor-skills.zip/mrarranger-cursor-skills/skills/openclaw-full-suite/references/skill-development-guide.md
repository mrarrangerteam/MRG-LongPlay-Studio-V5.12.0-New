# OpenClaw Skills Development - Complete Reference Guide

## Table of Contents

1. [Three-Tier Loading Architecture](#three-tier-loading-architecture)
2. [Skill Manifest Deep Dive](#skill-manifest-deep-dive)
3. [Creating Professional Skills](#creating-professional-skills)
4. [MCP Skills Integration](#mcp-skills-integration)
5. [Testing Strategies](#testing-strategies)
6. [Security Hardening](#security-hardening)
7. [Publishing Workflow](#publishing-workflow)
8. [ClawHub Registry Integration](#clawhub-registry-integration)
9. [Troubleshooting Guide](#troubleshooting-guide)
10. [Real-World Examples](#real-world-examples)

---

## Three-Tier Loading Architecture

OpenClaw skills use intelligent progressive disclosure to optimize loading performance and user experience.

### Tier 1: Discovery & Search (Minimal Load)

**When:** User searches for skills, lists available skills, or browses categories
**What's Loaded:** YAML frontmatter metadata only (first 200 bytes)
**Load Time:** <50ms per skill
**Memory:** ~2KB per skill

```yaml
# ONLY these fields loaded for Tier 1
name: my-skill                    # Unique identifier
description: |                    # First 30-50 tokens only
  One-line summary for discovery.
  Keep brief and keyword-rich.
emoji: 🎯                        # Visual identifier
version: "1.0.0"                 # For pinning
category: "development"          # Category filtering
tags: ["tag1", "tag2"]           # Search refinement
```

**Use Case:** `clawhub search "database" --limit 50`
- Only Tier 1 loaded for all 50 results
- Fast response (<200ms for 50 skills)
- Enough info to decide if interested

### Tier 2: Preview & Selection (Partial Load)

**When:** User selects skill from list, reads preview, checks examples
**What's Loaded:** Full YAML + SKILL.md body (up to first 5KB)
**Load Time:** ~100-200ms
**Memory:** ~50KB per skill

```markdown
---
[Full YAML frontmatter]
---

# My Skill

Quick introduction and use cases.

## Usage Examples

```bash
# Command example
/my-command --option value
```

## Quick Start

Brief setup instructions.

[Rest of inline documentation...]

For detailed API reference, see {baseDir}/references/api-reference.md
For architecture details, see {baseDir}/references/architecture.md
```

**Use Case:** User views skill preview before installation
- Enough info to understand functionality
- Examples show basic usage
- References point to detailed docs
- Progressive: "See {baseDir}/references/..." for more

### Tier 3: Full Context Load (Complete)

**When:** Skill selected/executed, user needs full implementation details
**What's Loaded:** All files including references/, scripts/, configs/
**Load Time:** ~500-1000ms
**Memory:** Full skill size (typically 100KB-1MB)

```
my-skill/
├── SKILL.md                      # All content loaded
├── references/
│   ├── architecture.md           # Full implementation guide
│   ├── api-reference.md          # Complete API docs
│   ├── security-audit.md         # Security details
│   └── examples.md               # Advanced examples
├── scripts/
│   ├── validate.py               # Validation logic
│   ├── setup.js                  # Initialization
│   └── cli.py                    # CLI implementation
└── configs/
    ├── openclaw.json             # Configuration schema
    └── defaults.yaml             # Default settings
```

**Use Case:** Skill execution, advanced configuration
- Full implementation details available
- Scripts can be executed
- Configuration loaded and applied
- Sandbox mode available for untrusted skills

### Tier Loading Flow

```
User Action                 Tier Loaded              Response Time
─────────────────────────────────────────────────────────────────
Search "database"       →   Tier 1 (50 skills)    →   <200ms
View skill preview      →   Tier 2                →   ~150ms
Select/Execute skill    →   Tier 3                →   ~800ms
Install skill locally   →   Tier 3                →   ~300ms (cached)
```

---

## Skill Manifest Deep Dive

### Complete YAML Frontmatter Reference

```yaml
---
# REQUIRED FIELDS
name: skill-identifier              # Must be unique in namespace
                                    # Format: lowercase-with-hyphens
                                    # Length: 3-50 characters
                                    # Regex: ^[a-z0-9-]+$

description: |                      # 30-50 tokens for Tier 1 (crucial!)
  One-sentence summary with keywords for search.
  Keep specific and action-oriented.
  Example: "Execute SQL queries with prepared statements."

# RECOMMENDED FIELDS
emoji: 🎯                           # Single emoji for UI (U+0000 to U+10FFFF)
version: "1.0.0"                    # Semantic versioning (MAJOR.MINOR.PATCH)
author: "Your Name"                 # Creator attribution
license: "MIT"                       # SPDX license identifier
category: "development"             # From: 31 predefined categories
                                    # See: categories.json in registry

# DEPENDENCIES
requires:
  bins:                             # Executable requirements
    - "node"                        # Optional version: "node@18.0.0"
    - "python3"                     # Checked at load time
    - "ffmpeg"
  envVars:                          # Environment variables
    - "API_KEY"                     # Required variables
    - "LOG_LEVEL"                   # Optional: "OPTIONAL_VAR?"
  externalEndpoints:                # External HTTP calls
    - "https://api.example.com"    # Declare all external APIs
    - "https://cdn.example.com"

# DISCOVERY & METADATA
tags:                               # Search tags (max 10)
  - keyword1
  - keyword2
  - capability
repository: "https://github.com/user/skill"
homepage: "https://example.com"
bugTracker: "https://github.com/user/skill/issues"

# SECURITY & SANDBOXING
sandbox:
  type: "docker"                    # Options: docker, vm, none
  image: "python:3.11-slim"         # Docker image if type=docker
  mounts:                           # Volume mounts
    - source: "/tmp"
      target: "/workspace"
      readonly: false

# MCP INTEGRATION
mcp:
  enabled: true                     # Enable MCP server wrapping
  server: "@anthropic/mcp-server"  # MCP package name
  tools:                            # Exposed tools from MCP
    - name: tool-name
      description: "Tool description"

# ADVANCED CONFIGURATION
config:
  timeout: 30                        # Default timeout in seconds
  retries: 3                         # Automatic retry count
  cacheable: true                    # Enable result caching
  parallelizable: false              # Can run in parallel

# SKILL FLAGS
flags:
  experimental: false               # Mark as beta/experimental
  deprecated: false                 # Mark as deprecated
  requiresAuth: true                # Needs authentication
  dataProcessing: true              # Processes user data
---
```

### Category List (31 Categories)

```
development, data-science, devops, automation, productivity,
ai-ml, database, api-integration, security, testing,
content-creation, documentation, monitoring, performance,
networking, cloud, containers, git, cli-tools, code-quality,
analytics, visualization, utility, entertainment, education,
infrastructure, backup, web-scraping, system-admin, time-management,
custom
```

### Discovery Keywords Best Practices

**DON'T:**
```yaml
description: "This is a great skill that does stuff"  # Too vague
description: "My skill"                                # No info
description: "Skill for database work"                 # Unclear
```

**DO:**
```yaml
description: |
  Execute secure SQL queries with prepared statements.
  Supports: PostgreSQL 12+, MySQL 5.7+, SQLite 3.
  Features: Query validation, connection pooling, transaction management.
  Use: Database operations, analytics exports, data migrations.
```

**Keywords that trigger search:**
- Action verbs: Execute, Parse, Transform, Validate, Generate, Analyze
- Technology names: PostgreSQL, Docker, Kubernetes, AWS
- Capability words: secure, fast, parallel, reliable, monitored
- Problem domain: database, deployment, testing, security, performance

---

## Creating Professional Skills

### Directory Structure Best Practices

```
my-professional-skill/
├── SKILL.md                          # Main manifest (keep <500 lines)
├── LICENSE                           # Apache 2.0 recommended
├── README.md                         # GitHub readme (optional, if published)
├── CHANGELOG.md                      # Version history
├── package.json                      # Node.js metadata
├── pyproject.toml                    # Python metadata
│
├── references/                       # Detailed documentation (Tier 3)
│   ├── skill-development-guide.md   # Architecture & patterns
│   ├── api-reference.md             # Complete API documentation
│   ├── configuration.md             # Configuration schema
│   ├── examples.md                  # Real-world examples
│   ├── troubleshooting.md           # Common issues & solutions
│   ├── security-audit.md            # Security review details
│   └── changelog.md                 # Detailed version history
│
├── scripts/                          # Supporting executables
│   ├── validate.py                  # Validation script
│   ├── setup.js                     # Initialization
│   ├── cli.py                       # CLI implementation
│   ├── requirements.txt             # Python dependencies
│   └── package.json                 # Node.js dependencies
│
├── configs/                          # Configuration templates
│   ├── openclaw.json                # Skill config schema
│   ├── default-config.yaml          # Default settings
│   └── example-config.yaml          # Example configuration
│
├── tests/                            # Test suite
│   ├── unit/
│   │   ├── test-validation.py
│   │   └── test-parsing.js
│   ├── integration/
│   │   ├── test-api-integration.py
│   │   └── test-error-handling.py
│   └── fixtures/
│       ├── sample-input.json
│       └── expected-output.json
│
└── .gitignore                        # Git ignore rules
```

### SKILL.md Progressive Disclosure Pattern

**Keep SKILL.md <500 lines** by following this structure:

```markdown
---
[Frontmatter]
---

# Skill Title (h1)

**1. Quick Intro (50 words max)**
One sentence about what it does, what problem it solves.

**2. Quick Start (100 words + code block)**
Minimal example showing basic usage.

**3. Features List (Bullet points)**
- Feature with brief description
- Feature with brief description

**4. Installation & Setup (5-10 lines)**
Basic setup commands.

**5. Common Use Cases (Bullet points)**
- Use case 1
- Use case 2

**6. Support & References (External links)**
For detailed API reference, see {baseDir}/references/api-reference.md
For configuration guide, see {baseDir}/references/configuration.md
For examples, see {baseDir}/references/examples.md
For troubleshooting, see {baseDir}/references/troubleshooting.md

[Total: ~300-400 lines for good skills]
```

### Example Professional Skill

See {baseDir}/references/examples.md for complete working examples:
1. **sql-query-builder** - Database operations skill
2. **container-orchestrator** - Docker/Kubernetes wrapper
3. **document-processor** - PDF/text processing
4. **api-gateway** - REST API wrapper skill

---

## MCP Skills Integration

MCP (Model Context Protocol) servers can be wrapped as OpenClaw skills.

### Basic MCP Skill Structure

```yaml
---
name: mcp-example-skill
description: Wrapped MCP server for example functionality
emoji: 🔌
version: "1.0.0"
mcp:
  enabled: true
  server: "@anthropic/mcp-server-example"
  tools:
    - name: example_tool
      description: Tool from MCP server
      enabled: true
---

# MCP Wrapped Skill

This skill wraps an MCP (Model Context Protocol) server.

## Available Tools

See {baseDir}/references/mcp-tools.md for complete tool documentation.

For setup instructions, see {baseDir}/references/setup.md
```

### Converting MCP Server to Skill

1. **Identify MCP server package**
   ```bash
   npm search "@anthropic/mcp-server-" | grep -E "mcp-server-"
   ```

2. **Create SKILL.md with MCP config**
   ```yaml
   mcp:
     enabled: true
     server: "@anthropic/mcp-server-filesystem"
     tools:
       - name: read_file
       - name: write_file
       - name: list_directory
   ```

3. **Document exposed tools**
   - Reference MCP server documentation
   - Add parameter examples in {baseDir}/references/

4. **Test MCP integration**
   ```bash
   openclaw skill test ./mcp-skill --verbose
   ```

### MCP Tool Exposure

```yaml
mcp:
  enabled: true
  server: "@anthropic/mcp-server-sqlite"
  tools:
    - name: query                      # Expose tool
      description: "Execute SQL query"
      parameters:
        sql:
          type: "string"
          description: "SQL query"
        db_path:
          type: "string"
          description: "Database file path"
    - name: schema                     # Expose another tool
      description: "Get database schema"
```

---

## Testing Strategies

### Unit Testing Pattern

**File: tests/unit/test-validation.py**

```python
import pytest
import sys
from pathlib import Path

# Add scripts to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "scripts"))

from validate import validate_skill, validate_command

class TestSkillValidation:
    def test_skill_structure(self):
        """Test skill directory structure validation."""
        result = validate_skill(".")
        assert result["valid"] == True
        assert len(result["errors"]) == 0

    def test_yaml_frontmatter(self):
        """Test YAML frontmatter parsing."""
        skill = parse_skill_manifest("./SKILL.md")
        assert skill["name"] == "my-skill"
        assert "description" in skill
        assert len(skill["description"].split()) >= 20

    def test_required_fields(self):
        """Test all required YAML fields present."""
        skill = parse_skill_manifest("./SKILL.md")
        required = ["name", "description", "version"]
        for field in required:
            assert field in skill, f"Missing required field: {field}"

    def test_version_semver(self):
        """Test semantic versioning format."""
        skill = parse_skill_manifest("./SKILL.md")
        version = skill["version"]
        assert re.match(r'^\d+\.\d+\.\d+$', version), \
            f"Invalid semver: {version}"

    def test_no_hardcoded_secrets(self):
        """Test for hardcoded credentials."""
        secret_patterns = [
            r'(?i)(password|passwd|pwd)\s*[:=]',
            r'(?i)(token|auth|api[_-]?key)\s*[:=]',
            r'(?i)(secret|credential)\s*[:=]'
        ]

        for filepath in Path(".").rglob("*"):
            if filepath.is_file() and not filepath.name.startswith("."):
                content = filepath.read_text()
                for pattern in secret_patterns:
                    matches = re.finditer(pattern, content)
                    assert not any(matches), \
                        f"Possible hardcoded secret in {filepath}"

@pytest.mark.parametrize("category", [
    "development", "data-science", "automation",
    "api-integration", "security"
])
def test_valid_categories(category):
    """Test valid skill categories."""
    skill = parse_skill_manifest("./SKILL.md")
    valid_categories = load_valid_categories()
    assert skill["category"] in valid_categories
```

### Integration Testing Pattern

**File: tests/integration/test-api-integration.py**

```python
import pytest
import asyncio
from pathlib import Path

@pytest.fixture
def skill_runner():
    """Set up skill runner for testing."""
    runner = SkillRunner("./", verbose=True)
    yield runner
    runner.cleanup()

class TestSkillIntegration:
    def test_command_execution(self, skill_runner):
        """Test skill command execution."""
        result = skill_runner.execute_command(
            "example-command",
            options={"param": "value"}
        )
        assert result["success"] == True
        assert "output" in result

    def test_error_handling(self, skill_runner):
        """Test skill error handling."""
        result = skill_runner.execute_command(
            "example-command",
            options={"invalid": "option"}
        )
        assert result["success"] == False
        assert "error" in result

    def test_external_api_calls(self, skill_runner):
        """Test external API integration."""
        # Mock external API
        with patch('requests.get') as mock_get:
            mock_get.return_value.json.return_value = {"status": "ok"}

            result = skill_runner.execute_command("fetch-data")
            assert result["success"] == True

    @pytest.mark.asyncio
    async def test_async_operations(self, skill_runner):
        """Test asynchronous skill operations."""
        result = await skill_runner.execute_async_command(
            "long-operation",
            timeout=30
        )
        assert result["completed"] == True

    def test_concurrent_execution(self, skill_runner):
        """Test skill can handle concurrent requests."""
        commands = [
            {"cmd": "operation-1", "opts": {}},
            {"cmd": "operation-2", "opts": {}},
            {"cmd": "operation-3", "opts": {}}
        ]

        results = skill_runner.execute_concurrent(commands)
        assert len(results) == 3
        assert all(r["success"] for r in results)
```

### Prompt Testing Pattern

**File: tests/integration/test-prompt-responses.py**

```python
import pytest

PROMPT_TEST_CASES = [
    {
        "prompt": "Execute a simple SQL query",
        "expected_contains": ["SELECT", "query"],
        "should_not_contain": ["DROP", "DELETE"]
    },
    {
        "prompt": "Show me all databases",
        "expected_contains": ["SHOW DATABASES"],
        "should_not_contain": []
    },
    {
        "prompt": "Update user table",
        "expected_contains": ["UPDATE"],
        "should_not_contain": ["DROP"]
    }
]

@pytest.mark.parametrize("test_case", PROMPT_TEST_CASES)
def test_prompt_responses(test_case):
    """Test skill response to various prompts."""
    skill = load_skill()
    response = skill.process_prompt(test_case["prompt"])

    for expected in test_case["expected_contains"]:
        assert expected in response, \
            f"Expected '{expected}' in response"

    for forbidden in test_case["should_not_contain"]:
        assert forbidden not in response, \
            f"Should not contain '{forbidden}'"
```

### Running Tests

```bash
# Run all tests with coverage
openclaw skill test ./my-skill --coverage --verbose

# Output:
# ✓ Unit tests: 12 passed
# ✓ Integration tests: 8 passed
# ✓ Security tests: 5 passed
# ✓ Coverage: 87%

# Run specific test suite
openclaw skill test ./my-skill --suite "unit"

# Test specific command
openclaw skill test ./my-skill --command "query-builder"

# Generate coverage report
openclaw skill test ./my-skill --coverage --report html
```

---

## Security Hardening

### Security Review Checklist

Before publishing, validate against this checklist:

```markdown
## Pre-Publishing Security Audit

### Code Analysis
- [ ] No hardcoded API keys, tokens, or credentials
- [ ] No hardcoded database passwords
- [ ] No embedded test credentials
- [ ] All environment variables properly declared
- [ ] No obfuscated or minified code (without justification)
- [ ] Code review completed for injection vulnerabilities

### Input Validation
- [ ] All user inputs validated before processing
- [ ] SQL queries use parameterized statements
- [ ] Shell commands avoid string concatenation
- [ ] Path traversal attacks prevented (../../ patterns)
- [ ] File operations restricted to intended directories
- [ ] JSON/XML parsing handles malformed input

### External Integration
- [ ] All external API endpoints declared in frontmatter
- [ ] HTTPS enforced for all external calls
- [ ] SSL certificate validation enabled
- [ ] API credentials stored in environment variables
- [ ] Rate limiting implemented for external calls
- [ ] Error messages don't leak sensitive info

### Permissions & Access
- [ ] Script files properly marked executable
- [ ] No unnecessary file system permissions
- [ ] No elevation to root without justification
- [ ] Sandboxing requirements documented
- [ ] Data handling policy clear and documented

### Dependencies
- [ ] All dependencies documented (bins, Python, Node.js)
- [ ] Dependency versions pinned for security
- [ ] No deprecated/vulnerable dependencies
- [ ] Dependency licenses compatible
- [ ] Transitive dependencies reviewed

### Documentation
- [ ] Security considerations documented
- [ ] Error handling strategy explained
- [ ] Limitations clearly stated
- [ ] Data retention policy specified
- [ ] Compliance requirements noted (GDPR, HIPAA, etc.)

### Testing
- [ ] Security tests included
- [ ] Injection attack tests included
- [ ] Error handling tests included
- [ ] Edge cases tested
- [ ] No test credentials in code
```

### Automated Security Scanning

```bash
# Run automatic security checks
openclaw skill validate ./my-skill --security-audit

# Output:
# Security Audit Results
# ═════════════════════════════════════
#
# Code Analysis:
# ✓ No hardcoded credentials detected
# ✓ No obfuscated code detected
# ⚠ Warning: External API call to https://api.example.com
#   → Declared in frontmatter: Yes
#   → SSL enforced: Yes
#   → Rate limiting: Not found
#
# Input Validation:
# ✓ SQL queries use parameterized statements
# ✗ CRITICAL: Shell command in scripts/process.sh uses string concatenation
#   → Line 42: rm -rf $FOLDER_PATH
#   → Recommendation: Use quotes or safer alternative
#
# VirusTotal Scan:
# ✓ No malware detected
# ✓ No suspicious patterns detected
#
# Severity: 1 Critical, 1 Warning, 0 Info
# Recommendation: Fix critical issues before publishing
```

### Red Flags That Block Publishing

Automatically rejected if:
```
1. ✗ Hardcoded credentials (tokens, API keys, passwords)
2. ✗ Obfuscated code without explanation
3. ✗ Undeclared external API calls
4. ✗ VirusTotal detects malware signatures
5. ✗ Shell commands with unsanitized user input
6. ✗ Privilege escalation without documentation
7. ✗ Network access without declaration
8. ✗ File system access to sensitive paths
9. ✗ No input validation on user data
10. ✗ Disabled SSL certificate verification
```

### Vulnerability Response Protocol

If vulnerability found after publishing:

1. **Immediate Actions (within 1 hour)**
   - Pull skill from registry: `clawhub unpublish my-skill@1.0.0`
   - Post security bulletin to GitHub
   - Notify direct users via email

2. **Remediation (within 24 hours)**
   - Fix vulnerability in codebase
   - Run full security audit
   - Add regression tests
   - Bump version: `1.0.0` → `1.0.1`

3. **Re-publishing (within 48 hours)**
   - Full security scan
   - Publish patched version
   - Announce patch availability

---

## Publishing Workflow

### Step 1: Pre-Publishing Checklist

```bash
# Validate structure
openclaw skill validate ./my-skill --verbose

# Run tests
openclaw skill test ./my-skill --coverage

# Security audit
openclaw skill validate ./my-skill --security-audit

# Verify package.json or pyproject.toml
cat package.json        # For Node.js
cat pyproject.toml      # For Python
```

### Step 2: Create GitHub Account (if needed)

- Must be ≥1 week old
- Linked to publishing account
- 2FA enabled recommended

### Step 3: Authentication Setup

```bash
# Install clawhub CLI
npm install -g clawhub

# Login with GitHub
clawhub login
# Opens browser for GitHub OAuth
# Stores token: ~/.clawhub/credentials.json

# Verify login
clawhub whoami
# Output: You are logged in as: your-username
```

### Step 4: Dry-Run Before Publishing

```bash
# Test publish without uploading
clawhub publish ./my-skill --dry-run

# Output:
# ┌─ Dry-Run Publish ──────────────────┐
# │ Skill: my-awesome-skill           │
# │ Version: 1.0.0                    │
# │ Author: Your Name                 │
# │ Size: 256 KB                      │
# │ Dependencies: Node.js, Python 3   │
# │ Security Scan: ✓ Pass             │
# │                                   │
# │ Would be published to:            │
# │ registry.clawhub.io/my-awesome... │
# │                                   │
# │ Run without --dry-run to publish  │
# └───────────────────────────────────┘
```

### Step 5: Publish to ClawHub

```bash
# First-time publish
clawhub publish ./my-skill \
  --slug "my-awesome-skill" \
  --name "My Awesome Skill" \
  --version "1.0.0" \
  --description "Full description here"

# Update existing skill (new version)
# Version automatically bumped from SKILL.md
clawhub publish ./my-skill --version "1.0.1"

# With additional metadata
clawhub publish ./my-skill \
  --version "1.0.0" \
  --homepage "https://example.com" \
  --repository "https://github.com/user/skill"
```

### Step 6: Verify Publishing

```bash
# Check if published
clawhub inspect my-awesome-skill

# Output:
# Skill: My Awesome Skill
# ═══════════════════════════════════════════
#
# Author: Your Name
# Version: 1.0.0
# Published: 2026-03-15 14:30:00 UTC
# Downloads: 0
# Rating: No ratings yet
#
# Description:
# Full description here
#
# Requirements:
#   Binaries: node, python3
#   Environment: API_KEY, LOG_LEVEL
#
# Repository: https://github.com/user/skill
# Homepage: https://example.com
```

### Update Workflow (New Version)

```bash
# 1. Make changes to skill
# 2. Run tests
openclaw skill test ./my-skill

# 3. Update version in SKILL.md
---
version: "1.0.1"
---

# 4. Update CHANGELOG.md with changes
# 5. Publish new version
clawhub publish ./my-skill --version "1.0.1"

# 6. Verify
clawhub inspect my-awesome-skill --version "1.0.1"

# Users can pin version in their config:
# openclaw.json:
# {
#   "skills": {
#     "my-awesome-skill": "1.0.1"
#   }
# }
```

---

## ClawHub Registry Integration

### Registry Architecture

```
Registry Overview (Feb 2026)
═════════════════════════════════
Total Skills:     13,729+
Published Monthly: ~150-200
Downloads/Day:    ~50,000+
Active Users:     ~8,000+
Categories:       31
Average Rating:   4.2/5.0
```

### Semantic Search

ClawHub uses semantic search (not keyword matching) for discovery:

```bash
# Semantic search examples
clawhub search "Execute SQL safely"
# Results: sql-query-builder, database-validator, sql-injection-filter

clawhub search "Docker deployment automation"
# Results: container-orchestrator, docker-deployer, k8s-manager

clawhub search "Process text documents"
# Results: document-processor, pdf-extractor, text-analyzer

# Traditional keyword search (exact match)
clawhub search "database" --keyword
# Results: database-validator, sql-query-builder, db-connector
```

### Registry Statistics

```bash
# Browse categories
clawhub categories

# Output:
# Categories (31 total)
# ═════════════════════════════════════════
# 1. development          (2,143 skills)
# 2. data-science         (1,876 skills)
# 3. automation           (1,654 skills)
# 4. devops               (1,234 skills)
# 5. api-integration      (987 skills)
# 6. security             (876 skills)
# ... 25 more categories

# Top skills by downloads
clawhub trending --limit 10

# Output:
# Top 10 Skills This Month
# ════════════════════════════════════════════════════════════
# 1. sql-query-builder       (1,234 downloads) ★★★★★ 4.9
# 2. container-deployer      (1,102 downloads) ★★★★★ 4.8
# 3. markdown-converter      (998 downloads)   ★★★★☆ 4.3
# 4. json-validator         (876 downloads)   ★★★★★ 4.7
# 5. api-gateway            (765 downloads)   ★★★★☆ 4.4
# ... 5 more
```

### Installation & Version Management

```bash
# Install latest version
clawhub install my-awesome-skill

# Install specific version
clawhub install my-awesome-skill@1.0.0

# Install with local override (development)
clawhub install my-awesome-skill --local ./my-skill

# Pin version in openclaw.json
clawhub install my-awesome-skill@1.0.0 --pin

# List installed skills
clawhub list

# Update all skills to latest
clawhub update

# Dry-run update to see what would change
clawhub update --dry-run

# Uninstall skill
clawhub uninstall my-awesome-skill
```

### Registry Search Filters

```bash
# Filter by category
clawhub search "validator" --category "development"

# Filter by rating
clawhub search "database" --min-rating 4.5

# Filter by downloads
clawhub search --min-downloads 1000

# Filter by author
clawhub search --author "john-doe"

# Combine filters
clawhub search "database" \
  --category "development" \
  --min-rating 4.0 \
  --sort "downloads" \
  --limit 20

# Sort options: relevance, downloads, rating, updated, created
```

---

## Troubleshooting Guide

### Common Issues & Solutions

#### Issue: "SKILL.md not found"

```bash
# Error
openclaw skill validate ./my-skill
# Error: SKILL.md not found in ./my-skill

# Solution: Check directory structure
ls -la ./my-skill
# Ensure SKILL.md exists in skill root directory
```

#### Issue: "Invalid YAML frontmatter"

```bash
# Error
openclaw skill validate ./my-skill
# Error: Invalid YAML in SKILL.md

# Solution: Validate YAML syntax
python3 -m yaml SKILL.md
# Or check for common issues:
# - Missing '---' delimiters
# - Incorrect indentation
# - Unquoted special characters
```

#### Issue: "Missing required fields"

```bash
# Error
# Missing required field: description

# Solution: Add all required YAML fields
---
name: my-skill
description: What this skill does
version: "1.0.0"
---
```

#### Issue: "VirusTotal scan failed"

```bash
# Error
clawhub publish ./my-skill
# Error: Security scan failed - suspicious code detected

# Solution: Address security issues
1. Review flagged code sections
2. Remove obfuscation if not justified
3. Remove any credential-like strings
4. Verify no injection vulnerabilities
5. Re-run: openclaw skill validate --security-audit
```

#### Issue: "External API not declared"

```bash
# Error during security scan
# Warning: External API call to api.example.com not declared

# Solution: Declare in frontmatter
requires:
  externalEndpoints:
    - "https://api.example.com"
    - "https://cdn.example.com"
```

#### Issue: "Dependency not found"

```bash
# Error at runtime
# Error: Node.js 18+ required but version 16 installed

# Solution: Check required versions in frontmatter
requires:
  bins:
    - "node@18.0.0"     # Specify version
    - "python3@3.9.0"   # Use semantic version
```

#### Issue: "Permission denied" on scripts

```bash
# Error: Cannot execute ./scripts/validate.py

# Solution: Make script executable
chmod +x ./scripts/validate.py
chmod +x ./scripts/setup.js
# Or set in SKILL.md:
requires:
  bins: ["python3"]  # Run via python3 scripts/validate.py
```

#### Issue: "Skill not found in registry"

```bash
# Error
clawhub inspect my-awesome-skill
# Error: Skill not found

# Solutions:
1. Check skill was published: clawhub search my-awesome
2. Use correct slug (lowercase-with-hyphens)
3. Wait 1-2 minutes for indexing
4. Check GitHub OAuth token: clawhub whoami
```

#### Issue: "Configuration not loading"

```bash
# Error at runtime
# Warning: openclaw.json configuration not found

# Solution: Create configuration file
{
  "skills": {
    "my-skill": {
      "version": "1.0.0",
      "enabled": true,
      "config": {
        "timeout": 30
      },
      "env": {
        "API_KEY": "${VAULT_API_KEY}"
      }
    }
  }
}
```

### Debugging Tips

```bash
# Enable verbose logging
openclaw skill test ./my-skill --verbose

# Check environment variables
env | grep -E "API_KEY|LOG_LEVEL"

# Verify binary dependencies
which node python3 git

# Check skill logs
tail -f ~/.openclaw/logs/skill.log

# Run with debug output
OPENCLAW_DEBUG=1 openclaw skill test ./my-skill
```

---

## Real-World Examples

### Example 1: SQL Query Builder Skill

**File: sql-query-builder/SKILL.md**

```yaml
---
name: sql-query-builder
description: |
  Build and execute secure SQL queries with prepared statements.
  Support: PostgreSQL 12+, MySQL 5.7+, SQLite 3.
  Prevent SQL injection with automatic parameterization.
emoji: 🗄️
version: "1.0.0"
requires:
  bins: ["python3", "node"]
  envVars: ["DATABASE_URL"]
---

# SQL Query Builder

Safe, parameterized SQL query execution.

## Quick Usage

\`\`\`bash
/query-builder execute \
  --sql "SELECT * FROM users WHERE id = ?" \
  --params "[123]" \
  --database "postgresql"
\`\`\`

For complete API reference, see {baseDir}/references/api-reference.md
For examples, see {baseDir}/references/examples.md
```

### Example 2: Document Processor Skill

```yaml
---
name: document-processor
description: |
  Process PDF, Word, and text documents.
  Extract text, images, metadata.
  Supports: PDF, DOCX, XLSX, TXT, Markdown
emoji: 📄
version: "2.1.0"
requires:
  bins: ["python3", "ffmpeg"]
  envVars: ["TEMP_DIR"]
---

# Document Processor

Convert and extract content from documents.

## Quick Start

\`\`\`bash
/process-document extract \
  --file "document.pdf" \
  --format "text" \
  --include-images true
\`\`\`

For advanced features, see {baseDir}/references/advanced-features.md
```

### Example 3: Container Orchestrator Skill

```yaml
---
name: container-orchestrator
description: |
  Deploy and manage Docker containers.
  Support Kubernetes manifests.
  Health checks, rolling updates, auto-scaling.
emoji: 🐳
version: "1.5.0"
requires:
  bins: ["docker", "kubectl"]
  envVars: ["DOCKER_HOST", "KUBECONFIG"]
sandbox:
  type: docker
  image: bitnami/kubectl:latest
---

# Container Orchestrator

Manage containers and Kubernetes deployments.

## Deploy Example

\`\`\`bash
/deploy container \
  --image "myapp:1.0.0" \
  --replicas 3 \
  --port 8080
\`\`\`

For Kubernetes integration, see {baseDir}/references/kubernetes.md
```

---

## Advanced Topics

### Skill Caching & Performance

Skills support result caching for expensive operations:

```yaml
---
config:
  cacheable: true           # Enable result caching
  cacheTimeout: 3600       # Cache for 1 hour
  parallelizable: true     # Can run concurrently
---
```

### Multi-Language Skills

Skills can use multiple languages:

```
my-skill/
├── scripts/
│   ├── processor.py      # Python logic
│   ├── handler.js        # Node.js handler
│   └── verify.sh         # Shell script
├── configs/
│   └── requirements.txt
│   └── package.json
```

### Environment Variable Validation

```python
# In scripts/validate.py
import os

def validate_environment():
    required_vars = [
        "DATABASE_URL",
        "API_KEY",
        "LOG_LEVEL"
    ]

    missing = [var for var in required_vars if var not in os.environ]
    if missing:
        raise EnvironmentError(f"Missing variables: {missing}")

    return True
```

### GitHub Actions for Skill Testing

```yaml
# .github/workflows/test.yml
name: Test Skill

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      - name: Validate Skill
        run: |
          pip install pyyaml
          python3 scripts/validate.py
      - name: Run Tests
        run: |
          pip install pytest
          pytest tests/
      - name: Security Audit
        run: |
          openclaw skill validate . --security-audit
```

---

## Additional Resources

- **ClawHub CLI Documentation**: `clawhub help`
- **OpenClaw Skills Registry**: https://registry.clawhub.io
- **Security Vulnerabilities**: Report to security@clawhub.io
- **Community Forum**: https://community.openclaw.dev
- **Skill Examples**: https://github.com/openclaw/skill-examples

---

Last Updated: 2026-03-15
Version: 1.0.0
Maintained by: OpenClaw DevTeam
