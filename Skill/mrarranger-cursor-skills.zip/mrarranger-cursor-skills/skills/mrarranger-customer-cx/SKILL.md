---
name: mrarranger-customer-cx
description: "MRARRANGER Customer Experience and Support - Customer Support Strategy, Ticketing System Design, FAQ/Knowledge Base, Chatbot Design, Customer Journey Mapping, NPS/CSAT Surveys, SLA Management, Escalation Procedures, Voice of Customer (VoC), Customer Success, Retention Strategy, Churn Analysis, Help Center, Community Support, CRM Integration. Commands: /support /ticket /faq /chatbot /journey /nps /sla /escalation /voc /retention /churn /helpdesk /crm. Triggers: customer support, ticketing, chatbot, NPS, customer journey, SLA, retention, churn, CRM"
---

# Customer Experience & Support Strategy Skill

## Overview

This skill provides comprehensive guidance on building and managing exceptional customer experiences across all touchpoints. It covers support operations, customer success, retention strategies, and voice-of-customer programs to drive loyalty and business growth.

## Core Competencies

### 1. Customer Support Strategy

**Support Philosophy & Model Development**

**First Contact Resolution (FCR)**:
- Percentage of issues resolved on first interaction
- Target: 70-80% FCR rate
- Enables through comprehensive knowledge bases
- Staff training on escalation criteria
- Feedback loops to identify repeat issues
- Metric tracking by support level

**Support Tiers**

**Tier 1 - Front-line Support**:
- Initial contact and triage
- FAQs and self-service direction
- Simple troubleshooting
- Ticket creation and logging
- SLA: 2-4 hour response time
- Staff: Support specialists, part-time/contractors acceptable

**Tier 2 - Technical Support**:
- Complex troubleshooting
- Technical expertise required
- Customer escalations from Tier 1
- Documentation and knowledge base updates
- SLA: 4-8 hour response, 24 hour resolution
- Staff: Senior support engineers, technical specialists

**Tier 3 - Engineering/Product**:
- Critical issues and bugs
- Product feature requests
- System-level problems
- Customer account issues
- SLA: 4 hour response, 48-72 hour resolution
- Staff: Engineers, architects, product team

**Support Channel Strategy**

**Multi-channel Approach**:
- **Email**: Asynchronous, good for detailed issues, tracking
- **Phone**: Synchronous, urgent issues, complex conversations
- **Chat/Live Support**: Real-time, simple questions, quick resolution
- **Social Media**: Public visibility, rapid response required
- **Community Forums**: Peer-to-peer support, reduces ticket volume
- **Help Center**: Self-service, reduce support costs

**Channel Assignment**:
- Email: General inquiries, detailed requests, documentation
- Phone: Account issues, urgent problems, enterprise customers
- Chat: Quick questions, shopping assistance, onboarding
- Social: Brand monitoring, public complaints, reputation management
- Forums: Feature requests, troubleshooting, community building

**Service Level Management**

**KPIs**:
- First Response Time (FRT)
- Time to Resolution (TTR)
- Customer Satisfaction (CSAT)
- Net Promoter Score (NPS)
- Ticket Volume Trends
- Cost Per Ticket
- Agent Productivity (tickets/hour)

**Benchmarking**:
- Industry standards vary by vertical
- SaaS: 4-hour FRT, 24-48 hour resolution
- E-commerce: 2-hour FRT, same-day resolution
- Enterprise: 1-hour FRT, 4-hour resolution
- Technology: 30-min FRT, 24-hour resolution

**Scaling Support**

**As Company Grows**:
- Move from founder support to dedicated team
- Implement ticketing system (Zendesk, Intercom)
- Build knowledge base and FAQs
- Create support documentation
- Hire support specialists
- Establish processes and workflows
- Measure and optimize

**Cost Management**:
- Knowledge base reduces ticket volume by 30-40%
- Self-service can reduce tickets by 50%
- Community forums provide peer support
- AI chatbots handle 20-30% of inquiries
- Outsourcing for non-technical questions
- Tiered pricing for support levels

### 2. Ticketing System Design & Implementation

**System Selection**

**Key Features to Evaluate**:
- Multi-channel integration (email, chat, phone, social)
- Ticket routing and assignment
- Workflow automation
- Knowledge base integration
- Reporting and analytics
- API and third-party integrations
- Scalability and performance
- Pricing (seats, per-ticket)

**Popular Platforms**:
- Zendesk (comprehensive, enterprise-focused)
- Intercom (conversational, AI-powered)
- Freshdesk (affordable, feature-rich)
- ServiceTitan (field service)
- Help Scout (email-first)
- Jira Service Desk (development teams)

**System Configuration**

**Ticket Routing**:
- Auto-assignment based on skills and workload
- Round-robin assignment
- Priority-based routing
- Customer type routing (enterprise, SMB, free)
- Language-based routing
- Escalation rules and queue prioritization

**Workflow Automation**:
- Auto-acknowledge tickets
- Send surveys on resolution
- Escalate if no update in X days
- Auto-close after customer inactivity
- Route based on keywords
- Suggest knowledge articles
- Notify customers of updates

**Categorization & Tagging**

**Ticket Types**:
- Bug report
- Feature request
- Technical support
- Billing issue
- Account issue
- General question
- Feedback

**Tags for Analysis**:
- Product/feature area
- Issue severity
- Customer segment
- Agent name
- Response language
- Time to resolution
- Customer sentiment

**Metrics & Dashboard**:
- Tickets by status (new, open, pending, resolved, closed)
- Average response and resolution times
- Customer satisfaction scores
- Agent productivity
- Busiest times and trends
- Reopened tickets
- Unresolved tickets aging

**Process Documentation**

**Ticket Workflow**:
1. Ticket created (inbound from various channels)
2. Auto-categorize and route
3. Agent reviews and responds
4. Customer replies (agent updates ticket)
5. Issue resolved (agent closes)
6. Survey sent and closed

**Agent Responsibilities**:
- Acknowledge within SLA
- Understand customer issue fully
- Provide accurate, helpful solution
- Document for future reference
- Update knowledge base (if applicable)
- Close with confirmation

### 3. FAQ & Knowledge Base Development

**Knowledge Base Strategy**

**Content Coverage**:
- **Getting Started**: Onboarding, account setup, first steps
- **How-To Guides**: Step-by-step instructions with screenshots
- **Troubleshooting**: Common issues and solutions
- **Billing & Accounts**: Pricing, payment, subscription management
- **API Documentation**: For technical users, developers
- **Best Practices**: Tips for getting most value
- **FAQ**: Most common questions answered concisely

**Content Organization**:
- Clear navigation and categorization
- Search functionality (crucial)
- Related articles suggestions
- Breadcrumbs and linking
- Regular updates (stale content is worse than no content)
- Version control for product changes

**FAQ Best Practices**

**Question Selection**:
- Most frequently asked questions (from support data)
- Questions that reduce support burden
- Questions from customer feedback
- Competitive/feature questions

**Answer Structure**:
- Short, clear answer (1-2 sentences)
- Expanded explanation if needed
- Link to detailed guide or documentation
- Visual aids (screenshot, video)
- Alternative solutions
- Link to related FAQs

**Writing Guidelines**:
- Use simple, clear language
- Avoid jargon or explain it
- Use active voice
- Short paragraphs and bullet points
- Mobile-friendly formatting
- Answer the question first, then elaborate
- Update with customer feedback

**Knowledge Base Content Creation**

**Process**:
1. Identify high-volume support topics (analyze tickets)
2. Assign content owner/author
3. Draft and review for accuracy
4. Get SME (subject matter expert) approval
5. Format and add visuals
6. Implement with proper SEO and keywords
7. Monitor usage metrics
8. Update based on feedback

**Maintenance**:
- Quarterly review and update
- Monitor for outdated information
- Remove low-performing articles
- Refresh and re-organize
- Gather feedback from users
- Track search queries (identify gaps)
- Version articles for product changes

**Metrics**:
- Page views and unique visitors
- Search queries
- Engagement (time on page)
- Upvote/downvote rating
- Bounce rate
- How many resolved issue without support
- Link from support tickets

### 4. Chatbot & AI Support Design

**Chatbot Strategy & Use Cases**

**Appropriate Use Cases**:
- Welcome and initial triage
- FAQ and knowledge base queries
- Account status checks
- Billing questions
- Return/refund processes
- Appointment scheduling
- Simple troubleshooting
- Escalation to human agents

**Limitation Awareness**:
- Complexity (multi-step reasoning)
- Empathy and emotional support
- Policy exceptions or discussions
- Custom/account-specific issues
- Sensitive or delicate matters

**Chatbot Technology Options**

**Rule-based Bots**:
- Scripted responses and decision trees
- Deterministic and predictable
- Easy to implement and maintain
- Limited natural language understanding
- Good for simple, high-volume queries
- Examples: FAQ bots, appointment scheduling

**NLP/ML Bots**:
- Natural language processing
- Machine learning from data
- Can understand intent and context
- More flexible and natural
- Require training data and iteration
- Continuous improvement as usage increases
- Examples: ChatGPT, Bard, Claude

**Integration Options**:
- Build proprietary using frameworks (Rasa, Dialogflow)
- Use AI platforms (OpenAI, Anthropic API)
- Implement chatbot platforms (Intercom, Zendesk)
- No-code solutions (Tidio, Drift)

**Chatbot Implementation**

**Training & Setup**:
1. Define intents (what user wants)
2. Create training data with examples
3. Build knowledge base integration
4. Test with common scenarios
5. Configure escalation to humans
6. Monitor performance
7. Iterate and improve

**Conversation Design**:
- Natural language patterns
- Quick replies and suggestions
- Context awareness
- Escalation triggers
- Error handling and fallbacks
- Personality and tone consistency
- Handoff to human agents

**Performance Metrics**:
- Conversation completion rate
- User satisfaction (post-chat survey)
- Escalation rate
- Resolution rate
- Average conversation length
- Peak usage times
- Cost per interaction

**Best Practices**:
- Be transparent (disclose bot vs human)
- Provide easy escalation
- Maintain context across turns
- Handle misunderstandings gracefully
- Clear escalation to human agents
- Continuous learning from failures
- Human oversight and review

### 5. Customer Journey Mapping

**Journey Mapping Process**

**Stage Definition**:
1. **Awareness**: Customer discovers product/brand
2. **Consideration**: Evaluating solution, comparing options
3. **Purchase**: Buying decision and transaction
4. **Onboarding**: Getting started, initial value
5. **Adoption**: Regular usage, feature exploration
6. **Retention**: Ongoing satisfaction, renewals
7. **Advocacy**: Referrals, reviews, upsell

**Touchpoint Identification**

**Common Touchpoints**:
- Website and landing pages
- Product demo and trial
- Sales conversations
- Pricing page and comparison
- Checkout and payment
- Welcome email
- Onboarding tutorials
- In-product help and tooltips
- Support interactions
- Email campaigns
- Community forums
- Account management reviews
- Renewal/upsell conversations

**Customer Actions & Emotions**:
- What they're trying to do (job to be done)
- Their pain points and frustrations
- Their emotions at each stage
- Their information needs
- Decision-making criteria
- What success looks like

**Experience Mapping**

**Create the Map**:
- Horizontal: Journey stages and touchpoints
- Vertical: Customer actions, touchpoints, emotions, pain points
- Add data: Usage metrics, satisfaction scores, support tickets
- Identify gaps and opportunities
- Find moments of truth (critical interactions)

**Insights & Opportunities**:
- High-friction areas (reduce complexity)
- Emotional low points (increase support/empathy)
- Information gaps (improve communication)
- Missing touchpoints (add interactions)
- Opportunities for delight (exceed expectations)
- Retention risks (identify churn signals)
- Upsell/cross-sell opportunities

**Implementation**:
- Prioritize improvements
- Assign ownership and budgets
- Track metrics and impact
- Iterate based on feedback
- Share map across organization

**Personas & Scenarios**

**Buyer Personas**:
- Decision-maker vs user personas
- Different buying criteria
- Different onboarding needs
- Different support preferences
- Different success metrics

**Usage Scenarios**:
- New small team starting
- Large enterprise adoption
- Free to paid conversion
- Feature expansion use cases
- Problem-solving scenarios

### 6. NPS, CSAT & Customer Surveys

**Net Promoter Score (NPS)**

**Survey Design**:
- Primary question: "How likely are you to recommend this to a colleague?" (0-10)
- Follow-up: "Why did you give that score?"
- Optional: Additional feedback questions
- Sent post-purchase, post-support, or regularly (quarterly)

**Scoring**:
- 9-10: Promoters (loyal, will refer)
- 7-8: Passives (satisfied but not enthusiastic)
- 0-6: Detractors (unsatisfied, may damage reputation)
- NPS = % Promoters - % Detractors (range: -100 to +100)

**Benchmarks**:
- Excellent: 50+
- Good: 30-50
- Average: 10-30
- Below average: 0-10
- Poor: negative

**Analysis**:
- Segment by customer type, geography, feature usage
- Track trends over time
- Identify leading indicators of churn
- Correlate with product changes
- Act on feedback from detractors
- Recognize and retain promoters

**Customer Satisfaction (CSAT)**

**Measurement**:
- "How satisfied are you with your experience?" (1-5 scale)
- Sent after support interactions, feature releases, milestones
- Can be transaction-specific or overall

**Advantages Over NPS**:
- Specific to transaction or touchpoint
- Easier to understand
- Correlates to retention and loyalty
- Track multiple CSATs (support, product, company)

**Implementation**:
- Email survey post-ticket
- In-product survey after feature usage
- Post-purchase survey
- Quarterly satisfaction surveys
- SMS surveys for quick feedback

**Customer Effort Score (CES)**

**Measurement**:
- "How easy was it to resolve your issue?" (1-5 scale)
- Lower effort = higher satisfaction and retention
- Good predictor of loyalty

**Usage**:
- After support interactions
- Post-purchase/onboarding
- Feature usability feedback
- System and process feedback

**Survey Best Practices**

**Design**:
- Keep short (1-3 questions maximum)
- Clear, unbiased language
- Avoid leading questions
- Mobile-optimized
- Easy to complete (2 minutes max)
- Optional comment field

**Timing**:
- Post-interaction while fresh
- Not too frequent (survey fatigue)
- Appropriate to customer lifecycle
- Consider time zones for global customers

**Analysis & Action**:
- Segment responses (high vs low satisfaction)
- Analyze open feedback for themes
- Track trends over time
- Share results with team
- Set improvement goals
- Communicate changes based on feedback
- Close the loop with customers

### 7. SLA Management & Escalation

**Service Level Agreements (SLAs)**

**Components**:
- Scope: What's covered (support channels, times)
- Target times: Response, resolution, update intervals
- Uptime guarantees: System availability percentages
- Exclusions: What's not covered (misuse, third-party)
- Remedies: Credits or compensation if not met
- Review: How often terms are reviewed

**SLA Tiers**

**Example Structure**:
- **Free/Starter**: 24-hour response, best-effort resolution
- **Professional**: 4-hour response, 24-hour resolution
- **Enterprise**: 1-hour response, 4-hour resolution
- **Critical**: 30-minute response, 2-hour resolution

**Business Hours vs 24/7**:
- Standard: Business hours only (9-5 ET)
- Extended: Early morning/evening coverage
- 24/7: Round-the-clock support (premium)

**Managing SLA Compliance**

**Processes**:
- Prioritize tickets by severity
- Route to appropriate tier/expertise
- Monitor real-time progress
- Alert if approaching SLA threshold
- Escalate if likely to miss
- Document breaches
- Analyze root causes

**Tools**:
- Automatic escalation rules in ticketing system
- Dashboards for SLA status
- Reports on compliance rates
- Alerts for approaching deadlines

**SLA Metrics**:
- % of tickets meeting SLA
- Average response and resolution times
- Tickets exceeding SLA by stage
- SLA breaches by agent or team
- Peak periods and trends

**Challenges & Solutions**:
- **Challenge**: High volume exceeds capacity
- **Solution**: Hire support staff, improve knowledge base

- **Challenge**: Complex issues exceed resolution time
- **Solution**: Improve documentation, train agents

- **Challenge**: Customers not responding to updates
- **Solution**: Schedule auto-close for inactive tickets

### 8. Escalation Procedures & Problem Resolution

**Escalation Framework**

**Escalation Criteria**:
- **Priority/Severity**: Critical system outage, major feature broken
- **Complexity**: Issues requiring engineering/product
- **Account Risk**: Churn risk, major customer threat
- **Policy**: Requests requiring exception or approval
- **Regulatory**: Legal, compliance, or security implications
- **Emotion**: Angry customer, damaged relationship

**Escalation Path**:
- Level 1: Support specialist to support manager
- Level 2: Support manager to technical team lead
- Level 3: Technical lead to engineering/product leadership
- Level 4 (if needed): VP of support to C-suite

**Clear Communication**:
- Escalation reason (specific)
- Impact assessment (business/customer)
- Context and history
- What's been tried
- What decision/info is needed
- Timeline/urgency

**Problem Resolution Framework**

**Root Cause Analysis**:
1. Identify the problem (symptom vs cause)
2. Gather information (logs, user actions, timeline)
3. Form hypotheses (what could cause this)
4. Test hypotheses systematically
5. Identify root cause
6. Document findings

**Example Process**:
- **Problem**: "User can't upload files"
- **Investigation**: Check file size limits, browser compatibility, server logs, user permissions
- **Root Cause**: Browser cache contains old JavaScript preventing upload
- **Solution**: Instruct user to clear browser cache or use incognito mode
- **Prevention**: Add cache-busting headers to JavaScript files

**Solution Development**:
- Immediate workaround (if needed)
- Short-term fix (if available)
- Long-term solution (product improvement)
- Timeline for each

**Documentation & Prevention**

**Incident Response**:
1. Quick resolution for immediate customer impact
2. Root cause analysis
3. Implementation of permanent fix
4. Monitoring for recurrence
5. Communicate findings to relevant teams
6. Update knowledge base
7. Prevent similar issues

**Knowledge Base Updates**:
- Common issues get documented
- Known workarounds recorded
- Prevention steps documented
- Shared with all support team

**Product Team Communication**:
- Feature requests from support tickets
- Bug reports with detailed reproduction steps
- UX issues affecting customers
- Trends in customer confusion

### 9. Voice of Customer (VoC) Program

**VoC Program Components**

**Data Sources**:
- Support tickets and issues
- Customer surveys (NPS, CSAT, CES)
- Customer interviews and feedback calls
- Community forums and discussions
- Social media mentions and reviews
- Feature requests and product feedback
- Usage analytics and behavior
- Win/loss interviews

**Organization Structure**:
- Assign VoC coordinator/owner
- Cross-functional team (product, marketing, support, leadership)
- Regular cadence (monthly reviews)
- Documented process and governance
- Communication and feedback loops

**Collection & Analysis**

**Systematic Approach**:
1. Collect feedback from multiple sources
2. Centralize in system (CRM, database, tool)
3. Analyze for themes and patterns
4. Prioritize by impact and frequency
5. Share insights across organization
6. Act on feedback and communicate back

**Common Themes**:
- Feature requests and missing functionality
- Usability and user experience issues
- Performance and reliability concerns
- Pricing and value perception
- Support and documentation quality
- Competitive comparisons
- Customer success and ROI

**Tools**:
- Customer feedback platforms (Alchemer, Qualtrics)
- CRM integration (Salesforce, HubSpot)
- Comment aggregation (UseResponse, Disqus)
- Social listening tools
- Custom database or spreadsheet

**Act on Insights**

**Product Roadmap Impact**:
- High-demand features prioritized
- UX improvements identified
- Pain points addressed
- Competitive gaps closed

**Marketing & Sales Alignment**:
- Messaging based on customer language
- Proof points and testimonials
- Addressing customer objections
- Case studies on customer success

**Support Team Improvements**:
- Documentation updates
- Training on common issues
- Workflow improvements
- Tier-specific guidance

**Communication Back to Customers**:
- Share what you're building (roadmap)
- Explain decisions made
- Thank them for feedback
- Show impact of their input
- Build community around shared vision

### 10. Customer Success & Retention

**Customer Success Onboarding**

**90-Day Success Plan**:
- Week 1: Welcome and setup assistance
- Week 2-4: Initial training and key feature orientation
- Month 2: Use case alignment and best practices
- Month 3: ROI review and expansion opportunities

**Success Metrics**:
- Core features adopted (% of users trained)
- Time to first value achieved
- Adoption of best practices
- Health check assessment
- NPS score trending
- Expansion revenue potential

**Proactive Customer Success**

**Check-in Cadence**:
- Weekly for first month
- Bi-weekly for first quarter
- Monthly thereafter
- Quarterly business reviews (annual/large customers)

**Check-in Content**:
- Usage trends and adoption
- Feature utilization
- Performance against goals
- Upcoming needs and challenges
- Training and enablement
- Community and best practices
- Upsell/cross-sell opportunities

**Identification of At-Risk Customers**:
- Declining usage trends
- Lower feature adoption
- Support ticket increase
- Engagement decrease
- Contract renewal date approaching
- Negative NPS/CSAT scores
- Reduced logins or activity

**Retention Strategy**:
- Proactive outreach before churn signs appear
- Executive sponsorship for key accounts
- Dedicated success manager for enterprise
- Custom training and support
- Feature enablement aligned to use case
- Regular value reviews
- Community and networking opportunities
- Exclusive benefits and early access

### 11. Churn Analysis & Retention Metrics

**Churn Metrics**

**Definitions**:
- **Monthly Churn Rate**: % customers lost per month
- **Annual Churn Rate**: % customers lost per year
- **Revenue Churn**: Recurring revenue lost (includes downgrades)
- **Net Churn**: Total churn minus expansion revenue
- **Negative Churn**: Expansion revenue exceeds churn (expansion focus)

**Calculations**:
- Churn Rate = (Lost Customers / Starting Customers) × 100
- Example: 100 customers start month, 5 leave = 5% churn
- Annual equivalent of 5% monthly = 46% annual

**Benchmarking**:
- SaaS industry average: 3-7% monthly
- Enterprise SaaS: 0.5-2% monthly
- Downmarket SaaS: 5-10% monthly
- Improve by reducing 1% monthly saves significant revenue

**Churn Analysis**

**Segmentation**:
- By product tier or plan
- By customer company size
- By use case or industry
- By tenure (early churn vs late)
- By support quality
- By geographic region

**Churn Cohort Analysis**:
- Customers from same time period
- Track retention over time
- Identify if changes (product, support) impact retention
- Measure effect of changes

**Exit Interview Data**:
- Primary reason for leaving (product, pricing, competitor, need change)
- Satisfaction score
- Could we have retained them?
- Competitive win/loss insight
- Feature requests and concerns

**Retention Improvement**

**Strategies**:
1. **Product-focused**: Improve core value, fix pain points
2. **Success-focused**: Proactive outreach, training, personalized guidance
3. **Community-focused**: Build network and peer relationships
4. **Loyalty-focused**: Rewards, exclusive benefits, VIP treatment
5. **Price-focused**: Flexible pricing, discounts for renewals
6. **Relationship-focused**: Executive sponsorship, dedicated success

**Prioritization**:
- Analyze why customers churn most
- Identify highest-impact interventions
- A/B test retention initiatives
- Measure and track improvements

**Expansion Opportunities**:
- Upsell to higher tier
- Cross-sell complementary products
- Add seats or usage
- Professional services or implementations
- Training and enablement programs

### 12. Help Center & Community Support

**Help Center Architecture**

**Structure**:
- Self-service first
- Knowledge base for articles
- Community forums for peer support
- Contact support for personal help
- Status page for system reliability

**User Experience**:
- Prominent search bar (users' first instinct)
- Smart suggestions and recommendations
- Clear categorization and navigation
- Mobile-responsive design
- Fast loading and performance
- Accessible design (WCAG 2.1 AA)

**Best Practices**:
- Content authored by SMEs
- Regular updates and maintenance
- User ratings and feedback (helpful votes)
- Analytics to identify missing content
- SEO optimization for discovery
- Link to community forums
- Easy escalation to support

**Community Forum Management**

**Forum Purposes**:
- Peer-to-peer support (reduce tickets)
- Feature requests and feedback
- Best practices and tips sharing
- User networking and relationships
- Product community building
- User-generated content

**Community Moderation**

**Responsibilities**:
- Monitor discussions
- Answer questions and provide guidance
- Mark correct/helpful answers
- Remove spam and off-topic content
- Enforce community guidelines
- Escalate to support if needed
- Recognize helpful community members

**Community Guidelines**:
- Respectful and professional tone
- No spam, self-promotion, or advertising
- Relevant to product/service
- No sharing of sensitive information
- Support from official team encouraged
- Recognition of expert community members

**Gamification & Recognition**:
- Reputation points for helpful answers
- Badges and status levels
- Recognition of power users
- Rewards program (discounts, free features)
- Featured members or posts
- Community ambassador program

**Community Metrics**:
- Monthly active users
- New discussion topics
- Response time to questions
- Answer quality and helpfulness
- % questions answered by community
- Reduction in support tickets
- Engagement and participation rates

### 13. CRM Integration & Customer Data

**CRM Integration Strategy**

**Data Consolidation**:
- Customer profile (contact, company info)
- Interaction history (support, sales, marketing)
- Support tickets and conversations
- Product usage and adoption
- Satisfaction and NPS scores
- Subscription and billing information
- Preferred communication methods

**Bidirectional Sync**:
- CRM → Support: Customer context, account status
- Support → CRM: Interaction notes, escalations
- Product → CRM: Usage data, feature adoption
- Marketing → CRM: Campaign engagement
- Billing → CRM: Payment status, contract details

**Implementation**:
- Use APIs or integration platform (Zapier, custom)
- Define data mapping and ownership
- Establish sync frequency (real-time or daily)
- Test data integrity and completeness
- Document and train team
- Monitor and maintain integration

**360-Degree Customer View**

**Information Elements**:
- Contact and company information
- Support history and satisfaction
- Product usage and engagement
- Purchase history and contract details
- Communication preferences
- Account health and risk indicators
- Opportunities and next steps

**Usage Benefits**:
- Personalized support (reference past interactions)
- Context for new interactions
- Opportunity identification (upsell/cross-sell)
- Churn risk identification
- Team alignment and handoffs
- Executive dashboards and reports

**Privacy & Compliance**:
- GDPR and data privacy compliance
- Customer consent for data usage
- Data retention and deletion policies
- Access controls and permissions
- Audit trails and transparency
- Breach notification procedures

**CRM Best Practices**

**Data Quality**:
- Regular data cleaning and deduplication
- Enforce required fields
- Validation rules
- Regular audits
- Training on proper usage
- Incentives for quality (metrics, recognition)

**User Adoption**:
- Training before rollout
- Make data entry easy
- Show value to users (reporting, insights)
- Regular refresher training
- Feedback and continuous improvement
- Executive sponsorship

**Reporting & Analytics**:
- Customer health dashboards
- Support KPIs and trends
- Retention and churn analysis
- Revenue and customer lifetime value
- Product adoption metrics
- Team performance analytics
- Executive reporting

## Quick Reference

### Common Commands & Triggers
- `/support` - Customer support strategy and operations
- `/ticket` - Ticketing system design and management
- `/faq` - FAQ and knowledge base development
- `/chatbot` - AI chatbot design and implementation
- `/journey` - Customer journey mapping
- `/nps` - NPS and survey programs
- `/sla` - SLA management and tracking
- `/escalation` - Escalation procedures and problem resolution
- `/voc` - Voice of customer program
- `/retention` - Retention strategy and metrics
- `/churn` - Churn analysis and prevention
- `/helpdesk` - Help center setup
- `/crm` - CRM integration

## Conclusion

Exceptional customer experience is built through systematic investment in support quality, proactive success, and genuine listening to customer feedback. By implementing these frameworks and maintaining a customer-centric culture, organizations drive loyalty, reduce churn, and grow revenue.
