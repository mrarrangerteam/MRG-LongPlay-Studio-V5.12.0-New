---
name: mrarranger-marketing-sales
description: "MRARRANGER Marketing & Sales - รวม 7 Skills: Sales (Funnels, Ads, Email Sequences, Launch Strategy), Outreach (Cold Email, DM, Partnership, Affiliate), E-commerce (Shopify, WooCommerce, Product Launch, Pricing), Marketing (Campaign, Ads, SEO Content, Growth Hacking), SaaS Solo Entrepreneur (MVP, Pricing, Launch, Growth), Analytics (Data Analysis, KPI, Dashboard, Attribution), Finance (Revenue Model, P&L, Cash Flow, Invoicing). Commands: /sales /funnel /ads /outreach /cold-email /ecommerce /shopify /marketing /campaign /saas /mvp /analytics /kpi /finance /invoice. Triggers: sales funnel, marketing campaign, ecommerce, ads, email sequence, outreach, SaaS, analytics, finance, revenue"
---

# MRARRANGER Marketing & Sales — 7 Skills Combined

> Routing table for marketing and sales skills

## SKILL ROUTING TABLE

| Trigger | Reference File | Use When |
|---------|---------------|----------|
| `/sales` `/funnel` `/ads` `/sequence` | `references/mrarranger-sales.md` | Sales funnels, ads |
| `/outreach` `/cold-email` `/dm` `/affiliate` | `references/mrarranger-outreach.md` | Outreach campaigns |
| `/ecommerce` `/shopify` `/product` | `references/mrarranger-ecommerce.md` | E-commerce |
| `/marketing` `/campaign` `/growth` | `references/mrarranger-marketing.md` | Marketing campaigns |
| `/saas` `/mvp` `/solo` | `references/mrarranger-saas-solo-entrepreneur.md` | SaaS business |
| `/analytics` `/kpi` `/dashboard` | `references/mrarranger-analytics.md` | Analytics & KPI |
| `/finance` `/invoice` `/cashflow` | `references/mrarranger-finance.md` | Finance & invoicing |
