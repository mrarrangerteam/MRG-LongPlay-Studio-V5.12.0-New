# mrarranger-outreach

**Source:** `/mnt/skills/user/mrarranger-outreach/SKILL.md`
**Size:** 10915 bytes

---

---
name: mrarranger-outreach
description: |
  ระบบ Email & Outreach ครบวงจร - Cold Email, Follow-up Sequences, B2B Outreach, Networking, Partnership Requests
  Templates และ Frameworks สำหรับติดต่อคนที่ไม่รู้จักอย่างมืออาชีพ
  ใช้เมื่อ: (1) ส่ง Cold Email (2) Follow-up (3) ติดต่อ B2B (4) Networking (5) ขอ Partnership (6) Pitch งาน
  Commands: /cold [type], /followup [context], /pitch [offer], /network [person], /intro [context], /sequence [goal]
---

# MRARRANGER Outreach System

## Quick Commands

```
/cold [type]           → Cold email template
/followup [context]    → Follow-up email
/pitch [offer]         → Pitch email
/network [person]      → Networking outreach
/intro [request]       → ขอ introduction
/sequence [goal]       → Email sequence
/linkedin [type]       → LinkedIn message
```

## Cold Email Framework

### AIDA Structure
```
A - Attention: Subject line + First line ที่สะดุดตา
I - Interest: ทำไมเขาควรสนใจ
D - Desire: ประโยชน์ที่เขาจะได้
A - Action: CTA ที่ชัดเจน
```

### Key Principles
```
1. Short: ไม่เกิน 100-150 คำ
2. Personal: เห็นว่า research มาแล้ว
3. Relevant: เกี่ยวข้องกับเขา
4. Value-first: ให้ก่อนขอ
5. Clear CTA: บอกชัดว่าอยากให้ทำอะไร
6. Easy to reply: ถามง่าย ตอบง่าย
```

### Subject Line Formulas
```
Question:
"Quick question about [their company/project]"
"[Name], quick thought on [topic]?"

Personalized:
"Loved your [post/talk/article] on [topic]"
"[Mutual connection] suggested I reach out"

Value:
"Idea for [their goal/challenge]"
"[X]% improvement for [their company]"

Curiosity:
"[Name], [unexpected observation]"
"This reminded me of [their company]"
```

## Cold Email Templates

### Template 1: Value-First
```
Subject: Idea for [Company]'s [specific area]

Hi [Name],

เห็น [specific thing about them/company] แล้วชอบมาก 
โดยเฉพาะ [specific detail].

สังเกตว่า [observation about their business/challenge].

ผมมีไอเดียที่น่าจะช่วย [specific benefit] ได้
ถ้าสนใจ ผมส่งรายละเอียดให้ได้เลยครับ

[Name]
```

### Template 2: Mutual Connection
```
Subject: [Mutual]'s suggestion

Hi [Name],

[Mutual connection] แนะนำให้ติดต่อมาครับ

ผมทำ [what you do] และเห็นว่า [observation about them].

[One sentence about how you can help]

มีเวลา 15 นาทีสัปดาห์นี้ไหมครับ?

[Name]
```

### Template 3: Compliment + Ask
```
Subject: Your [content] was spot on

Hi [Name],

เพิ่งอ่าน/ดู [their content] เรื่อง [topic]
ชอบมากตรงที่พูดเรื่อง [specific point].

กำลังทำ [related project] อยู่พอดี
อยากถามความเห็นเรื่อง [specific question] ครับ

ขอบคุณล่วงหน้าครับ
[Name]
```

### Template 4: Case Study
```
Subject: How [similar company] achieved [result]

Hi [Name],

เพิ่งช่วย [similar company] ทำ [result] ได้

เห็นว่า [their company] กำลัง [related initiative].

ถ้าสนใจ share วิธีที่ใช้ได้ครับ
ไม่มี strings attached.

[Name]
```

### Template 5: Direct Ask
```
Subject: Quick favor?

Hi [Name],

ตามติด [their work] มาสักพักแล้ว
ชื่นชมมากครับ

ขอถาม 1 คำถามสั้นๆ:
[Specific, easy-to-answer question]

ขอบคุณมากครับ
[Name]
```

## Follow-Up Sequences

### 3-Email Sequence
```
Email 1 (Day 0): Initial outreach
Email 2 (Day 3-4): Gentle bump + new value
Email 3 (Day 7-10): Final attempt + easy out
```

### Follow-Up Templates

**Follow-Up 1 (Day 3-4):**
```
Subject: Re: [Original subject]

Hi [Name],

รู้ว่ายุ่งมาก แค่อยาก bump email นี้ขึ้นมา

[Add one new piece of value/info]

ถ้าไม่สะดวกตอนนี้ บอกได้เลยครับ

[Name]
```

**Follow-Up 2 (Day 7-10):**
```
Subject: Re: [Original subject]

Hi [Name],

ลองติดต่อมาสองครั้งแล้ว 
เข้าใจว่าอาจไม่ตรงเวลา

ถ้าสนใจในอนาคต reply กลับมาได้เลยครับ
ถ้าไม่สนใจก็ไม่เป็นไรครับ ขอบคุณที่อ่าน

[Name]
```

**Break-Up Email (Optional Day 14):**
```
Subject: Should I close your file?

Hi [Name],

ไม่ได้รับ reply กลับมา
ไม่แน่ใจว่า:
a) ยุ่งมาก
b) ไม่ใช่เรื่องสำคัญตอนนี้
c) ไม่สนใจเลย

ถ้า c) เข้าใจครับ จะไม่รบกวนอีก
ถ้า a) หรือ b) บอกได้เลยครับว่าเมื่อไหร่สะดวก

[Name]
```

## B2B Outreach

### Decision Maker Research
```
Before reaching out:
□ หา decision maker ตัวจริง
□ ดู LinkedIn profile
□ อ่าน recent posts/articles
□ เข้าใจ company priorities
□ หา mutual connections
□ ดู tech stack (if relevant)
```

### B2B Email Template
```
Subject: [Specific result] for [Company]

Hi [Name],

ผมช่วย [similar companies] ทำ [specific result].

เห็นว่า [Company] กำลัง [initiative/challenge].

สิ่งที่เราทำ:
• [Benefit 1]
• [Benefit 2]

[Short case study or proof point]

มีเวลาคุย 15 นาทีไหมครับ?
[Calendar link]

[Name]
[Title]
```

### Enterprise Outreach
```
Multiple touchpoints:
1. LinkedIn connection request
2. Email to main contact
3. Email to other stakeholders
4. Comment on their content
5. Phone call (if appropriate)

Timing:
- Tuesday-Thursday best
- 8-10am or 2-4pm
- Avoid Monday morning, Friday afternoon
```

## Networking

### LinkedIn Connection Request
```
Hi [Name],

เห็น profile แล้วสนใจมาก
โดยเฉพาะ [specific thing].

ผมทำ [what you do] และสนใจ [overlap].
อยากเชื่อมต่อครับ

[Name]
```

### After Meeting Template
```
Subject: Great meeting you at [Event]

Hi [Name],

ดีใจที่ได้คุยกันที่ [Event] เมื่อวาน

ชอบที่คุณพูดเรื่อง [specific thing] มาก
มีความเห็นตรงกันเรื่อง [shared interest].

[Follow-up on something discussed]

เจอกันอีกครับ!
[Name]
```

### Informational Interview Request
```
Subject: 20 minutes for coffee? (virtual okay!)

Hi [Name],

ผมกำลัง [explore career/start project] ใน [field].

ติดตามงานคุณมาสักพักแล้ว
โดยเฉพาะ [specific work].

ขอเวลา 20 นาทีได้ไหมครับ?
อยากถามเรื่อง [2-3 specific questions].

ยืดหยุ่นเรื่องเวลาครับ

[Name]
```

## Partnership Requests

### Partnership Proposal Template
```
Subject: Partnership idea: [Company] x [Your Company]

Hi [Name],

[One line about why reaching out to them specifically]

Idea: [Brief partnership concept]

Why it works:
• สำหรับ [Their Company]: [benefit]
• สำหรับ [Your Company]: [benefit]
• สำหรับ customers: [benefit]

เคยทำคล้ายๆ กับ [example] ได้ผล [result].

สนใจคุยเพิ่มเติมไหมครับ?

[Name]
```

### Collaboration Request
```
Subject: Collab idea?

Hi [Name],

ชอบ [their work] มาก
audience ของเราน่าจะ overlap กัน

ไอเดีย: [specific collaboration idea]

คิดว่าจะเป็นประโยชน์กับทั้งสองฝ่าย

สนใจไหมครับ?

[Name]
```

## Pitch Templates

### Freelance/Job Pitch
```
Subject: [Skill] specialist - portfolio attached

Hi [Name],

เห็นว่ากำลังหา [role/skill].

ผมทำ [what you do] มา [X] ปี
เคยช่วย [similar client] ทำ [result].

ตัวอย่างงาน:
• [Link 1]
• [Link 2]

ถ้าสนใจคุย ว่างได้ทุกวันครับ

[Name]
```

### Investor Pitch
```
Subject: [Company] - [One-line description]

Hi [Name],

[Company] ช่วย [target customers] แก้ปัญหา [problem].

Traction:
• [Metric 1]
• [Metric 2]

กำลัง raise [amount] for [use of funds].

Deck attached. มีเวลา 30 นาทีไหมครับ?

[Name]
```

## Response Optimization

### When to Send
```
Best times:
- Tuesday-Thursday
- 8-10am (before meetings start)
- 2-4pm (after lunch lull)

Avoid:
- Monday morning (inbox overflow)
- Friday afternoon (weekend mode)
- Holidays/Long weekends
```

### Subject Line Testing
```
A/B test:
- Question vs Statement
- Personalized vs Generic
- Short vs Long
- With emoji vs Without

Track:
- Open rate (good: >50%)
- Reply rate (good: >10%)
```

### Signature Tips
```
Keep it simple:
[Name]
[Title] | [Company]
[Phone] | [Website]

Optional:
- Calendar link
- Recent achievement
- Social proof
```

## Thai Outreach Adjustments

```
ภาษาไทย considerations:
- ใช้ครับ/ค่ะ ให้สุภาพ
- เปิดด้วยการทักทายอุ่น
- อ้างอิง mutual connections ถ้ามี
- อย่า direct เกินไป ให้มี context ก่อน
- ปิดท้ายด้วยความขอบคุณ

Example opener:
"สวัสดีครับ คุณ [Name]
เห็นโปรไฟล์แล้วประทับใจมากครับ..."
```

## File References

- `references/email-templates.md` - Email templates เพิ่มเติม
- `references/linkedin-scripts.md` - LinkedIn message scripts
- `references/follow-up-sequences.md` - Sequence templates