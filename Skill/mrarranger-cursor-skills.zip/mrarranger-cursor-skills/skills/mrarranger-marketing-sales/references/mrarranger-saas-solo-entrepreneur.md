# mrarranger-saas-solo-entrepreneur

**Source:** `/mnt/skills/user/mrarranger-saas-solo-entrepreneur/SKILL.md`
**Size:** 23958 bytes

---

---
name: "mrarranger-saas-solo-entrepreneur"
description: "MRARRANGER SaaS Solo Entrepreneur - ระบบสร้างและบริหาร SaaS/MaaS ครบวงจรแบบ Zero-Human-in-the-Loop ด้วย Multi-Agent System 6 ตัว (Marketing, Support, Finance, Dev, Orchestrator/CEO, Analytics) รวม Onchain Due Diligence, Manus-style Daily Research, Business Idea Generation, Low-Cost Launch Playbook (งบเริ่มต้น $28-$155) ใช้เมื่อ: (1) สร้าง Multi-Agent System สำหรับธุรกิจ SaaS/MaaS (2) วิเคราะห์โปรเจค Onchain/Crypto ด้วย AI (3) สร้าง Daily Research & Business Ideas อัตโนมัติ (4) วาง Launch Strategy แบบ Solo Founder (5) ออกแบบ Knowledge System สำหรับ AI Agents (6) สร้าง AI Automation Pipeline ครบวงจร (7) วิเคราะห์ SaaS Ideas แบบ Scale-or-Kill Commands: /solo /agents /onchain /research /launch /knowledge /saas /maas /validate /scale /kill /stack /ceo /daily"
---

# 🚀 MRARRANGER SaaS Solo Entrepreneur

## ระบบสร้างและบริหาร SaaS/MaaS ครบวงจร — Zero Human in the Loop

> **Philosophy:** "ขี้เกียจให้เป็น ทำตามได้ — AI ทำแทนคนได้ทั้งหมด ถ้ามีระบบที่ดี"
>
> **Core Belief:** เวลา > เงิน — AI ย่อระยะเวลาหลายปีให้เหลือไม่กี่วัน

---

## 🔒 MANDATORY PROTOCOL

> ⛔ **กฎเหล็ก — ปฏิบัติทุกครั้ง ไม่มีข้อยกเว้น**

### RULE #1: RESEARCH BEFORE ACTION
```
❌ ห้าม: แนะนำ SaaS idea โดยไม่วิเคราะห์ตลาดก่อน
❌ ห้าม: วิเคราะห์ Onchain project โดยไม่ search ข้อมูลจริง
❌ ห้าม: สร้าง Agent system โดยไม่เข้าใจ business context
❌ ห้าม: Launch โดยไม่ผ่าน Validation framework
✅ ต้อง: Web Search → Analyze → Recommend → Execute
```

### RULE #2: SCALE-OR-KILL MINDSET
```
ทุก SaaS idea ต้องผ่าน Kill Criteria:
- ไม่มี signup หลัง 500+ views → KILL
- ไม่ถึง 100 users หรือ $200 MRR ใน 12 สัปดาห์ → KILL
- CAC > $50 → REVIEW
- Landing page conversion < 10% → PIVOT
- 20%+ บอก "I'd pay" → GREEN LIGHT
```

---

## 📋 COMMANDS

| Command | Action | อ่าน Reference |
|---------|--------|----------------|
| `/solo` | เริ่มต้น Solo Entrepreneur journey — วิเคราะห์ตัวเอง หาจุดแข็ง | - |
| `/agents` | ออกแบบ Multi-Agent System 6 ตัว | `references/agents-blueprint.md` |
| `/onchain [url]` | วิเคราะห์โปรเจค Onchain/Crypto ครบวงจร | `references/onchain-research.md` |
| `/research` | สร้าง Daily Research Pipeline อัตโนมัติ | `references/daily-research.md` |
| `/launch [idea]` | 6-Week Launch Playbook — จาก idea ถึง revenue | `references/launch-playbook.md` |
| `/knowledge` | ออกแบบ Knowledge System สำหรับ Agent team | `references/knowledge-system.md` |
| `/saas [topic]` | Generate SaaS Ideas + Validation | - |
| `/maas [topic]` | Generate MaaS (Model-as-a-Service) Ideas | - |
| `/validate [idea]` | Run Validation Framework — test ก่อน build | - |
| `/scale` | Scale Strategy สำหรับ product ที่ผ่าน validation | - |
| `/kill` | Kill Analysis — เมื่อไหร่ควรหยุด pivot | - |
| `/stack` | แนะนำ Tech Stack ตามงบ ($28 / $150 / $500 / $1000) | - |
| `/ceo` | CEO Agent mode — orchestrate ทุก agent | `references/agents-blueprint.md` |
| `/daily` | Generate Daily Briefing (News + Ideas + Opportunities) | `references/daily-research.md` |

---

## 🏗️ ARCHITECTURE OVERVIEW

### The 6-Agent System (Zero-Human-in-the-Loop)

```
┌─────────────────────────────────────────────────────────┐
│              🧠 ORCHESTRATOR / CEO AGENT                 │
│         (ควบคุม ประสาน ให้คำแนะนำ ดุ Agent อื่น)         │
│         LangGraph Supervisor Node + n8n Triggers         │
├──────────┬──────────┬──────────┬──────────┬─────────────┤
│ 📢       │ 💬       │ 💰       │ 💻       │ 📊          │
│ MARKETING│ SUPPORT  │ FINANCE  │ DEV      │ ANALYTICS   │
│ AGENT    │ AGENT    │ AGENT    │ AGENT    │ AGENT       │
│          │          │          │          │             │
│ • แคมเปญ │ • ตอบลค  │ • ดูงบ   │ • พัฒนา  │ • วิเคราะห์  │
│ • Ads    │ • Inbox  │ • Package│ • Fix    │ • KPI       │
│ • SEO    │ • Post   │ • Payment│ • Deploy │ • Best Stat │
│ • Media  │ • RAG    │ • Pricing│ • Test   │ • Report    │
├──────────┴──────────┴──────────┴──────────┴─────────────┤
│          📦 SHARED KNOWLEDGE LAYER                       │
│     PostgreSQL + Redis + Vector DB (ChromaDB/Pinecone)   │
│     + Conversation RAG + Sentiment RAG                   │
├─────────────────────────────────────────────────────────┤
│          🔌 EXTERNAL INTEGRATIONS                        │
│  Stripe • GitHub • Sentry • Email • TikTok Ads • Manus  │
│  n8n • NotebookLM • Obsidian • Vercel • Supabase        │
└─────────────────────────────────────────────────────────┘
```

### Agent Communication Rules

| From → To | Trigger | Response Format |
|-----------|---------|-----------------|
| Marketing → Finance | ก่อนตั้งราคา/โปรโมชั่น | APPROVED / CONCERNS / BLOCKING |
| Marketing → Dev | ต้องการ feature ใหม่สำหรับ campaign | FEASIBLE / ESTIMATE / BLOCKING |
| Support → Dev | Bug report จากลูกค้า | PRIORITY / ETA / WORKAROUND |
| Support → Marketing | Customer feedback pattern | INSIGHT / ACTION_NEEDED |
| Finance → CEO | งบผิดปกติ หรือ KPI ตก | ALERT / RECOMMENDATION |
| Analytics → ALL | Weekly performance report | METRICS / TRENDS / ACTIONS |
| CEO → ALL | Strategic decision | DIRECTIVE / DEADLINE / CHECK |

**Max call-chain depth: 3** (ป้องกัน infinite loop)

---

## 💡 COMMAND DETAILS

### `/solo` — เริ่มต้น Solo Entrepreneur Journey

เมื่อ user เรียกคำสั่งนี้ ให้ทำตาม:

1. **Self-Assessment Interview** — ถาม 5 คำถามสำคัญ:
   - คุณเก่งอะไร? (Technical skills, Domain knowledge)
   - คุณมีเวลาเท่าไหร่ต่อวัน?
   - งบลงทุนเริ่มต้น? ($28 / $150 / $500 / $1000+)
   - เป้าหมายรายได้ต่อเดือน?
   - มีความรู้ด้าน coding ระดับไหน? (No-code / Low-code / Full-code)

2. **AI Skill Mapping** — วิเคราะห์ว่า user เหมาะกับ path ไหน:
   - **Path A: ขายความรู้** — ใช้ AI เป็น แต่คิด idea ไม่ออก → เปิดสอน/ที่ปรึกษา
   - **Path B: ซื้อเวลา** — ใช้ AI Automation ทดแทนงาน manual → รับ freelance เพิ่ม
   - **Path C: สร้าง SaaS** — มี coding skill → build micro-SaaS portfolio
   - **Path D: สร้าง MaaS** — มี AI knowledge → API wrapper / AI agent service
   - **Path E: Onchain** — มี crypto knowledge → AI-powered trading/research tools

3. **Personalized Roadmap** — สร้าง 90-day action plan

### `/saas [topic]` — Generate SaaS Ideas

เมื่อ user เรียก ให้ generate 5 SaaS ideas ตาม criteria:

```
STRICT CRITERIA:
- Buildable ด้วย low-code/AI coding tools
- Solve micro-niche pain point เฉพาะเจาะจง
- Pricing: $29-$99/month subscription
- Low CAC (ต้นทุนหาลูกค้าต่ำ)
- Profitable ภายใน 6-12 เดือน
- คู่แข่งตรง < 5 เจ้า
- Dev cost < 3,000 THB ต่อตัว (ไม่รวม marketing + API)

OUTPUT FORMAT PER IDEA:
1. Problem Statement (ปัญหาอะไร)
2. Target Customer (ขายใคร)
3. MVP Features (max 3 features)
4. Revenue Model (วิธีทำเงิน)
5. Go-to-Market Channel (ช่องทางหาลูกค้า)
6. Dev Cost Estimate (ประมาณค่าใช้จ่าย)
7. Competition Analysis (คู่แข่ง)
8. Risk Assessment (ความเสี่ยง)
9. Score: /10 (โอกาสสำเร็จ)
```

**Research Workflow:**
- Web Search: "micro saas [topic] low competition 2026"
- Web Search: Reddit pain points ใน niche นั้น
- Web Search: G2/Capterra 3-star reviews ของ competitors
- วิเคราะห์ gap → Generate ideas → Score → Rank

### `/validate [idea]` — Validation Framework

```
VALIDATION STAGES:

Stage 1: Quick Validation (Day 1-3, $0)
├── Mom Test: 10+ conversations
├── Landing Page: Carrd/Typedream
├── Metric: Conversion > 10% = Promising
└── Decision: GO / NO-GO

Stage 2: Market Signal (Day 4-7, $50-150)  
├── TikTok Ads: 21-34 sec vertical video
├── Content: Problem → Agitation → Product → CTA
├── Metric: Signups at < $5 CAC = Scale
└── Decision: SCALE / ITERATE / KILL

Stage 3: Build MVP (Week 2-4, $28-155)
├── Stack: Next.js + Supabase + Stripe + Vercel
├── Method: BMAD v6 + Cursor + Claude Sonnet
├── Metric: First paying customer
└── Decision: SCALE / PIVOT / KILL

KILL SIGNALS:
🔴 ไม่มี signup หลัง 20K+ views → KILL
🔴 0 retention หลัง 30 days → KILL  
🔴 CAC > $50 consistently → REVIEW

SCALE SIGNALS:
🟢 Paying customers ใน Week 1 → SCALE
🟢 CAC < $5 → SCALE AGGRESSIVELY
🟢 Retention > 40% month-over-month → SCALE
```

### `/stack` — Tech Stack Recommendations

```
TIER 1: $28/month (Domain only)
├── Frontend: Next.js 14+ (free)
├── Backend: Supabase Free (500MB DB, 50K MAU)
├── Deploy: Vercel Hobby (free)
├── Payment: Stripe (2.9% + $0.30 per tx)
├── Auth: Supabase Auth (free)
├── Dev: Claude Code + Cursor
└── Total: ~$28 (domain only)

TIER 2: $150/month  
├── Everything in Tier 1, plus:
├── Supabase Pro ($25)
├── Vercel Pro ($20)
├── n8n Cloud ($24) — automation
├── Manus Plus ($39) — daily research
├── Upstash Redis ($10)
├── Domain + Email ($20)
└── Total: ~$158

TIER 3: $500/month (Full Agent Stack)
├── Everything in Tier 2, plus:
├── LLM APIs: Claude + GPT ($100-200)
├── Vector DB: Pinecone ($25)
├── SEO: Frase.io ($45)
├── Social: Buffer ($30) + Enrich Labs ($99)
├── Support: Intercom Fin ($29/seat)
├── Media: Nano Banana Pro + Veo 3.1 ($40)
└── Total: ~$500-550

TIER 4: $1000/month (Scale Mode)
├── Everything in Tier 3, plus:
├── OTTO SEO ($249)
├── TikTok Ads budget ($200)
├── Advanced monitoring: Sentry ($26)
├── CDN: Cloudflare Pro ($25)
└── Total: ~$1,000-1,200
```

### `/onchain [url]` — Onchain Due Diligence

เมื่อ user ให้ URL โปรเจค crypto ให้วิเคราะห์ 8 มิติ:

**อ่าน `references/onchain-research.md` สำหรับรายละเอียดเต็ม**

Quick overview:
1. 🔍 Project Fundamentals — Problem, Team, Roadmap
2. 💰 Tokenomics — Supply, Allocation, Vesting, Utility
3. 📊 On-Chain Metrics — Active addresses, TVL, Dev activity
4. 🔐 Smart Contract Security — Audits, Vulnerabilities
5. 💧 Liquidity & Market — Volume, Depth, Whale activity
6. 👥 Social & Community — Engagement, Sentiment, Bot detection
7. ⚔️ Competitive Landscape — Moat assessment
8. ⚠️ Risk Assessment — Regulatory, Centralization, Technical

**Red Flag Auto-Detection:**
```
🔴 CRITICAL: Owner can change fees post-launch
🔴 CRITICAL: Unlimited minting function
🔴 CRITICAL: Honeypot pattern detected
🟡 HIGH: Team allocation > 30% with short vesting
🟡 HIGH: Top 10 wallets > 50% supply
🟡 HIGH: LP unlocked or locked < 30 days
```

### `/agents` — Multi-Agent Blueprint

**อ่าน `references/agents-blueprint.md` สำหรับ spec เต็มของแต่ละ Agent**

Quick setup guide:

```
STEP 1: สร้าง Knowledge Base
- ให้ Agent อ่าน codebase ทั้งหมด + ทุก .md files
- สร้าง 1 knowledge ก้อนใหญ่
- แตกย่อยเป็น 6 ส่วนตาม Agent domain

STEP 2: กำหนด Agent Roles
- Marketing Agent (+ sub: SEO Agent, Media Agent)
- Support Agent (+ Conversation RAG + Sentiment RAG)
- Finance Agent
- Dev Agent (+ Checklists + Score system)
- Orchestrator/CEO Agent
- Analytics Agent

STEP 3: ตั้งค่า Communication
- Trigger table สำหรับ cross-agent consultation
- Max depth: 3 (ป้องกัน infinite loop)
- Shared memory: PostgreSQL + Redis + Vector DB

STEP 4: Deploy
- n8n สำหรับ automation triggers
- LangGraph สำหรับ orchestration
- Cron jobs สำหรับ daily/weekly tasks
```

### `/research` & `/daily` — Daily Research Pipeline

**อ่าน `references/daily-research.md` สำหรับ pipeline เต็ม**

```
DAILY PIPELINE (ทำงานอัตโนมัติ 6:00 AM):

06:00 — AI News Digest
        n8n → Perplexity/Claude → summarize → deliver

09:00 — Business Idea Generation (Monday only)
        Manus → 5 SaaS ideas + validation criteria

12:00 — Opportunity Scanning  
        Reddit pain mining + Competitor gap analysis

18:00 — Daily Report
        Analytics Agent → compile all findings → Obsidian

WEEKLY PIPELINE (Monday 9:00 AM):
- Full market analysis
- Competition update
- KPI review across all products
- Strategy recommendations from CEO Agent
```

### `/launch [idea]` — 6-Week Launch Playbook

**อ่าน `references/launch-playbook.md` สำหรับ playbook เต็ม**

```
WEEK 1: Ideation & Validation
├── GPT + Obsidian brainstorming
├── Reddit/community pain mining
├── 10+ Mom Test conversations  
├── Carrd landing page
└── Measure conversion

WEEK 2: Architecture & Planning
├── Install BMAD v6: npx bmad-method install
├── Business Analyst agent → product brief
├── Generate PRD
├── Architecture docs
└── Solutioning gate check

WEEK 3-4: Build MVP
├── Cursor + Claude Sonnet 4.5/4.6
├── Feed PRD → build
├── Next.js + Supabase + Stripe
├── Deploy Vercel free tier
└── Auth + Core feature + Payments

WEEK 5: Launch & Validate
├── Production deploy
├── $50-150 TikTok test
├── Post: Indie Hackers, Product Hunt
├── Collect feedback
└── Measure conversion

WEEK 6+: Scale or Kill
├── SCALE: paying customers, <$50 CAC, positive retention
│   → Upgrade Vercel Pro + Supabase Pro
├── KILL: no signups, 0 retention
│   → Keep notes, pivot to next idea
└── PORTFOLIO: stack 3-5 micro-SaaS → target $5K/mo
```

### `/knowledge` — Knowledge System Design

**อ่าน `references/knowledge-system.md` สำหรับ architecture เต็ม**

```
5-DAY IMPLEMENTATION:

Day 1: Obsidian Vault Setup
├── Domain folders: /marketing, /technical, /financial, /support
├── AGENTS.md at vault root
├── Templates for each agent
└── Install: Smart Connections + Copilot plugins

Day 2-3: Ingestion Pipeline
├── Code repos → markdown summaries
├── Business docs → clean text
├── Semantic chunking: 512-token chunks, 50-token overlap
└── Metadata: {agent_domain, timestamp, source, topic}

Day 3: Vector DB Setup
├── ChromaDB for prototyping (free, local)
├── Domain-specific collections per agent
├── Shared collection for cross-agent queries
└── Embedding: text-embedding-3-small

Day 4-5: Agent Memory Wiring
├── Working Memory: Redis (transient per-task state)
├── Episodic Memory: Task histories + interaction logs
├── Semantic Memory: Product info, customer data, domain rules
├── Procedural Memory: Learned workflows + strategies
├── Shared Memory: Cross-agent decisions + company state
└── Conversation RAG with sentiment detection
```

---

## 📊 CASE STUDIES & BENCHMARKS

### Solo Founder Success Stories (ข้อมูลจริง)

| Founder | Product | Revenue | Employees |
|---------|---------|---------|-----------|
| John Rush | 24 SaaS products | $2M+ ARR | 0 |
| Nick Dobos | BoredHumans | ~$8.8M ARR | 0 |
| Eric Smith | AutoShorts.ai | $113K MRR | Solo |
| Sarah Chen | AI Calculator | $50K MRR | Solo |
| Peter Steinberger | OpenClaw | Unicorn valuation | 1 (himself) |

### Key Statistics
- 84% ธุรกิจ US ไม่มีพนักงาน
- Solo-founded startups: 23.7% (2019) → 36.3% (2025)
- 44% SaaS ที่กำไร run by solo founders
- AI-first SaaS ถึง $1M ARR เร็วกว่า traditional 4 เดือน
- Operating margin solo AI business: > 70%
- Break-even ภายใน 60-90 วัน

### Cost Comparison
```
Traditional Team (5 คน):    $250,000-500,000+/ปี
AI-First Solo:              $3,000-12,000/ปี
                            ────────────────────
Savings:                    95-98% cost reduction
```

---

## 🔧 TOOL STACK REFERENCE

### Primary Tools (ที่ใช้หลักๆ)
| Tool | Purpose | Cost |
|------|---------|------|
| Claude Code | Main coding agent | $20/mo |
| Cursor IDE | AI-powered development | $20/mo |
| Manus AI | Daily research + automation | $39/mo |
| ChatGPT/GPT | Brainstorming + analysis | $20/mo |
| Grok | Alternative AI for X/Twitter data | Free-$25/mo |
| Gemini Gem | Image + Video generation | $19.99/mo |
| Obsidian | Knowledge hub | Free |
| NotebookLM | Audio summaries | Free/$19.99 |
| n8n | Workflow automation | Free self-hosted |

### Orchestration Layer
| Tool | Best For | Cost |
|------|----------|------|
| n8n | Glue layer, 1000+ integrations | Free/$24/mo |
| LangGraph | Production orchestration | Free/$39/mo |
| CrewAI | Role-based agent teams | Free |
| AutoGen | Group brainstorming/debate | Free |

### Deployment
| Service | Free Tier | Paid |
|---------|-----------|------|
| Vercel | 100GB BW, 150K functions | $20/mo Pro |
| Supabase | 500MB DB, 50K MAU | $25/mo Pro |
| Cloudflare Workers | 100K req/day | $5/mo |
| Upstash Redis | 10K commands/day | $10/mo |

---

## 🎯 WORKFLOW PATTERNS

### Pattern 1: GPT → Obsidian → Claude Code Pipeline
```
1. Brainstorm กับ GPT/ChatGPT
2. Dump ideas → Obsidian Daily Notes (#idea #insight #feature)
3. Structure ด้วย MOCs + [[wiki links]]
4. Open terminal → Claude Code อ่าน vault ผ่าน CLAUDE.md
5. Build MVP จาก structured notes
```

### Pattern 2: Manus → NotebookLM → Action Pipeline
```
1. Manus สร้าง research report ทุกวัน
2. Export เป็น PDF/Markdown
3. Upload → NotebookLM → generate Audio Overview
4. ฟังช่วงพัก → จด highlights
5. Ideas ที่ดี → Obsidian → Claude Code → Build
```

### Pattern 3: BMAD v6 Rapid Dev
```
1. npx bmad-method install
2. *analyst → Product Brief
3. /prd → Product Requirements Document
4. /architecture → System Design
5. /sprint-planning → /create-story → /dev-story
6. Deploy → Validate → Iterate
```

### Pattern 4: Micro-SaaS Portfolio Stack
```
John Rush Playbook (ทำซ้ำ 20+ ครั้ง):
1. หา popular SaaS
2. หา sub-audience ที่เข้าใจ
3. Build one-feature tool
4. เริ่มด้วย one-time pricing
5. เปลี่ยนเป็น monthly recurring
6. Cross-link ทุก product → compound growth
7. Target: 3-5 products → $5K/mo aggregate
```

---

## ⚙️ INTEGRATION WITH OTHER MRARRANGER SKILLS

Skill นี้ทำงานร่วมกับ MRARRANGER skills อื่นๆ:

| เมื่อต้องการ | ใช้ Skill |
|-------------|----------|
| สร้าง Marketing content | `mrarranger-content` หรือ `mrarranger-viral-content` |
| เขียน Copy ขาย | `mrarranger-sales` |
| ทำ Social Media posts | `mrarranger-social` |
| วิเคราะห์คู่แข่ง | `mrarranger-research` |
| สร้าง Workflow Automation | `mrarranger-n8n` |
| วิเคราะห์ข้อมูล | `mrarranger-data` หรือ `mrarranger-analytics` |
| สร้าง Business Documents | `mrarranger-business` |
| เขียนภาษาไทย | `mrarranger-thai-master` |
| AI Image/Video prompts | `mrarranger-visual` หรือ `mrarranger-promptlib` |
| คิดเชิงกลยุทธ์ | `mrarranger-brain` |
| Clone style/brand | `mrarranger-clone-master` |
| Mass produce content | `mrarranger-mass-production` |
| Coordinate ทุกทีม | `mrarranger-coordinator` |

---

## 📌 RESPONSE FORMAT

เมื่อตอบทุก command ให้ใช้ format นี้:

```
🎯 [COMMAND NAME]

📋 ANALYSIS:
[วิเคราะห์สิ่งที่ user ต้องการ]

🔍 RESEARCH FINDINGS:
[ข้อมูลจาก web search / analysis]

💡 RECOMMENDATIONS:
[คำแนะนำที่ actionable]

📊 METRICS/CRITERIA:
[ตัวเลขและ KPI ที่ต้อง track]

⏭️ NEXT STEPS:
[ขั้นตอนถัดไปที่ชัดเจน]

🔗 TOOLS NEEDED:
[เครื่องมือที่ต้องใช้]
```

---

## 📚 REFERENCE FILES

อ่าน reference files เหล่านี้เมื่อจำเป็น:

| File | เมื่อไหร่ต้องอ่าน |
|------|-------------------|
| `references/agents-blueprint.md` | เมื่อ `/agents` หรือ `/ceo` — รายละเอียด 6 agents |
| `references/onchain-research.md` | เมื่อ `/onchain` — Crypto due diligence framework |
| `references/daily-research.md` | เมื่อ `/research` หรือ `/daily` — Pipeline specs |
| `references/launch-playbook.md` | เมื่อ `/launch` — Full 6-week playbook |
| `references/knowledge-system.md` | เมื่อ `/knowledge` — Memory architecture |