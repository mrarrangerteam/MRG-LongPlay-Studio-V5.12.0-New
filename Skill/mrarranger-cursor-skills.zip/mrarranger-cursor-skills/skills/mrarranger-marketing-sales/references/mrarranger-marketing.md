# mrarranger-marketing

**Source:** `/mnt/skills/user/mrarranger-marketing/SKILL.md`
**Size:** 33767 bytes

---

---
name: mrarranger-marketing
description: "MRARRANGER Marketing Master - ระบบวางแผนและ Execute Marketing ครบวงจร รองรับ Strategy, Campaign Planning, Growth Hacking, Influencer Marketing, และ Analytics ใช้เมื่อ: (1) วางแผน Marketing Strategy (2) สร้าง Campaign Plan (3) ทำ Customer Research (4) Growth Marketing (5) Influencer Outreach (6) วิเคราะห์ Marketing Performance Commands: /strategy /campaign /avatar /growth /influencer /launch /metrics"
---

# MRARRANGER Marketing Master

ระบบ Marketing ครบวงจรสำหรับ Digital Business & Content Creators

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/strategy [ธุรกิจ]` | วางแผน Marketing Strategy | Strategic plan + roadmap |
| `/campaign [ชื่อ]` | สร้าง Campaign Plan | Full campaign blueprint |
| `/avatar [กลุ่มเป้าหมาย]` | สร้าง Customer Avatar | Detailed persona |
| `/research [ตลาด]` | Market Research | Analysis + insights |
| `/position [แบรนด์]` | Brand Positioning | Positioning statement |
| `/growth [เป้าหมาย]` | Growth Strategy | Tactics + experiments |
| `/influencer [niche]` | Influencer Strategy | Outreach plan |
| `/launch [สินค้า]` | Launch Campaign | Complete launch plan |
| `/viral [content]` | Viral Strategy | Viral loop design |
| `/metrics [campaign]` | Marketing Metrics | KPIs + dashboard |
| `/budget [งบ]` | Budget Allocation | Channel allocation |
| `/calendar [เดือน]` | Marketing Calendar | Content + campaign schedule |

---

## PART 1: MARKETING STRATEGY FRAMEWORK

### Marketing Strategy Canvas

```
┌─────────────────────────────────────────────────────────────────┐
│                  MARKETING STRATEGY CANVAS                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │   WHO           │  │   WHAT          │  │   WHY           │  │
│  │   Target        │  │   Value Prop    │  │   Goals         │  │
│  │   Audience      │  │   Offering      │  │   Objectives    │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
│           │                    │                    │           │
│           └────────────────────┼────────────────────┘           │
│                                ▼                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                      HOW                                 │   │
│  │   Channels │ Tactics │ Content │ Campaigns              │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                │                                │
│                                ▼                                │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │   MEASURE       │  │   OPTIMIZE      │  │   SCALE         │  │
│  │   KPIs          │  │   A/B Tests     │  │   Budget        │  │
│  │   Analytics     │  │   Iterations    │  │   Growth        │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Strategy Template (ใช้กับ /strategy)

```markdown
# Marketing Strategy: [ธุรกิจ/แบรนด์]

## 1. SITUATION ANALYSIS

### Current State
- Revenue: ฿___/เดือน
- Customers: ___ คน
- Main channels: ___
- Top products: ___

### SWOT Analysis
| Strengths | Weaknesses |
|-----------|------------|
| • | • |
| • | • |

| Opportunities | Threats |
|---------------|---------|
| • | • |
| • | • |

### Competitor Landscape
| Competitor | Strengths | Weaknesses | Market Share |
|------------|-----------|------------|--------------|
| A | | | |
| B | | | |
| C | | | |

## 2. TARGET AUDIENCE

### Primary Persona
- Name: ___
- Age: ___
- Job: ___
- Income: ___
- Pain points: ___
- Goals: ___
- Where they hang out: ___

### Secondary Persona
[เพิ่มถ้ามี]

## 3. GOALS & OBJECTIVES

### Business Goals (1 Year)
- Revenue: ฿___
- Customers: ___
- Market share: ___%

### Marketing Objectives (Quarterly)
- Q1: ___
- Q2: ___
- Q3: ___
- Q4: ___

### KPIs
| Metric | Current | Target | Timeline |
|--------|---------|--------|----------|
| Traffic | | | |
| Leads | | | |
| Conversion | | | |
| CAC | | | |
| LTV | | | |

## 4. POSITIONING & MESSAGING

### Positioning Statement
For [target audience] who [need/want], 
[Brand] is the [category] that [key benefit] 
because [reason to believe].

### Key Messages
1. Primary: ___
2. Secondary: ___
3. Proof points: ___

### Tone of Voice
- Personality: ___
- Do's: ___
- Don'ts: ___

## 5. CHANNEL STRATEGY

### Channel Mix
| Channel | Role | Budget % | KPI |
|---------|------|----------|-----|
| Organic Social | Awareness | 20% | Reach |
| Paid Social | Acquisition | 30% | CAC |
| SEO | Discovery | 15% | Traffic |
| Email | Nurture | 10% | Open rate |
| Content | Authority | 15% | Engagement |
| Partnerships | Growth | 10% | Referrals |

### Channel-Specific Strategy
[รายละเอียดแต่ละช่อง]

## 6. CAMPAIGN ROADMAP

### Annual Calendar
| Month | Campaign | Channel | Budget | Goal |
|-------|----------|---------|--------|------|
| Jan | | | | |
| Feb | | | | |
| ... | | | | |

## 7. BUDGET ALLOCATION

### Total Budget: ฿___/เดือน

| Category | Amount | % |
|----------|--------|---|
| Paid Ads | | |
| Content | | |
| Tools | | |
| Influencers | | |
| Events | | |

## 8. MEASUREMENT & OPTIMIZATION

### Reporting Cadence
- Daily: ___
- Weekly: ___
- Monthly: ___

### Optimization Plan
- A/B tests to run: ___
- Review checkpoints: ___
```

---

## PART 2: CUSTOMER AVATAR BUILDER

### Avatar Template (ใช้กับ /avatar)

```markdown
# Customer Avatar: [ชื่อ Persona]

## DEMOGRAPHICS
┌─────────────────────────────────────┐
│ 📊 Basic Info                       │
├─────────────────────────────────────┤
│ Name: [ชื่อสมมติ]                    │
│ Age: [อายุ]                         │
│ Gender: [เพศ]                       │
│ Location: [ที่อยู่]                  │
│ Education: [การศึกษา]               │
│ Job Title: [ตำแหน่งงาน]             │
│ Income: [รายได้]                    │
│ Family: [สถานะครอบครัว]             │
└─────────────────────────────────────┘

## PSYCHOGRAPHICS

### Values & Beliefs
- ค่านิยม: ___
- ความเชื่อ: ___
- สิ่งที่สำคัญ: ___

### Goals & Aspirations
- เป้าหมายชีวิต: ___
- เป้าหมายอาชีพ: ___
- ความฝัน: ___

### Fears & Frustrations
- กลัวอะไร: ___
- หงุดหงิดกับอะไร: ___
- อุปสรรค: ___

### Pain Points (เรียงลำดับความสำคัญ)
1. [Pain point หลัก]
2. [Pain point รอง]
3. [Pain point อื่นๆ]

## BEHAVIOR

### Online Behavior
- Platforms: [แพลตฟอร์มที่ใช้]
- Content types: [ชอบ content แบบไหน]
- Active hours: [ช่วงเวลา online]
- Devices: [อุปกรณ์ที่ใช้]

### Buying Behavior
- Research style: [หาข้อมูลอย่างไร]
- Decision factors: [ปัจจัยตัดสินใจ]
- Price sensitivity: [ความอ่อนไหวเรื่องราคา]
- Buying triggers: [อะไรกระตุ้นให้ซื้อ]

### Media Consumption
- Blogs/Websites: ___
- YouTube channels: ___
- Podcasts: ___
- Social accounts: ___
- Influencers they follow: ___

## MESSAGING

### How to Reach Them
- Best channels: ___
- Best time: ___
- Best format: ___

### Language to Use
- Words they use: ___
- Tone that resonates: ___
- Topics they care about: ___

### Objections & How to Handle
| Objection | Response |
|-----------|----------|
| "แพงไป" | |
| "ไม่มีเวลา" | |
| "ไม่แน่ใจว่าได้ผล" | |

## CUSTOMER JOURNEY

### Awareness Stage
- Questions: ___
- Content needs: ___
- Channels: ___

### Consideration Stage
- Questions: ___
- Content needs: ___
- Channels: ___

### Decision Stage
- Questions: ___
- Content needs: ___
- Triggers: ___

### Post-Purchase
- Expectations: ___
- Support needs: ___
- Upsell opportunities: ___
```

### Avatar Research Questions

```
📋 คำถามสำหรับ Research

Demographics:
1. อายุเท่าไหร่?
2. ทำงานอะไร? ตำแหน่งอะไร?
3. รายได้ประมาณเท่าไหร่?
4. อยู่ที่ไหน? (เมือง/ต่างจังหวัด)

Goals & Challenges:
5. เป้าหมายหลักในชีวิตตอนนี้คืออะไร?
6. อะไรคืออุปสรรคที่ใหญ่ที่สุด?
7. ถ้าแก้ปัญหานี้ได้ ชีวิตจะเปลี่ยนอย่างไร?

Behavior:
8. ใช้เวลา online ที่ไหนบ้าง?
9. ติดตามใครใน social media?
10. ชอบ content แบบไหน? (video/text/audio)

Buying:
11. ซื้อของ online บ่อยแค่ไหน?
12. อะไรทำให้ตัดสินใจซื้อ?
13. อะไรทำให้ลังเล?
14. งบในการซื้อ [หมวดสินค้า] เท่าไหร่?
```

---

## PART 3: CAMPAIGN PLANNING

### Campaign Types

```
┌─────────────────────────────────────────────────────────────────┐
│                     CAMPAIGN TYPES                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  🚀 LAUNCH          📅 EVERGREEN       🎉 SEASONAL              │
│  • New product      • Always running   • Holiday sales          │
│  • New feature      • Lead generation  • Back to school         │
│  • Brand launch     • Brand awareness  • Year-end               │
│  • Course launch    • Content series   • Special occasions      │
│                                                                  │
│  ⚡ FLASH           🔄 REFERRAL        🤝 COLLABORATION         │
│  • Limited time     • Refer-a-friend   • Influencer             │
│  • Urgency-based    • Affiliate        • Brand partnership      │
│  • Scarcity         • Ambassador       • Cross-promotion        │
│                                                                  │
│  💪 RETENTION       🔥 RE-ENGAGEMENT   📈 GROWTH                │
│  • Loyalty program  • Win-back         • Viral campaigns        │
│  • VIP benefits     • Re-activation    • Growth hacking         │
│  • Renewal          • Cart abandonment • Expansion              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Campaign Blueprint (ใช้กับ /campaign)

```markdown
# Campaign Blueprint: [ชื่อ Campaign]

## OVERVIEW
- Campaign Name: ___
- Type: [Launch/Evergreen/Seasonal/etc.]
- Duration: ___ to ___
- Budget: ฿___
- Goal: ___

## OBJECTIVE & KPIs

### Primary Objective
[เป้าหมายหลัก - 1 อย่าง]

### Secondary Objectives
1. ___
2. ___

### Success Metrics
| Metric | Target | Tracking Method |
|--------|--------|-----------------|
| Reach | | |
| Engagement | | |
| Leads | | |
| Sales | | |
| ROI | | |

## TARGET AUDIENCE

### Primary
- Segment: ___
- Size: ___
- Targeting criteria: ___

### Secondary
- Segment: ___
- Size: ___
- Targeting criteria: ___

## KEY MESSAGE

### Big Idea
[1 ประโยค core message]

### Value Proposition
[ทำไมต้องสนใจ]

### Call-to-Action
[อยากให้ทำอะไร]

### Key Messages by Stage
| Stage | Message | CTA |
|-------|---------|-----|
| Awareness | | |
| Interest | | |
| Desire | | |
| Action | | |

## CHANNEL MIX

### Paid Media
| Channel | Budget | Targeting | Format |
|---------|--------|-----------|--------|
| Facebook Ads | | | |
| Google Ads | | | |
| YouTube Ads | | | |
| TikTok Ads | | | |

### Owned Media
| Channel | Content Type | Frequency |
|---------|--------------|-----------|
| Website | | |
| Email | | |
| Social | | |
| Blog | | |

### Earned Media
| Type | Target | Approach |
|------|--------|----------|
| PR | | |
| Influencers | | |
| UGC | | |
| Reviews | | |

## CONTENT PLAN

### Content Needed
| Content | Format | Channel | Deadline |
|---------|--------|---------|----------|
| | | | |
| | | | |

### Creative Assets
- [ ] Hero image/video
- [ ] Ad creatives (5-10 variations)
- [ ] Landing page
- [ ] Email templates
- [ ] Social posts
- [ ] Blog content

## TIMELINE

### Pre-Launch (Week -2 to -1)
- [ ] Finalize assets
- [ ] Set up tracking
- [ ] Test landing page
- [ ] Prepare email sequences
- [ ] Brief team

### Launch (Week 1)
- Day 1: ___
- Day 2-3: ___
- Day 4-7: ___

### Mid-Campaign (Week 2-3)
- Optimization: ___
- Content refresh: ___

### Close (Final Week)
- Urgency push: ___
- Last call: ___

### Post-Campaign
- [ ] Report
- [ ] Learnings
- [ ] Follow-up

## BUDGET BREAKDOWN

| Item | Amount | % of Total |
|------|--------|------------|
| Paid Ads | | |
| Content Creation | | |
| Influencers | | |
| Tools/Tech | | |
| Contingency | | |
| **TOTAL** | | 100% |

## TRACKING & OPTIMIZATION

### UTM Parameters
```
utm_source=___
utm_medium=___
utm_campaign=___
utm_content=___
```

### A/B Tests Planned
1. ___
2. ___
3. ___

### Optimization Checkpoints
- Day 3: Review initial data
- Day 7: First optimization round
- Day 14: Mid-campaign review
- Day 21: Final push planning

## TEAM & RESPONSIBILITIES

| Role | Person | Responsibilities |
|------|--------|------------------|
| Campaign Lead | | |
| Creative | | |
| Media Buyer | | |
| Content | | |
| Analytics | | |
```

---

## PART 4: GROWTH MARKETING

### Growth Framework

```
┌─────────────────────────────────────────────────────────────────┐
│                    AARRR PIRATE METRICS                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ACQUISITION ──────> ACTIVATION ──────> RETENTION               │
│  (Get users)        (Aha moment)       (Keep coming back)       │
│       │                  │                    │                  │
│       │                  │                    │                  │
│       ▼                  ▼                    ▼                  │
│  ┌─────────┐       ┌─────────┐          ┌─────────┐            │
│  │ Traffic │       │ Sign-up │          │ Return  │            │
│  │ Sources │       │  Rate   │          │  Rate   │            │
│  └─────────┘       └─────────┘          └─────────┘            │
│                                                                  │
│  REVENUE ────────────────────────────> REFERRAL                │
│  (Make money)                          (Users invite users)     │
│       │                                      │                   │
│       ▼                                      ▼                   │
│  ┌─────────┐                           ┌─────────┐             │
│  │   LTV   │                           │ Viral   │             │
│  │   CAC   │                           │  Loop   │             │
│  └─────────┘                           └─────────┘             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Growth Tactics Library

```
📈 ACQUISITION TACTICS

Organic:
□ SEO optimization
□ Content marketing
□ Social media organic
□ Community building
□ Guest posting
□ Podcast appearances
□ YouTube optimization
□ Quora/Reddit answers
□ Product Hunt launch

Paid:
□ Facebook/Instagram Ads
□ Google Search Ads
□ YouTube Ads
□ TikTok Ads
□ LinkedIn Ads (B2B)
□ Influencer partnerships
□ Sponsorships
□ Affiliate marketing

🎯 ACTIVATION TACTICS

□ Optimize onboarding flow
□ Reduce friction (fewer steps)
□ Progress indicators
□ Quick wins / Aha moment
□ Welcome email sequence
□ Tutorial videos
□ Chatbot assistance
□ Personalization
□ Free trial optimization

🔄 RETENTION TACTICS

□ Email nurture sequences
□ Push notifications
□ In-app messages
□ Loyalty program
□ Exclusive content
□ Community access
□ Regular check-ins
□ Feature updates
□ Win-back campaigns

💰 REVENUE TACTICS

□ Upsell sequences
□ Cross-sell recommendations
□ Annual plan discounts
□ Limited-time offers
□ Bundle deals
□ Premium features
□ Add-on services
□ Price optimization
□ Payment plan options

🔥 REFERRAL TACTICS

□ Referral program
□ Double-sided incentives
□ Share buttons
□ Referral contests
□ Ambassador program
□ Affiliate program
□ Case study features
□ Testimonial requests
□ Social proof display
```

### Growth Experiment Template

```markdown
# Growth Experiment: [ชื่อ]

## Hypothesis
We believe that [การเปลี่ยนแปลง]
will result in [ผลลัพธ์ที่คาดหวัง]
because [เหตุผล].

## Metric to Move
- Primary: ___
- Current baseline: ___
- Target: ___

## Experiment Design
- Test type: [A/B / Multivariate / Before-After]
- Sample size: ___
- Duration: ___
- Confidence level: ___

## Implementation
- Changes needed: ___
- Resources required: ___
- Dependencies: ___

## Results
- Control: ___
- Variant: ___
- Lift: ___%
- Statistical significance: ___

## Decision
[ ] Ship it
[ ] Iterate
[ ] Kill it

## Learnings
- What worked: ___
- What didn't: ___
- Next experiment: ___
```

---

## PART 5: INFLUENCER MARKETING

### Influencer Tiers

```
┌─────────────────────────────────────────────────────────────────┐
│                    INFLUENCER TIERS                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  MEGA (1M+)          MACRO (100K-1M)      MICRO (10K-100K)      │
│  • Celebrities       • Established        • Niche experts       │
│  • High reach        • Good reach         • High engagement     │
│  • Expensive         • Mid-range cost     • Affordable          │
│  • Low engagement    • Moderate engage    • Authentic           │
│  • Brand awareness   • Mixed goals        • Conversions         │
│                                                                  │
│  NANO (1K-10K)       BRAND FANS           EMPLOYEES             │
│  • Super niche       • Existing customers • Internal advocacy   │
│  • Very authentic    • Organic advocacy   • Company culture     │
│  • Very affordable   • Free/low cost      • Free                │
│  • High trust        • Highest trust      • Authentic           │
│  • Word-of-mouth     • UGC/reviews        • Employer brand      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Influencer Outreach Template

```markdown
# Influencer Campaign: [Campaign Name]

## Campaign Overview
- Objective: ___
- Budget: ฿___
- Timeline: ___
- Product/Service: ___

## Influencer Criteria
- Niche: ___
- Follower range: ___
- Engagement rate minimum: ___%
- Location: ___
- Audience demographics: ___
- Content style: ___

## Influencer List

| Name | Platform | Followers | Engagement | Rate | Status |
|------|----------|-----------|------------|------|--------|
| | | | | | |
| | | | | | |

## Collaboration Types
□ Sponsored post
□ Product review
□ Unboxing
□ Tutorial/How-to
□ Giveaway
□ Takeover
□ Affiliate
□ Brand ambassador
□ Event attendance
□ Content creation (for brand use)

## Deliverables per Influencer
- [ ] X Instagram posts
- [ ] X Instagram stories
- [ ] X YouTube video
- [ ] X TikTok video
- [ ] X Blog post
- [ ] Usage rights for ___ months

## Compensation Structure
| Tier | Followers | Rate Range | Notes |
|------|-----------|------------|-------|
| Nano | 1K-10K | ฿___ - ฿___ | Product + small fee |
| Micro | 10K-100K | ฿___ - ฿___ | |
| Macro | 100K-1M | ฿___ - ฿___ | |
| Mega | 1M+ | ฿___ - ฿___ | |

## Outreach Messages

### Initial DM
```
สวัสดีครับ/ค่ะ [ชื่อ]

ติดตามคอนเทนต์ของคุณมาสักพักแล้ว ชอบ [specific content] มากๆ

ผม/ฉันจาก [Brand] กำลังมองหา Creator ที่ [คุณสมบัติ] มาร่วมงานด้วย คิดว่าคุณเหมาะมากเลย

สนใจคุยรายละเอียดเพิ่มเติมไหมครับ/คะ?

[ชื่อคุณ]
```

### Follow-up Email
```
Subject: Collaboration opportunity with [Brand] 🤝

สวัสดีครับ/ค่ะ [ชื่อ],

ตามที่ได้ DM ไปเมื่อวาน...

[Brand] คือ [อธิบายสั้นๆ]

เรากำลังมองหา Creator มาร่วม [campaign objective]:
• What: [deliverables]
• When: [timeline]  
• Compensation: [rate/product]

ถ้าสนใจ เรายินดีโทรคุยรายละเอียดเพิ่มเติมครับ/ค่ะ

ขอบคุณครับ/ค่ะ
[ชื่อ]
```

## Content Guidelines
- Brand mentions: ___
- Hashtags required: ___
- Disclosure: #ad #sponsored
- Do's: ___
- Don'ts: ___

## Tracking & Measurement
| Metric | Target | How to Track |
|--------|--------|--------------|
| Reach | | |
| Engagement | | |
| Clicks | | UTM links |
| Conversions | | Promo codes |
| EMV | | |
```

---

## PART 6: MARKETING ANALYTICS

### Key Marketing Metrics

```
┌─────────────────────────────────────────────────────────────────┐
│                    MARKETING METRICS DASHBOARD                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  💰 REVENUE METRICS          📈 GROWTH METRICS                  │
│  • Revenue                   • MoM Growth Rate                  │
│  • MRR/ARR                   • YoY Growth Rate                  │
│  • ARPU                      • Customer Growth                  │
│  • Revenue per Channel       • Market Share                     │
│                                                                  │
│  👥 ACQUISITION METRICS      🔄 RETENTION METRICS               │
│  • CAC (Customer Acq Cost)   • Churn Rate                       │
│  • CPL (Cost per Lead)       • Retention Rate                   │
│  • CPC/CPM/CPA               • Repeat Purchase Rate             │
│  • Conversion Rate           • Customer Lifetime (months)       │
│                                                                  │
│  💎 VALUE METRICS            📊 CHANNEL METRICS                 │
│  • LTV (Lifetime Value)      • Traffic by Source                │
│  • LTV:CAC Ratio            • Conversion by Channel            │
│  • Payback Period            • Attribution                      │
│  • Net Promoter Score        • ROAS (Return on Ad Spend)        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Metric Formulas

```
📊 ESSENTIAL FORMULAS

CAC (Customer Acquisition Cost)
= Total Marketing Spend / New Customers Acquired

LTV (Customer Lifetime Value)
= Average Order Value × Purchase Frequency × Customer Lifespan
หรือ
= ARPU × Gross Margin × (1 / Churn Rate)

LTV:CAC Ratio
= LTV / CAC
(Target: 3:1 หรือมากกว่า)

Payback Period
= CAC / (ARPU × Gross Margin)
(จำนวนเดือนที่ต้องใช้คืนทุน CAC)

ROAS (Return on Ad Spend)
= Revenue from Ads / Ad Spend
(Target: 3x หรือมากกว่า)

ROI (Return on Investment)
= (Revenue - Cost) / Cost × 100%

Conversion Rate
= Conversions / Total Visitors × 100%

Churn Rate
= Customers Lost / Total Customers at Start × 100%

Retention Rate
= 100% - Churn Rate

Net Promoter Score (NPS)
= % Promoters (9-10) - % Detractors (0-6)

Engagement Rate
= Total Engagements / Total Followers × 100%

Email Open Rate
= Opens / Delivered × 100%

Email Click Rate (CTR)
= Clicks / Delivered × 100%

Click-to-Open Rate (CTOR)
= Clicks / Opens × 100%
```

### Marketing Dashboard Template

```markdown
# Marketing Dashboard: [Month/Quarter]

## Executive Summary
- Total Revenue: ฿___
- Marketing Spend: ฿___
- Marketing ROI: ___%
- New Customers: ___
- CAC: ฿___
- LTV: ฿___

## Traffic Overview
| Source | Sessions | % of Total | Conversions | Conv Rate |
|--------|----------|------------|-------------|-----------|
| Organic Search | | | | |
| Paid Search | | | | |
| Social Organic | | | | |
| Social Paid | | | | |
| Email | | | | |
| Direct | | | | |
| Referral | | | | |
| **TOTAL** | | 100% | | |

## Campaign Performance
| Campaign | Spend | Revenue | ROAS | Leads | CPA |
|----------|-------|---------|------|-------|-----|
| | | | | | |
| | | | | | |

## Channel Performance

### Paid Ads
| Platform | Spend | Impressions | Clicks | CTR | CPC | Conv | CPA |
|----------|-------|-------------|--------|-----|-----|------|-----|
| Facebook | | | | | | | |
| Google | | | | | | | |
| YouTube | | | | | | | |
| TikTok | | | | | | | |

### Email Marketing
| Metric | This Month | Last Month | Change |
|--------|------------|------------|--------|
| List Size | | | |
| Emails Sent | | | |
| Open Rate | | | |
| Click Rate | | | |
| Unsubscribes | | | |

### Social Media
| Platform | Followers | Reach | Engagement | Eng Rate |
|----------|-----------|-------|------------|----------|
| Instagram | | | | |
| Facebook | | | | |
| Twitter | | | | |
| TikTok | | | | |
| YouTube | | | | |
| LinkedIn | | | | |

## Funnel Metrics
| Stage | Volume | Conversion to Next |
|-------|--------|-------------------|
| Visitors | | |
| Leads | | % |
| MQLs | | % |
| SQLs | | % |
| Opportunities | | % |
| Customers | | % |

## Key Insights
1. ___
2. ___
3. ___

## Action Items
1. ___
2. ___
3. ___
```

---

## Quick Reference: Marketing Calendar

### Annual Marketing Calendar Framework

```
┌─────────────────────────────────────────────────────────────────┐
│                    ANNUAL MARKETING CALENDAR                     │
├─────┬───────────────────────────────────────────────────────────┤
│ Q1  │ Jan: New Year, Planning, Goal Setting                     │
│     │ Feb: Valentine's Day                                      │
│     │ Mar: Thai New Year Prep                                   │
├─────┼───────────────────────────────────────────────────────────┤
│ Q2  │ Apr: Songkran, Thai New Year                              │
│     │ May: Mother's Day (US), Mid-year Check                    │
│     │ Jun: Mid-year Sale                                        │
├─────┼───────────────────────────────────────────────────────────┤
│ Q3  │ Jul: Mid-year Review                                      │
│     │ Aug: Mother's Day (TH)                                    │
│     │ Sep: Back to School (Prep for Q4)                         │
├─────┼───────────────────────────────────────────────────────────┤
│ Q4  │ Oct: Pre-holiday Prep                                     │
│     │ Nov: 11.11, Black Friday, Cyber Monday                    │
│     │ Dec: 12.12, Christmas, Year End                           │
└─────┴───────────────────────────────────────────────────────────┘
```

---

## Related Skills

- **mrarranger-sales** - Copywriting, Ads, Sales Funnels
- **mrarranger-content-master** - Content Marketing
- **mrarranger-social** - Social Media Marketing
- **mrarranger-seo** - SEO & YouTube Optimization
- **mrarranger-analytics** - Performance Analytics
- **mrarranger-research** - Market & Competitor Research

---

## Version
- Version: 1.0.0
- Last Updated: 2024
- Author: MRARRANGER System