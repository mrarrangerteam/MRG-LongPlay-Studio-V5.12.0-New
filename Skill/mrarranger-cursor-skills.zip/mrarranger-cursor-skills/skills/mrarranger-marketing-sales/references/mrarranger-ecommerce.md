# mrarranger-ecommerce

**Source:** `/mnt/skills/user/mrarranger-ecommerce/SKILL.md`
**Size:** 9769 bytes

---

---
name: mrarranger-ecommerce
description: |
  ระบบ E-commerce ครบวงจร - Shopee, Lazada, TikTok Shop, Amazon, Shopify, WooCommerce
  รองรับ Product Listing, Store Optimization, Pricing Strategy, Inventory, Dropshipping, และ Marketplace Analytics
  ใช้เมื่อ: (1) สร้าง Product Listing (2) Optimize ร้านค้า (3) วางกลยุทธ์ราคา (4) วิเคราะห์คู่แข่ง (5) Dropshipping (6) Ads บน Marketplace
  Commands: /product [name], /listing [platform], /price [strategy], /store [optimize], /dropship [niche], /shopee [action], /lazada [action]
---

# MRARRANGER E-commerce Master

## Quick Commands

```
/product [name]           → สร้าง Product Listing
/listing [platform]       → Optimize Listing ตาม Platform
/price [strategy]         → วางกลยุทธ์ราคา
/store [action]           → จัดการร้านค้า
/dropship [niche]         → วางแผน Dropshipping
/shopee [action]          → Shopee Specific
/lazada [action]          → Lazada Specific
/tiktok-shop [action]     → TikTok Shop
/competitor [analyze]     → วิเคราะห์คู่แข่ง
/ads [platform]           → Marketplace Ads
```

## Platform Guides

### Shopee Thailand

**Store Tiers:**
```
Preferred Seller → Mall → Premium
- Response rate > 80%
- Ship on time > 95%
- Low cancellation < 2%
- Good ratings > 4.5
```

**Listing Optimization:**
```
Title Formula (Max 120 chars):
[Brand] + [Product] + [Key Feature] + [Size/Variant] + [Keyword]

Example:
"Samsung Galaxy S24 Ultra 5G 256GB มือถือ AI กล้อง 200MP ประกันศูนย์ไทย"

Images:
- Main: White background, product only
- 2-5: Features, lifestyle, size comparison
- 6-9: Details, packaging, warranty
- Video: 15-60 sec demo

Description Structure:
1. Hook (ทำไมต้องซื้อ)
2. Key Features (bullet points)
3. Specifications
4. What's in the box
5. Warranty/Return policy
6. Keywords (ซ่อนท้าย)
```

**Shopee Algorithms:**
```
Ranking Factors:
1. Conversion Rate (สำคัญสุด)
2. Click-Through Rate
3. Sales Velocity
4. Reviews & Ratings
5. Response Time
6. Shipping Performance

Boost Tactics:
- Flash Sale participation
- Voucher campaigns
- Free shipping
- Shopee Live
- Affiliate program
```

### Lazada Thailand

**LazMall vs Marketplace:**
```
LazMall:
- Brand owners only
- Higher trust
- Better visibility
- Commission 5-8%

Marketplace:
- Anyone can join
- Lower barrier
- Commission 2-5%
```

**Listing Best Practices:**
```
Title: Max 255 chars
- Include main keyword first
- Add variants (size, color)
- No special characters spam

Product Score:
- Images: 8+ images = higher score
- Video: +20% conversion
- A+ Content: Rich description
- Variants: Complete all options
```

### TikTok Shop

**Content Commerce:**
```
Strategy:
1. Create viral content first
2. Link products naturally
3. Use trending sounds
4. Live selling sessions

Video Formula:
Hook (0-3s) → Problem (3-7s) → Solution/Product (7-15s) → CTA (15-20s)

Best Sellers:
- Beauty & Skincare
- Fashion accessories
- Gadgets & Tech
- Home & Living
- Food & Snacks
```

**Live Selling Tips:**
```
Duration: 2-4 hours optimal
Peak times: 19:00-22:00
Structure:
- Opening games/giveaway
- Product demos
- Flash deals
- Q&A engagement
- Closing urgency
```

### Shopify / Own Store

**Store Setup Checklist:**
```
□ Domain (brandname.com)
□ SSL Certificate
□ Payment gateways (Credit, PayPal, PromptPay)
□ Shipping zones & rates
□ Tax settings
□ Legal pages (Privacy, Terms, Refund)
□ Google Analytics
□ Facebook Pixel
□ Email marketing integration
```

**Conversion Optimization:**
```
Homepage:
- Hero banner with value prop
- Best sellers section
- Trust badges
- Customer reviews

Product Page:
- High-quality images
- Clear pricing
- Stock urgency
- Social proof
- Easy add to cart

Checkout:
- Guest checkout option
- Multiple payment methods
- Clear shipping info
- Order summary
```

## Product Listing Templates

### Complete Product Listing
```markdown
## [Product Name]

### Title (SEO Optimized)
[Brand] [Product Type] [Key Feature] [Variant] [Keyword]

### Short Description (150 chars)
[Benefit-focused hook that makes them click]

### Key Features
• [Feature 1 + Benefit]
• [Feature 2 + Benefit]
• [Feature 3 + Benefit]
• [Feature 4 + Benefit]
• [Feature 5 + Benefit]

### Full Description
[Opening hook - why this product]

[Problem it solves]

[How it works / Key benefits]

[Social proof / Awards / Certifications]

[Specifications table]

[What's in the box]

[Warranty & Support]

### SEO Keywords
Primary: [main keyword]
Secondary: [keyword 2], [keyword 3], [keyword 4]
Long-tail: [long keyword phrase]

### Pricing
Cost: ฿___
Selling Price: ฿___
Compare at Price: ฿___
Margin: ___%
```

### Quick Listing Formula
```
สำหรับ [TARGET CUSTOMER] ที่ต้องการ [DESIRE]
[PRODUCT NAME] ช่วยให้คุณ [BENEFIT]
ด้วย [KEY FEATURE] ที่ [UNIQUE ADVANTAGE]
```

## Pricing Strategies

### Cost-Plus Pricing
```
Cost + Markup = Selling Price

Example:
Product Cost: ฿100
Shipping: ฿20
Platform Fee: ฿15 (15%)
Packaging: ฿10
Total Cost: ฿145

Target Margin: 40%
Selling Price: ฿145 / 0.6 = ฿242
```

### Competitive Pricing
```
Research:
1. Search exact product on platform
2. Note prices of top 10 sellers
3. Check their sales volume
4. Find sweet spot

Positioning:
- Premium: +20-30% (with added value)
- Match: Same price (compete on service)
- Undercut: -5-10% (volume play)
```

### Psychological Pricing
```
Tactics:
- ฿199 instead of ฿200
- ฿1,990 instead of ฿2,000
- Bundle pricing (3 for ฿500)
- Anchor pricing (was ฿599, now ฿399)
- Free shipping threshold (฿500+ free ship)
```

### Dynamic Pricing
```
Adjust based on:
- Demand (peak seasons +10-20%)
- Competition (match or beat)
- Inventory (clearance pricing)
- Time of day (flash sales)
- Customer segment (VIP discounts)
```

## Dropshipping

### Supplier Sources
```
China:
- 1688.com (cheapest, need agent)
- AliExpress (direct, higher cost)
- CJ Dropshipping (automation)
- Alibaba (bulk orders)

Thailand:
- Thai wholesalers
- Factory direct
- Local dropship suppliers

Print-on-Demand:
- Printful
- Printify
- Gooten
```

### Dropship Workflow
```
1. Customer orders on your store
2. You receive order notification
3. Place order with supplier
4. Supplier ships to customer
5. You keep the margin

Automation:
- Use apps like DSers, Oberlo
- Auto-sync inventory
- Auto-order placement
- Tracking sync
```

### Niche Selection Criteria
```
Good Niche:
✓ Passion/Interest exists
✓ Problem-solving products
✓ ฿500-2,000 price range
✓ Light & easy to ship
✓ Not easily found locally
✓ Repeat purchase potential
✓ Low return rate

Avoid:
✗ Fragile items
✗ Electronics (warranty issues)
✗ Fashion (size returns)
✗ Perishables
✗ Oversaturated markets
```

## Marketplace Ads

### Shopee Ads
```
Types:
1. Search Ads - Keyword targeting
2. Discovery Ads - Browse pages
3. Shop Ads - Store promotion

Bidding Strategy:
- Start low: ฿0.5-1 per click
- Monitor ROAS
- Increase for winners
- Pause losers after 3 days

Keywords:
- Exact match for best products
- Broad match for discovery
- Negative keywords to exclude
```

### Lazada Sponsored Products
```
Campaign Types:
- Keyword targeting
- Automatic targeting
- Affinity targeting

Optimization:
1. Start with auto-targeting
2. Analyze search term report
3. Move winners to manual
4. Bid higher on converting keywords
5. Add negatives
```

### Facebook/Meta Ads for E-commerce
```
Funnel:
1. Awareness: Video views
2. Consideration: Traffic, Engagement
3. Conversion: Purchase, Add to Cart

Audiences:
- Lookalike of buyers
- Retargeting cart abandoners
- Interest-based (cold)
- Custom audiences (email list)

Creative Tips:
- UGC style performs best
- Show product in use
- Clear pricing visible
- Strong CTA
```

## Analytics & KPIs

### Key Metrics
```
Traffic:
- Sessions
- Unique visitors
- Traffic sources

Conversion:
- Conversion rate (target: 2-5%)
- Add to cart rate
- Checkout completion rate

Revenue:
- Total sales
- Average order value
- Revenue per visitor

Profitability:
- Gross margin
- Net profit
- ROAS (Return on Ad Spend)
```

### Store Health Dashboard
```
Daily Check:
□ Orders received
□ Orders to ship
□ Customer messages
□ Reviews to respond
□ Stock levels

Weekly Check:
□ Sales vs last week
□ Top products
□ Ad performance
□ Competitor prices
□ Inventory forecast

Monthly Check:
□ P&L statement
□ Best/worst products
□ Customer segments
□ Growth opportunities
```

## Competitor Analysis

### Research Framework
```
1. Identify Top 10 Competitors
   - Search main keywords
   - Note top sellers
   
2. Analyze Each:
   - Pricing strategy
   - Product range
   - Listing quality
   - Review count & rating
   - Response time
   - Promotions used
   
3. Find Gaps:
   - What are they missing?
   - What complaints in reviews?
   - Underserved segments?
```

### Competitive Advantages
```
Beat them on:
□ Price (margin allows)
□ Bundling (add value)
□ Speed (faster shipping)
□ Service (better support)
□ Quality (premium positioning)
□ Niche (specialize deeper)
□ Content (better listings)
□ Trust (more reviews)
```

## File References

- `references/platform-guides.md` - รายละเอียดแต่ละ Platform
- `references/listing-templates.md` - Templates พร้อมใช้
- `references/pricing-calculator.md` - สูตรคำนวณราคา