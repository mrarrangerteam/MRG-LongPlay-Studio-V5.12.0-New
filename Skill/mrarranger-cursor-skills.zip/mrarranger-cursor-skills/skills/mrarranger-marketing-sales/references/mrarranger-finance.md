# mrarranger-finance

**Source:** `/mnt/skills/user/mrarranger-finance/SKILL.md`
**Size:** 12130 bytes

---

---
name: mrarranger-finance
description: |
  ระบบการเงินและการลงทุนครบวงจร - หุ้นไทย/US, Technical Analysis, Fundamental Analysis, Crypto, Portfolio Management
  วิเคราะห์หุ้น สร้าง Watchlist วางแผนการลงทุน และติดตาม Portfolio
  ใช้เมื่อ: (1) วิเคราะห์หุ้น (2) Technical Analysis (3) Fundamental Analysis (4) สร้าง Portfolio (5) Crypto Analysis (6) วางแผนการเงิน
  Commands: /stock [symbol], /analyze [ticker], /ta [chart], /fa [company], /portfolio [action], /crypto [coin], /screen [criteria]
---

# MRARRANGER Finance & Investment

## Quick Commands

```
/stock [symbol]           → ข้อมูลหุ้น
/analyze [ticker]         → วิเคราะห์รอบด้าน
/ta [symbol]              → Technical Analysis
/fa [symbol]              → Fundamental Analysis
/portfolio [action]       → จัดการ Portfolio
/screen [criteria]        → Stock Screening
/crypto [coin]            → วิเคราะห์ Crypto
/sector [name]            → วิเคราะห์ Sector
/compare [stock1] [stock2] → เปรียบเทียบหุ้น
```

## Stock Analysis Framework

### Quick Analysis Template
```
## [TICKER] Analysis

### Company Overview
- ชื่อ: 
- Sector/Industry:
- Market Cap:
- Business Model:

### Key Metrics
- P/E Ratio:
- P/BV Ratio:
- ROE:
- Dividend Yield:
- Debt/Equity:

### Technical View
- Trend: [Uptrend/Downtrend/Sideways]
- Support: 
- Resistance:
- RSI:
- MACD:

### Verdict
- Rating: [Strong Buy/Buy/Hold/Sell/Strong Sell]
- Target Price:
- Stop Loss:
- Risk Level: [Low/Medium/High]
```

## Technical Analysis

### Chart Patterns

**Bullish Patterns:**
```
📈 Reversal (กลับตัวขึ้น):
- Double Bottom (W)
- Inverse Head & Shoulders
- Morning Star (Candlestick)
- Bullish Engulfing
- Hammer / Dragonfly Doji

📈 Continuation (ไปต่อ):
- Bull Flag
- Ascending Triangle
- Cup and Handle
- Bullish Pennant
```

**Bearish Patterns:**
```
📉 Reversal (กลับตัวลง):
- Double Top (M)
- Head & Shoulders
- Evening Star
- Bearish Engulfing
- Shooting Star / Gravestone Doji

📉 Continuation:
- Bear Flag
- Descending Triangle
- Bearish Pennant
```

### Key Indicators

**Trend Indicators:**
```
Moving Averages:
- MA10: Short-term trend
- MA50: Medium-term trend
- MA200: Long-term trend
- Golden Cross: MA50 > MA200 (Bullish)
- Death Cross: MA50 < MA200 (Bearish)

MACD:
- MACD Line > Signal Line = Bullish
- MACD Line < Signal Line = Bearish
- Histogram แดง→เขียว = Buy signal
- Histogram เขียว→แดง = Sell signal
```

**Momentum Indicators:**
```
RSI (Relative Strength Index):
- > 70: Overbought (อาจปรับฐาน)
- < 30: Oversold (อาจดีดกลับ)
- 40-60: Neutral zone

Stochastic:
- > 80: Overbought
- < 20: Oversold
- %K cross %D: Signal
```

**Volume Indicators:**
```
OBV (On-Balance Volume):
- Price ขึ้น + Volume ขึ้น = Strong uptrend
- Price ขึ้น + Volume ลง = Weak (divergence)

Volume Profile:
- High volume nodes = Support/Resistance
- Low volume nodes = Price moves fast
```

### Support & Resistance
```
วิธีหา:
1. Previous highs/lows
2. Round numbers (100, 500, 1000)
3. Moving averages
4. Fibonacci levels (38.2%, 50%, 61.8%)
5. Volume profile POC

Trading Rules:
- Buy near support
- Sell near resistance
- Break + Volume = Confirm
- False break = Trap (ระวัง)
```

## Fundamental Analysis

### Financial Ratios

**Valuation Ratios:**
```
P/E (Price to Earnings):
- ราคา ÷ กำไรต่อหุ้น
- ต่ำ = ถูก (แต่ดูเหตุผลด้วย)
- เทียบกับ Industry average
- หุ้นเติบโต P/E สูงได้

P/BV (Price to Book Value):
- ราคา ÷ มูลค่าทางบัญชี
- < 1 = ต่ำกว่า Book (แต่อาจมีปัญหา)
- ธนาคาร/ประกัน ใช้ P/BV

P/S (Price to Sales):
- ราคา ÷ รายได้ต่อหุ้น
- ใช้กับบริษัทขาดทุน

EV/EBITDA:
- Enterprise Value ÷ EBITDA
- เปรียบเทียบข้าม sector ได้
```

**Profitability Ratios:**
```
ROE (Return on Equity):
- กำไร ÷ ส่วนของผู้ถือหุ้น
- > 15% = ดี
- ยิ่งสูงยิ่งดี (ถ้า sustainable)

ROA (Return on Assets):
- กำไร ÷ สินทรัพย์รวม
- > 5% = ดี
- เปรียบเทียบใน industry เดียวกัน

Gross Margin:
- (รายได้ - ต้นทุน) ÷ รายได้
- สูง = มี pricing power

Net Profit Margin:
- กำไรสุทธิ ÷ รายได้
- ดู trend หลายปี
```

**Financial Health:**
```
Debt/Equity Ratio:
- หนี้สิน ÷ ส่วนของผู้ถือหุ้น
- < 1 = Conservative
- > 2 = High leverage (risky)

Current Ratio:
- สินทรัพย์หมุนเวียน ÷ หนี้สินหมุนเวียน
- > 1.5 = Healthy
- < 1 = Liquidity risk

Interest Coverage:
- EBIT ÷ ดอกเบี้ยจ่าย
- > 3 = Safe
- < 1.5 = Risky
```

**Growth Metrics:**
```
Revenue Growth:
- YoY% และ CAGR 3-5 ปี
- เติบโตสม่ำเสมอ = ดี

EPS Growth:
- การเติบโตของกำไรต่อหุ้น
- ดู trend และ consistency

Dividend Growth:
- การเติบโตของปันผล
- Dividend Payout Ratio
- Dividend Yield
```

### Valuation Methods

**DCF (Discounted Cash Flow):**
```
Intrinsic Value = Σ (FCF / (1+r)^n) + Terminal Value

Steps:
1. Project Free Cash Flow 5-10 years
2. Calculate Terminal Value
3. Discount to present value
4. Divide by shares outstanding
5. Compare with current price

Margin of Safety:
- Buy when price < 70% of intrinsic value
```

**Relative Valuation:**
```
Compare with peers:
- P/E vs Industry P/E
- P/BV vs Industry P/BV
- EV/EBITDA vs Industry

Premium/Discount:
- หุ้นดี = Premium ได้
- หุ้นมีปัญหา = Discount
```

### Qualitative Analysis
```
Business Quality:
□ Moat (competitive advantage)
□ Industry position (#1, #2?)
□ Management quality
□ Corporate governance
□ ESG factors

Growth Drivers:
□ New products/services
□ Market expansion
□ M&A opportunities
□ Industry tailwinds

Risks:
□ Competition
□ Regulation
□ Technology disruption
□ Key person risk
□ Customer concentration
```

## Thai Stock Market (SET)

### Market Segments
```
SET:
- SET50: Top 50 หุ้นใหญ่สุด
- SET100: Top 100
- SETHD: High dividend stocks
- sSET: Small-mid cap

mai (Market for Alternative Investment):
- หุ้นขนาดเล็ก
- Growth stocks
- Higher risk/reward
```

### Key Sectors
```
Energy (ENERG): PTT, PTTEP, GULF
Banking (BANK): KBANK, SCB, BBL, KTB
Property (PROP): LH, AP, SPALI
Healthcare (HELTH): BDMS, BH
Tech (TECH): DELTA, HANA
Commerce (COMM): CPALL, BJC
Tourism (TOURISM): AOT, CENTEL, MINT
```

### SET Index Analysis
```
Key Levels to Watch:
- All-time high: ____
- 52-week high: ____
- 52-week low: ____
- Key support: ____
- Key resistance: ____

Indicators:
- Foreign flow (ซื้อ/ขายสุทธิ)
- Volume
- Advance/Decline
- Sector rotation
```

## US Stock Market

### Major Indices
```
Dow Jones (DJIA): 30 blue chips
S&P 500: 500 large cap
NASDAQ: Tech-heavy
Russell 2000: Small cap
```

### Sectors (GICS)
```
Technology (XLK): AAPL, MSFT, NVDA
Healthcare (XLV): JNJ, UNH, PFE
Financials (XLF): JPM, BAC, V
Consumer Disc (XLY): AMZN, TSLA, HD
Communication (XLC): GOOGL, META
Energy (XLE): XOM, CVX
```

### Key US Stocks
```
Magnificent 7:
AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA

Dividend Aristocrats:
JNJ, PG, KO, PEP, MMM (25+ years dividend growth)
```

## Portfolio Management

### Asset Allocation
```
Conservative (Low Risk):
- Bonds/Fixed Income: 60%
- Stocks: 30%
- Cash: 10%

Balanced (Medium Risk):
- Stocks: 60%
- Bonds: 30%
- Alternative: 10%

Aggressive (High Risk):
- Stocks: 80%
- Crypto/Alternative: 15%
- Cash: 5%
```

### Portfolio Diversification
```
By Asset Class:
- Stocks, Bonds, REITs, Commodities, Crypto

By Geography:
- Thailand, US, Emerging Markets

By Sector:
- ไม่เกิน 25% ต่อ sector

By Stock:
- ไม่เกิน 10% ต่อหุ้น (concentrated)
- ไม่เกิน 5% ต่อหุ้น (diversified)
```

### Position Sizing
```
Risk-based Sizing:
Position Size = (Portfolio × Risk%) / (Entry - Stop Loss)

Example:
Portfolio: ฿1,000,000
Risk per trade: 2% = ฿20,000
Entry: ฿100
Stop Loss: ฿90 (฿10 risk)
Position Size: ฿20,000 / ฿10 = 2,000 shares
```

### Risk Management
```
Rules:
1. Never risk > 2% per trade
2. Never risk > 6% total open positions
3. Always have stop loss
4. Take partial profits at targets
5. Cut losers, let winners run

Stop Loss Types:
- Fixed % (e.g., -7%)
- Technical (below support)
- Trailing stop
- Time-based
```

## Crypto Analysis

### Major Cryptocurrencies
```
Bitcoin (BTC): Digital gold, store of value
Ethereum (ETH): Smart contracts platform
BNB: Binance ecosystem
Solana (SOL): High-speed blockchain
XRP: Cross-border payments
```

### Crypto Metrics
```
On-chain:
- Active addresses
- Transaction volume
- Exchange inflow/outflow
- Whale movements
- Mining hashrate

Market:
- Market cap
- Dominance %
- Fear & Greed index
- Funding rates (futures)
```

### DeFi & NFTs
```
DeFi Metrics:
- TVL (Total Value Locked)
- APY/APR
- Protocol revenue

NFT Metrics:
- Floor price
- Volume
- Unique holders
```

## Stock Screening Criteria

### Value Investing
```
Criteria:
- P/E < 15
- P/BV < 1.5
- Debt/Equity < 0.5
- Dividend Yield > 3%
- ROE > 12%
- Current Ratio > 1.5
```

### Growth Investing
```
Criteria:
- Revenue Growth > 15% YoY
- EPS Growth > 20% YoY
- ROE > 15%
- Positive earnings
- Strong industry tailwind
```

### Dividend Investing
```
Criteria:
- Dividend Yield > 4%
- Payout Ratio < 70%
- 5+ years dividend history
- Dividend Growth > 5%
- Stable earnings
```

### Momentum Trading
```
Criteria:
- Price > MA50 > MA200
- RSI 50-70
- New 52-week high
- Above average volume
- Sector outperforming
```

## Investment Checklist

### Before Buying
```
□ Understand the business
□ Checked financials (3-5 years)
□ Analyzed competitors
□ Identified risks
□ Determined fair value
□ Set entry price
□ Set stop loss
□ Set profit targets
□ Position size calculated
□ Fits portfolio allocation
```

### Holding Period Review
```
Weekly:
□ Price vs stop loss
□ News/events
□ Sector performance

Quarterly:
□ Earnings review
□ Thesis still valid?
□ Rebalance needed?

Annually:
□ Full re-analysis
□ Tax-loss harvesting
□ Portfolio rebalancing
```

## Disclaimer
```
⚠️ ข้อมูลนี้เป็นเพื่อการศึกษาเท่านั้น
ไม่ใช่คำแนะนำในการลงทุน

- ศึกษาข้อมูลด้วยตัวเอง
- ลงทุนตามความเสี่ยงที่รับได้
- ปรึกษาที่ปรึกษาการเงินที่มีใบอนุญาต
- การลงทุนมีความเสี่ยง ผู้ลงทุนควรศึกษาข้อมูลก่อนตัดสินใจ
```

## File References

- `references/thai-stocks.md` - ข้อมูลหุ้นไทย SET/mai
- `references/us-stocks.md` - ข้อมูลหุ้น US
- `references/technical-patterns.md` - Chart patterns ทั้งหมด
- `references/valuation-models.md` - โมเดลประเมินมูลค่า