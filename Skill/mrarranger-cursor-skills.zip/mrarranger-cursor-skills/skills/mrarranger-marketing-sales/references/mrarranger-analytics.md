# mrarranger-analytics

**Source:** `/mnt/skills/user/mrarranger-analytics/SKILL.md`
**Size:** 9447 bytes

---

---
name: "mrarranger-analytics"
description: "MRARRANGER Analytics & Performance - ระบบวิเคราะห์ Performance และสร้าง Dashboard/Reports รองรับ YouTube Analytics, Social Media Metrics, Content Performance, และ ROI Tracking ใช้เมื่อ: (1) วิเคราะห์ YouTube Analytics (2) ดู Content Performance (3) สร้าง Dashboard (4) Track ROI (5) วิเคราะห์ Audience (6) สร้าง Performance Report Commands: /analytics /dashboard /report /roi /audience /benchmark /kpi"
---
  (4) Track ROI (5) วิเคราะห์ Audience (6) สร้าง Performance Report
  
  Commands: /analytics /dashboard /report /roi /audience /benchmark /kpi
---

# MRARRANGER Analytics & Performance

## Quick Commands

| Command | Output |
|---------|--------|
| `/analytics [platform]` | วิเคราะห์ metrics ของ platform |
| `/dashboard [type]` | สร้าง dashboard template |
| `/report [period]` | สร้าง performance report |
| `/roi [campaign]` | คำนวณ ROI |
| `/audience [platform]` | วิเคราะห์ audience insights |
| `/benchmark [niche]` | เทียบกับ industry benchmark |
| `/kpi [goal]` | ตั้ง KPIs และ tracking |

## Key Metrics by Platform

### YouTube Metrics
| Metric | ความหมาย | Target |
|--------|----------|--------|
| CTR | Click-through rate thumbnail | > 4% |
| AVD | Average view duration | > 50% |
| Watch Time | Total minutes watched | ↑ trend |
| Subs/Video | Subscribers per video | > 1% views |
| RPM | Revenue per 1000 views | Varies |

### Social Media Metrics
| Metric | Formula | Good Score |
|--------|---------|------------|
| Engagement Rate | (Likes+Comments+Shares)/Followers × 100 | > 3% |
| Reach Rate | Reach/Followers × 100 | > 30% |
| Saves Rate | Saves/Reach × 100 | > 2% |
| Share Rate | Shares/Reach × 100 | > 1% |

### Content Metrics
| Metric | วัดอะไร |
|--------|---------|
| Views | Awareness |
| Engagement | Interest |
| Click-through | Consideration |
| Conversion | Action |
| Retention | Loyalty |

## Dashboard Templates

### YouTube Dashboard
```
📊 YOUTUBE PERFORMANCE DASHBOARD
Period: [Date Range]

═══════════════════════════════════════

📈 OVERVIEW
┌─────────────┬─────────────┬─────────────┐
│ Views       │ Watch Time  │ Subscribers │
│ [X]         │ [X] hrs     │ [+X]        │
│ [% vs prev] │ [% vs prev] │ [% vs prev] │
└─────────────┴─────────────┴─────────────┘

🎬 TOP PERFORMING VIDEOS
1. [Title] - [X] views, [X]% CTR, [X]% AVD
2. [Title] - [X] views, [X]% CTR, [X]% AVD
3. [Title] - [X] views, [X]% CTR, [X]% AVD

📊 METRICS BREAKDOWN
• CTR Average: [X]%
• AVD Average: [X]%
• Engagement: [X]%

👥 AUDIENCE
• New: [X]% | Returning: [X]%
• Top Countries: [1], [2], [3]
• Peak Hours: [X], [X]

💡 INSIGHTS
• [Key insight 1]
• [Key insight 2]
• [Action recommendation]
```

### Social Media Dashboard
```
📱 SOCIAL MEDIA DASHBOARD
Period: [Date Range]

═══════════════════════════════════════

📊 OVERVIEW BY PLATFORM
┌────────────┬────────┬────────┬────────┐
│ Platform   │ Reach  │ Engage │ Growth │
├────────────┼────────┼────────┼────────┤
│ Instagram  │ [X]    │ [X]%   │ [+X]   │
│ TikTok     │ [X]    │ [X]%   │ [+X]   │
│ Twitter    │ [X]    │ [X]%   │ [+X]   │
│ LinkedIn   │ [X]    │ [X]%   │ [+X]   │
│ Facebook   │ [X]    │ [X]%   │ [+X]   │
└────────────┴────────┴────────┴────────┘

🔥 TOP CONTENT
1. [Platform] - [Content] - [Metric]
2. [Platform] - [Content] - [Metric]
3. [Platform] - [Content] - [Metric]

📈 TRENDS
• Best performing: [Content type]
• Best time: [Day/Time]
• Best format: [Format]

💡 RECOMMENDATIONS
• [Action 1]
• [Action 2]
```

## Report Templates

### Weekly Report
```
📋 WEEKLY PERFORMANCE REPORT
Week: [Date Range]

═══════════════════════════════════════

📊 EXECUTIVE SUMMARY
[2-3 sentences summary]

📈 KEY METRICS
• Total Reach: [X] ([+/-X]%)
• Total Engagement: [X] ([+/-X]%)
• New Followers: [X] ([+/-X]%)
• Content Published: [X] pieces

🏆 WINS
• [Win 1]
• [Win 2]

⚠️ CHALLENGES
• [Challenge 1]
• [Challenge 2]

📅 NEXT WEEK FOCUS
• [Priority 1]
• [Priority 2]
```

### Monthly Report
```
📋 MONTHLY PERFORMANCE REPORT
Month: [Month Year]

═══════════════════════════════════════

📊 MONTH OVERVIEW

[Summary paragraph]

📈 KEY METRICS COMPARISON
┌────────────────┬──────────┬──────────┬─────────┐
│ Metric         │ This Mo. │ Last Mo. │ Change  │
├────────────────┼──────────┼──────────┼─────────┤
│ Total Views    │ [X]      │ [X]      │ [+/-X]% │
│ Engagement     │ [X]      │ [X]      │ [+/-X]% │
│ Followers      │ [X]      │ [X]      │ [+/-X]% │
│ Revenue        │ ฿[X]     │ ฿[X]     │ [+/-X]% │
└────────────────┴──────────┴──────────┴─────────┘

🎯 GOAL PROGRESS
• Goal 1: [X]% complete
• Goal 2: [X]% complete
• Goal 3: [X]% complete

📊 CONTENT ANALYSIS
• Best format: [X]
• Best topic: [X]
• Best time: [X]

💡 INSIGHTS & LEARNINGS
1. [Insight 1]
2. [Insight 2]
3. [Insight 3]

📅 NEXT MONTH PLAN
1. [Priority 1]
2. [Priority 2]
3. [Priority 3]
```

## ROI Calculation

### Content ROI Formula
```
Content ROI = (Revenue from Content - Cost of Content) / Cost of Content × 100

Revenue Sources:
• Direct: Ads, Sponsorships, Sales
• Indirect: Brand awareness, Leads, Engagement

Cost Components:
• Production: Time, Tools, Talent
• Distribution: Ads, Promotion
• Opportunity: What else could you do?
```

### ROI Calculator Template
```
💰 ROI CALCULATOR

═══════════════════════════════════════

📊 INPUTS
Campaign/Content: [Name]
Period: [Date Range]

💵 REVENUE
• Ad Revenue: ฿[X]
• Sponsorship: ฿[X]
• Product Sales: ฿[X]
• Affiliate: ฿[X]
• Other: ฿[X]
─────────────────
Total Revenue: ฿[X]

💸 COSTS
• Production: ฿[X]
• Ads/Promotion: ฿[X]
• Tools/Software: ฿[X]
• Labor (hrs × rate): ฿[X]
• Other: ฿[X]
─────────────────
Total Costs: ฿[X]

📈 RESULTS
• Net Profit: ฿[X]
• ROI: [X]%
• Break-even: [X] views/sales

💡 INTERPRETATION
[Good/Average/Poor] - [Recommendation]
```

## Benchmark Data

### YouTube Benchmarks (Thai Market)
| Channel Size | CTR | AVD | Eng Rate |
|--------------|-----|-----|----------|
| < 10K | 2-4% | 30-40% | 5-8% |
| 10K-100K | 4-6% | 40-50% | 3-5% |
| 100K-1M | 5-8% | 45-55% | 2-4% |
| > 1M | 6-10% | 50-60% | 1-3% |

### Instagram Benchmarks
| Account Size | Eng Rate | Reach Rate |
|--------------|----------|------------|
| < 10K | 4-8% | 30-40% |
| 10K-50K | 2-5% | 20-30% |
| 50K-500K | 1-3% | 15-25% |
| > 500K | 0.5-2% | 10-20% |

### TikTok Benchmarks
| Account Size | Eng Rate | Views/Follower |
|--------------|----------|----------------|
| < 10K | 8-15% | 20-50% |
| 10K-100K | 5-10% | 15-30% |
| > 100K | 3-8% | 10-20% |

## Reference Files

| File | เมื่อไหร่ต้องอ่าน |
|------|-----------------|
| `references/dashboard-templates.md` | สร้าง dashboard ทุกประเภท |
| `references/kpi-frameworks.md` | ตั้ง KPIs และ tracking system |
| `references/benchmark-data.md` | Industry benchmarks ทุก platform |

## Workflow

```
1. รับ Request → ระบุ Platform + Period + Goal
2. รวบรวม Data → ดึง metrics ที่เกี่ยวข้อง
3. วิเคราะห์ → เทียบกับ benchmark + trends
4. สร้าง Visual → Dashboard/Report format
5. Insights → Key takeaways + recommendations
6. Action Items → สิ่งที่ต้องทำต่อ
```

## Rules

1. **Data-Driven** - ทุกข้อสรุปต้องมีข้อมูลสนับสนุน
2. **Actionable** - ทุก insight ต้องมี recommendation
3. **Comparative** - เทียบกับ benchmark และ previous period
4. **Visual** - ใช้ tables และ charts เพื่อ clarity
5. **Focused** - เน้น metrics ที่ matter ต่อ goal