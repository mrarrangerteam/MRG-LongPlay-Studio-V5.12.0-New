# mrarranger-sales

**Source:** `/mnt/skills/user/mrarranger-sales/SKILL.md`
**Size:** 17159 bytes

---

---
name: "mrarranger-sales"
description: "MRARRANGER Sales & Conversion - ระบบสร้าง Sales Funnel ครบวงจร (Copywriting, Ads, Email Funnel). ใช้เมื่อ (1) เขียน Copy ขาย (2) สร้าง Ad copies (3) วาง Email sequence (4) สร้าง Landing page copy (5) Launch campaign. Commands /copy /headline /fbads /googleads /sequence /funnel /launch"
---

# MRARRANGER Sales & Conversion

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/copy [ประเภท]` | เขียน Copy ขาย | Sales copy ตาม framework |
| `/headline [สินค้า]` | สร้าง Headlines | 10-20 headlines |
| `/hook [หัวข้อ]` | สร้าง Hooks | 10 hooks + variations |
| `/cta [action]` | Call-to-Action | 10 CTAs |
| `/fbads [สินค้า]` | Facebook Ads | Ad set ครบ |
| `/googleads [สินค้า]` | Google Ads | Search + Display |
| `/sequence [จำนวน]` | Email Sequence | X emails พร้อมใช้ |
| `/funnel [สินค้า]` | Sales Funnel | Full funnel map |
| `/launch [campaign]` | Full Campaign | ทุกอย่างครบ |

---

## PART 1: COPYWRITING

### Headline Formulas (ใช้กับ /headline)

```
1. How to [ผลลัพธ์] without [สิ่งที่ไม่ต้องการ]
2. [จำนวน] ways to [ผลลัพธ์] in [เวลา]
3. The secret to [ผลลัพธ์] that [กลุ่มคน] don't want you to know
4. Why [สิ่งที่ทำอยู่] is killing your [สิ่งสำคัญ]
5. [ผลลัพธ์] in [เวลา] — guaranteed
6. Stop [ปัญหา]. Start [ผลลัพธ์].
7. What [กลุ่มคนสำเร็จ] know about [หัวข้อ] that you don't
8. The [จำนวน]-step system to [ผลลัพธ์]
9. [จำนวน] [สิ่งที่ต้องหลีกเลี่ยง] that are costing you [สิ่งสำคัญ]
10. Finally, a [สินค้า] that actually [ผลลัพธ์]
```

### Hook Templates (ใช้กับ /hook)

```
Pattern A - Curiosity:
"สิ่งที่คนส่วนใหญ่ไม่รู้เกี่ยวกับ [หัวข้อ] คือ..."
"ผมเพิ่งค้นพบว่า..."
"นี่คือเหตุผลว่าทำไม [ปัญหา]..."

Pattern B - Pain:
"เบื่อไหมกับ [ปัญหา]?"
"ถ้าคุณกำลัง [ปัญหา] อยู่..."
"ทำไม [สิ่งที่ลูกค้าทำ] ถึงไม่ work?"

Pattern C - Result:
"ลูกค้าของผม [ผลลัพธ์] ใน [เวลา]"
"จาก [ก่อน] สู่ [หลัง] ใน [เวลา]"
"[ผลลัพธ์] โดยไม่ต้อง [สิ่งที่ไม่ต้องการ]"

Pattern D - Social Proof:
"[จำนวน] คนใช้แล้ว..."
"ทำไม [กลุ่มคน] ถึงเลือก..."
"[ชื่อคนดัง/บริษัท] ใช้วิธีนี้..."
```

### Copy Frameworks (ใช้กับ /copy)

**AIDA:**
```
A - Attention: จับความสนใจ (Headline/Hook)
I - Interest: สร้างความสนใจ (ปัญหา/Story)
D - Desire: สร้างความต้องการ (Solution/Benefits)
A - Action: บอกให้ทำ (CTA)
```

**PAS:**
```
P - Problem: ระบุปัญหา
A - Agitate: ขยายปัญหาให้รู้สึก
S - Solution: เสนอทางออก
```

**4Ps:**
```
P - Promise: สัญญาผลลัพธ์
P - Picture: วาดภาพความสำเร็จ
P - Proof: หลักฐาน/Testimonials
P - Push: กระตุ้นให้ action
```

**BAB:**
```
B - Before: สถานการณ์ก่อน
A - After: สถานการณ์หลัง
B - Bridge: สินค้า/บริการคือสะพาน
```

### Sales Page Structure

```
1. HERO SECTION
   - Headline (ผลลัพธ์หลัก)
   - Subheadline (ขยายความ)
   - Hero image/video
   - Primary CTA

2. PROBLEM SECTION
   - Pain points 3-5 ข้อ
   - "ถ้าคุณกำลัง..." list
   - Empathy statement

3. SOLUTION SECTION
   - แนะนำสินค้า/บริการ
   - Key benefits (ไม่ใช่ features)
   - How it works (3 steps)

4. SOCIAL PROOF
   - Testimonials 3-5 ชิ้น
   - Logos/Numbers
   - Case studies

5. OFFER SECTION
   - What you get (รายการทั้งหมด)
   - Bonuses
   - Pricing
   - Guarantee

6. FAQ
   - 5-7 คำถาม
   - Handle objections

7. FINAL CTA
   - Urgency/Scarcity
   - Last push
   - CTA button
```

### CTA Templates (ใช้กับ /cta)

```
Action-Based:
- เริ่มต้นเลย
- สมัครฟรี
- ดาวน์โหลดตอนนี้
- จองที่นั่ง
- รับข้อเสนอ

Benefit-Based:
- เริ่มสร้างรายได้
- รับคู่มือฟรี
- ปลดล็อคศักยภาพ
- เปลี่ยนชีวิตวันนี้

Urgency-Based:
- รับส่วนลด 50% วันนี้
- เหลืออีก X ที่
- ข้อเสนอหมดใน 24 ชม.
- สมัครก่อนราคาขึ้น
```

---

## PART 2: ADS

### Facebook Ads (ใช้กับ /fbads)

**Ad Structure:**
```
┌─────────────────────────────────┐
│ PRIMARY TEXT (125 ตัวอักษร)     │
│ - Hook แรก                      │
│ - Pain/Promise                  │
│ - CTA                           │
├─────────────────────────────────┤
│ [IMAGE/VIDEO]                   │
│ 1:1 หรือ 4:5                    │
├─────────────────────────────────┤
│ HEADLINE (40 ตัวอักษร)          │
│ DESCRIPTION (30 ตัวอักษร)       │
│ [CTA BUTTON]                    │
└─────────────────────────────────┘
```

**Ad Types:**

```
1. AWARENESS ADS
   - Educational content
   - Brand story
   - Problem awareness
   Goal: Reach/Video views

2. CONSIDERATION ADS
   - Lead magnet
   - Free trial
   - Webinar signup
   Goal: Leads/Traffic

3. CONVERSION ADS
   - Direct offer
   - Limited time
   - Testimonial ads
   Goal: Sales/Signups

4. RETARGETING ADS
   - Cart abandonment
   - Viewed but didn't buy
   - Past customers
   Goal: Recovery/Upsell
```

**Audience Targeting:**
```
Layer 1 - Demographics:
- Age range
- Gender
- Location
- Language

Layer 2 - Interests:
- Related pages
- Competitors
- Related topics

Layer 3 - Behaviors:
- Purchase behavior
- Device usage
- Travel habits

Layer 4 - Custom:
- Website visitors
- Email list
- Lookalikes
```

### Google Ads (ใช้กับ /googleads)

**Search Ad Structure:**
```
Headlines (3): แต่ละอัน 30 ตัวอักษร
- H1: Keyword + Benefit
- H2: Offer/USP
- H3: CTA + Urgency

Descriptions (2): แต่ละอัน 90 ตัวอักษร
- D1: ขยาย benefit + social proof
- D2: Features + CTA

Extensions:
- Sitelinks (4-6)
- Callouts (4-6)
- Structured snippets
```

**Keyword Match Types:**
```
[exact match] - ตรงเป๊ะ
"phrase match" - มีคำนี้
broad match - กว้าง
-negative - ไม่เอา
```

**Ad Copy Templates:**

```
Template A - Direct:
H1: [Keyword] - [ผลลัพธ์หลัก]
H2: [Offer] | [Social Proof]
H3: [CTA] - [Urgency]
D1: [ขยาย benefit]. [Testimonial/Number]. [Trust signal].
D2: [Features]. [Guarantee]. [CTA].

Template B - Question:
H1: ต้องการ [ผลลัพธ์]?
H2: [Solution] ที่ได้ผลจริง
H3: เริ่มต้นวันนี้ - [Offer]
D1: หยุด [ปัญหา]. [Solution] ช่วยให้คุณ [benefit]. ลูกค้า X+ คนไว้ใจ.
D2: ✓ [Feature 1] ✓ [Feature 2] ✓ [Feature 3]. [CTA].
```

### Ad Creative Guidelines

```
IMAGE:
- ใบหน้าคน = engagement สูง
- Before/After = conversion สูง
- Product in use = trust สูง
- Text < 20% ของภาพ

VIDEO:
- Hook ใน 3 วินาทีแรก
- แนว vertical (9:16) สำหรับ mobile
- Captions เสมอ
- CTA ที่ 15s และ end

CAROUSEL:
- Slide 1: Hook
- Slide 2-4: Benefits/Features
- Slide 5: Offer + CTA
```

---

## PART 3: EMAIL FUNNEL

### Email Sequence Templates (ใช้กับ /sequence)

**Welcome Sequence (5 emails):**
```
Email 1 (ทันที): Welcome + Deliver promise
- ขอบคุณ
- ส่ง lead magnet
- Set expectation
- Quick win

Email 2 (Day 2): Value + Story
- เล่า story ของคุณ
- ทำไมทำสิ่งนี้
- Connect กับ pain point

Email 3 (Day 4): Education
- สอนอะไรบางอย่าง
- Quick tip ใช้ได้เลย
- Build authority

Email 4 (Day 6): Social Proof
- Case study
- Testimonials
- Results

Email 5 (Day 7): Soft Pitch
- แนะนำ offer
- Special discount
- CTA
```

**Launch Sequence (7 emails):**
```
Email 1 (Day -3): Announcement
- Coming soon
- What to expect
- Build anticipation

Email 2 (Day -1): Reminder
- Tomorrow is the day
- Why you made this
- Early bird hint

Email 3 (Day 0): LAUNCH
- Doors open
- Full offer details
- Early bird bonus

Email 4 (Day 1): FAQ
- Common questions
- Overcome objections
- Testimonial

Email 5 (Day 3): Case Study
- Success story
- Results breakdown
- Social proof

Email 6 (Day 5): Last Chance
- Bonus หมดเร็วๆ นี้
- Urgency
- Reminder of value

Email 7 (Day 7): Final Call
- ปิดขาย
- Last testimonial
- Strong CTA
```

**Abandoned Cart Sequence (3 emails):**
```
Email 1 (1 ชม.): 
Subject: ลืมอะไรไว้หรือเปล่า?
- รายการที่ค้างอยู่
- Link กลับไป

Email 2 (24 ชม.):
Subject: ยังว่างอยู่นะ
- เพิ่ม social proof
- ตอบ objection
- เพิ่ม bonus เล็กๆ

Email 3 (72 ชม.):
Subject: สุดท้ายแล้ว + [Offer]
- ส่วนลดพิเศษ
- Urgency
- Final CTA
```

### Email Subject Lines

```
Curiosity:
- "เรื่องนี้เปลี่ยนทุกอย่าง..."
- "ผมทำผิดมาตลอด"
- "อย่าเปิดถ้ายังไม่พร้อม"

Benefit:
- "[ผลลัพธ์] ใน [เวลา]"
- "วิธีที่ดีที่สุดในการ [goal]"
- "ได้ผล 100%: [topic]"

Urgency:
- "เหลืออีก 24 ชม."
- "สุดท้ายแล้ว"
- "หมดเขตคืนนี้"

Personal:
- "คำถามด่วน"
- "คิดถึงคุณอยู่"
- "[ชื่อ], มีอะไรให้"

Numbers:
- "3 ขั้นตอนสู่ [goal]"
- "97% ของคนไม่รู้เรื่องนี้"
- "[ผลลัพธ์] ใน 7 วัน"
```

### Email Body Template

```
Subject: [Hook]
Preview: [ขยาย hook]

---

[Greeting],

[Hook - 1 ประโยคจับใจ]

[Story/Context - 2-3 ประโยค]

[Value/Insight - เนื้อหาหลัก]

[Bridge to CTA]

[CTA Button]

[P.S. - เพิ่ม urgency หรือ bonus]

[Signature]
```

---

## PART 4: FULL FUNNEL

### Funnel Map (ใช้กับ /funnel)

```
┌─────────────────────────────────────────────────────┐
│                    AWARENESS                         │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │ FB Ads  │  │ Content │  │ SEO     │             │
│  └────┬────┘  └────┬────┘  └────┬────┘             │
│       └────────────┼────────────┘                   │
│                    ↓                                │
├─────────────────────────────────────────────────────┤
│                  INTEREST                           │
│            ┌─────────────┐                          │
│            │ Landing Page│                          │
│            │ (Lead Magnet)│                         │
│            └──────┬──────┘                          │
│                   ↓                                 │
├─────────────────────────────────────────────────────┤
│                 CONSIDERATION                       │
│            ┌─────────────┐                          │
│            │   Email     │                          │
│            │  Sequence   │                          │
│            └──────┬──────┘                          │
│                   ↓                                 │
├─────────────────────────────────────────────────────┤
│                  DECISION                           │
│            ┌─────────────┐                          │
│            │ Sales Page  │                          │
│            │ /Webinar    │                          │
│            └──────┬──────┘                          │
│                   ↓                                 │
├─────────────────────────────────────────────────────┤
│                   ACTION                            │
│            ┌─────────────┐                          │
│            │  Checkout   │                          │
│            └──────┬──────┘                          │
│                   ↓                                 │
├─────────────────────────────────────────────────────┤
│                 RETENTION                           │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │ Onboard │  │ Upsell  │  │ Referral│             │
│  └─────────┘  └─────────┘  └─────────┘             │
└─────────────────────────────────────────────────────┘
```

### Launch Command (ใช้กับ /launch)

```
/launch [ชื่อ campaign]

Output ทั้งหมด:
├── 📢 Ad Copies
│   ├── Facebook Ads (3 versions)
│   ├── Google Ads (3 versions)
│   └── Retargeting Ads (2 versions)
│
├── 📝 Landing Page Copy
│   ├── Headline options (5)
│   ├── Full page copy
│   └── Thank you page
│
├── 📧 Email Sequences
│   ├── Welcome (5 emails)
│   ├── Launch (7 emails)
│   └── Abandoned cart (3 emails)
│
├── 🎯 Funnel Map
│   └── Visual diagram
│
└── 📊 Tracking Setup
    ├── KPIs to track
    └── Conversion goals
```

---

## Chain Integration

```
mrarranger-research (/competitor)
        ↓
mrarranger-sales (/funnel → /copy → /fbads → /sequence)
        ↓
mrarranger-automation (/track)
        ↓
mrarranger-content (/blog - สำหรับ nurture)
        ↓
mrarranger-social (/convert - amplify reach)
```

## Output Formats

| Content | Format | Ready to |
|---------|--------|----------|
| Ad Copy | Text + Image specs | Copy/Paste to Ads Manager |
| Email | HTML + Plain text | Import to ESP |
| Landing | Copy + Structure | Give to dev/builder |
| Funnel | Diagram + Copy | Implement |