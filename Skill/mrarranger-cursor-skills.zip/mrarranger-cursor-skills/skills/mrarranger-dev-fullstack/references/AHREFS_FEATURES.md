# AHREFS Complete Feature Guide

## Overview
Ahrefs เป็นเครื่องมือ SEO ระดับ Enterprise ที่เน้น Backlink Analysis และ Competitive Intelligence

**Database Stats:**
- 28.7B+ Keywords
- 12T+ Historical Backlinks
- 110B+ Keyword Database
- 170+ Countries Supported

## Core Tools

### 1. Site Explorer
วิเคราะห์ website แบบครบวงจร

**Metrics:**
- **Domain Rating (DR)**: 0-100, วัดความแข็งแกร่งของ backlink profile
- **URL Rating (UR)**: 0-100, วัดความแข็งแกร่งของ URL เฉพาะ
- **Organic Traffic**: ประมาณการ traffic จาก organic search
- **Organic Keywords**: จำนวน keywords ที่ rank อยู่
- **Referring Domains**: จำนวน domains ที่ link มา

**Features:**
```yaml
Overview:
  - Traffic trend graph
  - Top organic keywords
  - Top pages by traffic
  - Referring domains growth

Organic Search:
  - Organic keywords (full list)
  - Organic competitors
  - SERP features
  - Content gap analysis

Backlink Profile:
  - All backlinks
  - New/Lost backlinks
  - Broken backlinks
  - Anchors distribution
  - Referring domains
  - Referring IPs
```

### 2. Keywords Explorer
วิจัย keywords ข้าม 9 search engines

**Supported Engines:**
- Google
- YouTube
- Amazon
- Bing
- Yahoo
- Yandex
- Baidu
- Naver
- Daum

**Metrics:**
```yaml
Keyword Difficulty (KD): 0-100
  - 0-10: Easy
  - 11-30: Medium
  - 31-70: Hard
  - 71-100: Super Hard

Search Volume:
  - Global volume
  - Country-specific volume
  - Monthly trend

Clicks:
  - Estimated clicks
  - Clicks per search
  - % of clicks going to organic

Traffic Potential:
  - Total traffic from ranking #1
  - Including related keywords

Parent Topic:
  - Main topic cluster
  - Related subtopics
```

**Keyword Ideas:**
- Phrase match
- Having same terms
- Also rank for
- Search suggestions
- Newly discovered
- Questions

### 3. Content Explorer
ค้นหา content ที่ perform ดีที่สุด

**Search By:**
- Title
- Content
- URL

**Filters:**
```yaml
Traffic Filters:
  - Organic traffic range
  - Traffic value

Backlink Filters:
  - Referring domains
  - Dofollow links

Social Filters:
  - Twitter shares
  - Pinterest shares
  - Facebook shares

Content Filters:
  - Word count
  - Published date
  - Language
  - One article per domain
```

**Use Cases:**
1. หา content ideas ที่ได้ backlinks เยอะ
2. หา guest post opportunities
3. วิเคราะห์ competitor content strategy
4. ติดตาม brand mentions

### 4. Site Audit
ตรวจสอบ Technical SEO Issues

**Crawl Settings:**
- 5,000 credits/month (Free tier)
- Customizable crawl speed
- JavaScript rendering
- Mobile/Desktop user-agent

**170+ Issues Detected:**
```yaml
Critical Issues:
  - 4xx errors
  - 5xx errors
  - Redirect chains
  - Redirect loops

Warnings:
  - Missing H1
  - Duplicate title tags
  - Duplicate meta descriptions
  - Missing alt text

Notices:
  - Low word count
  - Orphan pages
  - Non-descriptive URLs
```

**Reports:**
- All issues overview
- Internal pages
- External pages
- Resources (JS, CSS, images)
- Incoming links
- Outgoing links

### 5. Rank Tracker
ติดตาม keyword rankings

**Features:**
- 170+ countries
- Desktop & Mobile tracking
- SERP features tracking
- Competitor comparison
- Scheduled reports
- Historical data

**Tracked Data:**
```yaml
Position:
  - Current position
  - Position change
  - Best position ever
  - SERP features owned

Traffic:
  - Estimated traffic
  - Traffic potential
  - Share of voice

Visibility:
  - % of total visibility
  - Visibility trend
```

## Advanced Features

### AI Content Helper
- Content scoring (173 languages)
- Topic generation
- Optimization suggestions
- Readability analysis

### Batch Analysis
- Analyze multiple URLs/domains
- Export to CSV/PDF
- API integration

### Alerts
```yaml
New Backlinks:
  - Daily/Weekly alerts
  - Filter by DR

Lost Backlinks:
  - Notification when links removed
  
New Keywords:
  - Alert when ranking for new keywords
  
Mentions:
  - Brand mention alerts
  - Unlinked mentions
```

## API Access

**Endpoints (100+):**
```yaml
Site Explorer:
  - /site-explorer/overview
  - /site-explorer/backlinks
  - /site-explorer/organic-keywords

Keywords Explorer:
  - /keywords-explorer/overview
  - /keywords-explorer/keyword-ideas

Rank Tracker:
  - /rank-tracker/overview
  - /rank-tracker/positions

Site Audit:
  - /site-audit/projects
  - /site-audit/issues
```

## Pricing

| Plan | Price | Projects | Keywords |
|------|-------|----------|----------|
| Free | $0 | Verified sites | Limited |
| Lite | $99/mo | 5 | 750 |
| Standard | $249/mo | 20 | 2,000 |
| Advanced | $449/mo | 50 | 5,000 |

## Best Practices

### For Backlink Analysis
1. ใช้ "Best by links" เพื่อหา linkable content
2. ดู "Referring domains" trend
3. Check anchor text distribution
4. Monitor competitor new backlinks

### For Keyword Research
1. เริ่มจาก seed keyword
2. ใช้ "Parent topic" เพื่อหา main topic
3. Check "Traffic potential" ไม่ใช่แค่ volume
4. ดู SERP เพื่อเข้าใจ search intent

### For Content Gap
1. ใส่ 3-5 competitors
2. Filter by position 1-10
3. Export และ prioritize by volume
4. สร้าง content calendar

## Commands Reference

```yaml
/ahrefs-site [domain]:
  Output: DR, UR, Traffic, Backlinks, Top Pages
  
/ahrefs-backlinks [url]:
  Output: Backlink list, Anchor text, Follow/Nofollow
  
/ahrefs-keywords [topic]:
  Output: KD, Volume, CPC, SERP analysis
  
/ahrefs-gap [domains]:
  Output: Missing keywords, Opportunities
  
/ahrefs-content [topic]:
  Output: Top performing content, Backlinks, Shares
  
/ahrefs-audit [domain]:
  Output: Health score, Issues list, Recommendations
  
/ahrefs-compete [domain]:
  Output: Competitor analysis, Traffic share, Keywords
```
