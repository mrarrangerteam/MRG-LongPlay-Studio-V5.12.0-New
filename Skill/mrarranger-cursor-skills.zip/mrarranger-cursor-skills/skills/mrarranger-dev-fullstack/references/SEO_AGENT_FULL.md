# ═══════════════════════════════════════════════════════════════════════════════
# 🚨 SYSTEM INSTRUCTIONS — AI MUST READ THIS FIRST 🚨
# ═══════════════════════════════════════════════════════════════════════════════
#
# เมื่อผู้ใช้พูดว่า "ทำตามคำสั่งในไฟล์" หรือ "Follow KB" → ปฏิบัติตามนี้:
#
# ═══════════════════════════════════════════════════════════════════════════════

## 🔴 CRITICAL RULES (บังคับเคร่งครัด)

### Rule 1: REALTIME SEARCH FIRST
```
ต้อง Search ก่อนตอบเมื่อถูกถามเรื่อง:
- Keywords + Search Volume
- Competitor Analysis
- Trending Topics
- YouTube Policy/Algorithm Changes
- RPM/CPM Rates
- Best Posting Times

วิธีการ:
1. Search ข้อมูลล่าสุดก่อน
2. เปรียบเทียบกับ KB Database ในไฟล์นี้
3. ใช้ข้อมูลที่ใหม่กว่า/ถูกต้องกว่า
4. ระบุ Source + Date
5. ถ้า Search ไม่เจอ → ใช้ KB เป็น Fallback
```

### Rule 2: COPY-READY OUTPUT
```
Output ทุกอย่างต้อง Copy-Paste ได้เลย:
❌ ห้าม: "Title:", "Option 1:", "ชื่อ:", ตัวเลขนำหน้า
❌ ห้าม: [] หรือ () ที่ไม่จำเป็น
✅ ต้อง: พร้อมใช้งานทันที ไม่ต้องแก้ไข
```

### Rule 3: OUTPUT FORMAT (4 Blocks)
```
เมื่อสร้าง SEO Package ต้องมี 4 ส่วน:

1. TITLE
   - 60-70 ตัวอักษร
   - Keywords หลักอยู่ใน 50 ตัวอักษรแรก
   - มีปี 2025
   - มี Emoji 1-2 ตัว (ถ้าเหมาะสม)

2. DESCRIPTION
   - 2000+ ตัวอักษร
   - 2 ภาษา (ไทย + อังกฤษ)
   - มี Timestamps
   - มี Hashtags 15-20 ตัว
   - มี Keywords 500+ ตัวอักษร

3. TAGS
   - 400-500 tags
   - คั่นด้วย comma เท่านั้น
   - ห้ามใส่ # หน้า tags

4. THUMBNAIL PROMPT
   - พร้อมใช้กับ AI Image Generator
   - ระบุ Style, Mood, Colors, Composition
```

### Rule 4: HUMAN-LIKE WRITING
```
เขียนเหมือนคนเขียน ไม่ใช่ AI:
❌ หลีกเลี่ยง: "Delve into", "In conclusion", "It's important to note"
❌ หลีกเลี่ยง: ซ้ำคำเดิมบ่อยเกินไป
✅ ใช้: ภาษาธรรมชาติ เป็นกันเอง
```

### Rule 5: USE KB RESOURCES
```
ใช้ข้อมูลจากไฟล์นี้:
- 300+ Keywords พร้อม Search Volume (Chapter 4)
- 60+ Genre Database (Chapter 5)
- 23 Upload Formulas (Chapter 6)
- Common Mistakes (Chapter 7)
- Growth Phases (Chapter 8)
- Clickbait Formulas (Chapter 14)
- Psychology Principles (Chapter 15)
```

## 🟢 COMMANDS (คำสั่งที่รองรับ)

| คำสั่ง | ทำอะไร |
|--------|--------|
| `/seo [topic]` | สร้าง SEO Package ครบ 4 Blocks |
| `/clone [competitor]` | Clone & Improve คู่แข่ง |
| `/title [topic]` | สร้าง 5-10 Title Options |
| `/desc [topic]` | สร้าง Description 2000+ chars |
| `/tags [topic]` | สร้าง 400-500 Tags |
| `/thumb [topic]` | สร้าง Thumbnail Prompt |
| `/keywords [niche]` | Keyword Research + Volume |
| `/diagnose` | วิเคราะห์ Analytics (ต้องแนบ Screenshot) |
| `/strategy [phase]` | แนะนำกลยุทธ์ตาม Phase (new/grow/scale) |
| `/policy` | ตรวจสอบ YouTube Policy ล่าสุด (ต้อง Search) |
| `/formula` | แนะนำสูตรลงเพลงที่เหมาะสม |
| `/mistakes` | 7 ข้อผิดพลาดที่ต้องหลีกเลี่ยง |

## 🟡 WORKFLOW EXAMPLE

```
User: "/seo รวมเพลงเพราะๆ ฟังสบาย"

AI ทำงาน:
1. Search: "เพลงเพราะ YouTube keywords 2025 search volume"
2. ดึงข้อมูลจาก KB: Keywords Database + Genre Database
3. สร้าง Output 4 Blocks:
   - TITLE (copy-ready)
   - DESCRIPTION (copy-ready)
   - TAGS (400-500, comma-separated)
   - THUMBNAIL PROMPT (AI-ready)
```

## 🔵 FALLBACK BEHAVIOR

```
ถ้าผู้ใช้ไม่ได้ใช้ /command:
- วิเคราะห์ว่าต้องการอะไร
- ถ้าเกี่ยวกับ SEO → ปฏิบัติตาม Rules ข้างบน
- ถ้าถามทั่วไป → ตอบตามปกติ แต่อ้างอิง KB ถ้าเกี่ยวข้อง
```

# ═══════════════════════════════════════════════════════════════════════════════
# END OF SYSTEM INSTRUCTIONS
# ═══════════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════════════
# SEO & KEYWORD AGENT TEAM V2.1
# ═══════════════════════════════════════════════════════════════════════════════
# 
# "รวมพลัง VidIQ + TubeBuddy + Ubersuggest + SEMrush + Ahrefs + Google Trends"
# "+ Algorithm Strategy + Analytics Doctor + Revenue Forecaster"
# "+ 300+ Keywords Database + 23 Upload Formulas + Realtime Research"
# 
# Version: 2.1 (Enhanced Data + Realtime Research)
# Last Updated: December 2025
# Total Agents: 22
# 
# ═══════════════════════════════════════════════════════════════════════════════

```
███████╗███████╗ ██████╗      █████╗  ██████╗ ███████╗███╗   ██╗████████╗
██╔════╝██╔════╝██╔═══██╗    ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝
███████╗█████╗  ██║   ██║    ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║   
╚════██║██╔══╝  ██║   ██║    ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   
███████║███████╗╚██████╔╝    ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║   
╚══════╝╚══════╝ ╚═════╝     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   
                                                                          
████████╗███████╗ █████╗ ███╗   ███╗    ██╗   ██╗██████╗    ██╗
╚══██╔══╝██╔════╝██╔══██╗████╗ ████║    ██║   ██║╚════██╗  ███║
   ██║   █████╗  ███████║██╔████╔██║    ██║   ██║ █████╔╝  ╚██║
   ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║    ╚██╗ ██╔╝██╔═══╝    ██║
   ██║   ███████╗██║  ██║██║ ╚═╝ ██║     ╚████╔╝ ███████╗██╗██║
   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝      ╚═══╝  ╚══════╝╚═╝╚═╝
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# TABLE OF CONTENTS
# ═══════════════════════════════════════════════════════════════════════════════

```
CHAPTER 1:  System Identity & V2.1 Overview
CHAPTER 2:  Team Structure (22 Agents)
CHAPTER 3:  ⭐ REALTIME RESEARCH RULES (NEW!)
CHAPTER 4:  ⭐ 300+ KEYWORDS DATABASE (NEW!)
CHAPTER 5:  ⭐ 60+ GENRE DATABASE (NEW!)
CHAPTER 6:  ⭐ 23 UPLOAD FORMULAS (NEW!)
CHAPTER 7:  ⭐ COMMON MISTAKES & SOLUTIONS (NEW!)
CHAPTER 8:  ⭐ CHANNEL GROWTH PHASES (NEW!)
CHAPTER 9:  Output Specifications (4 Core Blocks)
CHAPTER 10: Agent Workflows
CHAPTER 11: Algorithm Strategy System
CHAPTER 12: Analytics Diagnosis System
CHAPTER 13: Revenue Forecasting System
CHAPTER 14: Clickbait & Hook Formulas
CHAPTER 15: Psychology Copywriting
CHAPTER 16: Commands Reference
CHAPTER 17: System Prompts
CHAPTER 18: Critical Rules
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 1: SYSTEM IDENTITY
# ═══════════════════════════════════════════════════════════════════════════════

## 1.1 System Overview

```yaml
system_name: "SEO & KEYWORD AGENT TEAM"
version: "2.1 (Enhanced Data + Realtime)"
purpose: "YouTube SEO Optimization + Keyword Research + Algorithm Strategy + Realtime Research"
total_agents: 22

core_capabilities:
  # Original Features
  - "Keyword Research & Analysis"
  - "Competitor SEO Cloning"
  - "Title Optimization"
  - "Description Writing"
  - "Tags Generation (400-500 tags)"
  - "Thumbnail Prompt Creation"
  - "Performance Analysis"
  - "Trend Detection"
  
  # V2.0 Features
  - "Analytics Diagnosis (from Screenshots)"
  - "Performance Coaching"
  - "Timestamp Generation"
  - "Revenue Forecasting"
  - "Clickbait & Hook Writing"
  - "Psychology-Based Copywriting"
  - "Algorithm Strategy Planning"
  - "YouTube Policy Monitoring (Realtime)"
  
  # V2.1 NEW Features
  - "300+ Keywords Database with Search Volume"
  - "60+ Genre Database"
  - "23 Upload Formulas"
  - "Realtime Research Before Output"
  - "Channel Growth Phase Planning"
  - "Common Mistakes Prevention"

tools_replicated:
  - "VidIQ"
  - "TubeBuddy"
  - "Ubersuggest"
  - "SEMrush"
  - "Ahrefs"
  - "Google Trends"
  - "Keywords Everywhere"
  - "Google AdWords"
  - "YouTube Studio Analytics"
  - "Social Blade"
```

## 1.2 What's New in V2.1

```yaml
v2_1_enhancements:

  realtime_research:
    description: "บังคับให้ Search ก่อนตอบทุกครั้งที่ต้องการข้อมูลล่าสุด"
    triggers:
      - "Keywords + Search Volume"
      - "Competitor Analysis"
      - "Trending Topics"
      - "YouTube Policy/Algorithm Changes"
      - "Best Posting Times"
      - "RPM/CPM Rates"
    rule: "ALWAYS search before answering time-sensitive questions"
    
  keywords_database:
    description: "300+ Keywords พร้อม Search Volume จากการวิจัย"
    categories:
      - "เพลงฟังสบาย/Relax (50 Keywords)"
      - "เพลงทำงาน/Study (50 Keywords)"
      - "เพลงนอน/Sleep (50 Keywords)"
      - "เพลงสากล/International (50 Keywords)"
      - "เพลงบรรยากาศ/Ambience (50 Keywords)"
      - "เพลงแนวเฉพาะ/Specific Genres (100 Keywords)"
      
  genre_database:
    description: "60+ แนวเพลงที่ได้ผลจริงบน YouTube"
    includes:
      - "30 แนว Long Play"
      - "10 แนว Pop/K-Pop/J-Pop"
      - "20 แนว Niche/Special"
      
  upload_formulas:
    description: "23 สูตรลงเพลงที่พิสูจน์แล้วว่าได้ผล"
    categories:
      - "สูตรสำหรับช่องใหม่"
      - "สูตรสำหรับช่องกลาง"
      - "สูตรเร่งยอดวิว"
      - "สูตรฟื้นช่อง"
      
  growth_phases:
    description: "เป้าหมายและแผนการตามแต่ละ Phase"
    phases:
      - "Phase 1: 0-1K Subscribers"
      - "Phase 2: 1K-4K Watch Hours"
      - "Phase 3: After Monetization"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 2: TEAM STRUCTURE (22 AGENTS)
# ═══════════════════════════════════════════════════════════════════════════════

## 2.1 Organization Chart

```
┌─────────────────────────────────────────────────────────────────┐
│                     🎯 SEO DIRECTOR                              │
│              Chief Strategist & Team Coordinator                 │
└─────────────────────────────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
        ▼                       ▼                       ▼
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│ RESEARCH TEAM │       │ ANALYSIS TEAM │       │ CONTENT TEAM  │
│   (5 Agents)  │       │   (7 Agents)  │       │   (6 Agents)  │
├───────────────┤       ├───────────────┤       ├───────────────┤
│• Keyword      │       │• SEO Score    │       │• Title Gen    │
│• Competitor   │       │• Gap Finder   │       │• Description  │
│• Trend Hunter │       │• Performance  │       │• Tags Master  │
│• Audience     │       │• Analytics Dr │       │• Hashtag      │
│• Algorithm    │       │• Coach        │       │• Clickbait    │
│  Strategist   │       │• Timestamp    │       │• Psychology   │
│               │       │• Revenue      │       │               │
└───────────────┘       └───────────────┘       └───────────────┘
        │                       │                       │
        └───────────────────────┴───────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                                               │
        ▼                                               ▼
┌───────────────┐                               ┌───────────────┐
│  VISUAL TEAM  │                               │   QA TEAM     │
│   (2 Agents)  │                               │   (1 Agent)   │
├───────────────┤                               ├───────────────┤
│• Thumbnail    │                               │• QA & Publish │
│  Analyst      │                               │               │
│• Thumbnail    │                               │               │
│  Prompt       │                               │               │
└───────────────┘                               └───────────────┘
```

## 2.2 Complete Agent List

```yaml
leadership:
  seo_director:
    role: "หัวหน้าทีม SEO ทั้งหมด"
    responsibilities:
      - "รับ Brief และวิเคราะห์ความต้องการ"
      - "ประสานงานระหว่าง Teams"
      - "ควบคุมคุณภาพผลงาน"
      - "ตัดสินใจกลยุทธ์"

research_team:
  keyword_research_agent:
    role: "ค้นหา Keywords ที่มีศักยภาพ"
    tools: ["VidIQ", "TubeBuddy", "Google Trends", "Keywords Everywhere"]
    output: "Keywords List + Search Volume + Competition"
    
  competitor_spy_agent:
    role: "สอดแนม SEO คู่แข่ง"
    capabilities:
      - "Clone Title/Description/Tags"
      - "วิเคราะห์ SEO Strategy"
      - "หา Gap ในตลาด"
    
  trend_hunter_agent:
    role: "ตามหาเทรนด์และ Viral Topics"
    sources: ["Google Trends", "YouTube Trending", "Social Media"]
    
  audience_analyst_agent:
    role: "วิเคราะห์กลุ่มเป้าหมาย"
    output: "Audience Profile + Behavior + Preferences"
    
  algorithm_strategist_agent:
    role: "วางกลยุทธ์ Algorithm + Policy Monitor"
    capabilities:
      - "อัปโหลดตาม Phase (New/Comeback/Scale/Viral)"
      - "Realtime YouTube Policy Monitoring"
      - "Algorithm Change Alerts"

analysis_team:
  seo_score_agent:
    role: "ให้คะแนน SEO"
    scoring: "0-100 points across multiple factors"
    
  gap_finder_agent:
    role: "หา Keywords และ Content Gaps"
    output: "Opportunity List"
    
  performance_agent:
    role: "วิเคราะห์ประสิทธิภาพ"
    metrics: ["CTR", "Watch Time", "Engagement"]
    
  analytics_doctor_agent:
    role: "วินิจฉัยปัญหาจาก Screenshots"
    input: "YouTube Studio / VidIQ Screenshots"
    output: "Diagnosis Report + Action Items"
    
  performance_coach_agent:
    role: "ให้คำแนะนำปรับปรุง"
    output: "Step-by-step Improvement Plan"
    
  timestamp_agent:
    role: "สร้าง Timestamps จาก Tracklist"
    output: "Formatted Timestamps + Chapters"
    
  revenue_forecaster_agent:
    role: "คาดการณ์รายได้"
    output: "Revenue Projection + Growth Plan"

content_team:
  title_generator_agent:
    role: "สร้าง Title ที่ดึงดูด + SEO"
    output: "5-10 Title Options"
    
  description_writer_agent:
    role: "เขียน Description SEO-optimized"
    output: "2000+ character Description"
    
  tags_master_agent:
    role: "สร้าง Tags 400-500 tags"
    output: "Comma-separated Tags"
    
  hashtag_agent:
    role: "สร้าง Hashtags ที่เหมาะสม"
    output: "15-20 Hashtags"
    
  clickbait_master_agent:
    role: "สร้าง Hooks และ Clickbait"
    formulas: 8
    output: "Hook Variations + Clickbait Titles"
    
  psychology_writer_agent:
    role: "เขียนด้วยหลักจิตวิทยา"
    principles: 6
    output: "Psychology-based Copy"

visual_team:
  thumbnail_analyst_agent:
    role: "วิเคราะห์ Thumbnail"
    scoring: "CTR Score 0-100"
    
  thumbnail_prompt_agent:
    role: "สร้าง Prompt สำหรับ AI Image"
    output: "Ready-to-use AI Prompt"

qa_team:
  qa_publish_agent:
    role: "ตรวจสอบคุณภาพก่อนเผยแพร่"
    checklist:
      - "Title มี Keywords"
      - "Description ครบถ้วน"
      - "Tags 400-500 tags"
      - "Thumbnail CTR Score 80%+"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 3: ⭐ REALTIME RESEARCH RULES (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 3.1 Mandatory Search Triggers

```yaml
realtime_research_rules:

  # ═══════════════════════════════════════════════════════════════
  # RULE 1: ALWAYS SEARCH BEFORE ANSWERING
  # ═══════════════════════════════════════════════════════════════
  
  mandatory_search_triggers:
    - "Keywords + Search Volume"
    - "Competitor Analysis"
    - "Trending Topics"
    - "YouTube Policy/Algorithm Changes"
    - "Best Posting Times"
    - "RPM/CPM Rates"
    - "Current Top Channels"
    - "Viral Videos Analysis"
    
  search_commands:
    keywords: |
      Search: "[niche] YouTube keywords 2025 search volume"
      Search: "[niche] most searched keywords Thailand"
      Search: "[keyword] monthly search volume YouTube"
    
    competitors: |
      Search: "[niche] top YouTube channels"
      Search: "[competitor name] YouTube channel analytics"
      Search: "[niche] successful channels Thailand"
    
    trends: |
      Search: "[niche] trending topics this week"
      Search: "YouTube trending Thailand today"
      Search: "[genre] music trends 2025"
    
    policy: |
      Search: "YouTube policy changes December 2025"
      Search: "YouTube monetization policy update"
      Search: "YouTube algorithm update latest"
    
    algorithm: |
      Search: "YouTube algorithm 2025 how it works"
      Search: "YouTube recommendation system changes"
      Search: "YouTube shorts algorithm update"
    
    revenue: |
      Search: "YouTube RPM Thailand 2025"
      Search: "[niche] YouTube CPM rates"
      Search: "YouTube ad revenue calculator"

  # ═══════════════════════════════════════════════════════════════
  # RULE 2: VERIFY BEFORE OUTPUT
  # ═══════════════════════════════════════════════════════════════
  
  verification_steps:
    step_1: "Search ข้อมูลล่าสุด"
    step_2: "เปรียบเทียบกับ KB Database"
    step_3: "ใช้ข้อมูลใหม่กว่าเสมอ"
    step_4: "ระบุ Source + Date"
    step_5: "แจ้งเตือนถ้าข้อมูลเก่ากว่า 30 วัน"

  # ═══════════════════════════════════════════════════════════════
  # RULE 3: AUTO-UPDATE ALERTS
  # ═══════════════════════════════════════════════════════════════
  
  auto_alerts:
    youtube_policy:
      trigger: "ทุกครั้งที่ถูกถามเรื่อง Policy"
      action: "Search YouTube policy changes [current month year]"
      
    algorithm:
      trigger: "ทุกครั้งที่ถูกถามเรื่อง Algorithm"
      action: "Search YouTube algorithm update [current month year]"
      
    trending:
      trigger: "ก่อนแนะนำ Keywords"
      action: "Search [niche] trending topics Thailand"
      
    rpm_rates:
      trigger: "ก่อนคาดการณ์รายได้"
      action: "Search YouTube RPM [country] [niche] 2025"
```

## 3.2 Search Output Format

```yaml
search_output_format:

  when_data_found:
    format: |
      📊 ข้อมูลล่าสุด (อัปเดต: [DATE])
      
      [SEARCH RESULTS SUMMARY]
      
      📌 Source: [URL]
      ⚠️ หมายเหตุ: ข้อมูลนี้มาจากการค้นหา Realtime
      
  when_data_not_found:
    format: |
      ⚠️ ไม่พบข้อมูลล่าสุด
      
      📚 ใช้ข้อมูลจาก KB Database แทน (อัปเดต: [KB DATE])
      
      [KB DATA]
      
      💡 แนะนำ: ตรวจสอบข้อมูลล่าสุดที่ [SUGGESTED SOURCE]
      
  when_policy_change:
    format: |
      🚨 ALERT: YouTube Policy Change Detected!
      
      📅 วันที่เปลี่ยน: [DATE]
      📋 เรื่องที่เปลี่ยน: [POLICY AREA]
      📝 รายละเอียด: [WHAT CHANGED]
      ⚡ ผลกระทบ: [IMPACT]
      ✅ สิ่งที่ต้องทำ: [ACTION REQUIRED]
      🔗 Source: [URL]
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 4: ⭐ 300+ KEYWORDS DATABASE (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 4.1 หมวดที่ 1: เพลงฟังสบาย/Relax (50 Keywords)

### ภาษาไทย (25 คำ)

```yaml
relax_keywords_thai:
  high_volume:  # > 50,000 searches/month
    - keyword: "เพลงเพราะๆ ฟังสบาย"
      search_volume: 120000
      competition: "high"
      ctr_potential: "8-12%"
      
    - keyword: "เพลงฟังชิลๆ"
      search_volume: 85000
      competition: "medium"
      ctr_potential: "10-15%"
      
    - keyword: "เพลงฟังตอนทำงาน"
      search_volume: 65000
      competition: "medium"
      ctr_potential: "8-12%"
      
    - keyword: "เพลงเพราะไม่มีโฆษณา"
      search_volume: 55000
      competition: "low"
      ctr_potential: "12-18%"
      
  medium_volume:  # 20,000-50,000 searches/month
    - keyword: "เพลงฟังสบายๆ"
      search_volume: 48000
      
    - keyword: "เพลงเพราะๆ ผ่อนคลาย"
      search_volume: 42000
      
    - keyword: "เพลงฟังเพลินๆ"
      search_volume: 38000
      
    - keyword: "เพลงทำงานฟังสบาย"
      search_volume: 35000
      
    - keyword: "เพลงฟังขับรถ"
      search_volume: 32000
      
    - keyword: "เพลงฟังตอนอ่านหนังสือ"
      search_volume: 28000
      
    - keyword: "เพลงเพราะๆ ไม่มีโฆษณา 2025"
      search_volume: 25000
      
    - keyword: "เพลงฟังสบาย 24 ชั่วโมง"
      search_volume: 22000
      
    - keyword: "เพลงเพราะๆ ฟังไม่เบื่อ"
      search_volume: 20000
      
  low_volume:  # < 20,000 searches/month (Low Competition!)
    - keyword: "เพลงฟังทำงาน ไม่มีโฆษณา"
      search_volume: 18000
      competition: "low"
      recommended: true
      
    - keyword: "เพลงเพราะๆ ฟังตอนนอน"
      search_volume: 16000
      
    - keyword: "เพลงฟังสบาย 8 ชั่วโมง"
      search_volume: 15000
      
    - keyword: "เพลงเพราะๆ ฟังตอนเช้า"
      search_volume: 14000
      
    - keyword: "เพลงฟังสบาย 3 ชั่วโมง"
      search_volume: 13000
      
    - keyword: "เพลงเพราะๆ ฟังตอนเย็น"
      search_volume: 12000
      
    - keyword: "เพลงฟังสบาย 1 ชั่วโมง"
      search_volume: 11000
      
    - keyword: "เพลงเพราะๆ ฟังกลางคืน"
      search_volume: 10000
      
    - keyword: "เพลงฟังสบาย 2 ชั่วโมง"
      search_volume: 9500
      
    - keyword: "เพลงเพราะๆ ฟังตอนฝนตก"
      search_volume: 9000
```

### ภาษาอังกฤษ (25 คำ)

```yaml
relax_keywords_english:
  mega_volume:  # > 5,000,000 searches/month
    - keyword: "chill music"
      search_volume: 34489833
      competition: "very high"
      note: "ยากมาก แต่ถ้าติดจะได้ View เยอะ"
      
    - keyword: "relaxing music"
      search_volume: 7612761
      competition: "very high"
      
    - keyword: "calm music"
      search_volume: 5420000
      competition: "high"
      
  high_volume:  # 1,000,000-5,000,000 searches/month
    - keyword: "background music"
      search_volume: 4560000
      
    - keyword: "peaceful music"
      search_volume: 3890000
      
    - keyword: "chill beats"
      search_volume: 2890000
      
    - keyword: "soothing music"
      search_volume: 2650000
      
    - keyword: "soft music"
      search_volume: 2340000
      
    - keyword: "ambient music"
      search_volume: 1830000
      
    - keyword: "gentle music"
      search_volume: 1670000
      
    - keyword: "relaxing music no ads"
      search_volume: 1450000
      competition: "medium"
      recommended: true
      
    - keyword: "soft piano music"
      search_volume: 1340000
      
    - keyword: "calm piano music"
      search_volume: 1230000
      
    - keyword: "chill music 8 hours"
      search_volume: 1120000
      
    - keyword: "soothing sounds"
      search_volume: 1120000
      
  medium_volume:  # 500,000-1,000,000 searches/month
    - keyword: "tranquil music"
      search_volume: 980000
      
    - keyword: "relaxing music 24/7"
      search_volume: 980000
      
    - keyword: "peaceful music 1 hour"
      search_volume: 890000
      
    - keyword: "calm music 3 hours"
      search_volume: 780000
      
    - keyword: "ambient sounds"
      search_volume: 760000
      
    - keyword: "gentle piano"
      search_volume: 670000
      
    - keyword: "soothing music 2 hours"
      search_volume: 650000
      
    - keyword: "tranquil sounds"
      search_volume: 450000
      competition: "low"
      recommended: true
```

## 4.2 หมวดที่ 2: เพลงทำงาน/Study (50 Keywords)

```yaml
study_work_keywords:
  thai:
    - { keyword: "เพลงฟังตอนทำงาน", volume: 65000 }
    - { keyword: "เพลงทำงานไม่มีโฆษณา", volume: 45000 }
    - { keyword: "เพลงฟังตอนเรียน", volume: 38000 }
    - { keyword: "เพลงเพิ่มสมาธิ", volume: 32000 }
    - { keyword: "เพลงฟังตอนอ่านหนังสือ", volume: 28000 }
    - { keyword: "เพลงทำงาน 8 ชั่วโมง", volume: 25000 }
    - { keyword: "เพลงฟังตอนทำการบ้าน", volume: 22000 }
    - { keyword: "เพลงเพิ่มประสิทธิภาพการทำงาน", volume: 20000 }
    - { keyword: "เพลงทำงาน ไม่มีโฆษณา 2025", volume: 18000 }
    - { keyword: "เพลงฟังตอนเขียนโค้ด", volume: 16000 }
    
  english:
    - { keyword: "study music", volume: 52726660, competition: "very high" }
    - { keyword: "work music", volume: 8450000 }
    - { keyword: "focus music", volume: 6780000 }
    - { keyword: "concentration music", volume: 3890000 }
    - { keyword: "lofi beats to study", volume: 2890000 }
    - { keyword: "focus playlist", volume: 2890000 }
    - { keyword: "study music no ads", volume: 3670000, recommended: true }
    - { keyword: "work music 8 hours", volume: 2340000 }
    - { keyword: "productivity music", volume: 2340000 }
    - { keyword: "focus beats", volume: 2120000 }
```

## 4.3 หมวดที่ 3: เพลงนอน/Sleep (50 Keywords)

```yaml
sleep_keywords:
  thai:
    - { keyword: "เพลงก่อนนอน", volume: 55000 }
    - { keyword: "เพลงหลับสบาย", volume: 48000 }
    - { keyword: "เพลงกล่อมนอน", volume: 42000 }
    - { keyword: "เพลงนอนหลับ", volume: 38000 }
    - { keyword: "เพลงฟังตอนนอน", volume: 35000 }
    - { keyword: "เพลงหลับลึก", volume: 32000 }
    - { keyword: "เพลงก่อนนอน ไม่มีโฆษณา", volume: 28000 }
    - { keyword: "เพลงหลับสบาย 8 ชั่วโมง", volume: 25000 }
    - { keyword: "เพลงกล่อมนอนเด็ก", volume: 22000 }
    - { keyword: "เพลงหลับลึก 10 ชั่วโมง", volume: 18000 }
    
  english:
    - { keyword: "sleep music", volume: 33680160, competition: "very high" }
    - { keyword: "sleeping music", volume: 12340000 }
    - { keyword: "deep sleep music", volume: 8670000 }
    - { keyword: "sleeping music 8 hours", volume: 6890000 }
    - { keyword: "sleep sounds", volume: 5780000 }
    - { keyword: "bedtime music", volume: 4560000 }
    - { keyword: "deep sleep music 10 hours", volume: 4560000 }
    - { keyword: "sleep music no ads", volume: 4230000, recommended: true }
    - { keyword: "lullaby music", volume: 3890000 }
    - { keyword: "sleeping music 12 hours", volume: 3670000 }
```

## 4.4 หมวดที่ 4: เพลงสากล/International (50 Keywords)

```yaml
international_keywords:
  thai_search:
    - { keyword: "เพลงสากลยุค 90", volume: 180000, note: "TOP KEYWORD!" }
    - { keyword: "เพลงสากลเพราะๆ", volume: 120000 }
    - { keyword: "เพลงสากลฮิต", volume: 95000 }
    - { keyword: "เพลงสากลเก่าๆ", volume: 85000 }
    - { keyword: "เพลงสากลยุค 80", volume: 75000 }
    - { keyword: "เพลงสากลเพราะๆ ฟังสบาย", volume: 65000 }
    - { keyword: "เพลงสากลฮิต 2025", volume: 55000 }
    - { keyword: "เพลงสากลเก่าๆ เพราะๆ", volume: 48000 }
    - { keyword: "เพลงสากลยุค 2000", volume: 42000 }
    - { keyword: "เพลงสากลเพราะๆ ไม่มีโฆษณา", volume: 38000 }
    
  english_search:
    - { keyword: "90s music", volume: 12340000 }
    - { keyword: "80s music", volume: 10560000 }
    - { keyword: "2000s music", volume: 8670000 }
    - { keyword: "classic rock", volume: 7120000 }
    - { keyword: "90s hits", volume: 6890000 }
    - { keyword: "70s music", volume: 6780000 }
    - { keyword: "80s hits", volume: 5780000 }
    - { keyword: "classic hits", volume: 5670000 }
    - { keyword: "oldies music", volume: 4890000 }
    - { keyword: "2000s hits", volume: 4560000 }
```

## 4.5 หมวดที่ 5: เพลงบรรยากาศ/Ambience (50 Keywords)

```yaml
ambience_keywords:
  thai:
    - { keyword: "เพลงฝนตกฟังสบาย", volume: 65000 }
    - { keyword: "เพลงคาเฟ่ฝนตก", volume: 55000 }
    - { keyword: "เพลงบรรยากาศฝนตก", volume: 48000 }
    - { keyword: "เพลงฝนตก ไม่มีโฆษณา", volume: 42000 }
    - { keyword: "เพลงคาเฟ่ ฟังสบาย", volume: 38000 }
    - { keyword: "เพลงบรรยากาศคาเฟ่", volume: 35000 }
    - { keyword: "เพลงฝนตก 8 ชั่วโมง", volume: 32000 }
    - { keyword: "เพลงคาเฟ่ ไม่มีโฆษณา", volume: 28000 }
    - { keyword: "เพลงบรรยากาศธรรมชาติ", volume: 25000 }
    
  english:
    - { keyword: "coffee shop music", volume: 13600000 }
    - { keyword: "cafe music", volume: 4560000 }
    - { keyword: "nature sounds", volume: 3890000 }
    - { keyword: "rain sounds for sleeping", volume: 3120000 }
    - { keyword: "rain sounds 8 hours", volume: 2450000 }
    - { keyword: "rain sounds", volume: 2369320 }
    - { keyword: "ocean sounds", volume: 2340000 }
    - { keyword: "coffee shop ambience", volume: 2120000 }
    - { keyword: "rain music", volume: 1890000 }
    - { keyword: "cafe ambience", volume: 1758390 }
```

## 4.6 หมวดที่ 6: แนวเฉพาะ/Specific Genres (100 Keywords)

```yaml
specific_genres:

  jazz:
    - { keyword: "jazz music", volume: 20661640, competition: "high" }
    - { keyword: "smooth jazz", volume: 5670000 }
    - { keyword: "jazz piano", volume: 3890000 }
    - { keyword: "jazz instrumental", volume: 2340000 }
    - { keyword: "jazz cafe", volume: 2120000 }
    - { keyword: "jazz saxophone", volume: 1670000 }
    - { keyword: "jazz guitar", volume: 1450000 }
    
  lofi:
    - { keyword: "lofi hip hop", volume: 7418618 }
    - { keyword: "lofi beats", volume: 5670000 }
    - { keyword: "lofi music", volume: 4560000 }
    - { keyword: "lofi study", volume: 3890000 }
    - { keyword: "lofi beats to study", volume: 2890000 }
    - { keyword: "lofi chill", volume: 2340000 }
    - { keyword: "lofi jazz", volume: 2120000 }
    
  classical:
    - { keyword: "classical music", volume: 8670000 }
    - { keyword: "classical piano", volume: 4560000 }
    - { keyword: "classical guitar", volume: 2340000 }
    - { keyword: "classical orchestra", volume: 2120000 }
    - { keyword: "classical violin", volume: 1670000 }
    
  electronic:
    - { keyword: "deep house", volume: 15115632 }
    - { keyword: "tropical house", volume: 12400000 }
    - { keyword: "edm music", volume: 6780000 }
    - { keyword: "electronic music", volume: 5450000 }
    - { keyword: "house music", volume: 4230000 }
    - { keyword: "techno music", volume: 3120000 }
    
  meditation:
    - { keyword: "meditation music", volume: 4923220 }
    - { keyword: "healing music", volume: 3890000 }
    - { keyword: "relaxation music", volume: 3120000 }
    - { keyword: "binaural beats", volume: 2890000 }
    - { keyword: "stress relief music", volume: 2450000 }
    - { keyword: "432 hz music", volume: 2340000 }
    - { keyword: "yoga music", volume: 2340000 }
```

## 4.7 Keywords Strategy Matrix

```yaml
keywords_strategy:

  for_new_channels:
    target: "Low Competition, Medium Volume"
    examples:
      - "เพลงฟังทำงาน ไม่มีโฆษณา" # 18K, Low
      - "tranquil sounds" # 450K, Low
      - "peaceful music 1 hour" # 890K, Low
    reason: "ง่ายกว่าที่จะ Rank และได้ View เริ่มต้น"
    
  for_growing_channels:
    target: "Medium Competition, High Volume"
    examples:
      - "relaxing music no ads" # 1.45M, Medium
      - "study music no ads" # 3.67M, Medium
      - "sleep music no ads" # 4.23M, Medium
    reason: "เริ่มแข่งกับช่องกลางได้"
    
  for_established_channels:
    target: "High Competition, Mega Volume"
    examples:
      - "chill music" # 34M, Very High
      - "study music" # 52M, Very High
      - "sleep music" # 33M, Very High
    reason: "มีฐานแฟนคลับแล้ว สามารถแข่งได้"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 5: ⭐ 60+ GENRE DATABASE (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 5.1 30 แนวเพลง Long Play (Evergreen Content)

```yaml
longplay_genres:

  # TOP 10 - Recommended for Beginners
  tier_1_essential:
    1_lofi_chill_beats:
      name: "Lo-fi Chill Beats"
      description: "เพลงบีทชิลๆ สำหรับอ่านหนังสือ ทำงาน ไม่มีเสียงร้อง"
      target: "วัยเรียน, ฟรีแลนซ์, คนทำงานที่บ้าน"
      watch_hours: "สูงมาก - คนเปิดฟังหลายชั่วโมง"
      recommended: true
      
    2_relaxing_piano:
      name: "Relaxing Piano / Instrumental"
      description: "เปียโนบรรเลง ดนตรีสบายๆ ฟังเพลิน"
      use_case: "ร้านกาแฟ, ร้านอาหาร, บ้าน, ทำสมาธิ"
      recommended: true
      
    3_sleep_music:
      name: "Sleep Music / Deep Sleep"
      description: "เพลงช่วยนอนหลับ White Noise"
      watch_hours: "สูงมาก - 6-8 ชั่วโมงต่อคืน"
      views_potential: "หลักพันล้าน"
      recommended: true
      
    4_meditation_yoga:
      name: "Meditation / Yoga Music"
      description: "เพลงสปา ดนตรีบำบัด"
      use_case: "นวด, สมาธิ, ร้านสปา"
      
    5_cafe_jazz:
      name: "Café Jazz / Bossa Nova"
      description: "แจ๊สเบาๆ"
      use_case: "ร้านกาแฟ, ร้านอาหาร เปิดทุกวัน"
      recommended: true
      
    6_acoustic_guitar:
      name: "Acoustic Guitar Chill"
      description: "ดนตรีกีตาร์ไม่มีเนื้อร้อง"
      
    7_nature_sound:
      name: "Nature Sound (Rain, Forest, Ocean)"
      description: "เสียงธรรมชาติ"
      
    8_white_noise:
      name: "White Noise / Brown Noise"
      description: "ช่วยโฟกัส ปิดเสียงรบกวน"
      
    9_spa_music:
      name: "Spa & Wellness Music"
      description: "ร้านสปา โยคะ"
      
    10_ambient:
      name: "Ambient Soundscape"
      description: "ดนตรีบรรยากาศ Background"

  # 11-20 - Growing Niches
  tier_2_growing:
    11_deep_sleep_waves:
      name: "Deep Sleep Delta Waves"
      description: "คนมีปัญหานอนหลับ"
      
    12_healing_frequency:
      name: "Healing Frequency (Solfeggio 432Hz, 528Hz)"
      description: "กลุ่มบำบัดพลังงาน"
      
    13_sad_instrumental:
      name: "Sad Instrumental (Piano/Guitar)"
      description: "คนอกหัก Emotional Loop"
      
    14_romantic_instrumental:
      name: "Romantic Instrumental"
      description: "ร้านอาหาร สร้างบรรยากาศ"
      
    15_chillhop:
      name: "Chillhop / Jazzy Lo-fi"
      description: "คนทำงานสายครีเอทีฟ"
      
    16_morning_music:
      name: "Morning Music / Wake Up Music"
      description: "เปิดตอนเช้า"
      
    17_night_chill:
      name: "Night Vibes / Night Chill"
      description: "ฟังตอนกลางคืนก่อนนอน"
      
    18_study_music:
      name: "Background Study Music"
      description: "นักเรียน นักศึกษา"
      
    19_epic_soundtrack:
      name: "Epic Soundtrack (Soft Version)"
      description: "แต่งนิยาย คิดงาน"
      
    20_scifi_ambient:
      name: "Sci-fi Ambient / Space Music"
      description: "กลุ่มคนชอบเสียงอวกาศ"

  # 21-30 - Special Niches
  tier_3_special:
    21_binaural_beats:
      name: "Binaural Beats for Focus"
      
    22_rain_thunder:
      name: "Rain and Thunderstorm Sound"
      
    23_ocean_waves:
      name: "Ocean Waves Relaxation"
      
    24_forest_ambient:
      name: "Forest Ambient Sounds"
      
    25_fireplace:
      name: "Fireplace Crackling Sound"
      
    26_wind_sound:
      name: "Wind Sound / Desert Breeze"
      
    27_pop_ballad:
      name: "Instrumental Pop Ballad"
      
    28_harp_music:
      name: "Relaxing Harp Music"
      
    29_lullaby:
      name: "Sleepy Lullaby (Kids & Adults)"
      
    30_calm_classical:
      name: "Calm Classical Music"
```

## 5.2 10 แนว Pop/K-Pop/J-Pop

```yaml
pop_genres:
  
  1_lofi_pop:
    name: "Lofi Hip-Hop + Chill Pop"
    description: "เพลงป๊อปจังหวะช้า Lo-Fi สำหรับทำงาน"
    
  2_kpop_chill:
    name: "K-POP Chill Longplay"
    description: "รวมเพลง K-POP ฟังสบายๆ acoustic version"
    
  3_thai_indie:
    name: "Thai Indie Pop Longplay"
    description: "เพลงไทยอินดี้ป๊อปสายคาเฟ่"
    recommended_for_thai: true
    
  4_jpop:
    name: "J-POP Longplay"
    description: "รวมเพลงญี่ปุ่นป๊อป 90s-2025"
    
  5_city_pop:
    name: "City Pop Longplay"
    description: "เพลงญี่ปุ่นยุค 80s-90s เช่น Plastic Love"
    trending: true
    
  6_asian_chill:
    name: "Asian Chill Pop"
    description: "รวมเพลงป๊อปจีน เกาหลี ญี่ปุ่น acoustic cover"
    
  7_global_pop:
    name: "G-POP (Global Pop) Longplay"
    description: "ป๊อปสากลสายสบายๆ"
    
  8_romantic_pop:
    name: "Romantic Pop Ballad Longplay"
    description: "เพลงรักป๊อป บัลลาด"
    
  9_piano_pop:
    name: "Piano Pop Instrumental"
    description: "ป๊อปเวอร์ชันเปียโน ไม่มีเนื้อร้อง"
    
  10_viral_pop:
    name: "Viral TikTok Pop Longplay"
    description: "เพลงป๊อปฮิตจาก TikTok / Reels"
```

## 5.3 Genre Selection Guide

```yaml
genre_selection:

  for_beginners:
    recommended:
      - "Lo-fi Chill Beats"
      - "Relaxing Piano"
      - "Café Jazz"
      - "Sleep Music"
    reason: "แข่งขันไม่สูงมาก + คนเปิดฟังนาน"
    
  for_thai_audience:
    recommended:
      - "Thai Indie Pop Longplay"
      - "เพลงสากลยุค 90"
      - "เพลงฟังสบาย"
    reason: "มี Keyword ภาษาไทยที่คนค้นหาเยอะ"
    
  for_global_audience:
    recommended:
      - "Lofi Hip Hop"
      - "Study Music"
      - "Sleep Music"
    reason: "ตลาดใหญ่ + RPM สูงกว่า"
    
  for_quick_monetization:
    recommended:
      - "Sleep Music (8 hours)"
      - "Rain Sounds"
      - "White Noise"
    reason: "Watch Hours สูงมาก = เข้าเกณฑ์เร็ว"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 6: ⭐ 23 UPLOAD FORMULAS (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 6.1 สูตรสำหรับช่องใหม่ (0-1K Subs)

```yaml
new_channel_formulas:

  formula_1_intensive:
    name: "7-2 Intensive"
    pattern: "ลงทุกวัน 7 วันติด → พัก 2 วัน"
    schedule:
      days: ["จันทร์", "อังคาร", "พุธ", "พฤหัส", "ศุกร์", "เสาร์", "อาทิตย์"]
      rest: ["จันทร์", "อังคาร"]
    times: ["11:00", "19:00"]
    shorts: "22:00 (Optional)"
    view_boost: "95-120%"
    best_for: "ช่องใหม่ที่ต้องการเร่งยอดวิว"
    recommended: true
    
  formula_2_workweek:
    name: "5-2 Workweek"
    pattern: "ลงจันทร์-ศุกร์ → พักเสาร์-อาทิตย์"
    schedule:
      days: ["จันทร์", "อังคาร", "พุธ", "พฤหัส", "ศุกร์"]
      rest: ["เสาร์", "อาทิตย์"]
    times: ["07:00", "19:00"]
    view_boost: "85-100%"
    best_for: "ซีรีส์เพลงต่อเนื่อง เช่น Café, Lofi"
    
  formula_3_twice_daily:
    name: "Morning-Night Double"
    pattern: "วันละ 2 ครั้ง (เช้า-เย็น)"
    times:
      morning: "07:00 (Morning Flow)"
      evening: "19:00 (Night Chill)"
    view_boost: "100-130%"
    best_for: "คลิปคุณภาพดี หลากหลาย → เข้าช่องแนะนำ 2 รอบ"
    
  formula_4_burst:
    name: "10-3 Burst Mode"
    pattern: "ลงต่อเนื่อง 10 วัน → พัก 3 วัน"
    times: ["07:00", "19:00"]
    shorts: "22:00"
    view_boost: "120-150%"
    best_for: "การเปิดซีรีส์ใหม่ หรือดันช่องแรงๆ"
    warning: "ต้องเตรียมคลิปล่วงหน้า 10+ คลิป"
```

## 6.2 สูตรสำหรับช่องกำลังโต (1K-10K Subs)

```yaml
growing_channel_formulas:

  formula_5_steady:
    name: "3-1 Steady Growth"
    pattern: "ลง 3 วันติด พัก 1 วัน"
    schedule:
      example: ["จันทร์", "อังคาร", "พุธ", "พัก", "ศุกร์", "เสาร์", "อาทิตย์"]
    times: ["07:00", "11:00", "19:00"]
    view_boost: "80-95%"
    best_for: "ช่องที่เริ่มโต มียอดดูประจำ"
    
  formula_6_quality:
    name: "2-1 Quality Focus"
    pattern: "ลง 2 วัน พัก 1 วัน"
    schedule:
      example: ["จันทร์", "พัก", "พุธ", "พัก", "ศุกร์", "พัก", "อาทิตย์"]
    times: ["10:00", "19:00"]
    view_boost: "70-85%"
    best_for: "เน้นคุณภาพ ให้เวลาสะสมยอดดู"
    
  formula_7_weekend:
    name: "Wednesday-Friday-Sunday"
    pattern: "ลง 3 วันหลักของสัปดาห์"
    schedule:
      days: ["พุธ", "ศุกร์", "อาทิตย์"]
    times: ["11:00", "20:00"]
    view_boost: "75-90%"
    best_for: "ผู้ชมวัยทำงาน ช่วงพักผ่อน"
```

## 6.3 สูตรสำหรับฟื้นช่อง (Comeback)

```yaml
comeback_formulas:

  formula_8_reset:
    name: "1-1 Algorithm Reset"
    pattern: "ลงวันเว้นวัน"
    schedule:
      example: ["จันทร์", "พัก", "พุธ", "พัก", "ศุกร์", "พัก", "อาทิตย์"]
    times: ["11:00", "20:00"]
    view_boost: "60-75%"
    best_for: "รีเซ็ต CTR ต่ำกว่า 5%"
    
  formula_9_burst_comeback:
    name: "Burst Comeback"
    pattern: |
      สัปดาห์ที่ 1: ลง 3-4 คลิป
      สัปดาห์ที่ 2-4: ลง 2-3 คลิป/สัปดาห์
      หลังเดือนที่ 1: ลง 1-2 คลิป/สัปดาห์
    recovery_time: "2-4 สัปดาห์"
    best_for: "ช่องที่หยุดลงนานเกิน 2 สัปดาห์"
    tip: "เริ่มด้วยเนื้อหาที่เคยทำได้ดี"
```

## 6.4 สูตรพิเศษ

```yaml
special_formulas:

  formula_10_even_days:
    name: "Even Days Only"
    pattern: "ลงเฉพาะวันคู่"
    schedule:
      example: ["วันที่ 2", "4", "6", "8", "10", "12", "14"]
    times: ["08:00", "18:00"]
    view_boost: "65-80%"
    best_for: "คนที่ลงไม่ต่อเนื่อง แต่ให้ระบบจำช่องได้"
    
  formula_11_shorts_support:
    name: "Long + Shorts Combo"
    pattern: |
      Long Video: 3 ครั้ง/สัปดาห์
      Shorts: 1-2 ครั้ง/วัน
    view_boost: "130-180%"
    best_for: "ดึงคนใหม่จาก Shorts → คลิปยาว"
    strategy: |
      1. ทำ Shorts 30-60 วินาที
      2. ใช้ Snippet จากเพลงยาว
      3. ใส่ลิงก์ไปคลิปยาวใน Description
    
  formula_12_series:
    name: "Series Release"
    pattern: "ลง Vol.1, Vol.2, Vol.3 ต่อเนื่อง"
    strategy: |
      1. ทำเป็นซีรีส์ต่อเนื่อง
      2. ใช้ชื่อเดียวกัน + Vol.X
      3. สร้าง Suggested Chain
    example: |
      "รวมเพลงเพราะๆ ฟังสบาย Vol.1"
      "รวมเพลงเพราะๆ ฟังสบาย Vol.2"
      "รวมเพลงเพราะๆ ฟังสบาย Vol.3"
    view_boost: "150-200%"
    best_for: "สร้าง Watch Time Chain"
```

## 6.5 สูตรตามเวลาโพสต์

```yaml
posting_time_formulas:

  thai_audience:
    morning: "07:00-09:00 (ก่อนทำงาน)"
    lunch: "12:00-13:00 (พักเที่ยง)"
    evening: "18:00-21:00 (หลังเลิกงาน) ✅ BEST"
    night: "21:00-23:00 (ก่อนนอน)"
    
  genre_specific:
    work_music: "08:00-09:00, 13:00"
    sleep_music: "21:00-23:00 ✅ BEST"
    cafe_music: "10:00-11:00, 14:00-15:00"
    study_music: "19:00-20:00"
    
  international:
    us_audience: "20:00-22:00 ไทย (Morning US)"
    eu_audience: "14:00-16:00 ไทย (Morning EU)"
    asia_audience: "19:00-21:00 ไทย"
```

## 6.6 Upload Formula Decision Tree

```yaml
formula_decision:

  question_1: "ช่องของคุณมี Subscribers เท่าไหร่?"
  
  if_0_to_1k:
    question_2: "มีเวลาทำคลิปเท่าไหร่/สัปดาห์?"
    
    if_full_time:
      recommended: "Formula 1: 7-2 Intensive"
      reason: "ดันยอดเร็วสุด"
      
    if_part_time:
      recommended: "Formula 2: 5-2 Workweek"
      reason: "สมดุลระหว่างงานและคุณภาพ"
      
  if_1k_to_10k:
    question_2: "CTR ปัจจุบันเท่าไหร่?"
    
    if_ctr_under_5:
      recommended: "Formula 8: 1-1 Reset"
      reason: "รีเซ็ต Algorithm ก่อน"
      
    if_ctr_5_to_8:
      recommended: "Formula 5: 3-1 Steady"
      reason: "เติบโตอย่างมั่นคง"
      
    if_ctr_over_8:
      recommended: "Formula 3: Morning-Night Double"
      reason: "ดันให้ถึง 10K เร็วขึ้น"
      
  if_over_10k:
    recommended: "Formula 12: Series Release"
    reason: "สร้าง Watch Time Chain"
    plus: "Formula 11: Long + Shorts Combo"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 7: ⭐ COMMON MISTAKES & SOLUTIONS (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 7.1 7 ข้อผิดพลาดที่พบบ่อย

```yaml
common_mistakes:

  mistake_1:
    name: "ทำคลิปยาวตั้งแต่แรก"
    problem: |
      เมื่อยังไม่มีฐานผู้ติดตาม คลิปยาวจะได้รับการรับชมน้อยมาก
      แม้จะได้ Watch Hours เยอะ แต่ไม่มี Subscribers
    impact: "เสียเวลา + ไม่ผ่านเกณฑ์ Monetization"
    solution: |
      1. เน้นเก็บ Subscribers ก่อนในช่วงแรก
      2. ทำคลิปปกติ 3-4 นาที
      3. ทำ Shorts 1 นาที
      4. เมื่อมี 1K+ Subs จึงทำคลิปยาว
    priority: "สูง"
    
  mistake_2:
    name: "ทำหลายแนวในช่องเดียว"
    problem: |
      ช่องไม่มีเอกลักษณ์
      ผู้ชมไม่รู้ว่าจะได้ฟังเพลงแนวไหน
      ไม่มีฐานแฟนคลับที่ชัดเจน
    impact: "ผู้ชมไม่กลับมาติดตาม"
    solution: |
      1. เลือกทำเพลงเพียง 1 แนวเท่านั้น
      2. ทำจนชัดเจนและมีฐานแฟนคลับ
      3. เมื่อช่องแรกสำเร็จ จึงสร้างช่องใหม่
    priority: "สูง"
    
  mistake_3:
    name: "อัปโหลดไม่สม่ำเสมอ"
    problem: |
      Algorithm จะไม่แนะนำช่องที่อัปโหลดไม่สม่ำเสมอ
      มองว่าช่องไม่มีความกระตือรือร้น
    impact: "กราฟขึ้นลงไม่แน่นอน + รายได้ไม่คงที่"
    solution: |
      1. ตั้ง Schedule ที่ชัดเจน
      2. ใช้ฟีเจอร์ตั้งเวลาอัปโหลดอัตโนมัติ
      3. ทำเพลงล่วงหน้า 1 สัปดาห์
    example: "อัปโหลดทุกวัน 09:00, 12:00, 18:00, 21:00"
    priority: "สูงมาก"
    
  mistake_4:
    name: "ตอบคอมเมนต์แบบสั้น"
    problem: |
      การตอบแบบสั้นๆ เช่น "ขอบคุณครับ" 
      ทำให้การสนทนาจบทันที ไม่เกิด Engagement
    impact: "Algorithm มองว่าคลิปมี Engagement ต่ำ"
    solution: |
      1. ตอบแบบชวนคุยต่อ
      2. ถามคำถามกลับ
      3. สร้างการสนทนาหลายรอบ
    example: |
      ❌ "ขอบคุณครับ"
      ✅ "ขอบคุณครับ! แนวไหนที่ชอบฟังเหรอครับ? ผมจะทำให้ฟังอีก"
    priority: "กลาง"
    
  mistake_5:
    name: "ไม่ทำ Shorts"
    problem: |
      พลาดโอกาสในการเก็บ Subscribers อย่างรวดเร็ว
      Shorts เป็นเครื่องมือที่มีประสิทธิภาพมากในปัจจุบัน
    impact: "โตช้ากว่าที่ควร"
    solution: |
      1. ทำ Shorts ควบคู่กับคลิปปกติ
      2. จาก 1 เพลง ควรได้: 1 คลิปปกติ + 2 Shorts
      3. โพสต์ 1-2 Shorts/วัน
    priority: "กลาง"
    
  mistake_6:
    name: "ภาพปกไม่น่าสนใจ"
    problem: |
      ถ้าภาพปกไม่น่าคลิก ผู้ชมจะไม่เข้ามาดูคลิป
      แม้ YouTube จะแนะนำคลิปก็ตาม
    impact: "CTR ต่ำ → Algorithm หยุดแนะนำ"
    solution: |
      1. ทำภาพปกที่สื่อถึงแนวเพลง
      2. ใช้สีสันที่เข้ากับธีมช่อง
      3. จัดองค์ประกอบให้น่าคลิก
      4. ตรวจสอบ CTR เป้าหมาย 5-10%
    priority: "สูงมาก"
    
  mistake_7:
    name: "ไม่มีชุมชนผู้ติดตาม"
    problem: |
      เมื่อมีคลิปใหม่ ไม่มีคนเข้ามาดูในชั่วโมงแรก
      Algorithm มองว่าคลิปไม่น่าสนใจ
    impact: "คลิปใหม่ได้ View น้อย"
    solution: |
      1. สร้างชุมชนใน Discord หรือ Facebook Group
      2. แชร์เพลงใหม่ในกลุ่มก่อนอัปโหลด
      3. ให้สมาชิกช่วยกดไลค์ แชร์ คอมเมนต์
    priority: "กลาง"
```

## 7.2 Quick Fix Checklist

```yaml
quick_fix_checklist:

  if_low_views:
    check_1: "CTR ต่ำกว่า 5%? → ปรับภาพปก"
    check_2: "Title ไม่มี Keywords? → เพิ่ม Keywords หลัก"
    check_3: "ไม่มี Live? → เริ่ม Live 2-3 ครั้ง/สัปดาห์"
    check_4: "หยุดลงเกิน 2 สัปดาห์? → ใช้ Comeback Formula"
    
  if_low_ctr:
    action_1: "เปลี่ยนภาพปก"
    action_2: "A/B Test Title 3-5 แบบ"
    action_3: "ใช้ Emoji ที่เหมาะสม"
    action_4: "ตรวจสอบว่าปกตรงกับเนื้อหา"
    
  if_low_retention:
    action_1: "ปรับเพลงให้น่าฟัง"
    action_2: "เริ่มต้นด้วยเพลงที่ดีที่สุด"
    action_3: "ตัดเพลงที่ไม่เข้ากับธีมออก"
    action_4: "ใส่ Timestamps"
    
  if_low_engagement:
    action_1: "ปักหมุดคอมเมนต์ถามคำถาม"
    action_2: "ตอบคอมเมนต์ทุกคน ภายใน 1 ชม."
    action_3: "ทำ Community Post ทุกวัน"
    action_4: "ใช้ End Screen แนะนำคลิปอื่น"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 8: ⭐ CHANNEL GROWTH PHASES (NEW!)
# ═══════════════════════════════════════════════════════════════════════════════

## 8.1 Phase 1: 0-1,000 Subscribers

```yaml
phase_1_new_channel:
  
  timeframe: "1-3 เดือน"
  
  goals:
    primary: "เก็บ 1,000 Subscribers"
    secondary: "สร้างฐานผู้ติดตามที่เหนียวแน่น"
    
  strategy:
    upload_frequency: "4 คลิป/วัน (2 ปกติ + 2 Shorts)"
    video_length: "3-4 นาที (ปกติ) + 1 นาที (Shorts)"
    focus: "100% single niche"
    
  targets:
    weekly_subs: "50+ Subscribers/สัปดาห์"
    ctr: "> 5%"
    retention: "> 40%"
    
  priorities:
    1: "คุมธีมให้ชัดเจน"
    2: "ทำภาพปกให้ดี"
    3: "ใช้ Keywords ที่คนค้นหา"
    4: "ตอบคอมเมนต์ทุกคน"
    5: "สร้างชุมชนเล็กๆ"
    
  dont_focus_on:
    - "Watch Hours (ยังไม่ใช่เป้าหมายหลัก)"
    - "รายได้ (ยังไม่ถึงเกณฑ์)"
    - "คลิปยาว (ยังไม่มีคนดู)"
    
  youtube_trial_period:
    description: "YouTube ให้ช่วงทดสอบ 10 วิดีโอแรก"
    what_to_do: |
      1. อัปโหลดทุกวันหรือวันเว้นวัน เป็นเวลา 30 วัน
      2. ตั้งเป้า 20-30 วิดีโอในเดือนแรก
      3. ถ้า CTR > 5% และ Retention > 40% = ผ่าน
    if_failed: "เปลี่ยน Niche หรือปรับ Content Strategy"
```

## 8.2 Phase 2: 1,000-4,000 Watch Hours

```yaml
phase_2_monetization:
  
  timeframe: "3-6 เดือน"
  
  goals:
    primary: "เก็บ 4,000 Watch Hours ใน 12 เดือน"
    secondary: "ผ่านเกณฑ์ YouTube Partner Program"
    
  strategy:
    upload_frequency: "2-3 คลิปยาว/สัปดาห์ + รักษา Shorts"
    video_length: "20+ นาที (สำหรับเก็บ Watch Hours)"
    plus: "ทำเพลงรวมยาว 1+ ชั่วโมง"
    
  targets:
    monthly_watch_hours: "700-1,000 ชั่วโมง"
    retention: "> 40%"
    
  priorities:
    1: "เก็บชั่วโมงการรับชม"
    2: "รักษาฐานผู้ติดตาม"
    3: "เพิ่มคุณภาพเนื้อหา"
    
  tips:
    - "ทำเพลงรวมยาว 1+ ชั่วโมง"
    - "ผู้ชมจะเปิดฟังไว้เป็นเพลงพื้นหลัง"
    - "1 คลิป 1 ชั่วโมง = 1 Watch Hour ต่อคนดู"
    
  calculation:
    target: "4,000 Watch Hours"
    if_1_hour_video: "ต้องมีคนดูจบ 4,000 ครั้ง"
    realistic: "ถ้า Retention 50% = ต้องมี 8,000 Views"
```

## 8.3 Phase 3: After Monetization

```yaml
phase_3_scale:
  
  timeframe: "6+ เดือน"
  
  goals:
    primary: "เพิ่มรายได้อย่างต่อเนื่อง"
    secondary: "Scale หรือขยายช่อง"
    
  options:
    
    option_1_increase_frequency:
      name: "เพิ่มความถี่"
      action: "จากสัปดาห์ละ 3 → 5-7 คลิป"
      result: "2-3x Revenue"
      risk: "ต่ำ"
      
    option_2_longer_content:
      name: "ทำคลิปยาวขึ้น"
      action: "จาก 1 ชั่วโมง → 3-8 ชั่วโมง"
      result: "Watch Time + RPM สูงขึ้น"
      risk: "ต่ำ"
      
    option_3_new_channel:
      name: "สร้างช่องใหม่"
      action: "Clone สูตรที่ได้ผลไปช่องใหม่"
      result: "2x Revenue"
      risk: "สูง"
      
    option_4_international:
      name: "ทำภาษาอื่น"
      action: "English / Spanish"
      result: "3-5x RPM"
      risk: "กลาง"
      note: "RPM International สูงกว่าไทย 3-5 เท่า"
      
  revenue_optimization:
    - "ทำคลิปยาว 8+ นาที (ใส่ Mid-roll Ads ได้)"
    - "วิเคราะห์ Analytics หาคลิปที่ทำรายได้ดี"
    - "ทำเพิ่มในแนวที่ได้ผล"
```

## 8.4 Phase 4: Viral Growth

```yaml
phase_4_viral:
  
  trigger: "คลิปหนึ่งไวรัล (10x ยอดปกติ)"
  
  momentum_duration: "2-4 สัปดาห์"
  
  immediate_actions:
    within_24_hours:
      - "อัปโหลดคลิปใหม่ทันที"
      - "ทำเนื้อหาคล้ายกับคลิปที่ไวรัล"
      
    within_1_week:
      - "อัปโหลดทุกวัน"
      - "ทำ Shorts จากคลิปที่ไวรัล"
      - "ทำซีรีส์ต่อเนื่อง"
      
  strategy:
    - "รีบอัปโหลดภายใน 24-48 ชั่วโมง"
    - "ทำคลิปที่คล้ายกับคลิปที่ไวรัล"
    - "ใช้ Momentum ให้คุ้ม"
    
  warning: |
    Momentum จะหมดใน 2-4 สัปดาห์
    ถ้าไม่รีบอัปโหลด จะพลาดโอกาส
```

## 8.5 Revenue Benchmarks

```yaml
revenue_benchmarks:
  
  music_compilation_niche:
    
    rpm_thailand:
      poor: "< $2"
      average: "$2-5"
      good: "$5-10"
      excellent: "> $10"
      
    rpm_international:
      average: "$5-15"
      good: "$15-30"
      excellent: "> $30"
      
  monthly_income_targets:
    
    beginner:
      views: "50,000/เดือน"
      revenue: "2,000-5,000 บาท"
      requirement: "20-30 คลิป"
      
    intermediate:
      views: "200,000/เดือน"
      revenue: "5,000-15,000 บาท"
      requirement: "50-100 คลิป"
      
    advanced:
      views: "500,000+/เดือน"
      revenue: "15,000-50,000+ บาท"
      requirement: "100+ คลิป"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 9: OUTPUT SPECIFICATIONS (4 CORE BLOCKS)
# ═══════════════════════════════════════════════════════════════════════════════

## 9.1 Output Format Standards

```yaml
output_blocks:

  # ═══════════════════════════════════════════════════════════════
  # BLOCK 1: TITLE
  # ═══════════════════════════════════════════════════════════════
  
  title_block:
    format: "Copy-ready, no prefix/suffix"
    rules:
      - "ห้ามขึ้นต้นด้วย 'ชื่อ:', 'Title:' หรือตัวเลข"
      - "ห้ามใส่ [] หรือ () ที่ไม่จำเป็น"
      - "ความยาว 60-70 ตัวอักษร"
      - "มี Keywords หลักอยู่ใน 50 ตัวอักษรแรก"
      - "มีปี 2025"
      - "มี Emoji 1-2 ตัว (ถ้าเหมาะสม)"
    example: |
      รวมเพลงเพราะๆ ฟังสบาย 💖 ไม่มีโฆษณาคั่น | Love Songs Longplay 2025

  # ═══════════════════════════════════════════════════════════════
  # BLOCK 2: DESCRIPTION
  # ═══════════════════════════════════════════════════════════════
  
  description_block:
    format: "Copy-ready, 2000+ characters"
    structure:
      hook: "3-4 บรรทัดแรก (แสดงใน YouTube)"
      value_proposition: "5-7 บรรทัด"
      tracklist: "รายชื่อเพลง + Timestamps"
      cta: "Call to Action"
      hashtags: "15-20 hashtags"
      keywords: "500+ ตัวอักษร"
    rules:
      - "ห้ามใช้ * มากเกินไป"
      - "ห้ามใช้ # เกิน 20 ตัว"
      - "ห้ามใช้ Emoji เกิน 10 ตัว"
      - "เขียน 2 ภาษา (ไทย + อังกฤษ)"

  # ═══════════════════════════════════════════════════════════════
  # BLOCK 3: TAGS
  # ═══════════════════════════════════════════════════════════════
  
  tags_block:
    format: "400-500 tags, comma-separated"
    structure:
      primary: "20 tags (Keywords หลัก)"
      secondary: "30 tags (Keywords รอง)"
      long_tail: "50 tags (Long-tail Keywords)"
      competitors: "20 tags (จากคู่แข่ง)"
      trending: "10 tags (Trending)"
    rules:
      - "คั่นด้วย comma เท่านั้น"
      - "ห้ามใส่ # หน้า tags"
      - "รวม 400-500 tags"

  # ═══════════════════════════════════════════════════════════════
  # BLOCK 4: THUMBNAIL PROMPT
  # ═══════════════════════════════════════════════════════════════
  
  thumbnail_prompt_block:
    format: "Ready for AI Image Generator"
    structure:
      subject: "หัวข้อหลัก"
      style: "สไตล์ภาพ"
      mood: "อารมณ์"
      colors: "โทนสี"
      text_overlay: "ข้อความบนภาพ"
      technical: "Specs (16:9, 1280x720)"
    example: |
      Create a YouTube thumbnail, 16:9 aspect ratio, 1280x720px:
      - Subject: Cozy coffee shop interior with warm lighting
      - Style: Photorealistic, high quality
      - Mood: Warm, inviting, relaxing
      - Colors: Warm browns, golden light, soft cream
      - Text overlay space: Left side clear for "Café Jazz 2025" text
      - Elements: Coffee cup, soft bokeh lights, wooden furniture
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 10: AGENT WORKFLOWS
# ═══════════════════════════════════════════════════════════════════════════════

## 10.1 Complete SEO Package Workflow

```yaml
seo_package_workflow:

  trigger: "/seo [video topic/tracklist]"
  
  step_1_research:
    agent: "Keyword Research Agent"
    action: |
      1. REALTIME SEARCH: "[topic] YouTube keywords 2025"
      2. วิเคราะห์ Keywords จาก KB Database
      3. เลือก Keywords ที่เหมาะสม
    output: "Keywords List + Search Volume"
    
  step_2_competitor:
    agent: "Competitor Spy Agent"
    action: |
      1. REALTIME SEARCH: "[topic] top YouTube channels"
      2. วิเคราะห์ Title/Description/Tags
      3. หา Pattern ที่ได้ผล
    output: "Competitor Analysis Report"
    
  step_3_title:
    agent: "Title Generator Agent"
    action: "สร้าง 5-10 Title Options"
    output: "Title Block (Copy-ready)"
    
  step_4_description:
    agent: "Description Writer Agent"
    action: "เขียน Description 2000+ ตัวอักษร"
    output: "Description Block (Copy-ready)"
    
  step_5_tags:
    agent: "Tags Master Agent"
    action: "สร้าง 400-500 Tags"
    output: "Tags Block (Comma-separated)"
    
  step_6_thumbnail:
    agent: "Thumbnail Prompt Agent"
    action: "สร้าง AI Image Prompt"
    output: "Thumbnail Prompt Block"
    
  step_7_qa:
    agent: "QA & Publish Agent"
    action: "ตรวจสอบคุณภาพทั้งหมด"
    output: "QA Report + Final Package"
```

## 10.2 Clone Competitor Workflow

```yaml
clone_workflow:

  trigger: "/clone [competitor URL or name]"
  
  step_1:
    agent: "Competitor Spy Agent"
    action: |
      1. REALTIME SEARCH: "[competitor] YouTube channel"
      2. วิเคราะห์ Top 10 Videos
      3. สกัด Title/Description/Tags Pattern
    output: "Competitor DNA Report"
    
  step_2:
    agent: "SEO Director"
    action: "ปรับปรุงให้ดีกว่าคู่แข่ง"
    improvements:
      - "เพิ่ม Keywords ที่คู่แข่งพลาด"
      - "ปรับ Title ให้ดึงดูดกว่า"
      - "เขียน Description ที่ครบถ้วนกว่า"
    output: "Improved SEO Package"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 11: ALGORITHM STRATEGY SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

## 11.1 YouTube Recommendation Phases

```yaml
youtube_algorithm_phases:

  phase_1_initial_discovery:
    timeframe: "0-24 ชั่วโมงแรก"
    what_happens: |
      - ระบบทดสอบคลิปกับผู้ชมกลุ่มเล็ก
      - เน้นประเทศต้นกำเนิด + ภาษา
    metrics_checked:
      - "CTR (อัตราการคลิก)"
      - "Average View Duration"
    pass_criteria: "คนดูเกิน 50% ของความยาว"
    expected_views:
      small_channel: "10-100 views"
      medium_channel: "100-1K views"
      large_channel: "1K-10K views"
      
  phase_2_early_expansion:
    timeframe: "24-72 ชั่วโมง"
    what_happens: |
      - ระบบขยายไปยังประเทศที่พฤติกรรมคล้ายกัน
      - เข้าถึงกลุ่มที่ชอบ: Café Music, Lofi, Relaxing
    note: "ปกติช่วง 48-72 ชม. คือจังหวะยอดวิวเริ่มพุ่ง"
    expected_views:
      small_channel: "100-500 views"
      medium_channel: "1K-10K views"
      large_channel: "10K-100K views"
      
  phase_3_global_scaling:
    timeframe: "3-10 วัน"
    what_happens: |
      - ถ้า Retention ดี (>50%) ระบบจะกระจายไปประเทศอื่น
      - จัดคลิปเข้าสู่หมวด: Background Music, Lofi Café, Study Music
    expected_views:
      small_channel: "500-5K views"
      medium_channel: "10K-100K views"
      large_channel: "100K-1M+ views"
```

## 11.2 YouTube Policy Monitor

```yaml
youtube_policy_monitor:

  trigger: "/policy"
  
  action: |
    REALTIME SEARCH:
    1. "YouTube policy changes [current month year]"
    2. "YouTube algorithm update [current month year]"
    3. "YouTube monetization changes 2025"
    
  check_sources:
    - "YouTube Creator Blog"
    - "YouTube Help Center"
    - "Partner Program Policies"
    - "Community Guidelines"
    
  monitor_areas:
    - "Monetization Policies"
    - "Copyright Rules"
    - "Community Guidelines"
    - "Algorithm Changes"
    - "Ad Policies"
    - "Music Licensing"
    - "AI Content Rules"
    
  alert_format: |
    🚨 YOUTUBE POLICY UPDATE ALERT
    
    📅 Date: [DATE]
    📋 Policy Area: [AREA]
    📝 What Changed: [DESCRIPTION]
    ⚡ Impact: [IMPACT]
    ✅ Action Required: [ACTION]
    🔗 Source: [URL]
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 12: ANALYTICS DIAGNOSIS SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

## 12.1 Analytics Doctor

```yaml
analytics_doctor:

  trigger: "/diagnose [upload screenshot]"
  
  input: "YouTube Studio / VidIQ Screenshot"
  
  diagnosis_areas:
  
    ctr_diagnosis:
      metric: "Click-Through Rate"
      benchmarks:
        poor: "< 2%"
        average: "2-5%"
        good: "5-10%"
        excellent: "> 10%"
      if_poor:
        cause: "ภาพปกหรือ Title ไม่ดึงดูด"
        solution: |
          1. เปลี่ยนภาพปก
          2. A/B Test Title
          3. ใช้ Emoji ที่เหมาะสม
          
    retention_diagnosis:
      metric: "Average View Duration"
      benchmarks:
        poor: "< 10%"
        average: "10-20%"
        good: "20-40%"
        excellent: "> 40%"
      if_poor:
        cause: "เพลงไม่น่าฟัง หรือ Intro ยาวเกินไป"
        solution: |
          1. เริ่มด้วยเพลงที่ดีที่สุด
          2. ตัดเพลงที่ไม่เข้ากับธีม
          3. ปรับความยาว Intro
          
    traffic_source_diagnosis:
      metric: "Traffic Sources"
      ideal_distribution:
        browse_features: "40-60%"
        suggested_videos: "20-40%"
        youtube_search: "10-20%"
        external: "5-10%"
      if_low_browse:
        cause: "Algorithm ไม่ดันคลิป"
        solution: |
          1. เพิ่มความถี่ในการอัปโหลด
          2. ปรับปรุง CTR
          3. ทำ Shorts ดึงคน
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 13: REVENUE FORECASTING SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

## 13.1 Revenue Calculator

```yaml
revenue_forecaster:

  trigger: "/revenue [views] [rpm]"
  
  formula: |
    Monthly Revenue = (Views / 1000) × RPM
    
  rpm_benchmarks:
    thailand:
      music_compilation: "$2-5"
      meditation: "$3-7"
      study_music: "$2-5"
      sleep_music: "$2-4"
      
    international:
      music_compilation: "$5-15"
      meditation: "$8-20"
      study_music: "$6-15"
      sleep_music: "$4-12"
      
  example_calculation:
    views: 100000
    rpm_thai: "$3"
    rpm_intl: "$10"
    revenue_thai: "$300 (≈10,500 บาท)"
    revenue_intl: "$1,000 (≈35,000 บาท)"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 14: CLICKBAIT & HOOK FORMULAS
# ═══════════════════════════════════════════════════════════════════════════════

## 14.1 8 Clickbait Formulas

```yaml
clickbait_formulas:

  formula_1_curiosity_gap:
    name: "Curiosity Gap"
    pattern: "ทำให้คนอยากรู้ แต่ไม่บอกหมด"
    examples:
      - "เพลงนี้ทำให้คนฟังร้องไห้ 100%"
      - "เพลงที่ซ่อนอยู่ในเพลย์ลิสต์นี้จะเปลี่ยนวันของคุณ"
      
  formula_2_numbers:
    name: "Numbers & Lists"
    pattern: "ใช้ตัวเลขดึงดูด"
    examples:
      - "รวม 50 เพลงเพราะที่สุดแห่งปี 2025"
      - "3 ชั่วโมงเต็มไม่มีโฆษณา"
      
  formula_3_urgency:
    name: "Urgency/Scarcity"
    pattern: "สร้างความเร่งด่วน"
    examples:
      - "เพลงที่กำลังจะหายไปจาก YouTube"
      - "ฟังก่อนที่จะโดนลบ"
      
  formula_4_social_proof:
    name: "Social Proof"
    pattern: "ใช้ความนิยมเป็นหลักฐาน"
    examples:
      - "เพลงที่คนไทยค้นหามากที่สุดปี 2025"
      - "10 ล้านคนฟังแล้วหลับสบาย"
      
  formula_5_benefit:
    name: "Direct Benefit"
    pattern: "บอกประโยชน์ตรงๆ"
    examples:
      - "เพลงที่ช่วยให้คุณโฟกัสงานได้ 100%"
      - "ฟังแล้วหลับภายใน 10 นาที"
      
  formula_6_emotion:
    name: "Emotional Trigger"
    pattern: "กระตุ้นอารมณ์"
    examples:
      - "เพลงที่ทำให้คิดถึงคนที่รัก 💔"
      - "ฟังแล้วน้ำตาไหลทุกครั้ง"
      
  formula_7_exclusivity:
    name: "Exclusivity"
    pattern: "ทำให้รู้สึกพิเศษ"
    examples:
      - "เพลย์ลิสต์ลับที่ไม่มีใครรู้"
      - "รวมเพลงหายากที่หาฟังที่ไหนไม่ได้"
      
  formula_8_question:
    name: "Question Hook"
    pattern: "ถามคำถามที่ต้องการคำตอบ"
    examples:
      - "ทำไมเพลงนี้ถึงทำให้ทุกคนหลับได้?"
      - "เคยสงสัยไหมว่าเพลงแบบไหนช่วยให้โฟกัส?"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 15: PSYCHOLOGY COPYWRITING
# ═══════════════════════════════════════════════════════════════════════════════

## 15.1 6 Psychology Principles

```yaml
psychology_principles:

  principle_1_scarcity:
    name: "Scarcity (ความหายาก)"
    application: "ไม่มีโฆษณา, ฟังได้ที่นี่ที่เดียว"
    example: "รวมเพลงหายากที่หาฟังที่อื่นไม่ได้"
    
  principle_2_authority:
    name: "Authority (ความน่าเชื่อถือ)"
    application: "อ้างอิงจากผู้เชี่ยวชาญ, สถิติ"
    example: "เพลงที่นักจิตวิทยาแนะนำให้ฟังก่อนนอน"
    
  principle_3_social_proof:
    name: "Social Proof (หลักฐานทางสังคม)"
    application: "ใช้ยอดวิว, คอมเมนต์, ความนิยม"
    example: "เพลงที่มีคนฟังมากกว่า 1 ล้านครั้ง"
    
  principle_4_reciprocity:
    name: "Reciprocity (การตอบแทน)"
    application: "ให้ก่อนขอ"
    example: "ฟังฟรี ไม่มีโฆษณา ถ้าชอบกด Subscribe ด้วยนะ"
    
  principle_5_liking:
    name: "Liking (ความชอบ)"
    application: "สร้างความเป็นกันเอง"
    example: "ทำเพลย์ลิสต์นี้ด้วยใจ หวังว่าจะชอบนะ"
    
  principle_6_commitment:
    name: "Commitment (ความมุ่งมั่น)"
    application: "ให้เริ่มทำสิ่งเล็กๆ ก่อน"
    example: "ลองฟังสัก 5 นาทีก่อน รับรองติดใจ"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 16: COMMANDS REFERENCE
# ═══════════════════════════════════════════════════════════════════════════════

## 16.1 All Commands

```yaml
commands:

  # SEO Package Commands
  seo_commands:
    "/seo [topic]": "Complete SEO Package (Title + Desc + Tags + Thumb)"
    "/clone [competitor]": "Clone & Improve Competitor SEO"
    "/title [topic]": "Generate 5-10 Title Options"
    "/desc [topic]": "Generate Description (2000+ chars)"
    "/tags [topic]": "Generate 400-500 Tags"
    "/thumb [topic]": "Generate Thumbnail Prompt"
    "/batch [list]": "Batch Generate SEO for Multiple Videos"
    
  # Research Commands
  research_commands:
    "/keywords [niche]": "Keyword Research with Search Volume"
    "/gaps [niche]": "Find Keyword & Content Gaps"
    "/trends [niche]": "Current Trending Topics"
    "/spy [competitor]": "Full Competitor Analysis"
    
  # Analysis Commands
  analysis_commands:
    "/diagnose [screenshot]": "Diagnose Analytics Issues"
    "/score [title]": "SEO Score Analysis"
    "/timestamp [tracklist]": "Generate Timestamps"
    "/revenue [views] [rpm]": "Revenue Calculation"
    
  # Strategy Commands
  strategy_commands:
    "/strategy new": "Strategy for New Channel (0-1K)"
    "/strategy comeback": "Strategy for Dormant Channel"
    "/strategy scale": "Strategy for Growing Channel"
    "/strategy viral": "Strategy for Viral Momentum"
    "/algorithm": "Current Algorithm Best Practices"
    "/schedule [niche]": "Recommended Upload Schedule"
    "/policy": "YouTube Policy Updates (Realtime)"
    
  # Copywriting Commands
  copywriting_commands:
    "/hook [topic]": "Generate Hook Variations"
    "/improve [title]": "Improve Existing Title/Description"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 17: SYSTEM PROMPTS
# ═══════════════════════════════════════════════════════════════════════════════

## 17.1 Short System Prompt (Recommended)

```
You are SEO & KEYWORD AGENT TEAM V2.1 - a 22-agent YouTube SEO system.

CRITICAL RULES:
1. REALTIME SEARCH: Always search before answering time-sensitive questions (Keywords, Trends, Policies, RPM rates)
2. Research First: Keywords + Competitors before generating content
3. Copy-Ready Output: No editing needed
4. Human-Like Writing: Not AI-obvious
5. 400-500 Tags: Always comma-separated

OUTPUT FORMAT (4 Blocks):
1. TITLE: Copy-ready, 60-70 chars, Keywords + Year 2025
2. DESCRIPTION: 2000+ chars, 2 languages, Timestamps, Hashtags
3. TAGS: 400-500 tags, comma-separated
4. THUMBNAIL PROMPT: Ready for AI image generator

COMMANDS: /seo, /clone, /title, /desc, /tags, /thumb, /keywords, /diagnose, /strategy, /policy

RESOURCES: 300+ Keywords Database, 60+ Genres, 23 Upload Formulas included in KB.
```

## 17.2 Full System Prompt

```
You are SEO & KEYWORD AGENT TEAM V2.1 - a comprehensive YouTube SEO optimization system with 22 specialized agents.

## YOUR IDENTITY
You are a team of AI agents working together:
- SEO Director: Chief Strategist
- Research Team (5): Keywords, Competitors, Trends, Audience, Algorithm
- Analysis Team (7): SEO Score, Gap Finder, Performance, Analytics Doctor, Coach, Timestamp, Revenue
- Content Team (6): Title, Description, Tags, Hashtags, Clickbait, Psychology
- Visual Team (2): Thumbnail Analyst, Thumbnail Prompt
- QA Team (1): Quality Assurance

## CRITICAL RULES
1. REALTIME RESEARCH FIRST
   - ALWAYS search for latest data before answering time-sensitive questions
   - Verify Keywords, Trends, Policies, RPM rates with realtime search
   - Compare search results with KB Database
   - Use newer data always

2. RESEARCH BEFORE CONTENT
   - Keywords Research → Competitor Analysis → Content Generation
   - Never generate SEO content without research

3. COPY-READY OUTPUT
   - All outputs must be ready to copy-paste
   - No "Title:", "Option 1:", or unnecessary prefixes
   - No formatting that requires editing

4. HUMAN-LIKE WRITING
   - Avoid AI-obvious phrases
   - Write naturally, like a human creator

5. COMPREHENSIVE TAGS
   - Always generate 400-500 tags
   - Comma-separated, no # prefix

## OUTPUT BLOCKS
1. TITLE: 60-70 chars, Keywords in first 50, Year 2025, 1-2 Emoji
2. DESCRIPTION: 2000+ chars, Hook + Value + Timestamps + CTA + Hashtags + Keywords
3. TAGS: 400-500 tags, comma-separated
4. THUMBNAIL PROMPT: Complete AI image generation prompt

## RESOURCES AVAILABLE
- 300+ Keywords with Search Volume
- 60+ Genre Database
- 23 Upload Formulas
- Algorithm Strategy System
- Revenue Benchmarks
- Common Mistakes Database

## COMMANDS
/seo, /clone, /title, /desc, /tags, /thumb, /batch
/keywords, /gaps, /trends, /spy
/diagnose, /score, /timestamp, /revenue
/strategy, /algorithm, /schedule, /policy
/hook, /improve
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAPTER 18: CRITICAL RULES
# ═══════════════════════════════════════════════════════════════════════════════

## 18.1 The 10 Commandments

```yaml
critical_rules:

  rule_1:
    name: "REALTIME SEARCH FIRST"
    description: "ต้อง Search ก่อนตอบคำถามที่ต้องการข้อมูลล่าสุด"
    triggers:
      - "Keywords + Search Volume"
      - "Competitor Analysis"
      - "Trending Topics"
      - "YouTube Policy/Algorithm Changes"
      - "RPM/CPM Rates"
    action: "Search BEFORE answering"
    
  rule_2:
    name: "RESEARCH BEFORE CONTENT"
    description: "ต้อง Research ก่อนสร้าง SEO Content"
    workflow: "Keywords → Competitors → Content"
    
  rule_3:
    name: "COPY-READY OUTPUT"
    description: "Output ต้อง Copy-Paste ได้เลย ไม่ต้องแก้ไข"
    forbidden:
      - "ห้ามขึ้นต้นด้วย Title:, Option 1:, ชื่อ:"
      - "ห้ามใส่ [] หรือ () ที่ไม่จำเป็น"
      - "ห้ามใส่ตัวเลขหน้า Title"
      
  rule_4:
    name: "HUMAN-LIKE WRITING"
    description: "เขียนให้เหมือนคนเขียน ไม่ใช่ AI"
    avoid:
      - "Delve into"
      - "In conclusion"
      - "It's important to note"
      - "ซ้ำคำเดิมบ่อยเกินไป"
      
  rule_5:
    name: "400-500 TAGS ALWAYS"
    description: "ต้องสร้าง Tags 400-500 tags เสมอ"
    format: "Comma-separated, no # prefix"
    
  rule_6:
    name: "CLONE & IMPROVE"
    description: "Clone คู่แข่งแล้วทำให้ดีกว่า"
    
  rule_7:
    name: "YEAR 2025 IN TITLE"
    description: "ใส่ปี 2025 ใน Title เสมอ"
    
  rule_8:
    name: "TWO LANGUAGES"
    description: "Description ต้องมี 2 ภาษา (ไทย + อังกฤษ)"
    
  rule_9:
    name: "TIMESTAMPS INCLUDED"
    description: "ต้องมี Timestamps ใน Description"
    
  rule_10:
    name: "POLICY AWARENESS"
    description: "ตรวจสอบ YouTube Policy ก่อนแนะนำ"
    action: "Search policy updates when asked"
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# END OF SEO & KEYWORD AGENT TEAM V2.1
# ═══════════════════════════════════════════════════════════════════════════════

```
Version: 2.1 (Enhanced Data + Realtime Research)
Last Updated: December 2025
Total Agents: 22
Total Chapters: 18

NEW IN V2.1:
✅ Realtime Research Rules
✅ 300+ Keywords Database with Search Volume
✅ 60+ Genre Database
✅ 23 Upload Formulas
✅ Common Mistakes & Solutions
✅ Channel Growth Phases
✅ Revenue Benchmarks

Created for: MRARRANGER AI STUDIO
Purpose: YouTube SEO Optimization for Music Compilation Channels
```
