---
name: mrarranger-api-master
description: "API Design & Integration Mastery - Comprehensive guide covering REST (HATEOAS, versioning, content negotiation), GraphQL (schema, resolvers, subscriptions), tRPC (type-safe), WebSocket (real-time), gRPC (Protocol Buffers), API Gateway patterns, Webhook design, documentation (OpenAPI), authentication (OAuth2, JWT), error handling, testing, caching strategies, and API security (OWASP Top 10). Includes practical TypeScript examples."
---

# 🌐 mrarranger API Master: API Design & Integration

**ความเชี่ยวชาญด้าน API Architecture & Implementation** | Comprehensive REST, GraphQL, tRPC, WebSocket, gRPC Expertise

---

## 📋 Quick Navigation


| Topic | Command |
|-------|---------|
| **REST API Advanced** | `/api-design` |
| **GraphQL Mastery** | `/graphql` |
| **tRPC Type-Safe APIs** | `/trpc` |
| **WebSocket Real-Time** | `/websocket` |
| **gRPC Protocol Buffers** | `/grpc` |
| **Webhook Design** | `/webhook` |
| **API Documentation** | `/api-doc` |
| **API Testing & Performance** | `/api-test` |

---

## 1️⃣ REST API Advanced Patterns

### HATEOAS (Hypermedia As The Engine Of Application State)

**แนวคิด**: ให้ API หลีกเลี่ยงการ hardcode URLs โดยส่ง links ในทุก response

```typescript
// REST API with HATEOAS
interface HALResource<T> {
  _embedded?: Record<string, any>;
  _links: {
    self: { href: string };
    next?: { href: string };
    prev?: { href: string };
    [key: string]: { href: string };
  };
  data: T;
}

app.get('/api/users/:id', (req, res) => {
  const user = { id: req.params.id, name: 'User Name' };
  res.json({
    data: user,
    _links: {
      self: { href: `/api/users/${user.id}` },
      all: { href: `/api/users` },
      posts: { href: `/api/users/${user.id}/posts` },
    },
  });
});
```

### Content Negotiation

**Content-Type Negotiation**: Support multiple formats (JSON, XML, Protobuf)

```typescript
app.use((req, res, next) => {
  const accept = req.headers.accept || 'application/json';

  if (accept.includes('application/xml')) {
    res.type('application/xml');
  } else if (accept.includes('application/protobuf')) {
    res.type('application/protobuf');
  }
  next();
});

app.get('/api/data', (req, res) => {
  const data = { id: 1, name: 'Example' };
  if (res.type().includes('xml')) {
    return res.send(`<data><id>${data.id}</id></data>`);
  }
  res.json(data);
});
```

### Pagination Patterns

**Cursor-Based Pagination** (efficient for large datasets)

```typescript
app.get('/api/items', (req, res) => {
  const cursor = req.query.cursor || '0';
  const limit = parseInt(req.query.limit as string) || 20;

  const items = fetchItems(parseInt(cursor as string), limit + 1);
  const hasMore = items.length > limit;

  res.json({
    items: items.slice(0, limit),
    pageInfo: {
      endCursor: items[limit - 1]?.id,
      hasNextPage: hasMore,
    },
  });
});
```

### API Versioning Strategies

```typescript
// URL-based versioning
app.get('/api/v1/users', (req, res) => { /* v1 logic */ });
app.get('/api/v2/users', (req, res) => { /* v2 logic */ });

// Header-based versioning
app.get('/api/users', (req, res) => {
  const version = req.headers['api-version'] || '1';
  if (version === '2') {
    // v2 response format
  }
  res.json({});
});

// Query parameter versioning
app.get('/api/users?version=2', (req, res) => {
  const version = req.query.version || '1';
  res.json({});
});
```

---

## 2️⃣ GraphQL Mastery

### Schema Design & Resolvers

**ออกแบบ Schema ที่ดี**: Avoid N+1 queries, use DataLoader

```typescript
import { buildSchema, graphql, GraphQLObjectType, GraphQLField, GraphQLList, DataLoader } from 'graphql';

const userLoader = new DataLoader(async (userIds) => {
  const users = await db.users.findMany({ where: { id: { in: userIds } } });
  return userIds.map(id => users.find(u => u.id === id));
});

const schema = buildSchema(`
  type User {
    id: ID!
    name: String!
    posts: [Post!]!
  }

  type Post {
    id: ID!
    title: String!
    author: User!
  }

  type Query {
    user(id: ID!): User
    posts: [Post!]!
  }

  type Mutation {
    createPost(title: String!, authorId: ID!): Post!
  }

  type Subscription {
    postCreated: Post!
  }
`);

const resolvers = {
  Query: {
    user: (_, { id }) => db.users.findById(id),
    posts: () => db.posts.findAll(),
  },
  Mutation: {
    createPost: async (_, { title, authorId }) => {
      const post = await db.posts.create({ title, authorId });
      pubsub.publish('POST_CREATED', { postCreated: post });
      return post;
    },
  },
  Subscription: {
    postCreated: {
      subscribe: () => pubsub.asyncIterator(['POST_CREATED']),
    },
  },
  Post: {
    author: (post) => userLoader.load(post.authorId),
  },
};
```

### Apollo Server Setup

```typescript
import ApolloServer from '@apollo/server';

const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: async ({ req }) => ({
    userId: req.headers['x-user-id'],
    userLoader,
  }),
  plugins: {
    didResolveOperation: async (requestContext) => {
      console.log('Operation:', requestContext.operationName);
    },
  },
});

await server.start();
app.use('/graphql', expressMiddleware(server));
```

---

## 3️⃣ tRPC Type-Safe APIs

**ระบบ API ที่ type-safe ในฝั่ง client และ server**

```typescript
import { initTRPC } from '@trpc/server';

const t = initTRPC.create();
const procedure = t.procedure;
const router = t.router;

// Define procedures
export const userRouter = router({
  getById: procedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      return db.users.findById(input.id);
    }),

  create: procedure
    .input(z.object({ name: z.string(), email: z.string().email() }))
    .mutation(async ({ input, ctx }) => {
      return db.users.create(input);
    }),

  onUserCreated: procedure
    .subscription(async function* ({ ctx }) {
      for await (const user of ctx.userEvents) {
        yield user;
      }
    }),
});

export const appRouter = router({
  user: userRouter,
});

// Client-side (fully typed!)
type AppRouter = typeof appRouter;
const client = createTRPCClient<AppRouter>({
  links: [httpBatchLink({ url: 'http://localhost:3000/trpc' })],
});

const user = await client.user.getById.query({ id: '1' });
```

---

## 4️⃣ WebSocket Real-Time Communication

**การสื่อสารแบบเรียลไทม์ด้วย Socket.io**

```typescript
import { Server as SocketIOServer } from 'socket.io';

const io = new SocketIOServer(httpServer, {
  cors: { origin: 'http://localhost:3000' },
});

// Authentication middleware
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error('Auth required'));
  socket.userId = verifyToken(token).id;
  next();
});

io.on('connection', (socket) => {
  socket.on('message', (data) => {
    io.to(data.roomId).emit('message', {
      userId: socket.userId,
      text: data.text,
      timestamp: new Date(),
    });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.userId);
  });
});

// Reconnection strategy with exponential backoff
const client = io('http://localhost:3000', {
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
  reconnectionAttempts: 5,
});
```



## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations and advanced patterns, see:

- **advanced-patterns.md**: Advanced techniques and detailed examples

