---
name: mrarranger-ui-system
description: |
  MRARRANGER UI System - ระบบ UI Component Library ครบวงจร (Shadcn/UI + Tailwind CSS)
  รวม Component Patterns, Design Tokens, Tailwind Best Practices, Dark Mode, Theming
  ให้ Claude สร้าง UI Components ที่ consistent, accessible, และ production-ready
  ใช้เมื่อ: (1) สร้าง UI components (2) ใช้ Shadcn/UI (3) Tailwind CSS patterns
  (4) สร้าง Design System (5) Dark mode (6) Theming (7) Form components
  (8) อะไรก็ตามที่เกี่ยวกับ UI components, Tailwind, Shadcn, design tokens
  Commands: /ui [component], /shadcn [component], /tailwind [pattern], /theme [style], /token [type], /dark [mode]
---

# MRARRANGER UI System

ระบบสร้าง UI Components ด้วย Shadcn/UI + Tailwind CSS ที่ consistent และ production-ready

## Quick Commands

```
/ui [component]         → สร้าง UI component
/shadcn [component]     → ใช้ Shadcn/UI component
/tailwind [pattern]     → Tailwind CSS pattern
/theme [style]          → Custom theme/branding
/token [type]           → Design tokens
/dark [mode]            → Dark mode implementation
/form [type]            → Form component
```

---

## Tailwind CSS Best Practices

### Class Organization Order
```html
<!-- เรียง class ตามลำดับนี้ -->
<div class="
  [layout]      flex items-center justify-between
  [sizing]      w-full h-12 max-w-lg
  [spacing]     p-4 mx-auto mt-8 gap-4
  [typography]  text-lg font-semibold text-gray-900
  [background]  bg-white
  [border]      border border-gray-200 rounded-lg
  [effects]     shadow-sm
  [transitions] transition-all duration-200
  [states]      hover:bg-gray-50 focus:ring-2
  [responsive]  md:flex-row md:p-6
  [dark]        dark:bg-gray-900 dark:text-white
">
```

### Common Patterns
```html
<!-- Card -->
<div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm
            dark:border-gray-800 dark:bg-gray-950">
  <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Title</h3>
  <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Description</p>
</div>

<!-- Button Primary -->
<button class="inline-flex items-center justify-center rounded-lg bg-indigo-600 px-4 py-2.5
               text-sm font-medium text-white shadow-sm
               hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
               disabled:opacity-50 disabled:cursor-not-allowed
               transition-colors duration-200">
  Click Me
</button>

<!-- Input -->
<input class="w-full rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm
              placeholder:text-gray-400
              focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20
              dark:border-gray-700 dark:bg-gray-900 dark:text-white" />

<!-- Badge -->
<span class="inline-flex items-center rounded-full bg-indigo-50 px-2.5 py-0.5
             text-xs font-medium text-indigo-700
             dark:bg-indigo-900/30 dark:text-indigo-400">
  Badge
</span>
```

---

## Shadcn/UI Integration

### Setup
```bash
npx shadcn@latest init
# เลือก: New York style, Zinc color, CSS variables: yes
```

### Most Used Components
```bash
# Install commonly needed components
npx shadcn@latest add button input label card dialog dropdown-menu
npx shadcn@latest add table tabs toast form select checkbox
npx shadcn@latest add avatar badge separator skeleton sheet
```

### Component Usage Patterns

```tsx
// Button variants
import { Button } from "@/components/ui/button";

<Button variant="default">Primary</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="outline">Outline</Button>
<Button variant="ghost">Ghost</Button>
<Button variant="destructive">Delete</Button>
<Button variant="link">Link</Button>
<Button size="sm">Small</Button>
<Button size="lg">Large</Button>
<Button disabled>Disabled</Button>
<Button className="w-full">Full Width</Button>

// Card
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";

<Card>
  <CardHeader>
    <CardTitle>Card Title</CardTitle>
    <CardDescription>Card description here</CardDescription>
  </CardHeader>
  <CardContent>
    <p>Content goes here</p>
  </CardContent>
  <CardFooter>
    <Button>Action</Button>
  </CardFooter>
</Card>

// Dialog (Modal)
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

<Dialog>
  <DialogTrigger asChild>
    <Button>Open Modal</Button>
  </DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Modal Title</DialogTitle>
    </DialogHeader>
    <p>Modal content here</p>
  </DialogContent>
</Dialog>
```

---

## Design Tokens (CSS Variables)

### Tailwind Config with CSS Variables
```css
/* globals.css */
@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 240 10% 3.9%;
    --card: 0 0% 100%;
    --card-foreground: 240 10% 3.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 240 10% 3.9%;
    --primary: 240 5.9% 10%;
    --primary-foreground: 0 0% 98%;
    --secondary: 240 4.8% 95.9%;
    --secondary-foreground: 240 5.9% 10%;
    --muted: 240 4.8% 95.9%;
    --muted-foreground: 240 3.8% 46.1%;
    --accent: 240 4.8% 95.9%;
    --accent-foreground: 240 5.9% 10%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 0 0% 98%;
    --border: 240 5.9% 90%;
    --input: 240 5.9% 90%;
    --ring: 240 5.9% 10%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 240 10% 3.9%;
    --foreground: 0 0% 98%;
    --card: 240 10% 3.9%;
    --card-foreground: 0 0% 98%;
    --primary: 0 0% 98%;
    --primary-foreground: 240 5.9% 10%;
    --secondary: 240 3.7% 15.9%;
    --secondary-foreground: 0 0% 98%;
    --muted: 240 3.7% 15.9%;
    --muted-foreground: 240 5% 64.9%;
    --border: 240 3.7% 15.9%;
    --input: 240 3.7% 15.9%;
  }
}
```

### Custom Brand Theme
```css
/* Purple/Indigo theme (like MRARRANGER) */
:root {
  --primary: 245 58% 51%;          /* Indigo */
  --primary-foreground: 0 0% 100%;
  --accent: 187 92% 69%;           /* Cyan */
  --accent-foreground: 240 10% 3.9%;
}

/* Thai Gold theme */
:root {
  --primary: 43 75% 46%;           /* Gold */
  --primary-foreground: 0 0% 100%;
  --accent: 210 50% 30%;           /* Royal Blue */
}
```

---

## Dark Mode Implementation

### Next.js + next-themes
```bash
npm install next-themes
```

```tsx
// app/layout.tsx
import { ThemeProvider } from 'next-themes';

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}

// components/theme-toggle.tsx
'use client';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Moon, Sun } from 'lucide-react';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  return (
    <Button variant="ghost" size="icon"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
      <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
    </Button>
  );
}
```

### Dark Mode Rules
```
1. ใช้ CSS Variables (ไม่ hardcode colors)
2. ทุก text color ต้องมี dark: variant
3. Border colors ต้อง adjust
4. Background ต้อง layered (bg → surface → elevated)
5. ห้ามใช้ pure black (#000) → ใช้ dark gray (#0a0a0f, #111827)
6. Shadows ต้อง adjust (เข้มขึ้นใน dark mode)
7. Images/illustrations อาจต้องมี dark variant
```

---

## Common Page Layouts

### Dashboard Page
```tsx
export default function DashboardPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-card p-4">
        <nav className="space-y-1">
          <NavItem icon={Home} label="Dashboard" active />
          <NavItem icon={Users} label="Users" />
          <NavItem icon={Settings} label="Settings" />
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 p-8">
        <h1 className="text-2xl font-bold">Dashboard</h1>

        {/* Stats Grid */}
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Revenue" value="฿125,430" change="+12.5%" />
          <StatCard title="Users" value="1,234" change="+5.2%" />
          <StatCard title="Orders" value="456" change="+8.1%" />
          <StatCard title="Conversion" value="3.2%" change="-0.4%" />
        </div>

        {/* Content */}
        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Revenue Chart</CardTitle></CardHeader>
            <CardContent>{/* Chart */}</CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Recent Orders</CardTitle></CardHeader>
            <CardContent>{/* List */}</CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
```

### Settings Page
```tsx
export default function SettingsPage() {
  return (
    <div className="mx-auto max-w-2xl space-y-8 p-8">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings</p>
      </div>

      <Separator />

      {/* Profile Section */}
      <section className="space-y-4">
        <h2 className="text-lg font-medium">Profile</h2>
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" defaultValue="John Doe" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" defaultValue="john@example.com" />
          </div>
        </div>
      </section>

      <Separator />

      {/* Danger Zone */}
      <section className="space-y-4">
        <h2 className="text-lg font-medium text-destructive">Danger Zone</h2>
        <Button variant="destructive">Delete Account</Button>
      </section>
    </div>
  );
}
```

---

## Component Quality Checklist

```
ACCESSIBILITY:
□ Keyboard navigable (Tab, Enter, Escape)
□ Screen reader labels (aria-label, role)
□ Focus visible styles
□ Color contrast ≥ 4.5:1

RESPONSIVE:
□ Works on 320px-1920px
□ Touch targets ≥ 44px on mobile
□ No horizontal scroll

STATES:
□ Default, Hover, Focus, Active, Disabled
□ Loading state (skeleton/spinner)
□ Empty state
□ Error state

DARK MODE:
□ All colors have dark variants
□ Contrast maintained in dark mode
□ No flash on page load (suppressHydrationWarning)

PERFORMANCE:
□ Minimal DOM elements
□ CSS-only animations where possible
□ No unnecessary re-renders
□ Lazy load heavy components
```
