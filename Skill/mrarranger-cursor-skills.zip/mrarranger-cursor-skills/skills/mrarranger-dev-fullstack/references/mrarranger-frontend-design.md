---
name: mrarranger-frontend-design
description: |
  MRARRANGER Frontend Design System - ระบบออกแบบ Frontend ระดับมืออาชีพ 50+ Visual Styles
  รวม Typography System, Color Palettes, Animations, Layout Patterns, Responsive Design
  ให้ Claude สร้าง UI/UX ที่สวยงามจริง ไม่ใช่ generic - มี aesthetic เหมือน designer ระดับ senior
  ใช้เมื่อ: (1) สร้าง UI ที่สวย (2) เลือก design style (3) จัด typography (4) เลือก color palette
  (5) เพิ่ม animation (6) ทำ responsive design (7) สร้าง landing page (8) ออกแบบ component
  ใช้ skill นี้ทุกครั้งที่ต้องสร้าง HTML/CSS/React ที่ต้องการความสวยงาม แม้ user ไม่ได้บอกชัดเจน
  Commands: /style [name], /palette [mood], /type [font], /animate [element], /responsive [layout], /landing [product]
---

# MRARRANGER Frontend Design System

ระบบนี้ทำให้ Claude สร้าง Frontend ที่มี design quality ระดับมืออาชีพ ไม่ใช่แค่ functional แต่ต้อง beautiful

## Quick Commands

```
/style [name]           → เลือก visual style (50+ styles)
/palette [mood]         → สร้าง color palette
/type [purpose]         → เลือก typography system
/animate [element]      → เพิ่ม animation
/responsive [layout]    → ทำ responsive design
/landing [product]      → สร้าง landing page
/component [name]       → ออกแบบ component
/dark [toggle]          → สร้าง dark mode
```

---

## Design Philosophy

### Core Principles
1. **Bold Aesthetic Choices** - อย่ากลัวที่จะ bold, ทุก design ต้องมี personality
2. **Typography First** - Font คือ 80% ของ design ที่ดี
3. **Purposeful Color** - ทุกสีต้องมีเหตุผล ไม่ใช่แค่สวย
4. **Intentional Animation** - Animation ต้อง enhance UX ไม่ใช่แค่ flashy
5. **Whitespace is Design** - พื้นที่ว่างสร้าง hierarchy ได้ดีกว่า border

---

## Visual Styles Library (50+ Styles)

### Minimal & Clean
| Style | ลักษณะ | ใช้กับ |
|-------|--------|--------|
| Swiss | Grid-based, Helvetica, black/white/red | Corporate, Portfolio |
| Scandinavian | Soft colors, lots of whitespace, rounded | Lifestyle, Wellness |
| Japanese | Asymmetric, muted tones, delicate | Art, Culture |
| Brutalist Minimal | Raw typography, monospace, stark contrast | Tech, Design Agency |

### Bold & Expressive
| Style | ลักษณะ | ใช้กับ |
|-------|--------|--------|
| Neo-Brutalism | Thick borders, bright colors, raw shadows | SaaS, Startup |
| Memphis | Geometric shapes, bold patterns, playful | Creative, Youth |
| Retro-Futurism | Neon gradients, dark bg, glow effects | AI, Tech, Gaming |
| Maximalist | Layer everything, bold type, rich texture | Fashion, Art |

### Professional & Corporate
| Style | ลักษณะ | ใช้กับ |
|-------|--------|--------|
| Enterprise | Blue/gray, clean grid, data-dense | B2B, Finance |
| Modern Corporate | Gradient accents, card-based, professional | SaaS, Consulting |
| Dashboard | Data-first, minimal chrome, functional | Analytics, Admin |
| Government | Accessible, high contrast, structured | Public Sector |

### Creative & Artistic
| Style | ลักษณะ | ใช้กับ |
|-------|--------|--------|
| Editorial | Magazine-like, dramatic type, columns | Blog, News, Media |
| Gallery | Image-centric, minimal text, immersive | Photography, Portfolio |
| Glassmorphism | Frosted glass, blur, transparency | Modern App UI |
| Neumorphism | Soft shadows, extruded, tactile | Mobile, Dashboard |
| Gradient Mesh | Complex gradients, organic shapes | Landing, Brand |

### Thai & Southeast Asian
| Style | ลักษณะ | ใช้กับ |
|-------|--------|--------|
| Thai Modern | ลายไทยประยุกต์, สีทอง/น้ำเงิน, Sarabun font | Thai Brand |
| Thai Minimal | Clean + Thai elements, Prompt font | Thai Startup |
| Bangkok Neon | Neon colors, street culture, vibrant | Entertainment, Food |
| SEA Tropical | Warm colors, organic shapes, lush | Tourism, Lifestyle |

---

## Typography System

### Font Pairing Rules
```
RULE 1: ใช้ไม่เกิน 2-3 fonts
  - Heading font (display/serif)
  - Body font (sans-serif)
  - Code font (monospace) - ถ้าจำเป็น

RULE 2: Contrast ระหว่าง heading กับ body
  - Serif heading + Sans body (classic)
  - Bold sans heading + Light sans body (modern)
  - Display heading + Clean body (dramatic)

RULE 3: Type Scale (1.25 ratio recommended)
  - h1: 3rem (48px)
  - h2: 2.4rem (38px)
  - h3: 1.9rem (30px)
  - h4: 1.5rem (24px)
  - body: 1.125rem (18px)
  - small: 0.875rem (14px)
```

### Recommended Font Pairings
```css
/* Modern SaaS */
--font-heading: 'Inter', sans-serif;
--font-body: 'Inter', sans-serif;
/* Weights: 400, 500, 600, 700 */

/* Editorial/Premium */
--font-heading: 'Playfair Display', serif;
--font-body: 'Source Sans 3', sans-serif;

/* Tech/Developer */
--font-heading: 'Space Grotesk', sans-serif;
--font-body: 'Inter', sans-serif;
--font-code: 'JetBrains Mono', monospace;

/* Creative/Bold */
--font-heading: 'Clash Display', sans-serif;
--font-body: 'Satoshi', sans-serif;

/* Thai Content */
--font-heading: 'Prompt', sans-serif;
--font-body: 'Sarabun', sans-serif;

/* Thai Premium */
--font-heading: 'Kanit', sans-serif;
--font-body: 'Prompt', sans-serif;
```

### Line Height & Spacing
```css
/* Body text */
line-height: 1.6-1.8;
letter-spacing: -0.01em;
max-width: 65ch; /* optimal reading width */

/* Headings */
line-height: 1.1-1.3;
letter-spacing: -0.02em to -0.04em; /* tighter for large text */
```

---

## Color System

### Building a Palette
```
1. เลือก Primary Color (brand color หลัก)
2. สร้าง Shades: 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950
3. เลือก Accent Color (complementary หรือ analogous)
4. กำหนด Neutrals (gray scale)
5. กำหนด Semantic Colors (success, warning, error, info)
```

### Pre-built Palettes

```css
/* Midnight Ocean - สำหรับ Tech/AI/SaaS */
--primary-500: #6366f1;  /* Indigo */
--accent-500: #06b6d4;   /* Cyan */
--bg: #0f172a;           /* Slate 900 */
--surface: #1e293b;      /* Slate 800 */
--text: #f1f5f9;         /* Slate 100 */

/* Warm Sunrise - สำหรับ Lifestyle/Health */
--primary-500: #f97316;  /* Orange */
--accent-500: #ec4899;   /* Pink */
--bg: #fffbeb;           /* Amber 50 */
--surface: #ffffff;
--text: #1c1917;         /* Stone 900 */

/* Forest Calm - สำหรับ Eco/Wellness */
--primary-500: #22c55e;  /* Green */
--accent-500: #14b8a6;   /* Teal */
--bg: #f0fdf4;           /* Green 50 */
--surface: #ffffff;
--text: #1a2e05;

/* Thai Gold - สำหรับ Thai Premium Brand */
--primary-500: #d4a017;  /* Thai Gold */
--accent-500: #1e3a5f;   /* Royal Blue */
--bg: #0d1117;
--surface: #1a1a2e;
--text: #f5f5f5;

/* Neon Pulse - สำหรับ Creative/Gaming */
--primary-500: #a855f7;  /* Purple */
--accent-500: #22d3ee;   /* Cyan */
--bg: #0a0a0f;
--surface: #111827;
--text: #e0e0e0;
```

### Dark Mode Strategy
```css
/* Light → Dark conversion */
--bg:      white      → #0f172a
--surface: #f8fafc    → #1e293b
--border:  #e2e8f0    → #334155
--text:    #0f172a    → #f1f5f9
--muted:   #64748b    → #94a3b8
/* Primary color stays same, slightly lighter in dark */
```

---

## Animation System

### Entrance Animations (ใช้กับ scroll-reveal)
```css
/* Fade Up - ใช้บ่อยที่สุด universal */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
.fade-up { animation: fadeUp 0.6s ease-out forwards; }

/* Slide In - สำหรับ side panels/drawers */
@keyframes slideIn {
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: translateX(0); }
}

/* Scale Up - สำหรับ cards/modals */
@keyframes scaleUp {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}

/* Stagger children - สำหรับ lists/grids */
.stagger > * {
  opacity: 0;
  animation: fadeUp 0.5s ease-out forwards;
}
.stagger > *:nth-child(1) { animation-delay: 0.1s; }
.stagger > *:nth-child(2) { animation-delay: 0.2s; }
.stagger > *:nth-child(3) { animation-delay: 0.3s; }
/* ... */
```

### Micro-interactions
```css
/* Button hover - subtle lift */
.btn { transition: all 0.2s ease; }
.btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

/* Card hover - glow effect */
.card { transition: all 0.3s ease; }
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 40px rgba(99, 102, 241, 0.15);
}

/* Link underline animation */
.link { text-decoration: none; position: relative; }
.link::after {
  content: ''; position: absolute; bottom: -2px; left: 0;
  width: 0; height: 2px; background: var(--primary-500);
  transition: width 0.3s ease;
}
.link:hover::after { width: 100%; }
```

### Animation Rules
```
DO:
- ใช้ ease-out สำหรับ entrance
- ใช้ ease-in-out สำหรับ state changes
- Duration: 150-300ms สำหรับ micro, 300-600ms สำหรับ entrance
- ใช้ transform + opacity (GPU accelerated)
- Stagger delay: 50-100ms ระหว่าง elements

DON'T:
- Animation > 1 second (ยกเว้น page transitions)
- Animate layout properties (width, height, top, left)
- ใช้ animation กับทุก element (เลือกเฉพาะที่สำคัญ)
- Bounce/elastic effects บน UI ปกติ (ใช้เฉพาะ playful brands)
```

---

## Responsive Design System

### Breakpoints
```css
/* Mobile First */
--mobile: 320px;    /* min */
--tablet: 768px;
--laptop: 1024px;
--desktop: 1280px;
--wide: 1536px;
```

### Layout Patterns
```css
/* Fluid Container */
.container {
  width: min(90%, 1200px);
  margin: 0 auto;
  padding: 0 1rem;
}

/* Responsive Grid */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

/* Stack on Mobile, Side-by-side on Desktop */
.split {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}
@media (min-width: 768px) {
  .split { flex-direction: row; }
  .split > * { flex: 1; }
}
```

### Responsive Typography
```css
/* Fluid type scale using clamp */
h1 { font-size: clamp(2rem, 5vw, 3.5rem); }
h2 { font-size: clamp(1.5rem, 4vw, 2.5rem); }
h3 { font-size: clamp(1.25rem, 3vw, 1.75rem); }
body { font-size: clamp(1rem, 1.5vw, 1.125rem); }
```

---

## Landing Page Formula

### Structure (proven high-conversion)
```
1. HERO
   - Headline (value prop ชัดเจน)
   - Sub-headline (ขยายความ)
   - CTA button (1 primary action)
   - Hero image/video/demo

2. SOCIAL PROOF
   - Logos ลูกค้า
   - หรือ testimonial quotes
   - หรือ stats (1000+ users, 99.9% uptime)

3. FEATURES/BENEFITS
   - 3-4 key benefits (icon + title + description)
   - Feature showcase with screenshots

4. HOW IT WORKS
   - 3 steps (simple)
   - หรือ interactive demo

5. PRICING (if applicable)
   - 2-3 tiers
   - Highlight recommended tier

6. FAQ
   - 5-8 common questions

7. FINAL CTA
   - Repeat value prop
   - CTA button
```

### Hero Section Template (HTML)
```html
<section style="min-height: 90vh; display: flex; align-items: center;">
  <div class="container">
    <div class="split">
      <div>
        <p class="tag">✨ New Feature</p>
        <h1>Bold headline that<br>communicates value</h1>
        <p class="subtitle">Supporting text that explains the benefit in 1-2 sentences.</p>
        <div class="cta-group">
          <button class="btn-primary">Get Started Free</button>
          <button class="btn-secondary">Watch Demo →</button>
        </div>
      </div>
      <div class="hero-visual">
        <!-- screenshot, illustration, or animated demo -->
      </div>
    </div>
  </div>
</section>
```

---

## Implementation Checklist

ก่อนส่งมอบ frontend ทุกชิ้น ต้องผ่าน:

```
□ Visual hierarchy ชัดเจน (ดู squint test - หรี่ตาแล้วยังอ่าน hierarchy ได้)
□ Typography consistent (ไม่เกิน 3 fonts, scale ถูกต้อง)
□ Color accessible (contrast ratio >= 4.5:1 สำหรับ text)
□ Responsive (ดีบน mobile, tablet, desktop)
□ Animation smooth (ไม่กระตุก, ไม่ annoying)
□ Interactive states ครบ (hover, focus, active, disabled)
□ Loading states มี (skeleton/spinner)
□ Error states มี (form validation, empty states)
□ Dark mode (ถ้าเหมาะสม)
□ Performance (images optimized, CSS minimal)
```
