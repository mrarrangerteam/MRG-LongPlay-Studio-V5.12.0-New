---
name: mrarranger-react-nextjs
description: |
  MRARRANGER React & Next.js Best Practices - ระบบสร้าง React/Next.js Apps ระดับ Production
  รวม React Patterns, Server Components, App Router, State Management, Performance Optimization
  Inspired by Vercel's official best practices (210K+ installs บน skills.sh)
  ใช้เมื่อ: (1) สร้าง React app (2) สร้าง Next.js app (3) ออกแบบ component (4) จัดการ state
  (5) เพิ่ม performance (6) ทำ SSR/SSG (7) สร้าง API routes (8) deploy Vercel
  (9) อะไรก็ตามที่เกี่ยวกับ React, Next.js, JSX, hooks, components
  Commands: /react [component], /next [feature], /hook [name], /state [approach], /perf [issue], /api [route]
---

# MRARRANGER React & Next.js Best Practices

Best practices สำหรับ React 19+ และ Next.js 15+ ระดับ production

## Quick Commands

```
/react [component]      → สร้าง React component
/next [feature]         → สร้าง Next.js feature
/hook [name]            → สร้าง custom hook
/state [approach]       → เลือก state management
/perf [issue]           → แก้ performance issues
/api [route]            → สร้าง API route
/deploy [target]        → Deploy guide
```

---

## React Component Patterns

### Functional Component Template
```tsx
interface Props {
  title: string;
  description?: string;
  onAction: () => void;
  children?: React.ReactNode;
}

export function MyComponent({ title, description, onAction, children }: Props) {
  return (
    <div className="my-component">
      <h2>{title}</h2>
      {description && <p>{description}</p>}
      <button onClick={onAction}>Action</button>
      {children}
    </div>
  );
}
```

### Component Design Rules
```
1. Single Responsibility - 1 component ทำ 1 อย่าง
2. Props Interface - ประกาศ TypeScript interface ทุกครั้ง
3. Default Values - ใช้ destructuring defaults
4. Composition > Inheritance - ใช้ children, render props
5. Naming - PascalCase, ชื่อสื่อว่าทำอะไร
6. Size Limit - ถ้า > 150 lines → แตก component
```

### Server Components vs Client Components (Next.js 15+)
```
SERVER COMPONENTS (default):
- ไม่มี interactivity (no onClick, onChange)
- Fetch data directly (async/await)
- Access backend resources (DB, filesystem)
- ไม่เพิ่ม JS bundle size
- ใช้สำหรับ: layouts, data display, static content

CLIENT COMPONENTS ('use client'):
- มี interactivity (events, state)
- ใช้ hooks (useState, useEffect, etc.)
- Access browser APIs (localStorage, window)
- เพิ่ม JS bundle size
- ใช้สำหรับ: forms, buttons, animations, real-time updates
```

### Pattern: Smart Server + Dumb Client
```tsx
// page.tsx (Server Component - fetch data)
import { ClientForm } from './client-form';

export default async function Page() {
  const data = await fetchData(); // Server-side
  return <ClientForm initialData={data} />;
}

// client-form.tsx (Client Component - handle interaction)
'use client';
import { useState } from 'react';

export function ClientForm({ initialData }: { initialData: Data }) {
  const [value, setValue] = useState(initialData.value);
  return <input value={value} onChange={e => setValue(e.target.value)} />;
}
```

---

## Next.js App Router Structure

```
app/
├── layout.tsx              # Root layout (Server)
├── page.tsx                # Home page
├── loading.tsx             # Loading UI
├── error.tsx               # Error UI
├── not-found.tsx           # 404 UI
├── (marketing)/            # Route group (no URL impact)
│   ├── about/page.tsx
│   └── pricing/page.tsx
├── dashboard/
│   ├── layout.tsx          # Dashboard layout
│   ├── page.tsx            # /dashboard
│   └── settings/
│       └── page.tsx        # /dashboard/settings
├── api/
│   └── webhooks/
│       └── route.ts        # API route
└── globals.css
```

### Key Files
```
layout.tsx    → Shared UI wrapper (persists across navigations)
page.tsx      → Unique page content
loading.tsx   → Streaming/Suspense loading state
error.tsx     → Error boundary ('use client' required)
not-found.tsx → 404 page
route.ts      → API endpoint (GET, POST, etc.)
```

---

## State Management Decision Tree

```
ต้องการ state ประเภทไหน?
│
├── UI State (form, modal, toggle)
│   └── useState / useReducer
│
├── Server State (API data)
│   ├── Next.js → Server Components + React cache
│   ├── Client → TanStack Query (React Query)
│   └── Real-time → SWR or subscription
│
├── Global State (user, theme, cart)
│   ├── Simple → React Context + useReducer
│   ├── Medium → Zustand (recommended)
│   └── Complex → Jotai or Redux Toolkit
│
└── URL State (filters, pagination, search)
    └── useSearchParams / nuqs
```

### Zustand Example (Recommended for Global State)
```typescript
import { create } from 'zustand';

interface CartStore {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  total: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  addItem: (item) => set((state) => ({ items: [...state.items, item] })),
  removeItem: (id) => set((state) => ({ items: state.items.filter(i => i.id !== id) })),
  total: () => get().items.reduce((sum, item) => sum + item.price, 0),
}));
```

---

## Performance Optimization

### Rendering Optimization
```tsx
// 1. Memo - prevent unnecessary re-renders
const ExpensiveList = React.memo(function ExpensiveList({ items }: Props) {
  return items.map(item => <Item key={item.id} {...item} />);
});

// 2. useMemo - cache expensive calculations
const sortedItems = useMemo(
  () => items.sort((a, b) => a.price - b.price),
  [items]
);

// 3. useCallback - stable function references
const handleClick = useCallback((id: string) => {
  // ...
}, [dependency]);

// 4. Dynamic import - code splitting
const HeavyChart = dynamic(() => import('./heavy-chart'), {
  loading: () => <Skeleton />,
  ssr: false, // ถ้าไม่ต้องการ SSR
});
```

### Image Optimization (Next.js)
```tsx
import Image from 'next/image';

// ALWAYS use next/image instead of <img>
<Image
  src="/hero.jpg"
  alt="Description"
  width={1200}
  height={630}
  priority        // สำหรับ above-the-fold images
  placeholder="blur"
  blurDataURL={blurUrl}
/>
```

### Data Fetching Best Practices
```tsx
// Server Component - Direct fetch (no useEffect!)
export default async function Page() {
  const data = await fetch('https://api.example.com/data', {
    next: { revalidate: 3600 } // ISR: revalidate every hour
  });
  return <DataDisplay data={await data.json()} />;
}

// Parallel data fetching
export default async function Page() {
  const [users, products] = await Promise.all([
    fetchUsers(),
    fetchProducts(),
  ]);
  return <Dashboard users={users} products={products} />;
}

// Streaming with Suspense
export default function Page() {
  return (
    <div>
      <h1>Dashboard</h1>
      <Suspense fallback={<Skeleton />}>
        <SlowDataSection />
      </Suspense>
    </div>
  );
}
```

---

## Common Anti-Patterns to Avoid

```
❌ useEffect for data fetching (ใช้ Server Components หรือ TanStack Query)
❌ prop drilling > 3 levels (ใช้ Context หรือ Zustand)
❌ <img> tag (ใช้ next/image)
❌ <a> tag for internal links (ใช้ next/link)
❌ useState for server data (ใช้ Server Components)
❌ 'use client' ทุก component (ให้น้อยที่สุด)
❌ Large components > 200 lines (แตก component)
❌ Index as key in lists (ใช้ unique ID)
❌ Inline styles for everything (ใช้ Tailwind/CSS Modules)
❌ Fetching in useEffect without cleanup
```

---

## Project Setup Checklist

```
□ TypeScript enabled (strict mode)
□ ESLint + Prettier configured
□ Tailwind CSS / CSS Modules
□ next/font for font loading
□ next/image for images
□ Proper metadata (SEO)
□ Error boundaries
□ Loading states
□ 404 page
□ Environment variables (.env.local)
□ Git hooks (husky + lint-staged)
```
