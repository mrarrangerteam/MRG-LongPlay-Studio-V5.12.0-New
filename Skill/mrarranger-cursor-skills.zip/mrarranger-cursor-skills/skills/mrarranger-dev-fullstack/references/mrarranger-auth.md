---
name: mrarranger-auth
description: |
  MRARRANGER Auth - ระบบ Authentication & Authorization ครบวงจร
  รวม OAuth, JWT, Session Management, RBAC, Social Login, 2FA, Password Security
  Best practices สำหรับ NextAuth.js, Better Auth, Supabase Auth, Clerk, Lucia
  ใช้เมื่อ: (1) สร้างระบบ login/register (2) ทำ OAuth/Social Login (3) จัดการ JWT/Sessions
  (4) สร้าง RBAC (Role-Based Access Control) (5) เพิ่ม 2FA (6) Password reset flow
  (7) อะไรก็ตามที่เกี่ยวกับ authentication, authorization, login, signup, security
  Commands: /auth [provider], /oauth [service], /rbac [roles], /session [type], /2fa [method], /protect [route]
---

# MRARRANGER Auth System

ระบบ Authentication & Authorization สำหรับ web applications ทุกขนาด

## Quick Commands

```
/auth [provider]        → Setup auth (nextauth/better-auth/supabase/clerk)
/oauth [service]        → Add OAuth provider (Google/GitHub/Facebook)
/rbac [roles]           → Role-based access control
/session [type]         → Session management (JWT/cookie)
/2fa [method]           → Two-factor authentication
/protect [route]        → Protect routes/API
/password [flow]        → Password reset/change flow
```

---

## Auth Provider Selection

```
NEED                              → USE
Quick setup, hosted               → Clerk / Auth0
Full control, self-hosted         → Better Auth / Lucia
Already using Supabase            → Supabase Auth
Next.js ecosystem                 → NextAuth.js v5 (Auth.js)
Minimal, lightweight              → Lucia Auth
Enterprise SSO/SAML               → Auth0 / WorkOS
```

---

## Better Auth (Recommended for Self-Hosted)

### Setup
```typescript
// lib/auth.ts
import { betterAuth } from 'better-auth';
import { prismaAdapter } from 'better-auth/adapters/prisma';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: 'postgresql' }),
  emailAndPassword: { enabled: true },
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
    github: {
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    },
  },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24,     // refresh daily
  },
});

// Client
import { createAuthClient } from 'better-auth/react';
export const authClient = createAuthClient({ baseURL: process.env.NEXT_PUBLIC_APP_URL });
```

### Usage in Components
```tsx
'use client';
import { authClient } from '@/lib/auth-client';

function LoginButton() {
  const { data: session } = authClient.useSession();

  if (session) {
    return <p>Welcome, {session.user.name}</p>;
  }

  return (
    <div>
      <button onClick={() => authClient.signIn.email({ email, password })}>
        Login
      </button>
      <button onClick={() => authClient.signIn.social({ provider: 'google' })}>
        Login with Google
      </button>
    </div>
  );
}
```

---

## Auth.js / NextAuth.js v5

### Setup
```typescript
// auth.ts
import NextAuth from 'next-auth';
import Google from 'next-auth/providers/google';
import GitHub from 'next-auth/providers/github';
import Credentials from 'next-auth/providers/credentials';

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Google,
    GitHub,
    Credentials({
      credentials: {
        email: { label: "Email" },
        password: { label: "Password", type: "password" },
      },
      authorize: async (credentials) => {
        const user = await verifyCredentials(credentials);
        return user ?? null;
      },
    }),
  ],
  callbacks: {
    authorized({ auth, request: { nextUrl } }) {
      const isLoggedIn = !!auth?.user;
      const isOnDashboard = nextUrl.pathname.startsWith('/dashboard');
      if (isOnDashboard && !isLoggedIn) return false;
      return true;
    },
  },
});
```

### Middleware Protection
```typescript
// middleware.ts
export { auth as middleware } from './auth';

export const config = {
  matcher: ['/dashboard/:path*', '/api/protected/:path*'],
};
```

---

## Role-Based Access Control (RBAC)

### Database Schema
```sql
CREATE TYPE user_role AS ENUM ('user', 'moderator', 'admin', 'super_admin');

ALTER TABLE profiles ADD COLUMN role user_role DEFAULT 'user';

-- Permission table (flexible)
CREATE TABLE permissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  role user_role NOT NULL,
  resource TEXT NOT NULL,        -- 'products', 'orders', 'users'
  action TEXT NOT NULL,          -- 'read', 'create', 'update', 'delete'
  UNIQUE(role, resource, action)
);

-- Seed permissions
INSERT INTO permissions (role, resource, action) VALUES
  ('user', 'products', 'read'),
  ('user', 'orders', 'read'),
  ('user', 'orders', 'create'),
  ('moderator', 'products', 'read'),
  ('moderator', 'products', 'update'),
  ('moderator', 'orders', 'read'),
  ('moderator', 'orders', 'update'),
  ('admin', 'products', 'read'),
  ('admin', 'products', 'create'),
  ('admin', 'products', 'update'),
  ('admin', 'products', 'delete'),
  ('admin', 'orders', 'read'),
  ('admin', 'orders', 'update'),
  ('admin', 'users', 'read'),
  ('admin', 'users', 'update');
```

### Authorization Middleware
```typescript
function requireRole(...roles: string[]) {
  return async (req: Request) => {
    const session = await getSession(req);
    if (!session) return unauthorized();
    if (!roles.includes(session.user.role)) return forbidden();
    return next();
  };
}

// Usage
app.get('/admin/users', requireRole('admin', 'super_admin'), handleListUsers);
app.delete('/products/:id', requireRole('admin'), handleDeleteProduct);
```

### Client-side Protection
```tsx
function AdminPanel({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();

  if (!session || session.user.role !== 'admin') {
    return <NotAuthorized />;
  }

  return <>{children}</>;
}
```

---

## Password Security

### Rules
```
HASHING:
- ใช้ bcrypt หรือ argon2 (ห้าม MD5, SHA1, SHA256 เปล่าๆ)
- Salt รวมอยู่ใน bcrypt แล้ว (ไม่ต้อง manage เอง)
- Cost factor: bcrypt rounds >= 12

POLICY:
- Minimum 8 characters (แนะนำ 12+)
- ไม่จำกัด max length (ยกเว้น reasonable: 128)
- ไม่บังคับ special characters (ยาวกว่าดีกว่า)
- Check against breached password lists (haveibeenpwned API)
- Rate limit login attempts (5 per minute)
```

### Password Reset Flow
```
1. User clicks "Forgot Password"
2. User enters email
3. Server generates token (random, expires in 1 hour)
4. Send email with reset link (HTTPS only)
5. User clicks link → verify token
6. User enters new password
7. Invalidate token + all existing sessions
8. Redirect to login
```

---

## Security Checklist

```
AUTHENTICATION:
□ Passwords hashed with bcrypt/argon2
□ Rate limiting on login (5/min)
□ Account lockout after 10 failed attempts
□ HTTPS only (no HTTP)
□ Secure cookie flags (HttpOnly, Secure, SameSite)
□ CSRF protection enabled
□ Session timeout configured

TOKENS:
□ JWT ใช้ short expiry (15min access, 7d refresh)
□ Refresh token rotation (ใช้แล้วทิ้ง)
□ Token stored securely (HttpOnly cookie, NOT localStorage)
□ Token revocation mechanism

OAUTH:
□ State parameter for CSRF protection
□ PKCE for public clients
□ Redirect URL validation (exact match)
□ Scope limited to what's needed

GENERAL:
□ Input validation ทุก endpoint
□ SQL injection protection (parameterized queries)
□ XSS protection (Content-Security-Policy)
□ CORS configured correctly
□ Sensitive routes rate limited
□ Audit logging for auth events
```
