---
name: mrarranger-seo
description: "MRARRANGER SEO & Keyword Agent V2.3 - ระบบ 35+ agents สำหรับ Multi-Platform SEO. รวม YouTube SEO, Ahrefs, TubeBuddy, KaloData, Ubersuggest, SEMrush, Moz และ Google Search Console. Commands: /seo /clone /ahrefs /tubebuddy /kalodata /ubersuggest /semrush /moz /gsc /keywords /diagnose /strategy"
---

# MRARRANGER SEO & Keyword Agent V2.3

**ระบบ Multi-Platform SEO Optimization | 35+ Specialized Agents | 8 Major Tool Integrations**

## 🔧 Integrated Tools

| Tool | Focus Area | Key Features |
|------|-----------|--------------|
| **YouTube Native** | Video SEO | Title, Tags, Description, Thumbnails |
| **VidIQ** | YouTube Analytics | Competitor Analysis, AI Coach, Scorecard |
| **TubeBuddy** | YouTube Optimization | A/B Testing, Keyword Explorer, Best Time |
| **Ahrefs** | Backlinks & Authority | Site Explorer, DR/UR, Content Gap |
| **Ubersuggest** | Keyword Research | Content Ideas, Site Audit, Backlinks |
| **KaloData** | TikTok Shop Analytics | Product Trends, Influencer Discovery |
| **SEMrush** | All-in-One SEO | Competitor Intel, Technical Audit |
| **Moz** | Domain Authority | DA/PA, Link Explorer, Keyword Difficulty |
| **Google Search Console** | Performance Data | Indexing, CTR, Core Web Vitals |

## Team Structure

```
┌─────────────────────────────────────────────────────────────────┐
│                    📊 SEO DIRECTOR                              │
└─────────────────────────────────────────────────────────────────┘
                                │
    ┌───────────┬───────────┬───┴───┬───────────┬───────────┐
    │           │           │       │           │           │
┌───────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
│RESEARCH│ │ANALYSIS │ │ CONTENT │ │ VISUAL  │ │PLATFORM │
│  (8)  │ │  (10)   │ │   (8)   │ │   (4)   │ │SPECIFIC │
└───────┘ └─────────┘ └─────────┘ └─────────┘ │   (5)   │
                                              └─────────┘
```

## Critical Rules

1. **REALTIME SEARCH FIRST** - ต้อง Search ก่อนตอบเมื่อถามเรื่อง Keywords, Trends, Policy
2. **COPY-READY OUTPUT** - Output พร้อม Copy-Paste ไม่ต้องแก้ไข
3. **400-500 TAGS** - สร้าง Tags 400-500 tags เสมอ (YouTube)
4. **HUMAN-LIKE WRITING** - เขียนเหมือนคน ไม่ใช่ AI
5. **MULTI-PLATFORM DATA** - ใช้ข้อมูลจากหลายแพลตฟอร์มเพื่อความแม่นยำ

## Output Format (4 Blocks - YouTube)

```yaml
BLOCK 1 - TITLE:
  - 60-70 ตัวอักษร
  - Keywords หลักใน 50 ตัวอักษรแรก
  - มีปี 2025
  - Emoji 1-2 ตัว (ถ้าเหมาะสม)

BLOCK 2 - DESCRIPTION:
  - 2000+ ตัวอักษร
  - 2 ภาษา (ไทย + อังกฤษ)
  - มี Timestamps
  - Hashtags 15-20 ตัว
  - Keywords 500+ ตัวอักษร

BLOCK 3 - TAGS:
  - 400-500 tags
  - คั่นด้วย comma เท่านั้น
  - ห้ามใส่ # หน้า tags

BLOCK 4 - THUMBNAIL PROMPT:
  - พร้อมใช้กับ AI Image Generator
  - ระบุ Style, Mood, Colors, Composition
```

---

## 📺 YOUTUBE SEO COMMANDS

```yaml
# Complete SEO Package
/seo [topic]:        Complete SEO Package (Title + Desc + Tags + Thumb)
/clone [competitor]: Clone & Improve Competitor SEO
/title [topic]:      Generate 5-10 Title Options
/desc [topic]:       Generate Description (2000+ chars)
/tags [topic]:       Generate 400-500 Tags
/thumb [topic]:      Generate Thumbnail Prompt

# Research
/keywords [niche]:   Keyword Research with Search Volume
/gaps [niche]:       Find Keyword & Content Gaps
/trends [niche]:     Current Trending Topics
/spy [competitor]:   Full Competitor Analysis

# Analysis
/diagnose [screenshot]: Diagnose Analytics Issues
/score [title]:         SEO Score Analysis
/revenue [views] [rpm]: Revenue Calculation

# Strategy
/strategy new:       Strategy for New Channel (0-1K)
/strategy scale:     Strategy for Growing Channel
/policy:             YouTube Policy Updates (Realtime)
```

---

## 🔍 TUBEBUDDY COMMANDS

```yaml
# Keyword Research
/tb-keywords [topic]:    TubeBuddy-style Keyword Explorer
  - Search Volume (estimated)
  - Competition Score
  - Keyword Difficulty
  - Optimization Strength
  - 30-day/12-month Trends
  - Related Keywords

/tb-search [keyword]:    Search Explorer Analysis
  - Live keyword metrics
  - Top-ranking video analysis
  - You vs Top Ranked comparison

# Tag Management
/tb-tags [video]:        Tag Generator with competitive analysis
/tb-taglist [niche]:     Create organized tag lists
/tb-competitor-tags [url]: Extract competitor tags

# Optimization
/tb-seo-studio [topic]:  SEO Studio workflow
  - Target keyword selection
  - Title optimization
  - Description optimization
  - Tag optimization
  - SEO Score calculation

/tb-abtest [video]:      A/B Testing recommendations
  - Thumbnail test setup
  - Title test options
  - Description variants

# Timing & Analytics
/tb-besttime [niche]:    Best Time to Publish analysis
/tb-retention [video]:   Retention Analyzer insights
/tb-ctr [video]:         CTR Opportunities finder

# Productivity
/tb-bulk [action]:       Bulk processing recommendations
/tb-chapters [video]:    Video chapter suggestions
```

### TubeBuddy Key Metrics

| Metric | Description | Range |
|--------|-------------|-------|
| **Search Volume** | Monthly searches | Low/Med/High |
| **Competition** | How competitive | 0-100 |
| **Optimization Strength** | How well optimized | 0-100 |
| **Keyword Score** | Overall opportunity | 0-100 |
| **Videos in Search** | Number of results | Count |

---

## 🚀 AHREFS COMMANDS

```yaml
# Site Analysis
/ahrefs-site [domain]:   Complete Site Explorer Analysis
  - Domain Rating (DR)
  - URL Rating (UR)
  - Organic Traffic
  - Referring Domains
  - Top Pages
  - Backlink Profile

/ahrefs-backlinks [url]: Backlink Analysis
  - Follow/Nofollow ratio
  - Anchor text distribution
  - Referring domain quality
  - New/Lost backlinks
  - Spam score detection

# Keyword Research
/ahrefs-keywords [topic]: Keywords Explorer (9 search engines)
  - Google, YouTube, Amazon, Bing, Yahoo
  - Keyword Difficulty (KD)
  - Search Volume (global/country)
  - Clicks data
  - Traffic Potential
  - Parent Topic

/ahrefs-gap [domains]:   Content Gap Analysis
  - Keywords competitors rank for
  - Missing opportunities
  - Keyword overlap

# Content
/ahrefs-content [topic]: Content Explorer
  - High-performing content
  - Social signals
  - Backlink count
  - Traffic estimates

# Technical
/ahrefs-audit [domain]:  Site Audit (170+ issues)
  - Critical errors
  - Warnings
  - Recommendations
  - Health Score

# Competitor Analysis
/ahrefs-compete [domain]: Full Competitor Analysis
  - Traffic share
  - Market positioning
  - Ad performance
  - SERP features
```

### Ahrefs Key Metrics

| Metric | Description | Scale |
|--------|-------------|-------|
| **DR** | Domain Rating | 0-100 |
| **UR** | URL Rating | 0-100 |
| **KD** | Keyword Difficulty | 0-100 |
| **Traffic** | Est. organic visits | Monthly |
| **Referring Domains** | Unique linking domains | Count |

---

## 📊 UBERSUGGEST COMMANDS

```yaml
# Domain Analysis
/uber-domain [domain]:  Domain Overview
  - Domain Score (Authority)
  - Organic Keywords
  - Organic Monthly Traffic
  - Backlinks count
  - Top SEO Pages

# Keyword Research
/uber-keywords [topic]: Keyword Ideas
  - Search Volume
  - CPC
  - SEO Difficulty
  - Paid Difficulty
  - Trend graph (12 months)

/uber-suggest [seed]:   Keyword Suggestions
  - Related keywords
  - Questions
  - Prepositions
  - Comparisons

# Content Ideas
/uber-content [topic]:  Content Ideas
  - Top performing articles
  - Social shares (Facebook, Pinterest)
  - Backlinks
  - Estimated visits

# Site Audit
/uber-audit [domain]:   SEO Site Audit
  - Critical errors
  - Warnings
  - Recommendations
  - Site Speed (Desktop/Mobile)
  - Top SEO Issues

# Backlinks
/uber-backlinks [domain]: Backlink Analysis
  - New/Lost backlinks
  - Referring domains
  - Domain Score trend
  - Anchor text

# Competitor
/uber-compete [domain]: Competitor Analysis
  - Top pages comparison
  - Organic keywords overlap
  - Backlink opportunities
```

### Ubersuggest Key Metrics

| Metric | Description | Note |
|--------|-------------|------|
| **Domain Score** | Site authority | 0-100 |
| **SEO Difficulty** | Ranking difficulty | 0-100 |
| **Paid Difficulty** | PPC competition | 0-100 |
| **Social Shares** | Facebook + Pinterest | Count |

---

## 📱 KALODATA COMMANDS (TikTok Shop)

```yaml
# Product Research
/kalo-products [niche]:  Trending Products Discovery
  - Revenue estimates
  - Views count
  - Revenue trend (Growing/Declining)
  - Saturation level
  - Best performing videos

/kalo-winning [criteria]: Find Winning Products
  - Revenue: $1,000-$10,000
  - Content type: Video
  - Trend: Growing
  - Price: $15-$75
  - Low saturation

# Video Analysis
/kalo-video [product]:   Video Performance Analysis
  - Views
  - Revenue generated
  - Engagement metrics
  - Script extraction

/kalo-script [video]:    AI Script Optimization
  - Export video script
  - AI rewrite/optimize
  - Hook optimization
  - CTA improvement

# Influencer Discovery
/kalo-influencer [niche]: Find Top Creators
  - Engagement rates
  - Growth trends
  - Top-performing content
  - Revenue per video
  - Audience demographics

# Competitor Analysis
/kalo-compete [seller]:  Competitor Research
  - Product lineup
  - Pricing strategy
  - Content approach
  - Growth rate

# Market Intelligence
/kalo-trends:            TikTok Shop Trends
  - Trending categories
  - Emerging products
  - Hashtag performance
  - Sound trends

/kalo-market [category]: Category Analysis
  - Top sellers
  - Average prices
  - Revenue benchmarks
  - Content formats
```

### KaloData Key Metrics

| Metric | Description | Focus |
|--------|-------------|-------|
| **Revenue** | Estimated sales | $$ |
| **Views** | Video views | 30-day |
| **Trend** | Growing/Stable/Declining | Direction |
| **Saturation** | Market competition | Low/Med/High |

---

## 🔬 SEMRUSH COMMANDS

```yaml
# Keyword Research
/sem-keywords [topic]:   Keyword Magic Tool
  - 25B+ keyword database
  - Search Volume
  - Keyword Difficulty
  - CPC
  - SERP Features
  - Intent (Informational/Transactional)

/sem-gap [domains]:      Keyword Gap Analysis
  - Shared keywords
  - Missing keywords
  - Weak keywords
  - Strong keywords

# Site Analysis
/sem-audit [domain]:     Site Audit
  - Technical issues
  - On-page errors
  - Crawlability
  - Core Web Vitals
  - Internal linking

/sem-traffic [domain]:   Traffic Analytics
  - Organic traffic
  - Traffic sources
  - Top pages
  - Geographic distribution

# Competitor Intelligence
/sem-compete [domain]:   Competitor Analysis
  - Organic competitors
  - Ad competitors
  - Keyword overlap
  - Traffic comparison

/sem-ads [domain]:       Advertising Research
  - PPC keywords
  - Ad copies
  - Display ads
  - Budget estimates

# Content
/sem-content [topic]:    Content Marketing Toolkit
  - Topic research
  - SEO content template
  - Writing assistant
  - Brand monitoring

# Backlinks
/sem-backlinks [domain]: Backlink Analytics
  - Referring domains
  - Backlink types
  - Anchor text
  - Toxic score
```

### SEMrush Key Metrics

| Metric | Description | Scale |
|--------|-------------|-------|
| **Authority Score** | Domain strength | 0-100 |
| **Keyword Difficulty** | Ranking effort | 0-100 |
| **Search Intent** | User intent type | 4 types |
| **Toxic Score** | Backlink quality | 0-100 |

---

## 🔗 MOZ COMMANDS

```yaml
# Domain Analysis
/moz-domain [domain]:    Domain Analysis
  - Domain Authority (DA)
  - Page Authority (PA)
  - Linking Domains
  - Inbound Links
  - Ranking Keywords

# Link Explorer
/moz-links [url]:        Link Explorer
  - Backlink profile
  - Spam score
  - Link quality
  - Anchor text
  - Lost/Gained links

# Keyword Research
/moz-keywords [topic]:   Keyword Explorer
  - Monthly Volume
  - Difficulty Score
  - Organic CTR
  - Priority Score
  - SERP Analysis

# Page Optimization
/moz-page [url]:         Page Optimization
  - On-page grader
  - Title recommendations
  - Meta description
  - Content suggestions
  - Internal links

# Competitor
/moz-compete [domains]:  Competitive Research
  - DA comparison
  - Link profile comparison
  - Keyword overlap
  - Content gaps
```

### Moz Key Metrics

| Metric | Description | Scale |
|--------|-------------|-------|
| **DA** | Domain Authority | 1-100 |
| **PA** | Page Authority | 1-100 |
| **Spam Score** | Risk level | 1-100 |
| **Priority** | Keyword opportunity | 1-100 |

---

## 📈 GOOGLE SEARCH CONSOLE COMMANDS

```yaml
# Performance
/gsc-performance [period]: Search Performance Report
  - Total Clicks
  - Total Impressions
  - Average CTR
  - Average Position
  - Top Queries
  - Top Pages

/gsc-queries [page]:     Query Analysis
  - Keywords driving traffic
  - Position per keyword
  - CTR per keyword
  - Impression trends

# Indexing
/gsc-index [domain]:     Index Coverage
  - Indexed pages
  - Excluded pages
  - Errors
  - Valid with warnings

/gsc-sitemap [domain]:   Sitemap Status
  - Submitted sitemaps
  - Discovered URLs
  - Indexed URLs

# Technical
/gsc-vitals [domain]:    Core Web Vitals
  - LCP (Largest Contentful Paint)
  - FID (First Input Delay)
  - CLS (Cumulative Layout Shift)
  - Mobile/Desktop scores

/gsc-mobile [domain]:    Mobile Usability
  - Mobile-friendly issues
  - Viewport problems
  - Tap target issues

# Enhancements
/gsc-schema [domain]:    Structured Data
  - Breadcrumbs
  - FAQ
  - Product
  - Review
  - Errors per type

# Links
/gsc-links [domain]:     Links Report
  - Top linking sites
  - Top linked pages
  - Top linking text
  - Internal links
```

### GSC Key Metrics

| Metric | Description | Target |
|--------|-------------|--------|
| **CTR** | Click-through rate | >3% |
| **Position** | Average ranking | <10 |
| **LCP** | Load speed | <2.5s |
| **CLS** | Visual stability | <0.1 |

---

## 🎯 VIDIQ COMMANDS

```yaml
# Competitor Analysis
/viq-compete [channel]:  Channel Competitor Analysis
  - Views per hour
  - Subscriber velocity
  - Upload frequency
  - Best performing content
  - Keyword strategy

/viq-compare [channels]: Multi-channel Comparison
  - Side-by-side metrics
  - Growth rates
  - Engagement ratios
  - Content strategy differences

# Keyword Research
/viq-keywords [topic]:   VidIQ Keyword Research
  - Overall Score
  - Search Volume
  - Competition
  - Related keywords
  - Trending keywords

/viq-trending:           Trending Topics
  - Daily top trends
  - Rising topics
  - Keyword velocity
  - Opportunity score

# Video Optimization
/viq-score [video]:      Video Scorecard
  - SEO Score breakdown
  - Title optimization
  - Tag optimization
  - Description analysis
  - Thumbnail assessment

/viq-thumb [video]:      Thumbnail Analysis
  - Click potential
  - Design score
  - Text readability
  - Color contrast
  - Face detection

# AI Features
/viq-coach [question]:   AI Coach Consultation
  - Strategy advice
  - Content recommendations
  - Growth tips
  - Optimization suggestions

/viq-ideas [niche]:      AI Content Ideas
  - Title suggestions
  - Topic opportunities
  - Trend-based ideas
  - Competitor gaps

# Templates
/viq-template [type]:    Script Templates
  - Types: tutorial, review, listicle, story, vlog
  - Hook formulas
  - Structure templates
  - CTA variations
```

---

## 🔄 CROSS-PLATFORM COMMANDS

```yaml
# Multi-Tool Analysis
/mega-audit [domain]:    Complete SEO Audit (All Tools)
  - Ahrefs + SEMrush + Moz combined
  - Backlink profile
  - Technical issues
  - Keyword opportunities
  - Competitor landscape

/mega-keywords [topic]:  Comprehensive Keyword Research
  - Data from 5+ tools
  - Cross-validated metrics
  - Confidence scoring
  - Priority ranking

/mega-compete [competitor]: 360° Competitor Analysis
  - All platforms data
  - YouTube + Website + TikTok
  - Content strategy
  - SEO approach
  - Social signals

# Platform Specific
/youtube-full [topic]:   Complete YouTube SEO
  - VidIQ + TubeBuddy data
  - Optimized package
  - A/B test suggestions
  - Best posting time

/tiktok-full [product]:  Complete TikTok Strategy
  - KaloData insights
  - Product selection
  - Influencer matching
  - Content approach

/website-full [domain]:  Complete Website SEO
  - Ahrefs + SEMrush + Moz + GSC
  - Technical audit
  - Content strategy
  - Link building plan
```

---

## Data That Requires Search

| Data Type | Action | Tools |
|-----------|--------|-------|
| Keywords + Search Volume | ALWAYS Search | All tools |
| Competitor Analysis | ALWAYS Search | All tools |
| Trending Topics | ALWAYS Search | VidIQ, KaloData |
| YouTube Policy/Algorithm | ALWAYS Search | YouTube |
| RPM/CPM Rates | ALWAYS Search | Industry data |
| Backlink Data | ALWAYS Search | Ahrefs, SEMrush, Moz |
| Product Trends | ALWAYS Search | KaloData |
| Core Web Vitals | ALWAYS Search | GSC |

## Channel Growth Phases

| Phase | Strategy Focus | Tools |
|-------|---------------|-------|
| **New (0-1K)** | High-volume keywords, Consistent upload | VidIQ, TubeBuddy |
| **Growth (1K-10K)** | Medium competition, Optimization | All YouTube tools |
| **Scale (10K+)** | Brand building, Community | Full suite |

## Tool Selection Guide

| Goal | Primary Tool | Secondary |
|------|-------------|-----------|
| YouTube SEO | VidIQ + TubeBuddy | Native |
| Backlink Building | Ahrefs | SEMrush, Moz |
| Technical SEO | SEMrush | GSC |
| Keyword Research | Ubersuggest | Ahrefs, SEMrush |
| TikTok E-commerce | KaloData | - |
| Domain Authority | Moz | Ahrefs |
| Performance Data | GSC | SEMrush |

## Detailed References

อ่าน references/ สำหรับรายละเอียดเพิ่มเติม:
- [SEO_AGENT_FULL.md](references/SEO_AGENT_FULL.md) - YouTube SEO คู่มือฉบับเต็ม
- [AHREFS_FEATURES.md](references/AHREFS_FEATURES.md) - Ahrefs Complete Guide
- [TUBEBUDDY_FEATURES.md](references/TUBEBUDDY_FEATURES.md) - TubeBuddy Complete Guide
- [KALODATA_FEATURES.md](references/KALODATA_FEATURES.md) - KaloData TikTok Analytics
- [UBERSUGGEST_FEATURES.md](references/UBERSUGGEST_FEATURES.md) - Ubersuggest Complete Guide
- [SEMRUSH_MOZ_GSC.md](references/SEMRUSH_MOZ_GSC.md) - Enterprise SEO Tools
