# SEMRUSH, MOZ & GOOGLE SEARCH CONSOLE Guide

## SEMRUSH

### Overview
SEMrush เป็น All-in-One Marketing Toolkit ระดับ Enterprise

**Database:**
- 25B+ Keywords
- 43T+ Backlinks
- 808M+ Domains tracked
- 140+ Countries

### Core Tools

#### Keyword Magic Tool
```yaml
Features:
  - Keyword clustering
  - Intent classification
  - SERP features
  - Questions
  - Broad/Phrase/Exact match

Metrics:
  - Volume (monthly)
  - Keyword Difficulty
  - CPC
  - Competition
  - Trend

Intent Types:
  - Informational (I)
  - Navigational (N)
  - Commercial (C)
  - Transactional (T)
```

#### Site Audit
```yaml
Checks:
  - Crawlability
  - HTTPS implementation
  - Core Web Vitals
  - Internal linking
  - Markup validation

Issues:
  - Errors (critical)
  - Warnings (important)
  - Notices (minor)

Reports:
  - Thematic reports
  - Pages analyzed
  - Crawl comparison
```

#### Position Tracking
```yaml
Features:
  - Daily updates
  - Local tracking
  - Device targeting
  - SERP features
  - Competitor comparison

Metrics:
  - Visibility %
  - Estimated traffic
  - Average position
  - Rankings distribution
```

#### Backlink Analytics
```yaml
Data:
  - Referring domains
  - Backlink types
  - Anchor text
  - Authority Score
  - Toxic Score

Analysis:
  - New/Lost links
  - Follow/Nofollow
  - Text/Image/Form
  - Top pages by links
```

#### Competitive Research
```yaml
Domain Overview:
  - Authority Score
  - Organic traffic
  - Paid traffic
  - Backlinks

Gap Analysis:
  - Keyword gap
  - Backlink gap
  - Bulk analysis
```

### Pricing

| Plan | Price | Projects |
|------|-------|----------|
| Pro | $120/mo | 5 |
| Guru | $230/mo | 15 |
| Business | $450/mo | 40 |

### Commands

```yaml
/sem-keywords [topic]:
  Output: Keyword list with metrics, Intent

/sem-gap [domains]:
  Output: Keyword opportunities

/sem-audit [domain]:
  Output: Technical issues, Score

/sem-traffic [domain]:
  Output: Traffic analysis

/sem-compete [domain]:
  Output: Competitor breakdown

/sem-ads [domain]:
  Output: PPC keywords, Ad copies

/sem-content [topic]:
  Output: Content recommendations

/sem-backlinks [domain]:
  Output: Link profile, Toxic score
```

---

## MOZ

### Overview
Moz เป็นผู้บุกเบิก Domain Authority metric

**Metrics Created:**
- Domain Authority (DA)
- Page Authority (PA)
- Spam Score
- MozRank

### Core Tools

#### Link Explorer
```yaml
Metrics:
  - Domain Authority: 1-100
  - Page Authority: 1-100
  - Linking Domains
  - Inbound Links
  - Ranking Keywords

Features:
  - Link intersect
  - Anchor text analysis
  - Discovered/Lost links
  - Top pages by links
```

#### Keyword Explorer
```yaml
Metrics:
  - Monthly Volume
  - Difficulty: 1-100
  - Organic CTR
  - Priority Score

Features:
  - SERP analysis
  - Keyword suggestions
  - Related topics
  - Questions
```

#### On-Page Grader
```yaml
Analysis:
  - Title tag optimization
  - Meta description
  - URL structure
  - Content analysis
  - Internal links

Score:
  - Page grade: A-F
  - Issue breakdown
  - Recommendations
```

#### Rank Tracking (Moz Pro)
```yaml
Features:
  - Weekly updates
  - Local tracking
  - Mobile/Desktop
  - SERP features

Reports:
  - Visibility score
  - Ranking distribution
  - Competitor comparison
```

### DA vs DR Comparison

| Metric | Moz DA | Ahrefs DR |
|--------|--------|-----------|
| Scale | 1-100 | 0-100 |
| Focus | Link quantity + quality | Link quality |
| Update | Monthly | Daily |
| Best For | General authority | Link building |

### Pricing

| Plan | Price | Features |
|------|-------|----------|
| Free | $0 | 10 queries/mo |
| Standard | $99/mo | 150 queries |
| Medium | $179/mo | 5000 queries |
| Large | $299/mo | 25000 queries |

### Commands

```yaml
/moz-domain [domain]:
  Output: DA, PA, Links, Keywords

/moz-links [url]:
  Output: Backlink profile, Spam score

/moz-keywords [topic]:
  Output: Volume, Difficulty, Priority

/moz-page [url]:
  Output: On-page analysis, Grade

/moz-compete [domains]:
  Output: DA comparison, Link gaps
```

---

## GOOGLE SEARCH CONSOLE

### Overview
GSC เป็น official tool จาก Google สำหรับ monitoring search performance

**Data Provided:**
- Real Google data
- Free forever
- Direct from source
- Most accurate

### Core Reports

#### Performance Report
```yaml
Metrics:
  - Total Clicks
  - Total Impressions
  - Average CTR
  - Average Position

Dimensions:
  - Queries
  - Pages
  - Countries
  - Devices
  - Search Appearance
  - Dates

Filters:
  - Date range (16 months)
  - Query contains
  - Page URL
  - Country
  - Device type
```

#### Index Coverage
```yaml
Status:
  - Valid: Indexed pages
  - Valid with warnings: Minor issues
  - Excluded: Not indexed
  - Error: Cannot index

Common Issues:
  - Crawled but not indexed
  - Blocked by robots.txt
  - Noindex tag
  - Redirect errors
  - 404 errors
```

#### Core Web Vitals
```yaml
LCP (Largest Contentful Paint):
  - Good: <2.5s
  - Needs Improvement: 2.5-4s
  - Poor: >4s

FID (First Input Delay):
  - Good: <100ms
  - Needs Improvement: 100-300ms
  - Poor: >300ms

CLS (Cumulative Layout Shift):
  - Good: <0.1
  - Needs Improvement: 0.1-0.25
  - Poor: >0.25
```

#### Mobile Usability
```yaml
Issues:
  - Clickable elements too close
  - Content wider than screen
  - Text too small to read
  - Viewport not set
```

#### Enhancements
```yaml
Structured Data:
  - Breadcrumbs
  - FAQ
  - How-to
  - Product
  - Review
  - Article
  - Video

Status:
  - Valid items
  - Items with errors
  - Items with warnings
```

#### Links Report
```yaml
External Links:
  - Top linked pages
  - Top linking sites
  - Top linking text

Internal Links:
  - Top linked pages
  - Internal link distribution
```

### URL Inspection
```yaml
Data:
  - Index status
  - Crawl info
  - Mobile usability
  - Enhancements

Actions:
  - Request indexing
  - View live URL
  - View cached version
```

### Sitemaps
```yaml
Management:
  - Submit sitemap
  - Check status
  - View discovered URLs
  - Error reports
```

### Removals
```yaml
Tools:
  - Temporary removal
  - Clear cached URL
  - SafeSearch filtering
```

### Best Practices

#### Performance Analysis
```yaml
1. Review Top Queries:
   - High impressions, low CTR → improve titles
   - High CTR, low impressions → expand content
   
2. Analyze Pages:
   - Compare similar pages
   - Identify cannibalization
   - Find opportunities

3. Position Tracking:
   - Focus on position 4-20
   - Easier to improve
   - High impact potential
```

#### Index Management
```yaml
1. Monitor Coverage:
   - Check "Excluded" regularly
   - Fix errors promptly
   - Validate fixes

2. Submit Important Pages:
   - Use URL inspection
   - Request indexing
   - Monitor status
```

### Commands

```yaml
/gsc-performance [period]:
  Output: Clicks, Impressions, CTR, Position

/gsc-queries [page]:
  Output: Keywords, Performance

/gsc-index [domain]:
  Output: Coverage report

/gsc-sitemap [domain]:
  Output: Sitemap status

/gsc-vitals [domain]:
  Output: Core Web Vitals scores

/gsc-mobile [domain]:
  Output: Mobile usability issues

/gsc-schema [domain]:
  Output: Structured data status

/gsc-links [domain]:
  Output: Link reports
```

---

## Tool Comparison Matrix

| Feature | SEMrush | Moz | GSC |
|---------|---------|-----|-----|
| **Price** | $120+/mo | $99+/mo | Free |
| **Keyword DB** | 25B+ | 500M+ | N/A |
| **Backlink DB** | 43T+ | 40T+ | Limited |
| **Site Audit** | Advanced | Basic | Limited |
| **Rank Tracking** | Daily | Weekly | N/A |
| **Best For** | All-in-one | Authority | Official data |

## Recommended Workflow

```yaml
1. Start with GSC:
   - Get real performance data
   - Identify indexing issues
   - Check Core Web Vitals

2. Add SEMrush/Moz:
   - Competitive analysis
   - Backlink opportunities
   - Keyword expansion

3. Cross-Reference:
   - Validate data
   - Identify discrepancies
   - Make informed decisions
```

## Integration Tips

### Data Validation
- Always compare tool data with GSC
- GSC = source of truth for clicks
- Tools better for competitor data

### Workflow Optimization
```yaml
Research Phase:
  - SEMrush: Keyword ideas
  - Moz: Authority check
  
Optimization Phase:
  - GSC: Performance monitoring
  - SEMrush: Technical audit
  
Link Building Phase:
  - Moz: DA/PA targets
  - SEMrush: Link gap analysis
```
