# UBERSUGGEST Complete Feature Guide

## Overview
Ubersuggest เป็นเครื่องมือ SEO จาก Neil Patel ที่เน้นความคุ้มค่าและใช้งานง่าย

**Key Stats:**
- 500,000+ Companies Use Free Version
- 90% Cheaper Than Competitors
- Multi-Platform Keyword Support
- Chrome Extension Available

**Pricing Advantage:**
- Lifetime deal: $120 one-time
- Monthly: Starting $12/mo
- Free tier available

## Core Features

### 1. Domain Overview
ภาพรวม SEO ของ website

**Metrics:**
```yaml
Domain Score:
  - 0-100 scale
  - Similar to Moz DA
  - Authority indicator

Organic Keywords:
  - Total ranking keywords
  - Top 3, 4-10, 11-20, 21-50

Organic Monthly Traffic:
  - Estimated visits
  - Traffic value ($)
  - Trend graph

Backlinks:
  - Total backlinks
  - Referring domains
  - New/Lost trend
```

**SEO Overview:**
```yaml
Top Pages:
  - Highest traffic pages
  - Keywords per page
  - Traffic estimates

Top Keywords:
  - Best ranking keywords
  - Position
  - Volume
  - Trend

Backlink Data:
  - Domain score trend
  - Referring domains
  - Follow vs Nofollow
```

### 2. Keyword Research

**Keyword Overview:**
```yaml
Primary Metrics:
  - Search Volume (monthly)
  - SEO Difficulty (0-100)
  - Paid Difficulty (0-100)
  - Cost Per Click (CPC)

Additional Data:
  - 12-month trend graph
  - Seasonal patterns
  - % of SEO clicks
  - Age demographics
```

**Keyword Ideas:**
```yaml
Suggestion Types:
  - Related keywords
  - Questions
  - Prepositions
  - Comparisons

Filters:
  - Volume range
  - SEO difficulty
  - CPC range
  - Include/Exclude words
```

**SERP Analysis:**
```yaml
Top 100 Results:
  - URL
  - Domain Score
  - Backlinks
  - Social Shares
  - Estimated Traffic

Insights:
  - Average word count
  - Common topics
  - Content gaps
```

### 3. Content Ideas
หา content ที่ perform ดี

**Discovery Metrics:**
```yaml
Performance Data:
  - Estimated visits
  - Backlinks
  - Social shares
    - Facebook
    - Pinterest

Filters:
  - By keyword
  - By domain
  - By date
  - By engagement
```

**Analysis:**
- Top performing headlines
- Content structure patterns
- Engagement factors
- Link-worthy topics

### 4. Site Audit
ตรวจสอบ Technical SEO

**Health Check:**
```yaml
Overall Score:
  - Health percentage
  - Critical errors
  - Warnings
  - Recommendations

Categories:
  - Critical Issues
  - Warnings
  - Minor Issues
  - Passed Checks
```

**Issues Detected:**
```yaml
Critical:
  - Broken links (4xx)
  - Server errors (5xx)
  - Redirect loops
  - Missing pages

Warnings:
  - Missing meta descriptions
  - Duplicate titles
  - Low word count
  - Missing alt text

Recommendations:
  - Speed improvements
  - Mobile optimization
  - Schema markup
  - Internal linking
```

**Site Speed:**
```yaml
Desktop Score:
  - Loading time
  - Time to interactive
  - Core Web Vitals

Mobile Score:
  - Mobile loading
  - Mobile usability
  - Viewport issues
```

### 5. Backlink Analysis

**Overview:**
```yaml
Metrics:
  - Total backlinks
  - Referring domains
  - Domain Score
  - New backlinks (30 days)
  - Lost backlinks (30 days)

Distribution:
  - Follow vs Nofollow
  - Text vs Image links
  - Domain authority spread
```

**Backlink List:**
```yaml
Details Per Link:
  - Source URL
  - Domain Score
  - Page Score
  - Anchor text
  - Link type
  - First seen date
```

**Competitor Backlinks:**
- Compare backlink profiles
- Find link opportunities
- Identify common sources
- Gap analysis

### 6. Rank Tracking

**Tracking Features:**
```yaml
Setup:
  - Add target keywords
  - Select location
  - Choose device type
  - Set competitors

Monitoring:
  - Daily position updates
  - Position change alerts
  - Competitor comparison
  - Historical trends
```

**Reports:**
- Position distribution
- Visibility score
- Traffic estimates
- Featured snippets

## Multi-Platform Keywords

### Google Keywords
- Standard web search
- Local search
- News search
- Image search

### YouTube Keywords
```yaml
Data:
  - Search volume
  - Competition
  - CPC
  - Trend

Use For:
  - Video topic ideas
  - Title optimization
  - Tag research
```

### Amazon Keywords
```yaml
Data:
  - Search volume
  - Competition
  - CPC

Use For:
  - Product listings
  - PPC campaigns
  - Product research
```

## Chrome Extension

**Features:**
```yaml
In Google Search:
  - Volume overlay
  - CPC data
  - Competition score

In YouTube:
  - Keyword metrics
  - Channel data
  - Video stats

On Any Page:
  - Domain overview
  - Backlink count
  - Traffic estimate
```

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| Free | $0 | Limited searches |
| Individual | $12/mo | 1 domain, basic |
| Business | $20/mo | 5 domains, full |
| Enterprise | $40/mo | 8 domains, API |
| Lifetime | $120 | One-time payment |

## Integration

### Google Search Console
```yaml
Connected Data:
  - Actual impressions
  - Real CTR
  - True positions
  - Click data

Benefits:
  - Verified data
  - Historical comparison
  - Opportunity identification
```

### Competitors
- Add up to 5 competitors
- Side-by-side comparison
- Keyword overlap
- Content gap

## Commands Reference

```yaml
/uber-domain [domain]:
  Output: Domain Score, Traffic, Keywords, Backlinks

/uber-keywords [topic]:
  Output: Volume, Difficulty, CPC, Trend

/uber-suggest [seed]:
  Output: Keyword ideas, Questions, Related

/uber-content [topic]:
  Output: Top content, Shares, Backlinks

/uber-audit [domain]:
  Output: Health score, Issues, Speed

/uber-backlinks [domain]:
  Output: Backlink profile, Referring domains

/uber-compete [domain]:
  Output: Competitor comparison, Gaps
```

## Best Practices

### Keyword Research Flow
```yaml
1. Start with Seed:
   - Enter main topic
   - Review overview metrics
   
2. Expand Ideas:
   - Check "Keyword Ideas"
   - Review "Questions"
   - Explore "Related"
   
3. Analyze SERP:
   - Check top 10 results
   - Note content type
   - Identify gaps
   
4. Prioritize:
   - Balance volume/difficulty
   - Consider intent
   - Check trend
```

### Site Audit Process
```yaml
1. Run Full Audit:
   - Submit domain
   - Wait for crawl
   
2. Prioritize Issues:
   - Fix critical first
   - Address warnings
   - Implement recommendations
   
3. Monitor Progress:
   - Re-run monthly
   - Track improvements
   - Compare scores
```

### Content Strategy
```yaml
1. Find Opportunities:
   - Use Content Ideas
   - Check social shares
   - Review backlinks
   
2. Create Better Content:
   - Longer than average
   - More comprehensive
   - Better structure
   
3. Promote Content:
   - Target linking domains
   - Social promotion
   - Outreach
```

## Comparison with Other Tools

| Feature | Ubersuggest | Ahrefs | SEMrush |
|---------|-------------|--------|---------|
| Price | $12-40/mo | $99-449/mo | $120-450/mo |
| Keyword DB | Large | Largest | Very Large |
| Backlink DB | Good | Best | Very Good |
| Site Audit | Basic | Advanced | Advanced |
| Best For | Budget users | Backlinks | All-in-one |

## Use Cases

### For Small Business
- Affordable entry point
- Essential features
- Easy to use
- Good ROI

### For Bloggers
- Content ideas
- Keyword research
- Basic backlink analysis
- Traffic estimates

### For Agencies
- Client reporting
- Multiple projects
- Competitor analysis
- Site audits
