---
name: mrarranger-remotion
description: |
  MRARRANGER Remotion - ระบบสร้าง Programmatic Video ด้วย React Code
  สร้าง Video Infographics, Data Visualizations, Explainers, Social Clips, Animated Charts
  ทุก pixel control ได้ด้วย code ต่างจาก AI Video (Runway/Kling) ตรงที่ output เป็น deterministic
  ใช้เมื่อ: (1) สร้าง video จาก code/data (2) animated infographic (3) data visualization video
  (4) social media video clips (5) product demo animation (6) text animation
  (7) อะไรก็ตามที่ต้องการ programmatic video ที่ control ทุก frame ได้
  Commands: /remotion [type], /video-data [chart], /animate-text [text], /social-video [platform], /render [format]
---

# MRARRANGER Remotion - Programmatic Video

สร้าง Video ด้วย React Code - ทุก frame control ได้อย่างสมบูรณ์

## Quick Commands

```
/remotion [type]        → สร้าง Remotion project (infographic, data-viz, social)
/video-data [chart]     → Animated data visualization
/animate-text [text]    → Text animation video
/social-video [platform]→ Social media video clip
/render [format]        → Render to MP4/GIF/WebM
/template [name]        → Use pre-built template
```

---

## When to Use Remotion vs AI Video

```
USE REMOTION when:
- ต้องการ control ทุก pixel/frame
- Data-driven content (charts, stats, dashboards)
- Brand consistency (exact colors, fonts, logos)
- Batch generation (100+ videos จาก data)
- Text-heavy content (subtitles, captions, titles)
- Reproducible output (same input = same output)

USE AI VIDEO (Runway/Kling/Veo) when:
- ต้องการ realistic footage
- Creative/artistic content
- Human subjects
- Natural scenes/environments
- Style transfer
```

---

## Project Setup

```bash
npx create-video@latest my-video
cd my-video
npm start  # Preview at http://localhost:3000
```

### Project Structure
```
my-video/
├── src/
│   ├── Root.tsx              # Composition registry
│   ├── compositions/
│   │   ├── MyVideo.tsx       # Main video component
│   │   ├── scenes/           # Individual scenes
│   │   │   ├── Intro.tsx
│   │   │   ├── DataScene.tsx
│   │   │   └── Outro.tsx
│   │   └── components/       # Reusable elements
│   │       ├── AnimatedText.tsx
│   │       └── BarChart.tsx
│   └── data/                 # Data files
│       └── stats.json
├── public/                   # Static assets
│   ├── fonts/
│   └── images/
└── remotion.config.ts
```

---

## Core Concepts

### Composition (Video Definition)
```tsx
// Root.tsx
import { Composition } from 'remotion';
import { MyVideo } from './compositions/MyVideo';

export const RemotionRoot = () => {
  return (
    <Composition
      id="MyVideo"
      component={MyVideo}
      durationInFrames={300}    // 10 seconds at 30fps
      fps={30}
      width={1920}
      height={1080}
      defaultProps={{ title: "Hello" }}
    />
  );
};
```

### Using Frames for Animation
```tsx
import { useCurrentFrame, interpolate, spring, useVideoConfig } from 'remotion';

export const AnimatedTitle: React.FC<{ text: string }> = ({ text }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Linear interpolation
  const opacity = interpolate(frame, [0, 30], [0, 1], {
    extrapolateRight: 'clamp',
  });

  // Spring animation (natural bounce)
  const scale = spring({
    frame,
    fps,
    config: { damping: 200, stiffness: 100 },
  });

  // Slide up
  const translateY = interpolate(frame, [0, 30], [50, 0], {
    extrapolateRight: 'clamp',
  });

  return (
    <div style={{
      opacity,
      transform: `translateY(${translateY}px) scale(${scale})`,
      fontSize: 72,
      fontWeight: 'bold',
      color: 'white',
    }}>
      {text}
    </div>
  );
};
```

### Sequences (Timing Scenes)
```tsx
import { Sequence, AbsoluteFill } from 'remotion';

export const MyVideo = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: '#0a0a0f' }}>
      {/* Scene 1: Intro (frames 0-90, 3 seconds) */}
      <Sequence from={0} durationInFrames={90}>
        <IntroScene />
      </Sequence>

      {/* Scene 2: Data (frames 60-210, starts at 2s, overlaps 1s) */}
      <Sequence from={60} durationInFrames={150}>
        <DataScene />
      </Sequence>

      {/* Scene 3: Outro (frames 210-300) */}
      <Sequence from={210} durationInFrames={90}>
        <OutroScene />
      </Sequence>
    </AbsoluteFill>
  );
};
```

---

## Common Video Templates

### Animated Bar Chart
```tsx
import { useCurrentFrame, interpolate } from 'remotion';

interface BarChartProps {
  data: { label: string; value: number; color: string }[];
}

export const AnimatedBarChart: React.FC<BarChartProps> = ({ data }) => {
  const frame = useCurrentFrame();
  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 20, height: 400 }}>
      {data.map((item, i) => {
        const delay = i * 10;
        const progress = interpolate(frame - delay, [0, 40], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });
        const height = (item.value / maxValue) * 350 * progress;

        return (
          <div key={i} style={{ textAlign: 'center', flex: 1 }}>
            <div style={{
              backgroundColor: item.color,
              height,
              borderRadius: '8px 8px 0 0',
              transition: 'height 0.1s',
            }} />
            <p style={{ color: 'white', marginTop: 8 }}>{item.label}</p>
            <p style={{ color: item.color, fontWeight: 'bold' }}>
              {Math.round(item.value * progress)}
            </p>
          </div>
        );
      })}
    </div>
  );
};
```

### Counter Animation
```tsx
export const CounterAnimation: React.FC<{ target: number; prefix?: string }> = ({
  target, prefix = ''
}) => {
  const frame = useCurrentFrame();
  const count = interpolate(frame, [0, 60], [0, target], {
    extrapolateRight: 'clamp',
  });

  return (
    <span style={{ fontSize: 96, fontWeight: 'bold', color: '#a855f7' }}>
      {prefix}{Math.round(count).toLocaleString()}
    </span>
  );
};
```

### Text Reveal (Character by Character)
```tsx
export const TextReveal: React.FC<{ text: string }> = ({ text }) => {
  const frame = useCurrentFrame();
  const charsToShow = Math.floor(interpolate(frame, [0, text.length * 2], [0, text.length], {
    extrapolateRight: 'clamp',
  }));

  return (
    <p style={{ fontSize: 48, color: 'white', fontFamily: 'monospace' }}>
      {text.slice(0, charsToShow)}
      <span style={{ opacity: frame % 30 < 15 ? 1 : 0 }}>|</span>
    </p>
  );
};
```

---

## Video Sizes

```
PLATFORM          SIZE        FPS    DURATION
YouTube           1920x1080   30     any
Instagram Reel    1080x1920   30     15-90s
TikTok            1080x1920   30     15-60s
Twitter/X         1280x720    30     up to 140s
LinkedIn          1920x1080   30     up to 10min
YouTube Shorts    1080x1920   30     up to 60s
Facebook          1080x1080   30     up to 240min
```

---

## Rendering

```bash
# Render to MP4
npx remotion render MyVideo output.mp4

# Render specific frames
npx remotion render MyVideo output.mp4 --frames=0-150

# Render GIF
npx remotion render MyVideo output.gif --image-format=png

# Render with custom props
npx remotion render MyVideo output.mp4 --props='{"title":"Custom"}'

# Batch render (จาก data file)
node render-batch.js
```

### Batch Render Script
```javascript
// render-batch.js
const { bundle } = require('@remotion/bundler');
const { renderMedia } = require('@remotion/renderer');

const data = require('./data/videos.json');

async function renderAll() {
  const bundled = await bundle(require.resolve('./src/index.ts'));

  for (const item of data) {
    await renderMedia({
      composition: 'MyVideo',
      serveUrl: bundled,
      codec: 'h264',
      outputLocation: `output/${item.id}.mp4`,
      inputProps: item,
    });
    console.log(`Rendered: ${item.id}`);
  }
}

renderAll();
```

---

## Best Practices

```
PERFORMANCE:
- ใช้ useMemo สำหรับ expensive calculations
- Preload images/fonts ก่อน render
- ใช้ staticFile() สำหรับ assets
- ลด DOM elements ให้น้อยที่สุด

DESIGN:
- Motion graphics ใช้ 30fps (smooth พอ, file เล็ก)
- ใช้ spring() สำหรับ natural animation
- Stagger animations 5-10 frames
- Safe area: เว้น 10% จากขอบทุกด้าน
- Text size minimum 32px สำหรับ 1080p

AUDIO:
- ใช้ <Audio> component สำหรับเสียง
- Sync กับ frame (ไม่ใช่ time)
- Fade in/out เสียง 0.5s
```
