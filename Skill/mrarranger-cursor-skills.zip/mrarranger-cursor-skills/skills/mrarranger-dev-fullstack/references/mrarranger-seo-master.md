---
name: mrarranger-seo-master
description: "Comprehensive SEO expertise covering Technical, On-Page, Content, YouTube, Local, Link Building, AI SEO, International, E-commerce SEO, and complete audit strategies"
commands:
  - name: "/seo"
    description: "Get SEO consultation on any SEO topic"
  - name: "/technical-seo"
    description: "Technical SEO audit and optimization guide"
  - name: "/keyword"
    description: "Keyword research and content strategy"
  - name: "/youtube-seo"
    description: "YouTube video optimization guide"
  - name: "/local-seo"
    description: "Local SEO and Google Business optimization"
  - name: "/schema"
    description: "Schema markup and JSON-LD implementation"
  - name: "/audit-seo"
    description: "Complete SEO audit checklist"
  - name: "/geo"
    description: "GEO (Generative Engine Optimization) strategy"
---

# 🎯 SEO Master - SEO นักเก่งทั้งตัว

> ทำให้เว็บไซต์ของคุณอยู่เหนือสุดในการค้นหา | Make Your Website #1 in Search Results

## 📚 Core Sections

### 1. Technical SEO - เทคนิคพื้นฐาน

#### Site Speed & Core Web Vitals
- **Largest Contentful Paint (LCP)**: < 2.5 seconds (ความเร็วแสดงเนื้อหาหลัก)
- **First Input Delay (FID) / Interaction to Next Paint (INP)**: < 100ms (ความรวดเร็วในการตอบสนอง)
- **Cumulative Layout Shift (CLS)**: < 0.1 (ความเสถียรของเลย์เอาต์)

**Optimization Tips:**
- Compress images with WebP format
- Minify CSS, JavaScript, and HTML
- Use CDN for global delivery (Cloudflare, Akamai)
- Enable GZIP compression
- Implement lazy loading for below-the-fold images
- Remove render-blocking resources

#### Crawlability & Indexability
```
robots.txt Example:
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /private/
Disallow: /*.pdf$
Crawl-delay: 1
Sitemap: https://example.com/sitemap.xml
```

#### XML Sitemap
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/page1</loc>
    <lastmod>2026-03-15</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```

#### Structured Data / Schema Markup
```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Example Company",
  "url": "https://example.com",
  "logo": "https://example.com/logo.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "Customer Service",
    "telephone": "+1-800-123-4567"
  }
}
```

#### Mobile Friendliness
- Responsive design (Viewport meta tag)
- Touch-friendly buttons (48x48px minimum)
- Mobile-first indexing (design for mobile first)
- No Flash or pop-ups blocking content

---

### 2. On-Page SEO - การปรับในหน้าเว็บ

#### Title Tags (60-70 characters)
```html
<title>SEO Master Guide | Complete Rankings Formula 2026</title>
```
- Primary keyword near the beginning
- Brand name at the end (optional)
- Make it compelling and clickable

#### Meta Descriptions (155-160 characters)
```html
<meta name="description" content="Learn complete SEO strategies including technical, content, and link building. Get expert guidance to rank higher in Google search results.">
```

#### Heading Hierarchy (H1-H6)
```html
<h1>Complete SEO Mastery Guide</h1>
<h2>Technical SEO Fundamentals</h2>
<h3>Site Speed Optimization</h3>
<h2>Content SEO Strategy</h2>
<h3>Keyword Research</h3>
```
- One H1 per page (your main topic)
- Proper nesting (H2 → H3 → H4)
- Keywords naturally in headings

#### Internal Linking Strategy
- Link from high authority pages to new pages
- Use descriptive anchor text (not "click here")
- Link depth: 3 clicks maximum to reach any page
- 50-100 internal links per page (contextual)

#### Keyword Density
- Primary keyword: 0.5-1% of content
- LSI keywords: 2-3% of content
- Avoid keyword stuffing (unnatural)
- Use synonyms and related terms naturally

---

### 3. Content SEO - SEO ของเนื้อหา

#### Keyword Research Process
1. **Seed Keywords**: Start with 5-10 base keywords
2. **Competitor Analysis**: Check top 10 ranking sites
3. **Search Volume & Difficulty**: Use Ahrefs, Semrush, SEMrush
4. **Search Intent**: Identify user's purpose (Info, Nav, Commercial, Transactional)
5. **Long-tail Keywords**: Target 3-5 word phrases (easier to rank)

#### Content Clusters & Pillar Pages
```
Pillar Page: "Complete Guide to SEO"
├── Cluster 1: "Technical SEO"
├── Cluster 2: "On-Page SEO"
├── Cluster 3: "Link Building"
└── Cluster 4: "Content SEO"

Linking: All cluster pages link to pillar + internal linking
```

#### E-E-A-T Framework
- **Experience**: Show real-world experience
- **Expertise**: Demonstrate knowledge and credentials
- **Authority**: Cite trusted sources, earn backlinks
- **Trustworthiness**: Transparency, author info, security (HTTPS)

#### Content Length by Type
- Blog posts: 1,500-2,500 words (comprehensive)
- Pillar pages: 5,000+ words
- Product pages: 300-500 words
- How-to guides: 2,000+ words

#### Content Optimization Checklist
- [ ] Primary keyword in first 100 words
- [ ] Keyword in H1 and 2-3 H2 tags
- [ ] 2-3 internal links to related content
- [ ] External links to 3-5 authoritative sources
- [ ] Include images/video (1 media per 200 words)
- [ ] Add schema markup
- [ ] Meta description with CTA
- [ ] Readability score > 60%
- [ ] Mobile-optimized formatting

---

### 4. YouTube SEO - การทำ SEO สำหรับ YouTube

#### Title Optimization
- Keep under 60 characters for full display
- Primary keyword at the start
- Include emotional trigger or number
- Example: "7 SEO Secrets That 90% Don't Know | 2026 Guide"

#### Tags (Best Practices)
- 3-5 highly relevant tags
- Primary keyword as first tag
- Include branded tags
- Long-tail variations

#### Description Strategy
```
Line 1: Compelling hook + Call-to-action
Line 2-3: Keywords naturally placed
Line 4+: Links and timestamps

Example:
Learn the 5 secrets to ranking on Google. Subscribe for more SEO tips.

0:00 Introduction
2:15 Technical SEO Tips
5:30 Content Strategy
8:45 Link Building
11:20 Conclusion
```

#### Thumbnail Optimization
- Bold, high-contrast colors
- Large, readable text (faces optional)
- Consistency in style/branding
- A/B test different designs

#### Retention & Watch Time
- Hook viewers in first 3 seconds
- Add pattern interrupts every 30 seconds
- Use on-screen text and graphics
- End screen calls-to-action
- Chapters for better navigation

#### YouTube Metadata
```json
{
  "snippet": {
    "title": "SEO Guide 2026 | Rank on Google",
    "description": "Full description with links and timestamps",
    "tags": ["seo", "google ranking", "search engine optimization"],
    "categoryId": "27",
    "defaultLanguage": "en"
  }
}
```

---

### 5. Local SEO - SEO ท้องถิ่น

#### Google Business Profile Optimization
- Complete name, address, phone (NAP)
- Accurate business category (1 primary, 9 secondary)
- High-quality photos (10-20 minimum)
- Regular posts and updates
- Customer reviews (respond to all within 48 hours)

#### NAP Consistency (ความสม่ำเสมอของข้อมูล)
- Same format across all platforms
- Example: "123 Main Street, New York, NY 10001"
- Avoid abbreviations inconsistency (St. vs Street)
- Update immediately if business moves

#### Local Schema Markup
```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Your Business Name",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "123 Main St",
    "addressLocality": "New York",
    "addressRegion": "NY",
    "postalCode": "10001",
    "addressCountry": "US"
  },
  "telephone": "+1-212-555-0123",
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": "Monday",
    "opens": "09:00",
    "closes": "17:00"
  }
}
```

#### Local Link Building
- Local directories (Yelp, TripAdvisor)
- Chamber of Commerce
- Local business associations
- Community event sponsorships

#### Reviews Management
- Get 50+ reviews on Google (improves rankings)
- Respond professionally to negative reviews
- Encourage satisfied customers to review
- Link to reviews page from website

---

### 6. Link Building - การสร้างลิงค์

#### Outreach Strategy
1. **Identify target websites**: Use Ahrefs, Moz, SEMrush

2. **Find contact email**: Check about pages, look for "press" or "contact"
3. **Personalized email**: Reference their content, explain mutual benefit
4. **Follow up**: 2-3 follow-ups over 2 weeks

#### Guest Posting
- Contribute to industry publications
- Write 1,500-2,500 word articles
- Include bio with 1-2 relevant links
- Build relationships for future features

#### Broken Link Building
- Use Screaming Frog to find broken links on competitor sites
- Create similar or better content
- Reach out: "I noticed the broken link to [topic], I have a resource..."
- Convert broken link to link to your content

#### HARO (Help A Reporter Out)
- Join free HARO service
- Respond to journalist queries with expert insights
- Build authority links naturally
- Typically 1-2 links per month

#### Digital PR
- Create newsworthy content
- Press releases for major announcements
- Reach out to journalists and bloggers
- Build relationships with media

#### Link Quality Metrics
- **Domain Authority (DA)**: 30+ is good, 50+ is excellent
- **Page Authority (PA)**: Specific page quality
- **Topical Relevance**: Link from related industry
- **Anchor Text**: 20-30% branded, 70-80% natural/generic

---

### 7. AI SEO (GEO) - Generative Engine Optimization

#### Optimizing for AI Overviews
- Create original, cited content
- Include fact-checkable statements
- Provide data with sources
- Clear structure with lists and tables
- FAQ sections with direct answers

#### LLM-Friendly Content
- Clear topic sentences
- Structured data markup
- Numbered lists for steps
- Bold key terms and concepts
- Tables for comparisons

#### AI Overview Best Practices
```markdown
# Topic Name

## Quick Answer
1 sentence answer to common question

## How It Works
Step-by-step explanation with examples

## Key Metrics
- Metric 1: 95%
- Metric 2: 50ms
- Metric 3: 0.1


## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations and advanced patterns, see:

- **advanced-seo.md**: Advanced techniques and detailed examples

