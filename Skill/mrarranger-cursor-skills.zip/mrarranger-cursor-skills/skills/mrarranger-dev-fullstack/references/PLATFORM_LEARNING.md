# MRARRANGER Bridge - Platform Learning Reference

## Known AI Platforms (Auto-Updated via Research)

### Music Generation Platforms

```yaml
suno:
  url: "suno.com"
  type: "AI Music Generator"
  research_date: "2025"
  
  ui_elements:
    create_button: "Create button in sidebar"
    style_input: "Style of Music text area"
    lyrics_input: "Lyrics text area"
    title_input: "Title field"
    
  workflow:
    1: "Click Create"
    2: "Enter Style Prompt (from Music Skill)"
    3: "Enter Lyrics (if vocal song)"
    4: "Click Create button"
    5: "Wait 30-60 seconds"
    6: "Get 2 song variations"
    7: "Download or Continue/Extend"
    
  tips:
    - "Style ไม่เกิน 200 characters"
    - "Lyrics ใช้ [Verse], [Chorus] tags"
    - "ไม่ใส่ชื่อศิลปินจริง"

udio:
  url: "udio.com"
  type: "AI Music Generator"
  research_needed: true
  note: "Research real-time เมื่อผู้ใช้ต้องการ"

soundraw:
  url: "soundraw.io"
  type: "AI Music Generator"
  research_needed: true
```

### Video Generation Platforms

```yaml
kling:
  url: "klingai.com"
  type: "AI Video Generator"
  
  ui_elements:
    mode_selector: "Image to Video / Text to Video"
    prompt_input: "Prompt text area"
    duration: "5s / 10s selector"
    
  workflow:
    1: "Select mode (I2V or T2V)"
    2: "Upload reference image (if I2V)"
    3: "Enter prompt (from Visual Skill)"
    4: "Select duration"
    5: "Click Generate"
    6: "Wait 2-5 minutes"
    7: "Download result"

runway:
  url: "runwayml.com"
  type: "AI Video Generator"
  
  features:
    - "Gen-3 Alpha"
    - "Motion Brush"
    - "Image to Video"
    
  research_needed: true
  note: "UI เปลี่ยนบ่อย ต้อง research ก่อนใช้"

pika:
  url: "pika.art"
  type: "AI Video Generator"
  research_needed: true
```

### Image Generation Platforms

```yaml
midjourney:
  url: "midjourney.com"
  type: "AI Image Generator"
  access: "Discord หรือ Web (alpha)"
  
  workflow_discord:
    1: "ไป Discord server"
    2: "พิมพ์ /imagine [prompt]"
    3: "รอ generate"
    4: "เลือก U1-U4 เพื่อ upscale"
    
  workflow_web:
    research_needed: true
    note: "Web interface อาจต่างจาก Discord"

leonardo:
  url: "leonardo.ai"
  type: "AI Image Generator"
  research_needed: true

ideogram:
  url: "ideogram.ai"
  type: "AI Image Generator"
  features: ["Good with text in images"]
  research_needed: true

nano_banana:
  url: "nanobanana.com"
  type: "AI Image Generator"
  features: ["Free", "Face consistent"]
  research_needed: true
```

### Publishing Platforms

```yaml
youtube:
  url: "studio.youtube.com"
  type: "Video Publishing"
  
  ui_elements:
    create_button: "CREATE button top right"
    upload_option: "Upload videos"
    title_field: "Title input (100 chars)"
    description_field: "Description textarea"
    tags_field: "Tags section in More options"
    thumbnail: "Thumbnail upload"
    visibility: "Public/Private/Unlisted"
    
  workflow_upload:
    1: "Click CREATE → Upload videos"
    2: "Select video file"
    3: "Enter Title (from SEO Skill)"
    4: "Enter Description (from SEO Skill)"
    5: "Click More options → Add Tags"
    6: "Upload custom Thumbnail"
    7: "Select Visibility"
    8: "Click Publish (ต้องยืนยัน)"

tiktok:
  url: "tiktok.com/upload"
  type: "Short Video Publishing"
  research_needed: true

instagram:
  url: "instagram.com"
  type: "Image/Video Publishing"
  note: "ใช้ผ่าน mobile หรือ Creator Studio"
  research_needed: true
```

## Research Templates

### When Encountering New Platform

```yaml
research_queries:
  basic:
    - "[platform] how to use 2025"
    - "[platform] tutorial"
    - "[platform] UI guide"
    
  specific:
    - "[platform] create [content type] steps"
    - "[platform] interface elements"
    - "[platform] tips and tricks"
    
  comparison:
    - "[platform] vs [known platform]"
    - "[platform] pros cons"
```

### Information to Extract

```yaml
extract_info:
  required:
    - url: "ที่อยู่เว็บ"
    - type: "ประเภท tool"
    - main_features: "ความสามารถหลัก"
    - ui_elements: "ปุ่ม/ช่อง input ที่สำคัญ"
    - workflow: "ขั้นตอนการใช้งาน"
    
  optional:
    - pricing: "ราคา/plan"
    - limitations: "ข้อจำกัด"
    - tips: "เทคนิคพิเศษ"
    - alternatives: "ทางเลือกอื่น"
```

## Skill Integration Mapping

```yaml
skill_to_platform:

  mrarranger-music:
    outputs:
      - "Style Prompt"
      - "Lyrics"
      - "Title"
    compatible_platforms:
      - "suno.com → Style + Lyrics"
      - "udio.com → Style + Lyrics"
      - "soundraw.io → Style parameters"
      
  mrarranger-visual:
    outputs:
      - "Image Prompt"
      - "Video Prompt"
      - "Character Sheet"
      - "Storyboard"
    compatible_platforms:
      - "klingai.com → Video Prompt"
      - "runwayml.com → Video Prompt"
      - "midjourney.com → Image Prompt"
      - "leonardo.ai → Image Prompt"
      
  mrarranger-seo:
    outputs:
      - "Title"
      - "Description"
      - "Tags"
      - "Thumbnail Prompt"
    compatible_platforms:
      - "studio.youtube.com → Title/Desc/Tags"
      - "tiktok.com → Caption/Hashtags"
      - "Any AI Image tool → Thumbnail Prompt"
```

## Error Handling

```yaml
common_errors:

  login_required:
    detection: "Sign in button visible / redirect to login"
    action: "แจ้งผู้ใช้ว่าต้อง login ก่อน"
    
  rate_limited:
    detection: "Too many requests / Please wait"
    action: "รอแล้วลองใหม่ / แจ้งผู้ใช้"
    
  ui_changed:
    detection: "Expected element not found"
    action: "Research UI ใหม่ / ถามผู้ใช้"
    
  generation_failed:
    detection: "Error message / Generation failed"
    action: "ลองใหม่ / ปรับ prompt / แจ้งผู้ใช้"
```

## Update Protocol

```yaml
when_to_re_research:
  - "UI element ไม่เจอ"
  - "Workflow ไม่ทำงาน"
  - "ผู้ใช้บอกว่าผิด"
  - "ทุก 30 วัน สำหรับ major platforms"
  
how_to_update:
  1: "Search ข้อมูลล่าสุด"
  2: "เปรียบเทียบกับ knowledge เดิม"
  3: "อัพเดท workflow ถ้าต่าง"
  4: "แจ้งผู้ใช้ถ้ามีการเปลี่ยนแปลงสำคัญ"
```
