---
name: mrarranger-bridge
description: "MRARRANGER Intelligent Bridge - ระบบอัจฉริยะเชื่อมต่อทุก Skills กับ Chrome Browser อัตโนมัติ. ใช้เมื่อต้องการให้ Claude Chrome ทำงานจริงบน websites ใดก็ได้ โดยไม่ต้อง pre-define. สามารถ (1) Auto-detect ทุก Skills ที่ติดตั้ง (2) Research วิธีใช้ website/tool ใหม่แบบ real-time (3) เรียนรู้ UI อัตโนมัติ (4) Execute actions บน Chrome. รองรับทุก website ทุก AI tool โดยไม่จำกัด."
---

# MRARRANGER Intelligent Bridge

ระบบอัจฉริยะเชื่อมต่อทุก Skills กับ Chrome Browser | Auto-Learn & Execute

## Core Philosophy

```yaml
principle_1: "NEVER HARDCODE"
  - ไม่กำหนดตายตัวว่าใช้ website ไหนได้บ้าง
  - เรียนรู้ tool/website ใหม่ๆ ได้ตลอด

principle_2: "RESEARCH FIRST"
  - ไม่รู้จัก website → Search หาข้อมูลก่อน
  - เรียนรู้ UI, วิธีใช้, best practices

principle_3: "SKILL AWARE"
  - รู้จักทุก MRARRANGER Skills ที่ติดตั้ง
  - เลือกใช้ Skill ที่เหมาะสมอัตโนมัติ

principle_4: "EXECUTE & LEARN"
  - ทำงานจริงบน Chrome
  - จดจำ pattern สำหรับครั้งต่อไป
```

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                  🧠 INTELLIGENT BRIDGE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  ANALYZER   │  │  RESEARCHER │  │  EXECUTOR   │             │
│  │             │  │             │  │             │             │
│  │ • Parse คำสั่ง│  │ • Web Search│  │ • Chrome    │             │
│  │ • หา Intent │  │ • Learn UI  │  │ • Actions   │             │
│  │ • Match Skill│ │ • Best Way  │  │ • Verify    │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ MRARRANGER    │    │  ANY WEBSITE  │    │  ANY AI TOOL  │
│ SKILLS        │    │               │    │               │
│               │    │ • YouTube     │    │ • Suno        │
│ • Music       │    │ • Google      │    │ • Kling       │
│ • Visual      │    │ • Social Media│    │ • Runway      │
│ • SEO         │    │ • Any site... │    │ • Midjourney  │
│ • Future...   │    │               │    │ • Udio        │
└───────────────┘    └───────────────┘    │ • Future...   │
                                          └───────────────┘
```

## How It Works

### Step 1: Analyze Request

```yaml
user_input: "สร้างเพลง Lo-Fi แล้ว upload YouTube พร้อม SEO"

analyzer_output:
  intent: "create_and_publish"
  tasks:
    - task: "create_music"
      skill_needed: "mrarranger-music"
      platform: "suno.com"
      
    - task: "upload_video"
      platform: "youtube.com"
      
    - task: "apply_seo"
      skill_needed: "mrarranger-seo"
      platform: "youtube.com"
```

### Step 2: Research Unknown

```yaml
# ถ้าไม่รู้จัก platform
unknown_platform: "udio.com"

research_actions:
  - search: "Udio AI music generator how to use 2025"
  - search: "Udio interface tutorial"
  - search: "Udio vs Suno differences"
  
learned_info:
  - url: "udio.com"
  - type: "AI Music Generator"
  - ui_elements:
      - prompt_input: "text area at top"
      - generate_button: "Create button"
      - settings: "dropdown for style"
  - workflow: "Enter prompt → Select style → Click Create → Wait → Download"
```

### Step 3: Execute on Chrome

```yaml
chrome_actions:
  - navigate: "suno.com"
  - wait: "page_load"
  - find: "prompt input field"
  - type: "[Style Prompt from Music Skill]"
  - click: "Create button"
  - wait: "generation_complete"
  - extract: "audio_url"
  - report: "สร้างเพลงเสร็จแล้ว"
```

## Intelligent Features

### 1. Auto-Detect Skills

```yaml
on_startup:
  action: "Scan ทุก Skills ที่ติดตั้ง"
  detect:
    - mrarranger-music → "เพลง, Suno, music, clone เพลง"
    - mrarranger-visual → "วิดีโอ, ภาพ, MV, Kling, Runway"
    - mrarranger-seo → "SEO, YouTube, keywords, tags"
    - mrarranger-coordinator → "MV, full production, multi-team"
    - [any-new-skill] → "auto-learn capabilities"
```

### 2. Smart Platform Detection

```yaml
keyword_mapping:
  # ไม่ hardcode แต่เรียนรู้จาก context
  
  music_creation:
    keywords: ["สร้างเพลง", "แต่งเพลง", "music", "song"]
    likely_platforms: ["suno.com", "udio.com", "soundraw.io"]
    action: "Research ว่าผู้ใช้ต้องการ platform ไหน หรือแนะนำ"
    
  video_creation:
    keywords: ["สร้างวิดีโอ", "AI video", "MV"]
    likely_platforms: ["kling.ai", "runway.ml", "pika.art"]
    action: "ถามหรือแนะนำตาม context"
    
  image_creation:
    keywords: ["สร้างภาพ", "AI image", "รูป"]
    likely_platforms: ["midjourney.com", "leonardo.ai", "ideogram.ai"]
    action: "ถามหรือแนะนำตาม context"
```

### 3. Learn New Tools Real-time

```yaml
when_unknown_tool:
  
  step_1_research:
    - "Search: [tool name] how to use"
    - "Search: [tool name] UI guide"
    - "Search: [tool name] tutorial 2025"
    
  step_2_understand:
    - "สรุปว่า tool นี้ทำอะไรได้"
    - "UI มีอะไรบ้าง"
    - "ขั้นตอนการใช้งาน"
    
  step_3_map_to_skills:
    - "tool นี้ใช้กับ Skill ไหนได้บ้าง"
    - "output ของ Skill ใส่ tool ยังไง"
    
  step_4_remember:
    - "จดจำไว้สำหรับครั้งต่อไป"
```

### 4. Workflow Memory

```yaml
learned_workflows:
  
  workflow_1:
    name: "Suno Song Creation"
    steps:
      1: "ไป suno.com"
      2: "คลิก Create"
      3: "ใส่ Style Prompt ในช่อง Style"
      4: "ใส่ Lyrics ในช่อง Lyrics (ถ้ามี)"
      5: "คลิก Create"
      6: "รอ 30-60 วินาที"
      7: "ได้เพลง 2 versions"
    last_used: "auto-update"
    
  workflow_2:
    name: "YouTube Upload + SEO"
    steps:
      1: "ไป studio.youtube.com"
      2: "คลิก Create → Upload"
      3: "เลือกไฟล์"
      4: "ใส่ Title จาก SEO Skill"
      5: "ใส่ Description จาก SEO Skill"
      6: "ใส่ Tags"
      7: "เลือก Thumbnail"
      8: "Publish"
    last_used: "auto-update"
```

## Commands

```yaml
# Bridge จะทำงานอัตโนมัติ ไม่ต้องมี command พิเศษ
# แค่พิมพ์ธรรมชาติ

examples:
  - "สร้างเพลงบน Suno แนว Lo-Fi"
  - "ไป upload วิดีโอนี้ขึ้น YouTube"
  - "ลองใช้ Udio สร้างเพลงดูหน่อย"
  - "ไปดู analytics ของ channel หน่อย"
  - "สร้างภาพบน Midjourney ตาม prompt นี้"
  - "ไปหาข้อมูล competitor channel นี้"

# หรือใช้ explicit commands
explicit_commands:
  "/browse [url]": "เปิด website ที่ระบุ"
  "/learn [tool]": "เรียนรู้วิธีใช้ tool ใหม่"
  "/do [action] on [site]": "ทำ action บน site ที่ระบุ"
  "/workflow [name]": "รัน workflow ที่เคยเรียนรู้"
```

## Integration with MRARRANGER Skills

### Auto-Routing

```yaml
routing_logic:

  music_detected:
    trigger: "เพลง|song|music|Suno|clone เพลง"
    action:
      1: "เรียก mrarranger-music สร้าง prompt"
      2: "Research platform ที่ต้องใช้ (ถ้าไม่ระบุ)"
      3: "Chrome ไปทำงานจริง"
      
  visual_detected:
    trigger: "วิดีโอ|video|MV|ภาพ|image|Kling|Runway"
    action:
      1: "เรียก mrarranger-visual สร้าง prompt"
      2: "Research platform ที่ต้องใช้"
      3: "Chrome ไปทำงานจริง"
      
  seo_detected:
    trigger: "SEO|YouTube|upload|title|tags"
    action:
      1: "เรียก mrarranger-seo สร้าง content"
      2: "Chrome ไป YouTube Studio"
      3: "กรอกข้อมูลให้"
      
  unknown_skill:
    trigger: "[ไม่ match กับ skill ที่มี]"
    action:
      1: "Research ว่าต้องใช้อะไร"
      2: "แนะนำ หรือทำเองถ้าทำได้"
```

## Safety & Confirmation

```yaml
safety_rules:

  always_confirm:
    - "การ publish/post สาธารณะ"
    - "การจ่ายเงิน/subscribe"
    - "การลบข้อมูล"
    - "การเข้าถึง sensitive data"
    
  auto_execute:
    - "การกรอกฟอร์ม draft"
    - "การนำทาง/เปิดหน้า"
    - "การ copy/paste content"
    - "การ search หาข้อมูล"
    
  report_always:
    - "รายงานทุกขั้นตอนที่ทำ"
    - "แจ้งเมื่อเจอปัญหา"
    - "ถามเมื่อไม่แน่ใจ"
```

## Example Conversation

```
User: "สร้างเพลง Lo-Fi ฝนตก แล้ว upload YouTube ด้วย"

🧠 Bridge:
├─ Analyze: music creation + youtube upload
├─ Skills needed: Music + SEO
├─ Platforms: Suno → YouTube
│
├─ Step 1: Music Skill สร้าง prompt
│   └─ ได้ Style Prompt + Title
│
├─ Step 2: Research Suno UI (ถ้าจำเป็น)
│
├─ Step 3: Chrome → suno.com
│   ├─ ใส่ prompt
│   ├─ Generate
│   └─ ดาวน์โหลดเพลง ✓
│
├─ Step 4: SEO Skill สร้าง Title/Desc/Tags
│
├─ Step 5: Chrome → YouTube Studio
│   ├─ Upload video
│   ├─ ใส่ Title/Desc/Tags
│   └─ [รอยืนยันก่อน Publish]
│
└─ Report: "เสร็จแล้ว! รอยืนยัน publish ไหมครับ?"
```

## Extensibility

```yaml
future_ready:
  
  new_skills:
    - "เมื่อติดตั้ง Skill ใหม่ → Bridge รู้จักอัตโนมัติ"
    - "ไม่ต้องแก้ไข Bridge"
    
  new_platforms:
    - "เมื่อมี AI tool ใหม่ → Research แล้วใช้ได้เลย"
    - "ไม่ต้อง pre-define"
    
  new_workflows:
    - "เรียนรู้ workflow ใหม่จากการใช้งาน"
    - "จดจำ pattern ที่ซ้ำๆ"
```

## Summary

| Feature | Description |
|---------|-------------|
| **Auto-Detect** | รู้จักทุก Skills ที่ติดตั้ง |
| **Smart Research** | เรียนรู้ tool/website ใหม่ real-time |
| **Chrome Execute** | ทำงานจริงบน browser |
| **No Hardcode** | ไม่จำกัด platform |
| **Learn & Remember** | จดจำ workflow สำหรับครั้งต่อไป |
| **Safe & Confirm** | ยืนยันก่อนทำ action สำคัญ |
