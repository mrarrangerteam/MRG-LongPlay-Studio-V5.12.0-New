---
name: mrarranger-supabase
description: |
  MRARRANGER Supabase - ระบบสร้าง Backend ด้วย Supabase (Postgres, Auth, Storage, Edge Functions)
  Best practices สำหรับ Database Design, Row Level Security, Real-time Subscriptions, Edge Functions
  เหมาะสำหรับ Solo Founders / Indie Hackers ที่ต้องการ backend ที่ scale ได้โดยไม่ต้อง manage server
  ใช้เมื่อ: (1) สร้าง backend ด้วย Supabase (2) ออกแบบ database schema (3) ตั้งค่า Row Level Security
  (4) สร้าง Edge Functions (5) จัดการ Auth (6) File storage (7) Real-time features
  (8) อะไรก็ตามที่เกี่ยวกับ Supabase, Postgres, backend-as-a-service
  Commands: /supa [action], /schema [table], /rls [policy], /edge [function], /storage [bucket], /realtime [table]
---

# MRARRANGER Supabase Best Practices

สร้าง Production-ready backend ด้วย Supabase ตั้งแต่ schema ถึง deployment

## Quick Commands

```
/supa [action]          → Supabase setup & management
/schema [table]         → Database schema design
/rls [policy]           → Row Level Security policies
/edge [function]        → Edge Functions
/storage [bucket]       → File storage setup
/realtime [table]       → Real-time subscriptions
/migrate [change]       → Database migration
/seed [table]           → Seed data
```

---

## Database Schema Design

### Naming Conventions
```sql
-- Tables: snake_case, plural
CREATE TABLE users (...);
CREATE TABLE order_items (...);

-- Columns: snake_case
id, created_at, updated_at, user_id, full_name

-- Primary Keys: always 'id' with UUID
id UUID DEFAULT gen_random_uuid() PRIMARY KEY

-- Foreign Keys: table_name_id (singular)
user_id UUID REFERENCES users(id) ON DELETE CASCADE

-- Timestamps: always include
created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
```

### Common Table Templates

```sql
-- Users (extends Supabase auth.users)
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT,
  avatar_url TEXT,
  email TEXT UNIQUE,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'moderator')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, avatar_url)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'full_name',
    NEW.email,
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Products / Items
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  currency TEXT DEFAULT 'THB',
  image_url TEXT,
  category TEXT,
  is_active BOOLEAN DEFAULT true,
  metadata JSONB DEFAULT '{}',
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Orders
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'shipped', 'delivered', 'cancelled')),
  total DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'THB',
  shipping_address JSONB,
  payment_method TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);
```

### Updated_at Trigger
```sql
-- Auto-update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to each table
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
```

---

## Row Level Security (RLS)

### Golden Rules
```
1. ALWAYS enable RLS on every table
2. Start restrictive, then open up
3. Test policies from client side
4. Use auth.uid() for user identification
5. admin roles should be checked via database, not client
```

### Common RLS Patterns

```sql
-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Pattern 1: Users own their data
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Pattern 2: Public read, authenticated write
CREATE POLICY "Anyone can view active products"
  ON products FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage products"
  ON products FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Pattern 3: Users see their own orders
CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own orders"
  ON orders FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Pattern 4: Team/org-based access
CREATE POLICY "Team members can view team data"
  ON team_data FOR SELECT
  USING (
    team_id IN (
      SELECT team_id FROM team_members
      WHERE user_id = auth.uid()
    )
  );
```

---

## Edge Functions

### Template
```typescript
// supabase/functions/hello/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  try {
    // CORS headers
    if (req.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "authorization, content-type",
        },
      });
    }

    // Auth check
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
    );

    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
    }

    // Business logic
    const body = await req.json();
    const result = await processRequest(body, user);

    return new Response(JSON.stringify(result), {
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
});
```

### Deploy
```bash
supabase functions deploy function-name
```

---

## Storage

```typescript
// Upload file
const { data, error } = await supabase.storage
  .from('avatars')
  .upload(`${userId}/profile.png`, file, {
    cacheControl: '3600',
    upsert: true
  });

// Get public URL
const { data: { publicUrl } } = supabase.storage
  .from('avatars')
  .getPublicUrl('path/to/file.png');

// Storage policies (SQL)
CREATE POLICY "Users can upload own avatar"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );
```

---

## Client-side Usage (TypeScript)

```typescript
import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types'; // generated types

const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Fetch
const { data, error } = await supabase
  .from('products')
  .select('*, profiles(full_name)')
  .eq('is_active', true)
  .order('created_at', { ascending: false })
  .limit(20);

// Insert
const { data, error } = await supabase
  .from('orders')
  .insert({ user_id: userId, total: 1990, status: 'pending' })
  .select()
  .single();

// Real-time subscription
const channel = supabase
  .channel('orders-updates')
  .on('postgres_changes',
    { event: '*', schema: 'public', table: 'orders', filter: `user_id=eq.${userId}` },
    (payload) => { console.log('Order updated:', payload); }
  )
  .subscribe();
```

---

## Generate TypeScript Types

```bash
# Generate types from database schema
supabase gen types typescript --project-id YOUR_PROJECT_ID > database.types.ts
```

---

## Security Checklist

```
□ RLS enabled on ALL tables
□ RLS policies tested from client
□ Service role key NEVER exposed to client
□ Anon key ใช้กับ client only
□ Edge Functions validate auth
□ Storage policies set correctly
□ No sensitive data in public schemas
□ Database backups configured
□ Rate limiting on Edge Functions
□ Input validation on all writes
```
