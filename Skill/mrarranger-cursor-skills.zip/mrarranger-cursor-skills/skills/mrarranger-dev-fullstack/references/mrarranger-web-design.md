---
name: mrarranger-web-design
description: |
  MRARRANGER Web Design Guidelines - ระบบออกแบบเว็บระดับมืออาชีพ
  รวม Layout Systems, Grid Design, Spacing Scale, Accessibility, UX Patterns, Responsive
  Inspired by Vercel's design guidelines (165K+ installs บน skills.sh)
  ใช้เมื่อ: (1) ออกแบบ layout เว็บ (2) จัด spacing/grid (3) ทำ accessibility (4) UX patterns
  (5) Responsive design (6) Navigation design (7) Form design (8) Dashboard layout
  (9) อะไรก็ตามที่เกี่ยวกับ web layout, spacing, UX, accessibility
  Commands: /layout [type], /grid [columns], /spacing [scale], /a11y [check], /ux [pattern], /nav [style]
---

# MRARRANGER Web Design Guidelines

Guidelines สำหรับออกแบบเว็บที่ใช้งานง่าย สวยงาม และ accessible

## Quick Commands

```
/layout [type]          → Layout system (sidebar, stack, dashboard)
/grid [columns]         → Grid system design
/spacing [scale]        → Spacing and sizing scale
/a11y [check]           → Accessibility audit
/ux [pattern]           → UX pattern recommendation
/nav [style]            → Navigation design
/form [type]            → Form design patterns
/dashboard [layout]     → Dashboard layout
```

---

## Spacing System (8px Grid)

ทุก spacing ใช้ base 8px (0.5rem) เพื่อความ consistent:

```css
--space-0: 0;
--space-1: 0.25rem;   /* 4px - micro spacing */
--space-2: 0.5rem;    /* 8px - tight */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px - default */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px - comfortable */
--space-8: 2rem;      /* 32px - section gap */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px - large gap */
--space-16: 4rem;     /* 64px - section separator */
--space-20: 5rem;     /* 80px - page section */
--space-24: 6rem;     /* 96px - hero spacing */
```

### When to Use What
```
4px  → icon กับ text, badge padding
8px  → compact lists, tight groups
16px → default element spacing, card padding
24px → comfortable card padding, form groups
32px → section gaps within a page
48-64px → between page sections
80-96px → hero sections, major divisions
```

---

## Layout Systems

### 1. Sidebar Layout (Dashboard/Admin)
```css
.layout-sidebar {
  display: grid;
  grid-template-columns: 260px 1fr;
  min-height: 100vh;
}
.sidebar {
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  border-right: 1px solid var(--border);
  padding: 1.5rem;
}
.main-content {
  padding: 2rem;
  max-width: 1200px;
}
/* Mobile: sidebar เป็น drawer */
@media (max-width: 768px) {
  .layout-sidebar { grid-template-columns: 1fr; }
  .sidebar { position: fixed; transform: translateX(-100%); z-index: 50; }
  .sidebar.open { transform: translateX(0); }
}
```

### 2. Content Layout (Blog/Docs)
```css
.layout-content {
  display: grid;
  grid-template-columns: 1fr min(75ch, 100%) 1fr;
  padding: 0 1rem;
}
.layout-content > * { grid-column: 2; }
/* Full-bleed elements */
.layout-content > .full-bleed { grid-column: 1 / -1; }
```

### 3. Card Grid Layout
```css
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 1.5rem;
}
/* Compact variant */
.card-grid-compact {
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 1rem;
}
```

### 4. Split Layout (Landing Page)
```css
.split {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  padding: 4rem 0;
}
@media (max-width: 768px) {
  .split { grid-template-columns: 1fr; gap: 2rem; }
}
```

---

## Navigation Patterns

### Top Navigation Bar
```
┌──────────────────────────────────────────┐
│ Logo    Links...           User  Actions │
└──────────────────────────────────────────┘

Rules:
- Height: 56-64px
- Sticky on scroll (with optional hide-on-scroll-down)
- Mobile: hamburger menu
- Max 5-7 primary links
- CTA button right-aligned
```

### Sidebar Navigation
```
┌──────┬───────────────────────────────────┐
│ Logo │  Page Title              Search   │
│      ├───────────────────────────────────┤
│ Nav  │                                   │
│ Item │                                   │
│ Item │         Main Content              │
│ Item │                                   │
│      │                                   │
│ ─────│                                   │
│ Item │                                   │
└──────┴───────────────────────────────────┘

Rules:
- Width: 240-280px
- Collapsible (icon-only: 64px)
- Group nav items with dividers
- Active state ชัดเจน
- Scroll within sidebar if needed
```

### Breadcrumb
```
Home > Category > Sub-category > Current Page

Rules:
- ใช้เมื่อ > 2 levels deep
- Last item = current page (no link)
- Separator: > or / or →
- Truncate ถ้ายาวเกินไป
```

---

## Form Design

### Form Layout Rules
```
1. Label above input (ไม่ใช่ข้างๆ) - อ่านง่ายกว่า
2. 1 column สำหรับ form ทั่วไป (2 column เฉพาะ name, address)
3. Required fields ใส่ * (optional fields ใส่ "optional")
4. Error message ใต้ input ที่ผิด (สีแดง)
5. Submit button ซ้ายล่าง (อ่านจาก F-pattern)
6. Progressive disclosure - ซ่อน advanced options
```

### Input States
```css
/* Default */
border: 1px solid var(--border); border-radius: 8px;
padding: 0.625rem 0.875rem; font-size: 1rem;

/* Focus */
border-color: var(--primary); outline: none;
box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);

/* Error */
border-color: var(--error);
box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);

/* Disabled */
background: var(--muted-bg); opacity: 0.6;
cursor: not-allowed;
```

### Validation
```
Real-time validation:
- Email format → validate on blur
- Password strength → validate on input
- Required field → validate on blur (ไม่ validate ทันทีที่ focus)

Error messages:
✅ "Email ต้องมี @ และ domain เช่น user@example.com"
❌ "Invalid email" (ไม่ helpful)

✅ "Password ต้องมีอย่างน้อย 8 ตัวอักษร รวมตัวเลขและตัวพิเศษ"
❌ "Password too weak" (ไม่บอกว่าต้องทำอะไร)
```

---

## Accessibility (a11y) Checklist

### Must-Have
```
PERCEIVABLE:
□ Color contrast ratio ≥ 4.5:1 (text), ≥ 3:1 (large text)
□ ไม่ใช้สีอย่างเดียวในการสื่อความหมาย (เช่น error ต้องมี icon ด้วย)
□ Images มี alt text
□ Videos มี captions

OPERABLE:
□ ทุก interactive element ใช้ keyboard ได้ (Tab, Enter, Escape)
□ Focus visible ชัดเจน (ห้าม outline: none โดยไม่มี alternative)
□ Skip to main content link
□ ไม่มี keyboard trap

UNDERSTANDABLE:
□ Labels ชัดเจนทุก form input
□ Error messages อธิบายวิธีแก้
□ Consistent navigation
□ lang attribute on <html>

ROBUST:
□ Semantic HTML (h1-h6, nav, main, footer, article)
□ ARIA attributes เมื่อจำเป็น (aria-label, aria-describedby)
□ Role attributes สำหรับ custom widgets
```

### ARIA Quick Reference
```html
<!-- Announce dynamic content -->
<div aria-live="polite">Status: Loading...</div>

<!-- Label for icon-only buttons -->
<button aria-label="Close dialog">✕</button>

<!-- Describe additional context -->
<input aria-describedby="password-help" />
<p id="password-help">Must be at least 8 characters</p>

<!-- Mark required fields -->
<input aria-required="true" />

<!-- Expanded/collapsed state -->
<button aria-expanded="false" aria-controls="menu">Menu</button>
<div id="menu" hidden>...</div>
```

---

## Responsive Breakpoints Strategy

### Mobile First Approach
```css
/* Base: Mobile (320px+) */
.container { padding: 1rem; }
.grid { grid-template-columns: 1fr; }

/* Tablet (768px+) */
@media (min-width: 768px) {
  .container { padding: 2rem; }
  .grid { grid-template-columns: repeat(2, 1fr); }
}

/* Desktop (1024px+) */
@media (min-width: 1024px) {
  .container { padding: 2rem 4rem; }
  .grid { grid-template-columns: repeat(3, 1fr); }
}

/* Wide (1280px+) */
@media (min-width: 1280px) {
  .container { max-width: 1200px; margin: 0 auto; }
}
```

### What Changes Per Breakpoint
```
MOBILE (320-767):
- Single column
- Hamburger menu
- Full-width cards
- Stacked layout
- Bottom sheet modals
- Larger touch targets (44px min)

TABLET (768-1023):
- 2 column grids
- Sidebar as drawer
- Medium cards
- Some side-by-side layouts

DESKTOP (1024+):
- 3-4 column grids
- Persistent sidebar
- Modal dialogs
- Hover states
- Full navigation visible
```

---

## Performance Guidelines

```
IMAGES:
□ WebP/AVIF format
□ Lazy loading (loading="lazy")
□ Responsive srcset
□ Proper width/height (prevent layout shift)

CSS:
□ ไม่มี unused CSS (purge unused)
□ Critical CSS inline
□ CSS containment where possible
□ Prefer transform/opacity for animations

FONTS:
□ font-display: swap
□ Preload critical fonts
□ System font stack as fallback
□ Subset fonts (เฉพาะ characters ที่ใช้)

HTML:
□ Semantic elements
□ Minimal DOM depth
□ Defer non-critical scripts
□ Preconnect to external domains
```
