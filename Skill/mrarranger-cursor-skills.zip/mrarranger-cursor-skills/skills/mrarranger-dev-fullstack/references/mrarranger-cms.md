---
name: mrarranger-cms
description: ระบบจัดการ Content Management Systems ครบวงจร - Headless CMS, WordPress, Strapi, Sanity, Contentful, Payload CMS
commands:
  - /cms
  - /wordpress
  - /strapi
  - /sanity
  - /contentful
  - /payload
  - /migrate-cms
---

# MRARRANGER CMS & Platforms

**ระบบจัดการ Content Management Systems ครบวงจร** - Complete CMS management system.

## 1. Headless CMS Overview

### What is Headless CMS?
```
Traditional CMS (WordPress):
Content → Admin Panel → Database → Frontend Template → Website

Headless CMS:
Content → API → Database ← API ← Frontend (React/Next.js/etc)

Benefits:
✓ Content separate from presentation
✓ Use same content across web, mobile, email
✓ Modern frontend frameworks (React, Vue, etc)
✓ Better performance & flexibility
```

### When to Use Each Platform

| Platform | Use When | Example |
|----------|----------|---------|
| WordPress | Traditional site, plugins needed | Blog site, small business |
| Strapi | Full control, self-hosted, TypeScript | Custom content structure, team project |
| Sanity | Real-time collab, portable content | Large team content site |
| Contentful | SaaS preference, multi-project | Agency managing multiple clients |
| Payload CMS | Modern stack, TypeScript, self-hosted | Next.js projects |

## 2. WordPress

### Setup & Structure
```bash
# WordPress directory structure
wordpress/
├── wp-content/
│   ├── themes/      # Theme templates
│   ├── plugins/     # Plugins extend functionality
│   └── uploads/     # User uploads (media)
├── wp-admin/        # Admin panel
├── wp-includes/     # Core WordPress files
└── wp-config.php    # Configuration (database, keys)
```

### WordPress REST API
```bash
# Access WordPress content via API
curl https://example.com/wp-json/wp/v2/posts

# Response includes: id, title, content, date, author, etc.
```

### WP-CLI (Command Line Interface)
```bash
# Management from terminal
wp post create --post_title="New Post" --post_content="Content"
wp user create john john@example.com --user_pass=password
wp plugin install akismet --activate
wp db export backup.sql
```

## 3. Strapi (Node.js CMS)

### Setup
```bash
npx create-strapi-app my-project --quickstart
npm run develop
# Admin at http://localhost:1337/admin
```

### REST API
```bash
# Fetch articles
curl http://localhost:1337/api/articles

# Filter, populate, pagination
curl 'http://localhost:1337/api/articles?filters[author][id][$eq]=1&populate=*&pagination[limit]=10'
```

### GraphQL API
```graphql
query GetArticles {
  articles(first: 10) {
    id
    title
    author {
      name
    }
  }
}
```

## 4. Sanity

### Schema Definition
GROQ (Sanity Query Language) for fetching content:
```groq
*[_type == "post" && publishedAt < now()] | order(publishedAt desc) {
  title,
  slug,
  author->,
  body,
  _createdAt
}
```

### Portable Text
Rich text format for flexible content blocks with embedded media.

## 5. Contentful

### Setup
```bash
npm install -g contentful-cli
contentful login
contentful space create --name "My Blog"
```

### Delivery API
```bash
# Fetch all blog posts
curl 'https://cdn.contentful.com/spaces/{space-id}/environments/master/entries?access_token={token}&content_type=blogPost'

# Query parameters: include=3, limit=10, skip=20, order=-sys.createdAt
```

## 6. Payload CMS

### Setup
```bash
npx create-payload-app my-project
npm run dev
# Admin at http://localhost:3000/admin
```

### Collections (TypeScript)
Define data structures with rich TypeScript support. Includes hooks for beforeChange and afterChange lifecycle events.

### Global Types
Site-wide configuration like navigation menus and global settings.

## 7. Content Modeling Best Practices

### Relationships
- One-to-Many: Author has many Posts
- Many-to-Many: Posts have many Categories
- Use relationships for linked content
- Avoid deeply nested structures

### Localization
Support multiple languages with locale-specific content:
```javascript
{
  i18n: {
    defaultLocale: 'en',
    locales: ['en', 'th', 'ja'],
  },
}
```

### Versioning
Track draft and published states:
```javascript
{
  status: 'draft' | 'published',
  publishedAt: '2024-01-01T00:00:00Z',
  createdAt: '2024-01-01T00:00:00Z',
  updatedAt: '2024-01-01T12:00:00Z',
  publishedBy: 'user-id',
}
```

## 8. Media Management

### Image Optimization
```javascript
// Contentful image API
const imageUrl = `https:${asset.fields.file.url}?w=800&h=600&fit=fill&q=80`

// Strapi: Automatic thumbnail generation
// Payload: Built-in image optimization
```

### CDN Integration
- Cloudinary integration available in Strapi
- Automatic resizing and optimization
- URLs served from fast CDN

## 9. Next.js Integration

### Fetching from Strapi
```javascript
export async function getStaticProps() {
  const res = await fetch('http://localhost:1337/api/articles');
  const data = await res.json();
  return {
    props: { articles: data.data },
    revalidate: 60, // ISR: Revalidate every 60s
  };
}
```

### Fetching from Sanity
```javascript
import {createClient} from 'next-sanity'

export const sanityClient = createClient({
  projectId: 'xxx',
  dataset: 'production',
  apiVersion: '2024-01-01',
  useCdn: true,
})

export async function getStaticProps() {
  const posts = await sanityClient.fetch(`
    *[_type == "post"] | order(_createdAt desc)
  `)
  return {props: {posts}, revalidate: 60}
}
```

## 10. CMS Migration

### Migration Strategy
1. **Audit**: Inventory all content types, unused fields, orphaned content
2. **Plan**: Map old fields to new schema, handle transformations, define defaults
3. **Export**: Export from old CMS, transform to new format, validate
4. **Import**: Create types first, import content, verify, test frontend
5. **Redirect**: Keep old URLs working with 301 redirects, update internal links

### Contentful Migration
```bash
# Export from old space
contentful space export --space-id old-space --download-assets --output-file migration.json

# Import to new space
contentful space import --space-id new-space --content-file migration.json
```

---

## Reference Files

For detailed code examples, setup guides, and platform-specific implementations, see:
- `references/wordpress-setup.md` - Custom themes, Gutenberg blocks, plugins
- `references/strapi-models.md` - Content type definitions and custom controllers
- `references/sanity-schema.md` - Complete schema configuration and Portable Text
- `references/contentful-models.md` - Content models and API queries
- `references/payload-config.md` - Collections, globals, hooks, and middleware
- `references/cms-examples.md` - Complete working examples for all platforms

## Commands Summary

- `/cms [comparison]` - Compare CMS platforms
- `/wordpress [task]` - WordPress setup & management
- `/strapi [feature]` - Strapi configuration & API
- `/sanity [query]` - Sanity schema & GROQ queries
- `/contentful [setup]` - Contentful models & API
- `/payload [config]` - Payload CMS configuration
- `/migrate-cms [from-to]` - Migration between CMS

**MRARRANGER CMS: Flexible, scalable, content-first.**
