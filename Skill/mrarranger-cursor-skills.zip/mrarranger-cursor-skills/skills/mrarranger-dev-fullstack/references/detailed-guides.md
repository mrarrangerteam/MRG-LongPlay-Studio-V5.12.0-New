# CMS Platforms - Detailed Guides & Examples

## WordPress Custom Theme Setup

```php
<!-- themes/my-theme/style.css -->
/*
Theme Name: My Custom Theme
Theme URI: https://example.com
*/

<!-- themes/my-theme/functions.php -->
<?php
function my_theme_setup() {
    add_theme_support('custom-logo');
    add_theme_support('post-thumbnails');
    register_nav_menu('primary', 'Primary Menu');
}
add_action('after_setup_theme', 'my_theme_setup');

<!-- themes/my-theme/index.php -->
<?php get_header(); ?>
<div class="content">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            the_title();
            the_content();
        endwhile;
    endif;
    ?>
</div>
<?php get_footer(); ?>
```

## Gutenberg Block Registration

```php
register_block_type('myplugin/custom-block', array(
    'render_callback' => 'myplugin_render_custom_block',
    'attributes' => array(
        'title' => array('type' => 'string'),
        'color' => array('type' => 'string'),
    ),
));

function myplugin_render_custom_block($attributes) {
    return '<div style="color: ' . $attributes['color'] . '">'
        . $attributes['title'] . '</div>';
}
```

## Strapi Content Type Definition

```javascript
// src/api/article/models/article.js
module.exports = {
  attributes: {
    title: {
      type: 'string',
      required: true,
    },
    description: {
      type: 'richtext',
    },
    slug: {
      type: 'uid',
      targetField: 'title',
    },
    author: {
      type: 'relation',
      relation: 'manyToOne',
      target: 'api::author.author',
    },
    category: {
      type: 'relation',
      relation: 'manyToMany',
      target: 'api::category.category',
    },
    image: {
      type: 'media',
      multiple: false,
    },
    publishedAt: {
      type: 'datetime',
    },
  },
};
```

## Strapi Custom Controller

```javascript
// src/api/article/controllers/article.js
'use strict';

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::article.article', {
  async find(ctx) {
    const { query } = ctx;
    const articles = await strapi.service('api::article.article').find(query);
    ctx.body = {
      data: articles,
      count: articles.length,
    };
  },
});
```

## Sanity Complete Schema

```javascript
// schema.js
export default {
  name: 'blog',
  title: 'Blog',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: Rule => Rule.required().min(3),
    },
    {
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
    },
    {
      name: 'author',
      title: 'Author',
      type: 'reference',
      to: [{type: 'author'}],
    },
    {
      name: 'body',
      title: 'Body',
      type: 'blockContent',  // custom portable text
    },
    {
      name: 'publishedAt',
      title: 'Published at',
      type: 'datetime',
    },
  ],
};
```

## Sanity Portable Text Structure

```javascript
{
  _type: 'blockContent',
  blocks: [
    {
      _type: 'block',
      _key: 'abc123',
      style: 'h2',
      children: [{_type: 'span', text: 'Heading'}],
    },
    {
      _type: 'block',
      children: [{_type: 'span', text: 'Paragraph text'}],
    },
    {
      _type: 'image',
      asset: {_ref: 'image-123'},
      alt: 'Alt text',
    },
  ]
}
```

## Sanity Studio Configuration

```javascript
// sanity.config.js
import {defineConfig} from 'sanity'
import {deskTool} from 'sanity/desk'

export default defineConfig({
  projectId: 'xxx',
  dataset: 'production',
  plugins: [deskTool()],
  schema: {
    types: [post, author, category],
  },
})
```

## Contentful Content Model Definition

```javascript
{
  "name": "Blog Post",
  "description": "A blog post",
  "fields": [
    {
      "id": "title",
      "name": "Title",
      "type": "Text",
      "required": true,
    },
    {
      "id": "slug",
      "name": "Slug",
      "type": "Symbol",
    },
    {
      "id": "body",
      "name": "Body",
      "type": "RichText",
    },
    {
      "id": "author",
      "name": "Author",
      "type": "Link",
      "linkType": "Entry",
    },
    {
      "id": "image",
      "name": "Image",
      "type": "Link",
      "linkType": "Asset",
    },
  ],
}
```

## Payload CMS Collection Configuration

```typescript
// src/collections/Posts.ts
import { CollectionConfig } from 'payload/types'

export const Posts: CollectionConfig = {
  slug: 'posts',
  auth: false,
  admin: {
    useAsTitle: 'title',
  },
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
    },
    {
      name: 'slug',
      type: 'text',
      unique: true,
    },
    {
      name: 'content',
      type: 'richText',
    },
    {
      name: 'author',
      type: 'relationship',
      relationTo: 'authors',
    },
    {
      name: 'publishedAt',
      type: 'date',
    },
  ],
}
```

## Payload Global Type Configuration

```typescript
// src/globals/Navigation.ts
import { GlobalConfig } from 'payload/types'

export const Navigation: GlobalConfig = {
  slug: 'navigation',
  fields: [
    {
      name: 'menuItems',
      type: 'array',
      fields: [
        { name: 'label', type: 'text' },
        { name: 'url', type: 'text' },
      ],
    },
  ],
}
```

## Payload Hooks (Lifecycle Events)

```typescript
{
  name: 'posts',
  fields: [...],
  hooks: {
    beforeChange: [
      ({ data }) => {
        // Generate slug from title
        if (!data.slug && data.title) {
          data.slug = data.title
            .toLowerCase()
            .replace(/\s+/g, '-')
        }
        return data
      },
    ],
    afterChange: [
      ({ doc }) => {
        // Trigger revalidation on publish
        console.log(`Post ${doc.id} published`)
      },
    ],
  },
}
```

## Advanced Sanity GROQ Queries

```groq
// Fetch posts with author
*[_type == "post" && publishedAt < now()] | order(publishedAt desc) {
  title,
  slug,
  author->,
  body,
  _createdAt
}

// Filter by category
*[_type == "post" && "category-slug" in categories[]->slug.current]

// Get related posts
*[_type == "post" && slug.current != $slug && categories[]._ref in *[_type == "post" && slug.current == $slug][0].categories[]._ref] | order(_createdAt desc)[0...3]
```

## Advanced Content Modeling: Relationships

### One-to-Many Example
```
Author (one) ---- (many) Posts
```

### Many-to-Many Example
```
Posts (many) ---- (many) Categories
```

## Localization Implementation

```javascript
// Multi-language content structure
{
  title: {
    en: 'English Title',
    th: 'ชื่อเรื่องไทย',
    ja: '日本語のタイトル',
  },
  content: {
    en: 'English content...',
    th: 'เนื้อหาไทย...',
    ja: '日本語の内容...',
  },
}
```

## Image Optimization Best Practices

### Contentful Image API
```
https://images.ctfassets.net/xyz/abc123/v/img.jpg?w=800&h=600&fit=fill&q=80
```

### Strapi Integration
- Automatic thumbnail generation
- Responsive image variants
- Built-in CDN support

### Payload Integration
- Image processing middleware
- Sharp integration for optimization
- Webp format support

## Database Schema Documentation Format

```
Table users {
  id int [primary key]
  email varchar [unique]
  created_at timestamp

  indexes {
    email
  }
}

Table posts {
  id int [primary key]
  user_id int [ref: > users.id]
  title varchar
  content text
}

Ref: posts.user_id > users.id
```
