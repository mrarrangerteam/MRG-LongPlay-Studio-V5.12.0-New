---
name: mrarranger-dev-fullstack
description: "MRARRANGER Dev Fullstack - รวม 12 Skills: Auth (OAuth, JWT, RBAC, 2FA, NextAuth, Supabase Auth), API Master (REST, GraphQL, tRPC, WebSocket, gRPC), Supabase (Database, Auth, Storage, Edge Functions, RLS), CMS (Headless CMS, Strapi, Sanity, Contentful), Bridge (System Integration, API Gateway, Message Queue), React+Next.js (App Router, RSC, SSR, ISR), Frontend Design (CSS, Tailwind, Animations, Responsive), UI System (Design System, Component Library, Storybook, Tokens), Web Design (Landing Pages, Portfolio, Corporate Sites), Remotion (Programmatic Video, React Video, Animation), SEO (On-page, Technical, Local, International), SEO Master (Advanced SEO Strategy, Schema, Core Web Vitals). Commands: /auth /oauth /api /graphql /supabase /cms /bridge /react /nextjs /frontend /ui /web /remotion /seo"
---

# mrarranger-dev-fullstack - Combined Skill

> Auto-routing: วิเคราะห์ request แล้วโหลด reference ที่เกี่ยวข้อง

## HOW TO USE
1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง
3. โหลด reference file ที่ตรงกับ request
4. Execute ตาม instructions ใน reference

## SKILL ROUTING TABLE

| Skill | Reference File |
|-------|---------------|
| mrarranger-auth | references/mrarranger-auth.md |
| mrarranger-api-master | references/mrarranger-api-master.md |
| mrarranger-supabase | references/mrarranger-supabase.md |
| mrarranger-cms | references/mrarranger-cms.md |
| mrarranger-bridge | references/mrarranger-bridge.md |
| mrarranger-react-nextjs | references/mrarranger-react-nextjs.md |
| mrarranger-frontend-design | references/mrarranger-frontend-design.md |
| mrarranger-ui-system | references/mrarranger-ui-system.md |
| mrarranger-web-design | references/mrarranger-web-design.md |
| mrarranger-remotion | references/mrarranger-remotion.md |
| mrarranger-seo | references/mrarranger-seo.md |
| mrarranger-seo-master | references/mrarranger-seo-master.md |

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ skill ไหนจาก routing table
2. ใช้ `view` tool อ่าน reference file ที่เกี่ยวข้อง
3. ทำตาม instructions ใน reference file นั้นอย่างเคร่งครัด
4. ถ้าเกี่ยวข้องหลาย skills ให้อ่านทุก reference ที่เกี่ยวข้อง
