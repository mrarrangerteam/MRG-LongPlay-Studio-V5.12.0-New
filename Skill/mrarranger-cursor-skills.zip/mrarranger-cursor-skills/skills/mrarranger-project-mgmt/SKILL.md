---
name: mrarranger-project-mgmt
description: "MRARRANGER Project Management - Agile/Scrum (Sprint Planning, Retrospective, Daily Standup), Kanban, Product Backlog Management, User Story Writing, Story Points and Estimation, Release Planning, Roadmap, Risk Management, Stakeholder Management, Resource Allocation, Gantt Chart, Milestone Tracking, RACI Matrix, Post-Mortem Analysis, Jira/Linear/Asana Workflows. Commands: /sprint /scrum /kanban /backlog /userstory /estimate /roadmap /risk /stakeholder /raci /postmortem /release. Triggers: agile, scrum, sprint, kanban, backlog, roadmap, project management, RACI, estimation"
---

# Project Management & Agile Methodologies Skill

## Overview

This skill provides comprehensive guidance on modern project management practices, with emphasis on Agile and Scrum methodologies. It covers the full spectrum from day-to-day execution to strategic planning and continuous improvement.

## Core Competencies

### 1. Agile & Scrum Framework

**Agile Principles** (Agile Manifesto):

**Core Values**:
1. Individuals and interactions over processes and tools
2. Working software over comprehensive documentation
3. Customer collaboration over contract negotiation
4. Responding to change over following a plan

**Underlying Principles**:
- Customer satisfaction through early delivery
- Welcome changing requirements
- Deliver working software frequently
- Business and developers work together daily
- Build projects around motivated individuals
- Face-to-face communication preferred
- Working software is primary measure of progress
- Sustainable pace
- Technical excellence and good design
- Simplicity
- Self-organizing teams
- Continuous improvement

**Scrum Framework Overview**

**Scrum Roles**:
- **Product Owner**: Owns product vision, manages backlog, defines requirements
- **Scrum Master**: Facilitates process, removes blockers, coaches team
- **Development Team**: 5-9 people, cross-functional, self-organizing, does the work

**Scrum Artifacts**:
- **Product Backlog**: Prioritized list of all features/requirements
- **Sprint Backlog**: Items committed to for current sprint
- **Increment**: Working product at end of sprint (potentially shippable)

**Scrum Ceremonies** (Events):
- **Sprint Planning**: Plan what will be done in next sprint (4 hours for 2-week sprint)
- **Daily Standup**: 15-minute sync on progress and blockers
- **Sprint Review**: Demo work completed to stakeholders
- **Sprint Retrospective**: Team reflects on process and identifies improvements

**Sprint Mechanics**

**Typical 2-Week Sprint**:
- **Monday Morning**: Sprint Planning (4 hours)
- **Daily**: Standup (15 minutes)
- **Wednesday-Thursday**: Mid-sprint review or demos
- **Friday Afternoon**: Sprint Review (1.5 hours) + Retrospective (1.5 hours)

**Sprint Capacity Planning**:
- Team velocity: Points completed per sprint (historical)
- Example: Team has 40-point velocity
- New sprint: Select items totaling ~40 points
- Leave room for unknowns and support work

**Sprint Planning**

**Objective**: Team commits to what they'll accomplish

**Process**:
1. Product Owner presents top backlog items with context
2. Team asks clarifying questions
3. Team estimates effort (story points)
4. Team commits to items totaling expected velocity
5. Team breaks items into tasks
6. Team identifies dependencies and blockers

**Planning Meeting Timing**:
- 2-week sprint: 4-hour planning meeting
- 1-week sprint: 2-hour planning meeting
- Longer sprint: 8 hours or split across 2 days

**Definition of Ready** (before item can enter sprint):
- Clear acceptance criteria
- Estimated and sized
- Dependencies identified
- No major blockers
- Product Owner and team aligned

**Daily Standup**

**Purpose**: Synchronization and blocker identification (not status reporting)

**3 Questions**:
1. What did I complete since last standup?
2. What will I work on before next standup?
3. What blockers or issues are preventing progress?

**Best Practices**:
- Same time daily (maintains habit)
- 15-minute timebox (strictly enforced)
- Standing (keeps meetings brief)
- Team only (no status reporting to management)
- Focus on team impediments (not individual reporting)
- If deep discussion needed, schedule separate conversation

**Sprint Review (Demo)**

**Purpose**: Show stakeholders completed work and gather feedback

**Agenda** (1.5 hours for 2-week sprint):
- Welcome and overview
- Demo completed work (5-10 min per item)
- Gather feedback and questions
- Discuss any scope changes
- Thank participants

**What to Demo**:
- Working, potentially shippable functionality
- Focus on user-facing features
- Real data when possible
- Prepare for questions
- Get feedback, not approval

**Sprint Retrospective**

**Purpose**: Continuous improvement of team process

**Format** (1.5 hours):
1. Welcome and ground rules (5 min)
2. What went well? (20 min)
3. What didn't go well? (20 min)
4. What will we improve? (20 min)
5. Commit to action items (10 min)

**Retrospective Techniques**:
- **Glad/Sad/Mad**: Categorize feedback into these buckets
- **Start/Stop/Continue**: What to start, stop, and continue doing
- **Sailboat**: What's moving us forward, what's dragging us down
- **Learnings**: What did we learn, what can we apply
- **Times Flies**: Identify time wasters

**Action Items**:
- Choose 1-3 specific, achievable improvements
- Assign owner for each
- Revisit in next retrospective
- Small changes compound over time

**Common Retrospective Issues**:
- Blame vs learning mindset
- Solution: Frame as "how can we improve?" not "who messed up?"
- Repeated issues without action
- Solution: Actually implement changes, measure impact
- Dominating voices
- Solution: Use silent brainstorm before discussion

### 2. Kanban Framework & Continuous Flow

**Kanban Principles**

**Core Concepts**:
- Visualize workflow
- Limit work-in-progress (WIP)
- Manage flow
- Make policies explicit
- Implement feedback loops
- Improve collaboratively

**Kanban vs Scrum**:
- **Scrum**: Time-boxed iterations, estimated stories, velocity tracking
- **Kanban**: Continuous flow, WIP limits, cycle time focus
- **Hybrid (Scrumban)**: Combine both (common in practice)

**Kanban Board Setup**

**Basic Columns**:
- Backlog
- To Do (Ready to start)
- In Progress
- Review
- Done

**WIP Limits**:
- Each column has maximum items allowed
- Example: "In Progress" limit = 3 items
- Forces team to finish work before starting new
- Improves focus and reduces context-switching

**Card Design**:
- Title/description of work
- Owner/assignee
- Priority
- Due date (if applicable)
- Labels/tags for categorization
- Size estimate (optional, unlike Scrum)

**Kanban Metrics**

**Cycle Time**:
- Time from "To Do" to "Done"
- Target: Reduce cycle time
- Measure trends and variability
- Shorter is better (faster feedback)

**Throughput**:
- Items completed per time period
- Number of items shipped per week
- Trend indicator of productivity

**Cumulative Flow Diagram** (CFD):
- Visual representation of work at each stage
- Y-axis: Item count
- X-axis: Time
- Shows bottlenecks (widening sections)
- Shows trends (increasing or decreasing)

**Lead Time**:
- Time from request creation to completion
- Includes waiting time + cycle time
- Important for customer satisfaction

**Kanban Practices**

**Pull System**:
- Team pulls work when capacity available
- Not pushed/assigned by manager
- Self-organization
- Better for knowledge work

**Explicit Policies**:
- Definition of "Done"
- WIP limit rationale
- Priority rules
- Escalation procedures
- Blocking criteria

**Service Level Expectations** (SLE):
- Example: 85% of items complete in 15 days
- Set realistic expectations
- Monitor compliance
- Adjust if not meeting

**Class of Service**:
- Different priority levels (Standard, Expedite, Fixed Date)
- Different SLEs for each
- Handles urgent vs normal work
- Prevents all work becoming urgent

### 3. Product Backlog Management

**Backlog Organization**

**Hierarchy** (from largest to smallest):
1. **Epics**: Large initiatives (3-6 month effort)
2. **Features**: Substantial capability (1-2 sprint effort)
3. **User Stories**: Implementable piece of value (days of work)
4. **Tasks**: Implementation detail (hours of work)

**Example Hierarchy**:
- Epic: "Improve user onboarding experience"
  - Feature: "In-app tutorial system"
    - Story: "As new user, I can see step-by-step tutorial on signup"
      - Task: "Design tutorial UI mockups"
      - Task: "Implement tutorial component"

**Backlog Grooming (Refinement)**

**Purpose**: Prepare items for upcoming sprints

**Cadence**:
- Mid-sprint grooming session (1-2 hours)
- Product Owner ongoing refinement
- 2-3 sprints ahead should be groomed

**Process**:
1. Add new items to backlog
2. Clarify requirements and acceptance criteria
3. Estimate effort
4. Adjust priority
5. Break down large items
6. Validate "Definition of Ready"

**Prioritization Framework**

**RICE Scoring** (Prioritization):
- **Reach**: How many users affected (count or %)
- **Impact**: Value per user (massive, high, medium, low)
- **Confidence**: Certainty in estimates (high/medium/low)
- **Effort**: Time/resources needed (team-weeks)
- **Score**: (Reach × Impact × Confidence) ÷ Effort

**Example RICE Scoring**:
- Feature A: (100 users × 3 × 100%) ÷ 5 = 60
- Feature B: (1000 users × 2 × 50%) ÷ 2 = 500
- Feature B prioritized higher

**Other Prioritization Methods**:
- **MoSCoW**: Must, Should, Could, Won't have
- **Kano Model**: Basic, Performance, Delighter
- **Value vs Effort Matrix**: 2x2 grid
- **WSJF** (Weighted Shortest Job First): SAFe framework

**Backlog Debt & Maintenance**

**Technical Debt**:
- Shortcuts taken for speed
- Accumulates code quality issues
- Must be addressed periodically
- Example: 10-20% of sprint capacity

**Product Debt**:
- Features that need updating
- Bug fixes and stability
- Performance improvements
- Accessibility improvements

**Backlog Grooming Best Practices**:
- Remove duplicates and obsolete items
- Update priority based on business changes
- Break down large items
- Add customer feedback
- Identify dependencies
- Regular reviews (quarterly at minimum)

### 4. User Story Writing & Acceptance Criteria

**User Story Format**

**Template**:
"As a [user type], I want to [action/feature], so that [benefit/reason]"

**Examples**:
- "As a user, I want to search for articles, so that I can find relevant content quickly"
- "As an admin, I want to export user data, so that I can perform analytics"
- "As a mobile user, I want to save articles offline, so that I can read them on the plane"

**Benefits of Good Stories**:
- Focuses on user value, not implementation
- Encourages conversation and questions
- Fits in sprint
- Can be tested
- Clear acceptance criteria

**Story Components**

**Description**:
- User type: Who is this for?
- Action: What do they want to do?
- Benefit: Why do they want it?
- Context: Any additional information

**Acceptance Criteria**:
- Specific, testable conditions for "done"
- Written in Given/When/Then format (Gherkin syntax)
- Acceptance scenarios that define expected behavior

**Example Acceptance Criteria**:
Story: "As a user, I want to reset my password"

Criteria:
- Given I'm on the login page
  When I click "Forgot Password"
  Then I see an email input field

- Given I enter a valid email
  When I click "Send Reset Link"
  Then I receive an email with reset link within 2 minutes

- Given I click the reset link
  When I enter a new password
  Then my password is updated and I can log in

**Story Estimation**:
- Team estimates effort required
- Can be in story points, time, or complexity
- Rough estimate is acceptable (refine later)
- Consider team's velocity

**Story Splitting**

**Goal**: Break large stories into smaller, completable pieces

**Techniques**:
1. **By workflow step**: Signup → Verification → Profile completion
2. **By user role**: Admin vs regular user features
3. **Happy path first**: Core flow, then error cases
4. **By technical layer**: Backend API, then frontend UI
5. **By complexity**: Simple cases first, edge cases later

**Example Story Split**:
- Original: "Users can create projects"
  - Too large (1-2 weeks)

- Split:
  - "Users can view create project form"
  - "Users can fill out and submit project form"
  - "Users can see success message and new project in list"

**Definition of Done (DoD)**

**Team-Level DoD** (applies to all stories):
- Code complete
- Unit tests written and passing
- Code reviewed and approved
- Acceptance criteria met
- Documentation updated
- No new warnings in linter/build
- Accessible (WCAG 2.1 AA)

**Release-Level DoD**:
- QA testing passed
- Performance acceptable
- Security review completed
- Production deployment tested
- Monitoring configured
- Documentation published
- Release notes written

### 5. Story Points & Estimation

**Story Points Explained**

**Definition**:
- Relative measure of effort/complexity
- Not hours or days
- Same estimate regardless of who does it
- Includes uncertainty and unknowns

**Scale**: Usually Fibonacci (1, 2, 3, 5, 8, 13, 21)
- Higher numbers indicate more uncertainty
- Gap increases to account for estimation difficulty

**Advantage Over Hours**:
- Removes false precision (8 hours often becomes 12-16)
- Accounts for interruptions and unknowns
- Team-based vs individual capacity
- Better for comparing across stories

**Estimation Techniques**

**Planning Poker**:
1. Product Owner reads story
2. Team asks clarifying questions
3. Everyone silently estimates (1-21 points)
4. All reveal estimates simultaneously
5. Large discrepancies discussed
6. Re-estimate if needed
7. Team agrees on final estimate

**Three-Point Estimation**:
- Optimistic (best case): 2 points
- Pessimistic (worst case): 8 points
- Most likely: 5 points
- Average or weighted average for final estimate

**T-Shirt Sizing**:
- Small, Medium, Large, Extra-Large
- Convert to story points later
- Faster for initial backlog sizing

**Velocity & Capacity**

**Velocity Definition**:
- Total story points completed in a sprint
- Historical average over last 3-6 sprints
- Used to forecast future sprint capacity

**Calculating Velocity**:
- Sprint 1: 35 points completed
- Sprint 2: 42 points
- Sprint 3: 38 points
- Average velocity: 38-39 points

**Using Velocity for Planning**:
- Upcoming sprint capacity: ~38 points
- Select backlog items totaling that amount
- Expect completion by end of sprint

**Factors Affecting Velocity**:
- Team stability (same people, better velocity)
- Interruptions (support, meetings reduce velocity)
- Complexity of work
- Tools and infrastructure
- Team skill and experience

**Managing Velocity**:
- Track over time (trend analysis)
- Protect sprint (minimize interruptions)
- Consistent sprint definition
- Realistic estimation over time

**Common Estimation Mistakes**:
- Estimating scope as points (vs effort)
- Highly variable estimates (indicates unclear stories)
- Estimation by individual capacity (should be relative)
- Not accounting for unknowns (spike for investigation)
- Gaming the system (inflating estimates)

### 6. Release Planning & Roadmap

**Release Planning**

**Definition**: Schedule features into releases over next 3-6 months

**Inputs**:
- Backlog items with estimates
- Team velocity (historical)
- Business priorities
- Dependencies
- Release constraints (date-driven or feature-driven)

**Process**:
1. Identify release goals and timeline
2. Select features for release (prioritized backlog)
3. Estimate capacity (velocity × sprints)
4. Identify dependencies and risks
5. Communicate plan to stakeholders

**Release Types**:
- **Major Release**: Significant features, often delayed if needed
- **Minor Release**: Regular cadence (every 2 weeks, monthly)
- **Hotfix Release**: Emergency bug fixes (outside normal cycle)

**Release Planning Example**:
- Current date: March 1
- Team velocity: 40 points/sprint
- Release planned: June 1 (3 months, ~13 sprints)
- Capacity: 13 × 40 = 520 points available
- Select features totaling ~500 points
- Save 20 points for bugs/unknowns

**Product Roadmap Development**

**Roadmap Purpose**:
- Strategic plan for 6-18 months ahead
- Communicate vision to stakeholders
- Align team around priorities
- Guide resource allocation
- Enable dependency planning

**Roadmap Components**:

**Now (Current Quarter)**:
- Features in active development
- Clear acceptance criteria
- Assigned to team members
- Expected completion date

**Next (Next 2-3 Quarters)**:
- Planned features with estimates
- Prioritized but not detailed
- Likely to change
- Planning in progress

**Future (6+ Months Out)**:
- Strategic initiatives
- Rough priority order
- Rough effort estimates
- Subject to significant change

**Roadmap Format Options**:
- Timeline view (Gantt-like)
- Priority matrix (importance vs effort)
- Theme-based (collections of related features)
- Quarterly views (high-level themes)

**Roadmap Communication**:
- Transparent sharing (team sees strategic direction)
- Clear rationale (why prioritized)
- Version history (how it's evolved)
- Regular updates (quarterly review)
- Stakeholder input and feedback

**Managing Roadmap Changes**:
- Business priorities shift
- Market conditions change
- Technical constraints discovered
- Customer feedback highlights needs
- Regular review and adjustment (quarterly)
- Document what changed and why

**Best Practices**:
- Focus on outcomes, not features
- Include capacity for bugs and technical debt
- Leave flexibility (50/50 planned vs discovery)
- Communicate trade-offs
- Involve team in planning

### 7. Risk Management & Mitigation

**Risk Identification**

**Risk Categories**:
- **Technical**: Architecture issues, performance, integration
- **Resource**: Team availability, skill gaps, hiring delays
- **Schedule**: Estimation errors, scope creep, dependencies
- **Market**: Competitive threats, changing requirements
- **Organizational**: Leadership change, funding issues
- **External**: Third-party dependencies, regulatory changes

**Identification Techniques**:
- Team brainstorming (sprint planning)
- Historical lessons (post-mortems)
- Expert consultation (architects, senior engineers)
- Risk register review (quarterly)
- Stakeholder interviews

**Risk Assessment**

**Probability**: Likelihood of occurring (Low/Medium/High or %)
**Impact**: Consequence if it occurs (Low/Medium/High or cost/schedule impact)

**Risk Score**: Probability × Impact
- High/High risks (red): Must mitigate
- Medium/Medium or High/Low (yellow): Monitor and plan
- Low/Low risks (green): Accept, monitor

**Risk Matrix**:
```
        High Impact
        |
Medium  |  YELLOW  | RED
Impact  |----------|----
        |  GREEN   | YELLOW
Low     |_________|____
        Low    Medium   High
             Probability
```

**Risk Response Strategies**

**1. Mitigate**: Reduce probability or impact
- Example: Hiring delays → Start recruiting early
- Action: Technical spike to reduce uncertainty

**2. Avoid**: Eliminate the risk entirely
- Example: Third-party library risk → Build in-house
- Action: Design decision to avoid risky approach

**3. Transfer**: Pass risk to another party
- Example: Cloud outage → Use multi-cloud
- Action: Vendor insurance or contractual guarantees

**4. Accept**: Acknowledge and plan for occurrence
- Example: Team member leaving → Cross-train others
- Action: Have contingency plan

**Risk Register & Monitoring**

**Risk Register Template**:
- ID: Unique identifier
- Description: Specific risk
- Probability: Low/Medium/High
- Impact: Low/Medium/High
- Owner: Who monitors
- Response: Mitigation approach
- Status: Active/Mitigated/Realized
- Update: Latest review date

**Risk Review Cadence**:
- Weekly in standups (quick status)
- Sprint retrospectives (lessons learned)
- Sprint planning (new risks identified)
- Quarterly reviews (comprehensive assessment)

**Escalation**:
- High-probability, high-impact risks escalate to leadership
- Clear communication on mitigation status
- Resource allocation to address risks
- Regular stakeholder updates

### 8. Stakeholder Management

**Stakeholder Identification**

**Stakeholder Types**:
- **Internal**: Team members, leadership, executives, finance
- **External**: Customers, partners, vendors, regulators
- **Users**: End users of product/service
- **Decision-makers**: Approvers, budget holders

**Stakeholder Analysis**:
- **Interest**: How much do they care? (High/Medium/Low)
- **Influence**: How much power do they have? (High/Medium/Low)
- **Position**: Supporter, neutral, or opponent?

**Stakeholder Matrix**:
```
        High Interest
        |
High    |  MANAGE   | MANAGE
Influence|  CLOSELY  | CLOSELY
        |-----------|--------
Low     |  MONITOR  | KEEP
        |-----------|  AWARE
        Low     High
            Interest
```

**Stakeholder Engagement**

**High Interest/High Influence**:
- Executive sponsor, product owner, key customer
- Frequent communication (weekly+)
- Involve in decisions
- Address concerns immediately

**High Interest/Low Influence**:
- Team members, engaged users
- Regular updates (weekly/bi-weekly)
- Seek input and feedback
- Maintain enthusiasm

**Low Interest/High Influence**:
- Executives, board members, partners
- Periodic updates (monthly/quarterly)
- Highlight strategic impact
- Escalate risks early

**Low Interest/Low Influence**:
- Peripheral stakeholders
- Minimal communication
- Keep informed of progress
- Escalate only if issues

**Communication Plans**

**Stakeholder Communication Matrix**:
- Stakeholder name
- Key information needs
- Communication frequency (daily/weekly/monthly)
- Format (email, meeting, dashboard)
- Owner (who communicates)

**Communication Strategy**:
- Tailor message to audience (technical vs non-technical)
- Focus on impact and outcomes
- Use visuals (charts, demos)
- Timely delivery (before they ask)
- Clear and honest (bad news early)

**Handling Conflicting Stakeholders**:
- Understand underlying interests
- Find common ground
- Escalate if needed
- Document decisions made
- Maintain relationships

### 9. Resource Allocation & Capacity

**Resource Planning**

**Available Resources**:
- Developers (front-end, back-end, full-stack)
- Designers (UI/UX, visual)
- QA/Testers
- DevOps/Infrastructure
- Product managers
- Project managers/Scrum masters

**Capacity Assessment**:
- Team size: Number of each role
- Hours available: 40 hours/week vs ~35 productive hours
- Availability: Vacation, sick leave, other commitments
- Skill level: Junior/mid/senior impact

**Capacity Planning**:
- Calculate available hours per week
- Account for meetings and non-project work
- Estimate effort for planned work
- Adjust scope if needed
- Track actual capacity (retrospective)

**Resource Utilization**:
- Fully utilized: 90-100% (risky, no buffer)
- Healthy: 80-90% (room for unknowns)
- Underutilized: <70% (inefficient, consider reallocating)

**Multi-project Resource Management**

**Resource Conflicts**:
- Team members split across projects
- Context-switching reduces productivity
- Competing deadlines

**Mitigation**:
- Minimize splits (keep people on one project)
- Explicit resource allocation
- Clear priorities (which project takes precedence)
- Regular rebalancing (sprint to sprint)

**Escalation for Resource Issues**:
- Too much work: Reduce scope or hire
- Wrong skills: Training or hire specialists
- Bottlenecks: Cross-train or redistribute

### 10. Milestone Tracking & Status Reporting

**Milestone Definition**

**Characteristics**:
- Significant achievement (feature release, phase completion)
- Has specific date (target)
- Measurable (done/not done)
- Important for stakeholders
- Typically 2-3 months apart

**Examples**:
- Alpha release to customers
- Public launch
- Series B funding close
- 1M users achieved
- Feature complete

**Milestone Planning**

**Establishing Milestones**:
1. Identify key achievements
2. Sequence logically
3. Estimate effort
4. Assign target dates
5. Identify dependencies
6. Communicate to team

**Tracking Progress**:
- Status dashboard (real-time)
- Weekly updates to stakeholders
- Risk identification and escalation
- Proactive adjustment if needed

**Milestone Status Reporting**:

**Status Levels**:
- **On Track** (Green): Will meet deadline with current resources
- **At Risk** (Yellow): May miss deadline, mitigation planned
- **Off Track** (Red): Will miss deadline, escalation needed

**Status Report Contents**:
- Milestone name and target date
- Percent complete
- What was accomplished this week
- What's planned next week
- Risks and issues
- Changes or adjustments needed
- Confidence level in delivery

**Gantt Charts** (for complex projects)

**Components**:
- Vertical axis: Tasks or milestones
- Horizontal axis: Time (weeks, months)
- Bars: Duration of tasks
- Dependencies: Arrows showing task relationships
- Current date marker

**Benefits**:
- Visual timeline
- Dependency identification
- Critical path analysis
- Progress tracking
- Stakeholder communication

**Tools**: Microsoft Project, Asana, Monday.com, GanttProject

### 11. RACI Matrix & Accountability

**RACI Definition**

**R - Responsible**: Does the work, makes decisions
**A - Accountable**: Final authority, approves
**C - Consulted**: Provides input and expertise
**I - Informed**: Kept updated, but not consulted

**RACI Matrix Template**:

```
Activity          | PM | Dev | QA | Design | Product
Feature Design    | C  | C   | I  | A      | R
Sprint Planning   | A  | R   | C  | C      | C
Code Review       | I  | R   | C  | I      | I
Testing           | C  | C   | R  | C      | I
Release           | A  | C   | R  | C      | C
```

**RACI Best Practices**

**Principles**:
- Each task should have exactly one "A" (accountable)
- Limit "R"s (too many = confusion)
- Limit "C"s (too many = slow decisions)
- Use "I" for awareness only
- Review and update quarterly

**Benefits**:
- Clarity on who decides
- Clear accountability
- Efficient decision-making
- Reduced conflict
- Better handoffs

**Common Issues**:
- No "A" (accountable): Unclear who has final say
- Multiple "A"s: Conflicting decisions
- Too many "C"s: Slow process
- "R" without "A": Responsible but can't decide

### 12. Post-Mortem & Continuous Improvement

**Post-Mortem Purpose**

**Goals**:
- Learn from successes and failures
- Improve processes
- Share knowledge
- Build team resilience
- Document for future

**When to Conduct**:
- Major incident or outage
- Release issues
- Missed deadline
- Project completion (debrief)
- Major process changes

**Post-Mortem Process**

**Timing**: Within 1-2 days (while fresh, before blame)

**Structure** (1-2 hours):

**1. What Happened?** (Timeline)
- Chronological sequence of events
- Who did what
- When events occurred
- Facts, not opinions

**2. What Were the Impacts?**
- Customer impact (users affected, revenue loss)
- Business impact (reputation, trust)
- Team impact (hours spent, stress)
- Quantify when possible

**3. Why Did It Happen?** (Root Cause)
- Identify root causes (not just symptoms)
- Use "5 Whys" technique:
  - Why did the bug occur? Missing validation
  - Why was validation missing? Incomplete requirements
  - Why incomplete? No review before coding
  - Why no review? Rushing due to deadline
  - Why rushing? Underestimated effort

**4. What Can We Do Better?** (Action Items)
- Specific, actionable improvements
- Assign owners
- Set target dates
- Measurable outcomes
- Choose 2-3 highest-impact items

**Post-Mortem Culture**

**Blameless Approach**:
- Focus on systems and processes, not individuals
- Assume good intent
- Ask "How could this happen?" not "Who did this?"
- Psychological safety required

**Transparency**:
- Share post-mortems widely
- Learn from others' mistakes
- Prevent recurrence
- Build organizational knowledge

**Follow-Through**:
- Actually implement action items
- Track completion
- Measure impact
- Close the loop with team

**Common Post-Mortem Mistakes**:
- Blame individuals (kills learning)
- Vague action items (nothing happens)
- No follow-up (learn same lesson again)
- Taking too long (loses momentum)
- Only on failures (ignore successes)

### 13. Jira, Linear, Asana & Project Management Tools

**Tool Selection Criteria**

**Evaluation Factors**:
- **Team Size**: Works for 5 or 500?
- **Workflow**: Scrum, Kanban, hybrid support?
- **Integration**: GitHub, Slack, documentation?
- **Customization**: Flexible or opinionated?
- **Cost**: Per seat, per project, or flat?
- **Learning Curve**: Quick adoption or training needed?

**Jira** (Atlassian)

**Best For**: Development teams, Scrum/Kanban, complex workflows

**Features**:
- Flexible issue/task management
- Multiple view options (board, list, timeline)
- Custom fields and workflows
- Extensive integrations
- Reporting and dashboards
- Parent-child relationships (epics, features, stories)

**Common Workflows**:
- Issue created → In Progress → Code Review → In Testing → Done
- Epic → Stories → Tasks
- Sprints with planning, review, retrospective support

**Jira Best Practices**:
- Keep issue descriptions clear and detailed
- Use issue types consistently
- Define workflow that matches process
- Use fields strategically (not too many)
- Regular field and workflow audits

**Linear** (Linear.app)

**Best For**: Startups, fast-moving teams, simple workflows

**Features**:
- Streamlined interface (less overwhelming than Jira)
- Fast issue creation and navigation
- GitHub integration native
- Cycle management (similar to sprints)
- Database of archived issues
- Keyboard shortcuts for power users

**Best Practices**:
- Keep issue count manageable (archive completed)
- Use milestones for releases
- Estimate using t-shirt sizes or story points
- Link related issues
- Regular triage and prioritization

**Asana** (Asana.com)

**Best For**: Cross-functional teams, mixed Agile + traditional PM

**Features**:
- Project management with dependencies
- Multiple views (list, board, timeline, calendar)
- Template workflows
- Portfolios for strategic view
- Detailed task and subtask management
- Rich collaboration features

**Best Practices**:
- Create templates for recurring work types
- Use custom fields for categorization
- Set clear dependencies
- Regular review of project progress
- Utilize portfolios for leadership visibility

**General Tool Best Practices**

**Data Quality**:
- Keep descriptions clear and updated
- Remove completed/obsolete items periodically
- Use consistent terminology
- Assign ownership
- Prioritize ruthlessly

**Team Adoption**:
- Training on tool basics
- Create templates and workflows
- Consistent usage across team
- Regular tool updates and improvements
- Feedback and iteration

**Integration with Other Tools**:
- Link to GitHub/GitLab (code commits)
- Slack notifications (status updates)
- Documentation (Confluence, Google Docs)
- Calendar (deadlines, milestones)
- Analytics (dashboards, metrics)

**Avoiding Tool Overuse**:
- Tool is servant, not master
- Don't over-engineer workflows
- Regular simplification
- Focus on outcomes, not tool usage
- Some teams thrive with pen and paper (valid!)

## Quick Reference

### Common Commands & Triggers
- `/sprint` - Sprint planning and execution
- `/scrum` - Scrum framework and ceremonies
- `/kanban` - Kanban board setup and management
- `/backlog` - Product backlog management and grooming
- `/userstory` - User story writing and acceptance criteria
- `/estimate` - Story point estimation and planning poker
- `/roadmap` - Product roadmap development
- `/risk` - Risk identification and management
- `/stakeholder` - Stakeholder management and communication
- `/raci` - RACI matrix and accountability
- `/postmortem` - Post-mortem analysis and retrospectives
- `/release` - Release planning and milestones

## Conclusion

Effective project management combines strategic planning with iterative execution. Whether using Scrum, Kanban, or a hybrid approach, the key is creating clear structures that enable teams to communicate, adapt, and deliver value consistently while continuously improving processes and outcomes.
