#!/usr/bin/env python3
"""
MRARRANGER Asteroid Astrology Calculator
คำนวณตำแหน่งดาวและ Asteroid ด้วย Swiss Ephemeris

Usage:
    python astro_calc.py --date "1990-05-15" --time "14:30" --lat 13.7563 --lon 100.5018 --city "Bangkok"
    python astro_calc.py --date "1990-05-15" --time "14:30" --place "Bangkok, Thailand"

Dependencies:
    pip install pyswisseph geopy --break-system-packages
"""

import argparse
import json
import sys
import math
from datetime import datetime

try:
    import swisseph as swe
    HAS_SWE = True
except ImportError:
    HAS_SWE = False
    print("WARNING: pyswisseph not installed. Run: pip install pyswisseph --break-system-packages")

# ============================================================
# CONSTANTS
# ============================================================

SIGNS = [
    {"en": "Aries", "th": "เมษ", "symbol": "♈"},
    {"en": "Taurus", "th": "พฤษภ", "symbol": "♉"},
    {"en": "Gemini", "th": "เมถุน", "symbol": "♊"},
    {"en": "Cancer", "th": "กรกฎ", "symbol": "♋"},
    {"en": "Leo", "th": "สิงห์", "symbol": "♌"},
    {"en": "Virgo", "th": "กันย์", "symbol": "♍"},
    {"en": "Libra", "th": "ตุลย์", "symbol": "♎"},
    {"en": "Scorpio", "th": "พิจิก", "symbol": "♏"},
    {"en": "Sagittarius", "th": "ธนู", "symbol": "♐"},
    {"en": "Capricorn", "th": "มังกร", "symbol": "♑"},
    {"en": "Aquarius", "th": "กุมภ์", "symbol": "♒"},
    {"en": "Pisces", "th": "มีน", "symbol": "♓"},
]

HOUSES_TH = [
    "เรือนที่ 1 (ตัวตน)", "เรือนที่ 2 (ทรัพย์สิน)", "เรือนที่ 3 (การสื่อสาร)",
    "เรือนที่ 4 (บ้าน)", "เรือนที่ 5 (ความคิดสร้างสรรค์)", "เรือนที่ 6 (สุขภาพ)",
    "เรือนที่ 7 (คู่ครอง)", "เรือนที่ 8 (การเปลี่ยนแปลง)", "เรือนที่ 9 (ปรัชญา)",
    "เรือนที่ 10 (อาชีพ)", "เรือนที่ 11 (เพื่อน)", "เรือนที่ 12 (จิตใต้สำนึก)",
]

# Swiss Ephemeris planet IDs
PLANETS = {
    "Sun": swe.SUN if HAS_SWE else 0,
    "Moon": swe.MOON if HAS_SWE else 1,
    "Mercury": swe.MERCURY if HAS_SWE else 2,
    "Venus": swe.VENUS if HAS_SWE else 3,
    "Mars": swe.MARS if HAS_SWE else 4,
    "Jupiter": swe.JUPITER if HAS_SWE else 5,
    "Saturn": swe.SATURN if HAS_SWE else 6,
    "Uranus": swe.URANUS if HAS_SWE else 7,
    "Neptune": swe.NEPTUNE if HAS_SWE else 8,
    "Pluto": swe.PLUTO if HAS_SWE else 9,
    "North Node": swe.MEAN_NODE if HAS_SWE else 10,
    "Chiron": swe.CHIRON if HAS_SWE else 15,
}

# Asteroid numbers for swe.calc with FLG_ASTEROID
ASTEROIDS = {
    "Ceres": 1,
    "Pallas": 2,
    "Juno": 3,
    "Vesta": 4,
    "Eros": 433,
    "Psyche": 16,
    "Lilith (True)": swe.OSCU_APOG if HAS_SWE else 13,  # True Lilith
    "Nessus": 7066,
    "Pholus": 5145,
}

PLANET_SYMBOLS = {
    "Sun": "☉", "Moon": "☽", "Mercury": "☿", "Venus": "♀", "Mars": "♂",
    "Jupiter": "♃", "Saturn": "♄", "Uranus": "♅", "Neptune": "♆", "Pluto": "♇",
    "North Node": "☊", "Chiron": "⚷", "Ceres": "⚳", "Pallas": "⚴",
    "Juno": "⚵", "Vesta": "⚶", "Eros": "♡", "Psyche": "Ψ",
    "Lilith (True)": "⚸", "Nessus": "⊗", "Pholus": "⊕",
}

PLANET_TH = {
    "Sun": "อาทิตย์", "Moon": "จันทร์", "Mercury": "พุธ", "Venus": "ศุกร์",
    "Mars": "อังคาร", "Jupiter": "พฤหัสบดี", "Saturn": "เสาร์",
    "Uranus": "ยูเรนัส", "Neptune": "เนปจูน", "Pluto": "พลูโต",
    "North Node": "ราหู", "Chiron": "ไครอน", "Ceres": "ซีรีส",
    "Pallas": "พัลลาส", "Juno": "จูโน", "Vesta": "เวสตา",
    "Eros": "อีรอส", "Psyche": "ไซคี", "Lilith (True)": "ลิลิธ",
    "Nessus": "เนสซัส", "Pholus": "โฟลัส",
}


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def degree_to_sign(degree):
    """Convert ecliptic degree to sign + degree within sign"""
    sign_idx = int(degree / 30) % 12
    deg_in_sign = degree % 30
    deg = int(deg_in_sign)
    minutes = int((deg_in_sign - deg) * 60)
    return {
        "sign_idx": sign_idx,
        "sign_en": SIGNS[sign_idx]["en"],
        "sign_th": SIGNS[sign_idx]["th"],
        "sign_symbol": SIGNS[sign_idx]["symbol"],
        "degree": deg,
        "minutes": minutes,
        "total_degree": degree,
        "display_en": f"{deg}°{minutes:02d}' {SIGNS[sign_idx]['en']}",
        "display_th": f"{deg}°{minutes:02d}' ราศี{SIGNS[sign_idx]['th']}",
    }


def find_house(degree, house_cusps):
    """Find which house a degree falls in"""
    for i in range(12):
        next_i = (i + 1) % 12
        cusp = house_cusps[i]
        next_cusp = house_cusps[next_i]
        if next_cusp < cusp:  # Wraps around 0°
            if degree >= cusp or degree < next_cusp:
                return i + 1
        else:
            if cusp <= degree < next_cusp:
                return i + 1
    return 1  # Fallback


def calc_aspect(deg1, deg2):
    """Calculate aspect between two degrees"""
    diff = abs(deg1 - deg2)
    if diff > 180:
        diff = 360 - diff

    aspects = [
        {"name": "Conjunction", "symbol": "☌", "angle": 0, "orb": 8, "th": "ดาวร่วม"},
        {"name": "Opposition", "symbol": "☍", "angle": 180, "orb": 8, "th": "ดาวตรงข้าม"},
        {"name": "Trine", "symbol": "△", "angle": 120, "orb": 8, "th": "ตรีโกณ"},
        {"name": "Square", "symbol": "□", "angle": 90, "orb": 7, "th": "จัตุโกณ"},
        {"name": "Sextile", "symbol": "⚹", "angle": 60, "orb": 6, "th": "ฉกโกณ"},
        {"name": "Quincunx", "symbol": "⚻", "angle": 150, "orb": 3, "th": "ปรับตัว"},
    ]

    for asp in aspects:
        if abs(diff - asp["angle"]) <= asp["orb"]:
            orb_actual = round(abs(diff - asp["angle"]), 2)
            return {
                "name": asp["name"],
                "symbol": asp["symbol"],
                "angle": asp["angle"],
                "orb": orb_actual,
                "th": asp["th"],
                "applying": diff < asp["angle"],
            }
    return None


def datetime_to_jd(date_str, time_str, timezone_offset=7):
    """Convert date and time to Julian Day"""
    dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    # Convert to UT
    ut_hour = dt.hour + dt.minute / 60.0 - timezone_offset
    return swe.julday(dt.year, dt.month, dt.day, ut_hour)


def geocode_place(place_name):
    """Geocode a place name to lat/lon using geopy"""
    try:
        from geopy.geocoders import Nominatim
        geolocator = Nominatim(user_agent="mrarranger-astrology")
        location = geolocator.geocode(place_name)
        if location:
            return location.latitude, location.longitude, location.address
    except ImportError:
        print("WARNING: geopy not installed. Please provide --lat and --lon directly.")
        print("Install with: pip install geopy --break-system-packages")
    return None, None, None


# ============================================================
# MAIN CALCULATION
# ============================================================

def calculate_chart(date_str, time_str, lat, lon, timezone_offset=7, house_system=b'P'):
    """
    Calculate full natal chart with planets + asteroids

    Args:
        date_str: "YYYY-MM-DD"
        time_str: "HH:MM"
        lat: latitude
        lon: longitude
        timezone_offset: hours from UTC (default 7 for Thailand)
        house_system: b'P' Placidus, b'W' Whole Sign, b'K' Koch

    Returns:
        dict with all chart data
    """
    if not HAS_SWE:
        return {"error": "pyswisseph not installed"}

    jd = datetime_to_jd(date_str, time_str, timezone_offset)

    # Calculate houses
    houses, ascmc = swe.houses(jd, lat, lon, house_system)
    house_cusps = list(houses)
    asc = ascmc[0]
    mc = ascmc[1]

    result = {
        "birth_data": {
            "date": date_str,
            "time": time_str,
            "latitude": lat,
            "longitude": lon,
            "timezone": f"UTC+{timezone_offset}",
            "julian_day": jd,
            "house_system": "Placidus" if house_system == b'P' else "Whole Sign" if house_system == b'W' else "Koch",
        },
        "angles": {
            "Ascendant": degree_to_sign(asc),
            "Midheaven": degree_to_sign(mc),
            "Descendant": degree_to_sign((asc + 180) % 360),
            "IC": degree_to_sign((mc + 180) % 360),
        },
        "house_cusps": [degree_to_sign(h) for h in house_cusps],
        "planets": {},
        "asteroids": {},
        "aspects": [],
    }

    # Calculate planets
    all_positions = {}

    for name, planet_id in PLANETS.items():
        try:
            pos, ret = swe.calc_ut(jd, planet_id)
            deg = pos[0]
            speed = pos[3] if len(pos) > 3 else 0
            sign_info = degree_to_sign(deg)
            house = find_house(deg, house_cusps)

            result["planets"][name] = {
                **sign_info,
                "house": house,
                "house_th": HOUSES_TH[house - 1],
                "retrograde": speed < 0,
                "speed": round(speed, 4),
                "symbol": PLANET_SYMBOLS.get(name, ""),
                "th_name": PLANET_TH.get(name, name),
            }
            all_positions[name] = deg
        except Exception as e:
            result["planets"][name] = {"error": str(e)}

    # Calculate asteroids
    for name, ast_id in ASTEROIDS.items():
        try:
            if name == "Lilith (True)":
                pos, ret = swe.calc_ut(jd, ast_id)
            else:
                pos, ret = swe.calc_ut(jd, swe.AST_OFFSET + ast_id)
            deg = pos[0]
            speed = pos[3] if len(pos) > 3 else 0
            sign_info = degree_to_sign(deg)
            house = find_house(deg, house_cusps)

            result["asteroids"][name] = {
                **sign_info,
                "house": house,
                "house_th": HOUSES_TH[house - 1],
                "retrograde": speed < 0,
                "speed": round(speed, 4),
                "symbol": PLANET_SYMBOLS.get(name, ""),
                "th_name": PLANET_TH.get(name, name),
            }
            all_positions[name] = deg
        except Exception as e:
            result["asteroids"][name] = {"error": str(e)}

    # Add angles to positions for aspect calculation
    all_positions["Ascendant"] = asc
    all_positions["Midheaven"] = mc

    # Calculate aspects
    bodies = list(all_positions.keys())
    for i in range(len(bodies)):
        for j in range(i + 1, len(bodies)):
            name1, name2 = bodies[i], bodies[j]
            aspect = calc_aspect(all_positions[name1], all_positions[name2])
            if aspect:
                result["aspects"].append({
                    "body1": name1,
                    "body1_th": PLANET_TH.get(name1, name1),
                    "body1_symbol": PLANET_SYMBOLS.get(name1, ""),
                    "body2": name2,
                    "body2_th": PLANET_TH.get(name2, name2),
                    "body2_symbol": PLANET_SYMBOLS.get(name2, ""),
                    **aspect,
                })

    # Sort aspects by orb (tightest first)
    result["aspects"].sort(key=lambda x: x["orb"])

    # Calculate Part of Fortune
    sun_deg = all_positions.get("Sun", 0)
    moon_deg = all_positions.get("Moon", 0)
    pof = (asc + moon_deg - sun_deg) % 360
    result["special_points"] = {
        "Part of Fortune": {
            **degree_to_sign(pof),
            "house": find_house(pof, house_cusps),
        },
        "South Node": {
            **degree_to_sign((all_positions.get("North Node", 0) + 180) % 360),
            "house": find_house((all_positions.get("North Node", 0) + 180) % 360, house_cusps),
        },
    }

    # Element balance
    elements = {"Fire": 0, "Earth": 0, "Air": 0, "Water": 0}
    element_map = {0: "Fire", 1: "Earth", 2: "Air", 3: "Water",
                   4: "Fire", 5: "Earth", 6: "Air", 7: "Water",
                   8: "Fire", 9: "Earth", 10: "Air", 11: "Water"}
    modalities = {"Cardinal": 0, "Fixed": 0, "Mutable": 0}
    modality_map = {0: "Cardinal", 1: "Fixed", 2: "Mutable",
                    3: "Cardinal", 4: "Fixed", 5: "Mutable",
                    6: "Cardinal", 7: "Fixed", 8: "Mutable",
                    9: "Cardinal", 10: "Fixed", 11: "Mutable"}

    for name in ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"]:
        if name in result["planets"] and "sign_idx" in result["planets"][name]:
            idx = result["planets"][name]["sign_idx"]
            elements[element_map[idx]] += 1
            modalities[modality_map[idx]] += 1

    result["balance"] = {
        "elements": elements,
        "elements_th": {
            "ไฟ (Fire)": elements["Fire"],
            "ดิน (Earth)": elements["Earth"],
            "ลม (Air)": elements["Air"],
            "น้ำ (Water)": elements["Water"],
        },
        "modalities": modalities,
        "modalities_th": {
            "ริเริ่ม (Cardinal)": modalities["Cardinal"],
            "คงที่ (Fixed)": modalities["Fixed"],
            "ปรับตัว (Mutable)": modalities["Mutable"],
        },
    }

    return result


def format_chart_text(chart, lang="th"):
    """Format chart data as readable text"""
    lines = []

    if lang == "th":
        lines.append("=" * 60)
        lines.append("  รายงานดวงชะตากำเนิด — Natal Chart Report")
        lines.append("=" * 60)
        bd = chart["birth_data"]
        lines.append(f"  วันเกิด: {bd['date']}  เวลา: {bd['time']}  ({bd['timezone']})")
        lines.append(f"  พิกัด: {bd['latitude']}, {bd['longitude']}")
        lines.append(f"  ระบบเรือน: {bd['house_system']}")
        lines.append("")

        # Angles
        angles = chart["angles"]
        lines.append("--- จุดสำคัญ (Angles) ---")
        for name, info in angles.items():
            lines.append(f"  {name}: {info['display_th']}")
        lines.append("")

        # Planets
        lines.append("--- ดาวพื้นฐาน (Planets) ---")
        for name, info in chart["planets"].items():
            if "error" in info:
                continue
            rx = " (R)" if info.get("retrograde") else ""
            symbol = info.get("symbol", "")
            th_name = info.get("th_name", name)
            lines.append(
                f"  {symbol} {th_name} ({name}): {info['display_th']} "
                f"| {info['house_th']}{rx}"
            )
        lines.append("")

        # Asteroids
        lines.append("--- Asteroid ---")
        for name, info in chart["asteroids"].items():
            if "error" in info:
                continue
            rx = " (R)" if info.get("retrograde") else ""
            symbol = info.get("symbol", "")
            th_name = info.get("th_name", name)
            lines.append(
                f"  {symbol} {th_name} ({name}): {info['display_th']} "
                f"| {info['house_th']}{rx}"
            )
        lines.append("")

        # Balance
        lines.append("--- สมดุลธาตุและคุณภาพ ---")
        for k, v in chart["balance"]["elements_th"].items():
            bar = "█" * v
            lines.append(f"  {k}: {bar} ({v})")
        lines.append("")
        for k, v in chart["balance"]["modalities_th"].items():
            bar = "█" * v
            lines.append(f"  {k}: {bar} ({v})")
        lines.append("")

        # Top Aspects
        lines.append("--- Aspect สำคัญ (เรียงตาม Orb แคบสุด) ---")
        for asp in chart["aspects"][:30]:
            lines.append(
                f"  {asp['body1_th']} {asp['symbol']} {asp['body2_th']} "
                f"({asp['name']}, orb {asp['orb']}°)"
            )

    else:  # English
        lines.append("=" * 60)
        lines.append("  Natal Chart Report")
        lines.append("=" * 60)
        bd = chart["birth_data"]
        lines.append(f"  Date: {bd['date']}  Time: {bd['time']}  ({bd['timezone']})")
        lines.append(f"  Coordinates: {bd['latitude']}, {bd['longitude']}")
        lines.append(f"  House System: {bd['house_system']}")
        lines.append("")

        lines.append("--- Angles ---")
        for name, info in chart["angles"].items():
            lines.append(f"  {name}: {info['display_en']}")
        lines.append("")

        lines.append("--- Planets ---")
        for name, info in chart["planets"].items():
            if "error" in info:
                continue
            rx = " (R)" if info.get("retrograde") else ""
            symbol = info.get("symbol", "")
            lines.append(f"  {symbol} {name}: {info['display_en']} | House {info['house']}{rx}")
        lines.append("")

        lines.append("--- Asteroids ---")
        for name, info in chart["asteroids"].items():
            if "error" in info:
                continue
            rx = " (R)" if info.get("retrograde") else ""
            symbol = info.get("symbol", "")
            lines.append(f"  {symbol} {name}: {info['display_en']} | House {info['house']}{rx}")
        lines.append("")

        lines.append("--- Element Balance ---")
        for k, v in chart["balance"]["elements"].items():
            bar = "█" * v
            lines.append(f"  {k}: {bar} ({v})")
        lines.append("")

        lines.append("--- Top Aspects (sorted by orb) ---")
        for asp in chart["aspects"][:30]:
            lines.append(
                f"  {asp['body1']} {asp['symbol']} {asp['body2']} "
                f"({asp['name']}, orb {asp['orb']}°)"
            )

    return "\n".join(lines)


# ============================================================
# CLI
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="MRARRANGER Asteroid Astrology Calculator")
    parser.add_argument("--date", required=True, help="Birth date YYYY-MM-DD")
    parser.add_argument("--time", default="12:00", help="Birth time HH:MM (default 12:00)")
    parser.add_argument("--lat", type=float, help="Latitude")
    parser.add_argument("--lon", type=float, help="Longitude")
    parser.add_argument("--place", help="Place name (alternative to lat/lon)")
    parser.add_argument("--tz", type=float, default=7, help="Timezone offset from UTC (default 7)")
    parser.add_argument("--house", default="P", choices=["P", "W", "K"],
                       help="House system: P=Placidus, W=Whole Sign, K=Koch")
    parser.add_argument("--lang", default="th", choices=["th", "en", "both"],
                       help="Output language")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--output", help="Save output to file")

    args = parser.parse_args()

    # Get coordinates
    lat, lon = args.lat, args.lon
    if args.place and (lat is None or lon is None):
        lat, lon, addr = geocode_place(args.place)
        if lat is None:
            print(f"ERROR: Could not geocode '{args.place}'. Please provide --lat and --lon.")
            sys.exit(1)
        print(f"Geocoded: {addr} → ({lat}, {lon})")

    if lat is None or lon is None:
        print("ERROR: Please provide --lat and --lon, or --place")
        sys.exit(1)

    # Calculate chart
    chart = calculate_chart(
        args.date, args.time, lat, lon,
        timezone_offset=args.tz,
        house_system=args.house.encode()
    )

    if "error" in chart:
        print(f"ERROR: {chart['error']}")
        sys.exit(1)

    # Output
    if args.json:
        output = json.dumps(chart, ensure_ascii=False, indent=2)
    elif args.lang == "both":
        output = format_chart_text(chart, "th") + "\n\n" + format_chart_text(chart, "en")
    else:
        output = format_chart_text(chart, args.lang)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"Saved to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
