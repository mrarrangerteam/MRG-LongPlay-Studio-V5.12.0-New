---
name: mrarranger-asteroid-astrology
description: |
  MRARRANGER Asteroid Astrology - ระบบดูดวงดาว Asteroid แบบครบวงจร

  รวม Natal Chart + Asteroid Interpretation + Transit + Synastry + Composite + Return Chart
  รองรับทั้งภาษาไทยและอังกฤษ | คำนวณตำแหน่งดาวจริงด้วย Swiss Ephemeris + รับ Input จากผู้ใช้

  ใช้เมื่อ:
  (1) ต้องการดูดวงชะตา / Natal Chart ที่รวม Asteroid
  (2) วิเคราะห์ Asteroid (Chiron, Juno, Pallas, Vesta, Ceres, Lilith, Eros ฯลฯ) ในราศี/House
  (3) ดูดวงคู่ / Synastry / Composite Chart
  (4) ดู Transit ดาว Asteroid ที่ส่งผลต่อดวงชะตา
  (5) ดู Solar Return / Lunar Return Chart
  (6) ต้องการรายงานดูดวงละเอียดเป็น PDF/DOCX
  (7) ถามเรื่องดวง ดาว โหราศาสตร์ asteroid ราศี house aspect

  MANDATORY TRIGGERS: ดูดวง, โหราศาสตร์, asteroid, natal chart, horoscope, zodiac, ราศี,
  chiron, juno, pallas, vesta, ceres, lilith, eros, transit, synastry, composite chart,
  solar return, house, aspect, conjunction, opposition, trine, square, sextile,
  ดวงดาว, ดวงชะตา, เกิดราศี, ลัคนา, ascendant
---

# MRARRANGER Asteroid Astrology System

> ระบบวิเคราะห์ดวงชะตาด้วย Asteroid Astrology แบบครบวงจร
> Full Asteroid Astrology Analysis System (Thai + English)

## SKILL ROUTING TABLE

| Command | Reference File | Use When |
|---------|---------------|----------|
| `/natal` `/chart` `/ดูดวง` | `references/natal-chart.md` | วิเคราะห์ดวงชะตากำเนิด Natal Chart |
| `/asteroid` `/ดาว` | `references/asteroid-guide.md` | ข้อมูล Asteroid ทั้งหมด |
| `/transit` `/พยากรณ์` | `references/transit-forecast.md` | พยากรณ์ Transit + Progression |
| `/synastry` `/คู่` `/ดวงคู่` | `references/synastry-composite.md` | วิเคราะห์ดวงคู่ / ความสัมพันธ์ |
| `/return` `/solar-return` | `references/return-charts.md` | Solar Return / Lunar Return |
| `/calc` `/คำนวณ` | Run `scripts/astro_calc.py` | คำนวณตำแหน่งดาวจริง |

---

## WORKFLOW OVERVIEW

### Step 1: Gather Birth Data (เก็บข้อมูลเกิด)

ถามผู้ใช้:
1. **วันเกิด** (Date of Birth) — วัน/เดือน/ปี
2. **เวลาเกิด** (Time of Birth) — ถ้าไม่ทราบ ใช้ 12:00 น. (Noon Chart)
3. **สถานที่เกิด** (Place of Birth) — เมือง/จังหวัด/ประเทศ (สำหรับหา Latitude/Longitude)
4. **ภาษาที่ต้องการ** — ไทย / English / ทั้งสอง

### Step 2: Calculate Positions (คำนวณตำแหน่ง)

มี 2 วิธี:

**วิธี A: คำนวณจริงด้วย Swiss Ephemeris**
- รัน `scripts/astro_calc.py` เพื่อคำนวณตำแหน่งดาวทั้งหมด
- ได้ตำแหน่งแม่นยำทุกดวง รวม Asteroid
- ต้อง install: `pip install pyswisseph flatlib --break-system-packages`

**วิธี B: ผู้ใช้ป้อนตำแหน่งเอง**
- ผู้ใช้อาจมี Chart จาก Astro.com หรือแอปอื่นแล้ว
- ขอตำแหน่งดาวแต่ละดวงในราศี + องศา + House

### Step 3: Interpret (ตีความ)

อ่าน reference files ตาม command ที่ผู้ใช้ต้องการ แล้ววิเคราะห์:

1. **ดาวพื้นฐาน** — Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto
2. **Asteroid หลัก** — Chiron, Juno, Pallas Athena, Vesta, Ceres, Black Moon Lilith, Eros
3. **จุดสำคัญ** — Ascendant, Midheaven, North Node, South Node, Part of Fortune
4. **Aspect** — Conjunction, Opposition, Trine, Square, Sextile, Quincunx
5. **House System** — Placidus (default) / Whole Sign / Koch

### Step 4: Generate Report (สร้างรายงาน)

สร้างรายงานละเอียดโดยใช้โครงสร้าง:

```
# รายงานดูดวง Asteroid Astrology
## [ชื่อ] — เกิดวันที่ [วันเกิด] เวลา [เวลา] ที่ [สถานที่]

### 1. ภาพรวมดวงชะตา (Chart Overview)
   - Ascendant / ลัคนาราศี
   - Sun Sign / ราศีเกิด
   - Moon Sign / จันทร์ราศี
   - Chart Pattern (Bundle, Bowl, Bucket, Splash ฯลฯ)

### 2. ดาวพื้นฐานใน House (Planets in Houses)
   - Sun ใน House X — ความหมาย
   - Moon ใน House X — ความหมาย
   - ... ทุกดวง

### 3. Asteroid Analysis (วิเคราะห์ Asteroid)
   - Chiron — บาดแผลและการเยียวยา
   - Juno — ความสัมพันธ์และการแต่งงาน
   - Pallas Athena — ปัญญาและกลยุทธ์
   - Vesta — การอุทิศตนและจิตวิญญาณ
   - Ceres — การดูแลเอาใจใส่
   - Black Moon Lilith — ด้านมืดและพลังแฝง
   - Eros — ความปรารถนาและแรงดึงดูด

### 4. Aspect สำคัญ (Major Aspects)
   - Grand Trine, T-Square, Grand Cross, Yod ฯลฯ
   - Asteroid Aspects ที่สำคัญ

### 5. สรุปและคำแนะนำ (Summary & Guidance)
   - จุดแข็ง / ความท้าทาย
   - คำแนะนำสำหรับช่วงเวลานี้
```

---

## ZODIAC SIGNS REFERENCE (ราศีทั้ง 12)

| # | Thai | English | Symbol | Element | Mode | Ruler |
|---|------|---------|--------|---------|------|-------|
| 1 | ราศีเมษ | Aries | ♈ | Fire | Cardinal | Mars |
| 2 | ราศีพฤษภ | Taurus | ♉ | Earth | Fixed | Venus |
| 3 | ราศีเมถุน | Gemini | ♊ | Air | Mutable | Mercury |
| 4 | ราศีกรกฎ | Cancer | ♋ | Water | Cardinal | Moon |
| 5 | ราศีสิงห์ | Leo | ♌ | Fire | Fixed | Sun |
| 6 | ราศีกันย์ | Virgo | ♍ | Earth | Mutable | Mercury |
| 7 | ราศีตุลย์ | Libra | ♎ | Air | Cardinal | Venus |
| 8 | ราศีพิจิก | Scorpio | ♏ | Water | Fixed | Pluto/Mars |
| 9 | ราศีธนู | Sagittarius | ♐ | Fire | Mutable | Jupiter |
| 10 | ราศีมังกร | Capricorn | ♑ | Earth | Cardinal | Saturn |
| 11 | ราศีกุมภ์ | Aquarius | ♒ | Air | Fixed | Uranus/Saturn |
| 12 | ราศีมีน | Pisces | ♓ | Water | Mutable | Neptune/Jupiter |

## HOUSE MEANINGS (ความหมาย 12 House)

| House | Thai | English | Keywords |
|-------|------|---------|----------|
| 1st | เรือนที่ 1 | Self | ตัวตน, บุคลิก, รูปร่าง, การแสดงออก |
| 2nd | เรือนที่ 2 | Possessions | ทรัพย์สิน, รายได้, คุณค่า, ความมั่นคง |
| 3rd | เรือนที่ 3 | Communication | การสื่อสาร, พี่น้อง, การเดินทางใกล้, การเรียนรู้ |
| 4th | เรือนที่ 4 | Home | บ้าน, ครอบครัว, รากฐาน, แม่ |
| 5th | เรือนที่ 5 | Creativity | ความคิดสร้างสรรค์, ความรัก, ลูก, การเสี่ยง |
| 6th | เรือนที่ 6 | Health | สุขภาพ, งานประจำวัน, การรับใช้, สัตว์เลี้ยง |
| 7th | เรือนที่ 7 | Partnership | คู่ครอง, หุ้นส่วน, ความสัมพันธ์ |
| 8th | เรือนที่ 8 | Transformation | การเปลี่ยนแปลง, มรดก, เพศ, ความลึกลับ |
| 9th | เรือนที่ 9 | Philosophy | ปรัชญา, ศาสนา, การเดินทางไกล, การศึกษาสูง |
| 10th | เรือนที่ 10 | Career | อาชีพ, ชื่อเสียง, เป้าหมาย, พ่อ |
| 11th | เรือนที่ 11 | Community | เพื่อน, กลุ่ม, ความหวัง, อุดมคติ |
| 12th | เรือนที่ 12 | Unconscious | จิตใต้สำนึก, การสูญเสีย, กรรม, จิตวิญญาณ |

## ASPECT REFERENCE (มุมดาว)

| Aspect | Symbol | Degrees | Orb | Nature | Thai |
|--------|--------|---------|-----|--------|------|
| Conjunction | ☌ | 0° | ±8° | Neutral/Strong | ดาวร่วม — พลังรวม |
| Opposition | ☍ | 180° | ±8° | Challenging | ดาวตรงข้าม — ความตึงเครียด |
| Trine | △ | 120° | ±8° | Harmonious | ดาวตรีโกณ — ราบรื่น |
| Square | □ | 90° | ±7° | Challenging | ดาวจัตุโกณ — ความท้าทาย |
| Sextile | ⚹ | 60° | ±6° | Harmonious | ดาวฉกโกณ — โอกาส |
| Quincunx | ⚻ | 150° | ±3° | Adjustment | ดาวปรับตัว — ไม่ลงตัว |
| Semi-sextile | ⚺ | 30° | ±2° | Mild | กึ่งฉกโกณ — เชื่อมต่อ |

---

## INTERPRETATION GUIDELINES (แนวทางการตีความ)

### หลักการตีความแบบ Layer

ตีความเป็นชั้นๆ โดยเรียงลำดับความสำคัญ:

1. **Planet = อะไร** — ดาวบอกว่า "พลังงานประเภทไหน" ทำงาน
2. **Sign = อย่างไร** — ราศีบอกว่า "แสดงออกแบบไหน"
3. **House = ที่ไหน** — เรือนบอกว่า "เกิดขึ้นในด้านชีวิตไหน"
4. **Aspect = เกี่ยวข้องกับอะไร** — มุมดาวบอกว่า "มีปฏิสัมพันธ์กับพลังอื่นอย่างไร"

### สำหรับ Asteroid โดยเฉพาะ

Asteroid ให้ข้อมูลที่ละเอียดกว่าดาวหลัก เพราะเจาะลึกในประเด็นเฉพาะ:
- ไม่ใช่ "แทนที่" ดาวหลัก แต่ "เพิ่มเติมรายละเอียด"
- ให้น้ำหนัก Asteroid น้อยกว่าดาวหลัก แต่อย่ามองข้าม
- Asteroid ที่ Conjunct กับดาวหลักหรือ Angle (ASC/MC) จะมีพลังเด่นมาก
- ใช้ Orb แคบกว่าดาวหลัก (±2-3° สำหรับ Conjunction, ±1-2° สำหรับ Aspect อื่น)

### Tone การเขียน

- เขียนเหมือนที่ปรึกษาที่อบอุ่นและเข้าใจ ไม่ใช่ทำนายแบบตายตัว
- ใช้คำว่า "แนวโน้ม" "มีโอกาส" "อาจ" แทน "จะเป็น" "ต้อง"
- เน้นพลังที่สร้างสรรค์และวิธีใช้พลังดาวให้เป็นประโยชน์
- สำหรับ Aspect ท้าทาย ให้แนะวิธีรับมือ ไม่ใช่ทำให้กลัว
- เชื่อมโยงกับชีวิตจริงของผู้ใช้

---

## QUICK REFERENCE: ASTEROID KEYWORDS

| Asteroid | # | Symbol | Thai | Keywords |
|----------|---|--------|------|----------|
| **Chiron** | 2060 | ⚷ | ไครอน | บาดแผล, การเยียวยา, ผู้รักษา, จุดอ่อนที่เป็นพรสวรรค์ |
| **Juno** | 3 | ⚵ | จูโน | คู่ครอง, การแต่งงาน, ความซื่อสัตย์, สัญญา |
| **Pallas** | 2 | ⚴ | พัลลาส | ปัญญา, กลยุทธ์, ความยุติธรรม, Pattern Recognition |
| **Vesta** | 4 | ⚶ | เวสตา | การอุทิศตน, ไฟศักดิ์สิทธิ์, โฟกัส, พิธีกรรม |
| **Ceres** | 1 | ⚳ | ซีรีส | การดูแล, อาหาร, แม่, การปล่อยวาง |
| **Lilith** | — | ⚸ | ลิลิธ | ด้านมืด, เพศ, พลังดิบ, สิ่งถูกกดทับ |
| **Eros** | 433 | — | อีรอส | ความปรารถนา, แรงดึงดูด, Passion, ความเร่าร้อน |
| **Psyche** | 16 | — | ไซคี | จิตวิญญาณ, ตัวตนแท้จริง, การเปลี่ยนแปลงภายใน |
| **Vertex** | — | Vx | เวอร์เท็กซ์ | จุดหมายชะตา, การพบเจอที่กำหนดไว้ |
| **Nessus** | 7066 | — | เนสซัส | พลังมืด, การละเมิด, วงจรกรรม, การหยุดวงจร |
| **Pholus** | 5145 | — | โฟลัส | ตัวเร่ง, จุดเปลี่ยน, ปฏิกิริยาลูกโซ่ |

Read `references/asteroid-guide.md` for complete interpretation of each Asteroid in all 12 signs and 12 houses.

---

## OUTPUT FORMAT

เมื่อสร้างรายงานเสร็จ ให้:

1. แสดงรายงานแบบละเอียดในแชท
2. ถามว่าต้องการส่งออกเป็นไฟล์หรือไม่ (PDF / DOCX)
3. ถ้าต้องการไฟล์ ให้ใช้ skill `pdf` หรือ `docx` สร้างรายงานสวยงาม
4. บันทึกไฟล์ที่ `/sessions/peaceful-zen-cerf/mnt/outputs/`

---

## DISCLAIMER (ข้อจำกัดความรับผิดชอบ)

ใส่ท้ายรายงานเสมอ:

> "การวิเคราะห์ดวงชะตานี้เป็นเพียงแนวทางสำหรับการเรียนรู้และทำความเข้าใจตนเอง
> ไม่ใช่คำทำนายที่แน่นอนตายตัว ชีวิตของเราถูกกำหนดโดยการกระทำและทางเลือกของเราเอง
> ดวงดาวเป็นเพียงแผนที่ ไม่ใช่จุดหมายปลายทาง"
