# Synastry & Composite Chart Guide

> คู่มือวิเคราะห์ดวงคู่ (Synastry) และดวงรวม (Composite)

---

## SYNASTRY คืออะไร?

Synastry คือการเอาดวงชะตา 2 คนมาวางซ้อนกัน เพื่อดูว่าดาวของคนหนึ่งส่งผลต่อดาวของอีกคนอย่างไร

## COMPOSITE CHART คืออะไร?

Composite Chart คือจุดกึ่งกลางของดาวทุกดวงระหว่าง 2 คน สะท้อน "ตัวตนของความสัมพันธ์" ว่าความสัมพันธ์นี้เป็นอย่างไร

---

## SYNASTRY: ASTEROID CONNECTIONS

### Top Asteroid Aspects ที่สำคัญในดวงคู่

#### Chiron Connections (การเยียวยาร่วมกัน)

| Aspect | ความหมาย |
|--------|----------|
| Person A's Chiron ☌ Person B's Sun | A ช่วยเยียวยาตัวตนของ B, B ช่วยให้ A เข้าใจบาดแผล |
| Person A's Chiron ☌ Person B's Moon | เชื่อมต่อทางอารมณ์ลึกมาก ช่วยเยียวยาบาดแผลทางอารมณ์ |
| Person A's Chiron ☌ Person B's Venus | ความรักที่เยียวยา อาจเจ็บปวดแต่สร้างการเติบโต |
| Person A's Chiron ☌ Person B's ASC | A เห็น B อย่างลึกซึ้ง สัมผัสบาดแผลที่ B ซ่อน |
| Chiron ☌ Chiron | วัยเดียวกัน เข้าใจบาดแผลร่วมของรุ่น |

#### Juno Connections (คู่ครอง)

| Aspect | ความหมาย |
|--------|----------|
| Person A's Juno ☌ Person B's Sun | B คือคู่ในอุดมคติของ A |
| Person A's Juno ☌ Person B's Venus | ดึงดูดแบบคู่ครอง ความรักระยะยาว |
| Person A's Juno ☌ Person B's Mars | ดึงดูดทางเพศ + ความมุ่งมั่น |
| Person A's Juno ☌ Person B's ASC | B เป็นสิ่งที่ A ต้องการในคู่ครอง |
| Person A's Juno ☌ Person B's Juno | เข้ากันเรื่องคู่ครอง วิสัยทัศน์เหมือนกัน |
| Person A's Juno ☌ Person B's DSC | B คือคู่ที่เติมเต็ม A |

#### Eros-Psyche Connections (ความปรารถนาจิตวิญญาณ)

| Aspect | ความหมาย |
|--------|----------|
| Person A's Eros ☌ Person B's Psyche | แรงดึงดูดลึกซึ้ง ร่างกาย+จิตวิญญาณ เชื่อมต่อ |
| Person A's Eros ☌ Person B's Venus | ดึงดูดทางเพศสูงมาก |
| Person A's Eros ☌ Person B's Mars | ความเร่าร้อนอย่างรุนแรง |
| Person A's Eros ☌ Person B's ASC | A ดึงดูดรูปลักษณ์/ตัวตนของ B อย่างมาก |
| Person A's Psyche ☌ Person B's Moon | เชื่อมต่อทางจิตวิญญาณลึกมาก |

#### Lilith Connections (พลังดึงดูดมืด)

| Aspect | ความหมาย |
|--------|----------|
| Person A's Lilith ☌ Person B's Sun | ดึงดูดอย่างทรงพลัง A ปลุกด้านมืดของ B |
| Person A's Lilith ☌ Person B's Mars | เคมีทางเพศเข้มข้น อาจหมกมุ่น |
| Person A's Lilith ☌ Person B's Venus | ดึงดูดแบบ forbidden ต้องห้าม |
| Person A's Lilith ☌ Person B's Moon | A ท้าทายความปลอดภัยของ B |

#### Pallas Connections (ปัญญาร่วม)

| Aspect | ความหมาย |
|--------|----------|
| Pallas ☌ Mercury (cross) | คุยกันรู้เรื่อง คิดเสริมกัน |
| Pallas ☌ Jupiter (cross) | ขยายปัญญาร่วมกัน หุ้นส่วนที่ดี |

#### Vesta Connections (การอุทิศร่วมกัน)

| Aspect | ความหมาย |
|--------|----------|
| Vesta ☌ Sun (cross) | อุทิศตนให้กัน |
| Vesta ☌ Vesta | มีจุดอุทิศตนร่วมกัน |

#### Ceres Connections (การดูแล)

| Aspect | ความหมาย |
|--------|----------|
| Ceres ☌ Moon (cross) | ดูแลกันอย่างเป็นธรรมชาติ |
| Ceres ☌ Venus (cross) | ดูแลด้วยความรัก |

---

## SYNASTRY SCORING SYSTEM (ระบบให้คะแนน)

### Asteroid Compatibility Points

เมื่อวิเคราะห์ Synastry ให้คะแนนตามนี้:

**+5 คะแนน (Strong Positive)**
- Juno ☌ Sun/Venus/ASC/DSC
- Eros ☌ Psyche
- Chiron ☌ Moon (mutual healing)

**+3 คะแนน (Moderate Positive)**
- Juno △ Sun/Venus
- Eros ☌ Venus/Mars
- Pallas ☌ Mercury
- Ceres ☌ Moon

**+1 คะแนน (Mild Positive)**
- Juno ⚹ Sun/Venus
- Vesta ☌ Sun
- Any Asteroid △ Personal Planet

**-2 คะแนน (Challenge)**
- Chiron □ Sun/Moon/Venus (painful but growth)
- Lilith □ Venus/Mars (obsession)
- Juno □ Saturn (commitment issues)

**-1 คะแนน (Mild Challenge)**
- Nessus ☌ Personal Planets (power dynamics)
- Lilith ☍ Sun/Moon

### Interpretation Guide

| Total Score | ความหมาย |
|-------------|----------|
| 15+ | คู่ที่มีพันธะลึกซึ้งมาก มีโอกาสเป็น Soulmate |
| 10-14 | เชื่อมต่อกันดี มีเคมี |
| 5-9 | เชื่อมต่อปานกลาง มีบางด้านที่เข้ากัน |
| 0-4 | เชื่อมต่อน้อย ไม่ได้หมายความว่าไม่ดี — ดูดาวหลักประกอบ |
| ลบ | มีความท้าทาย แต่ Challenge = Growth |

---

## COMPOSITE CHART: ASTEROID INTERPRETATION

### Asteroid ใน Composite Chart บอกอะไร

| Asteroid | ใน Composite Chart หมายถึง... |
|----------|-------------------------------|
| **Chiron** | บาดแผลของความสัมพันธ์นี้ จุดที่ต้องเยียวยาร่วมกัน |
| **Juno** | ระดับความมุ่งมั่นของความสัมพันธ์ วิธีที่ทั้งคู่มองเรื่องคู่ครอง |
| **Pallas** | ปัญญาร่วมของคู่ วิธีแก้ปัญหาร่วมกัน |
| **Vesta** | สิ่งที่คู่นี้อุทิศตนให้ร่วมกัน |
| **Ceres** | วิธีที่คู่นี้ดูแลกัน |
| **Lilith** | ด้านมืดของความสัมพันธ์ สิ่งที่ไม่ถูกพูดถึง |
| **Eros** | ความเร่าร้อนของความสัมพันธ์ เคมีทางกายภาพ |

### Composite Asteroid in Houses

**Composite Chiron in Houses:**
- House 1: ความสัมพันธ์นี้เยียวยาเรื่องตัวตน
- House 4: เยียวยาเรื่องครอบครัว/บ้าน
- House 7: เยียวยาเรื่องความสัมพันธ์ (เด่นมาก)
- House 10: เยียวยาเรื่องอาชีพ/ชื่อเสียง
- House 12: เยียวยาเรื่องจิตวิญญาณ/กรรมเก่า

**Composite Juno in Houses:**
- House 1: ความสัมพันธ์แบบคู่ครองเด่นชัด
- House 5: ความรักสนุกสนาน โรแมนติก
- House 7: ความสัมพันธ์ระยะยาว (ตำแหน่งที่ดีที่สุด)
- House 10: คู่ที่ทำงานร่วมกัน / คู่ต่อหน้าสาธารณะ

---

## SYNASTRY REPORT TEMPLATE

```
# Synastry Report / รายงานดวงคู่
## [ชื่อ A] x [ชื่อ B]

### ข้อมูลพื้นฐาน
- [ชื่อ A]: เกิด [วันที่] เวลา [เวลา] ที่ [สถานที่]
- [ชื่อ B]: เกิด [วันที่] เวลา [เวลา] ที่ [สถานที่]

### 1. ภาพรวมความเข้ากัน (Overview)
- Element Compatibility: ...
- Modality Compatibility: ...
- Sun-Moon Compatibility: ...

### 2. ดาวพื้นฐาน Cross-Aspects
- [A's Sun] [aspect] [B's Moon] — ...
- [A's Venus] [aspect] [B's Mars] — ...
- ...

### 3. Asteroid Connections (สำคัญมาก)
#### Chiron: การเยียวยาร่วมกัน
- ...
#### Juno: ความมุ่งมั่นคู่ครอง
- ...
#### Eros-Psyche: แรงดึงดูดลึกซึ้ง
- ...
#### Lilith: ด้านเข้มข้น
- ...

### 4. Composite Chart Highlights
- Composite Sun in [Sign] House [#] — ...
- Composite Moon in [Sign] House [#] — ...
- Composite Chiron in [Sign] House [#] — ...
- Composite Juno in [Sign] House [#] — ...

### 5. จุดแข็งของคู่นี้
- ...

### 6. ความท้าทายที่ต้องรับมือ
- ...

### 7. คำแนะนำสำหรับความสัมพันธ์
- ...

### Asteroid Compatibility Score: [X] / 20
```

---

## SPECIAL SYNASTRY PATTERNS

### Double Whammy (สองทาง)
เมื่อ Aspect เกิดขึ้นทั้งสองทาง เช่น:
- A's Juno ☌ B's Venus AND B's Juno ☌ A's Venus
- = พลังเพิ่มเป็นสองเท่า มีความสำคัญมาก

### Karmic Indicators (สัญญาณกรรม)
- North Node ☌ Juno (cross) = คู่ที่ตั้งใจพบกัน
- Chiron ☌ North Node (cross) = ช่วยเยียวยาเพื่อเติมเต็มบทเรียนชีวิต
- South Node ☌ Juno (cross) = คู่จากชาติก่อน
- Vertex ☌ Juno/Eros (cross) = การพบเจอที่ชะตากำหนด

### Soulmate Indicators (สัญญาณคู่บุญ)
รวม 5+ ข้อจากนี้ = มีแนวโน้มเป็นคู่บุญ:
1. Juno ☌ Sun/Venus/ASC (cross)
2. Eros ☌ Psyche (cross)
3. Chiron ☌ Moon (cross)
4. North Node ☌ Venus/Juno (cross)
5. Vertex ☌ Personal Planet (cross)
6. Sun ☌ Moon (cross)
7. Composite Juno in House 7
8. Double Whammy ใดๆ
