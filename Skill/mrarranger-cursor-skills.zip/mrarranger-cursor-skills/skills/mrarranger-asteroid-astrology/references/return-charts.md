# Return Charts Guide

> คู่มือ Solar Return, Lunar Return และ Asteroid Returns

---

## SOLAR RETURN CHART

### คืออะไร?
Solar Return คือแผนภูมิที่สร้างขึ้นในวินาทีที่ดวงอาทิตย์กลับมาอยู่ตำแหน่งเดียวกันกับตอนเกิด (ใกล้วันเกิดทุกปี) ใช้พยากรณ์ธีมของปีนั้นๆ

### วิธีคำนวณ
- หาวันเวลาที่ Sun Transit กลับมาที่ตำแหน่ง Natal Sun (องศา+นาที เดียวกัน)
- สร้าง Chart ณ เวลานั้น สำหรับสถานที่ที่อยู่ ณ วันเกิดปีนั้น

### การตีความ Solar Return

#### Asteroid ใน Solar Return

**Solar Return Chiron:**
- SR Chiron in House 1: ปีแห่งการเยียวยาตัวเอง
- SR Chiron in House 4: เยียวยาเรื่องครอบครัว/บ้าน
- SR Chiron in House 7: เยียวยาเรื่องความสัมพันธ์
- SR Chiron in House 10: เยียวยาเรื่องอาชีพ
- SR Chiron ☌ SR ASC: ปีที่ต้องเผชิญบาดแผล
- SR Chiron ☌ SR MC: บาดแผลส่งผลต่ออาชีพ

**Solar Return Juno:**
- SR Juno in House 1: ปีที่เรื่องคู่ครองสำคัญมาก
- SR Juno in House 5: ปีแห่งความรักโรแมนติก
- SR Juno in House 7: ปีแห่งความสัมพันธ์ / อาจแต่งงาน
- SR Juno in House 10: คู่ครองส่งผลต่ออาชีพ
- SR Juno ☌ SR Venus: ปีที่ดีสำหรับความรัก
- SR Juno ☌ Natal Juno: Juno Return ย่อย — ประเมินความสัมพันธ์

**Solar Return Pallas:**
- SR Pallas in House 2: ปัญญาเรื่องการเงิน
- SR Pallas in House 6: ปัญญาเรื่องงาน/สุขภาพ
- SR Pallas in House 10: ปัญญาเรื่องอาชีพ กลยุทธ์ดี
- SR Pallas ☌ SR Mercury: ปีที่คิดแหลมคม

**Solar Return Vesta:**
- SR Vesta in House ไหน = สิ่งที่ต้องอุทิศตนปีนี้
- SR Vesta ☌ SR MC: อุทิศตนให้อาชีพ

**Solar Return Lilith:**
- SR Lilith in House ไหน = ด้านที่ถูกท้าทายให้เรียกคืนพลัง
- SR Lilith ☌ SR ASC: ปีแห่งการค้นพบพลังดิบ

**Solar Return Eros:**
- SR Eros in House 5: ปีแห่งความรักเร่าร้อน
- SR Eros in House 7: ดึงดูดทางเพศในความสัมพันธ์
- SR Eros in House 8: ความเข้มข้นทางเพศ/จิตวิญญาณ

---

## LUNAR RETURN CHART

### คืออะไร?
Lunar Return คือแผนภูมิที่สร้างขึ้นเมื่อดวงจันทร์กลับมาตำแหน่งเดียวกับตอนเกิด เกิดขึ้นทุก ~27.3 วัน ใช้พยากรณ์ธีมของเดือนนั้น

### การตีความ Lunar Return

เน้น:
- LR Moon House = ธีมอารมณ์ของเดือน
- LR ASC Sign = พลังงานที่แสดงออก
- Asteroid ที่ Conjunct LR Moon หรือ LR ASC

**Asteroid Highlights ใน Lunar Return:**
- LR Chiron ☌ LR Moon: เดือนแห่งการเยียวยาอารมณ์
- LR Juno ☌ LR Moon: เดือนที่เรื่องคู่ครองสำคัญ
- LR Lilith ☌ LR Moon: เดือนที่อารมณ์ดิบโผล่ขึ้น
- LR Eros ☌ LR Venus: เดือนแห่งความรักเร่าร้อน

---

## ASTEROID RETURNS

### Chiron Return (~อายุ 49-51)

เหตุการณ์สำคัญที่สุดของ Chiron — เกิดขึ้นครั้งเดียวในชีวิต

**การเตรียมตัว:**
1. ดู Natal Chiron — บาดแผลเดิมอยู่ตรงไหน
2. ดู Transit Chiron เข้าใกล้ Natal Chiron — เริ่มรู้สึกตั้งแต่ Orb 5°
3. ช่วง Exact: เผชิญบาดแผลเดิม โอกาสเยียวยาอย่างสมบูรณ์
4. หลัง Return: กลายเป็นผู้เยียวยาที่ทรงพลัง

**Chiron Return Chart:**
- สร้าง Chart ณ วินาทีที่ Transit Chiron ☌ Natal Chiron (exact)
- ดู House ของ Chiron Return = ด้านชีวิตที่ถูกเยียวยา
- ดู Aspects = วิธีการเยียวยา

### Juno Return (ทุก ~4.36 ปี)

**ความหมาย:**
- ประเมินความสัมพันธ์ปัจจุบัน
- เปิดรับคู่ครองใหม่ (ถ้าโสด)
- ต่อสัญญาหรือเปลี่ยนแปลงความสัมพันธ์

**Juno Return Chart:**
- House = ด้านที่เรื่องคู่ครองถูกเน้น
- Aspects to Venus/Mars = คุณภาพของความสัมพันธ์ปีนี้

### Lilith Return (ทุก ~8.85 ปี)

**ความหมาย:**
- เรียกคืนพลังที่ถูกกดทับ
- เผชิญ Shadow Self
- ช่วงที่ทรงพลังสำหรับการค้นพบตัวเอง

### Vesta Return (ทุก ~3.63 ปี)

**ความหมาย:**
- ทบทวนสิ่งที่อุทิศตนให้
- จุดไฟใหม่ให้จุดประสงค์

### Ceres Return (ทุก ~4.60 ปี)

**ความหมาย:**
- ทบทวนวิธีดูแลตัวเองและผู้อื่น
- เรื่องอาหาร สุขภาพ การเลี้ยงดู

---

## RETURN CHART REPORT TEMPLATE

```
# [Type] Return Report / รายงาน [ประเภท] Return
## [ชื่อ] — ปี [ปี]

### ข้อมูลพื้นฐาน
- Natal [Planet/Asteroid]: [Sign] [Degree] House [#]
- Return Date: [วันที่ exact]
- Return Location: [สถานที่]

### 1. Return Chart Overview
- ASC: [Sign] — พลังงานของปี/รอบนี้
- [Planet/Asteroid] in House [#] — ธีมหลัก
- Moon in [Sign] House [#] — อารมณ์ของช่วงนี้

### 2. Major Aspects ใน Return Chart
- ...

### 3. Asteroid Highlights
- ...

### 4. ธีมหลักและคำแนะนำ
- ธีม: ...
- สิ่งที่ควรทำ: ...
- สิ่งที่ควรระวัง: ...
- ช่วงเวลาสำคัญ: ...
```
