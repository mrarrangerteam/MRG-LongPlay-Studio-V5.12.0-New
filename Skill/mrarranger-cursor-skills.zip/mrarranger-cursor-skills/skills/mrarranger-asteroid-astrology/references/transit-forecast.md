# Transit & Forecast Guide

> คู่มือการพยากรณ์ด้วย Transit + Progression ของ Asteroid

---

## TRANSIT คืออะไร?

Transit คือตำแหน่งดาว ณ ปัจจุบัน (หรือช่วงเวลาที่กำหนด) เทียบกับดวงชะตากำเนิด
เมื่อดาว Transit ทำ Aspect กับดาว Natal = เกิดเหตุการณ์/พลังงานในชีวิต

---

## ASTEROID TRANSIT CYCLES (วงโคจร)

| Asteroid | รอบวงโคจร | ผลกระทบ |
|----------|----------|---------|
| **Chiron** | ~50 ปี | เหตุการณ์สำคัญ: Chiron Return (อายุ ~50) |
| **Juno** | ~4.36 ปี | รอบความสัมพันธ์ทุก ~4 ปี |
| **Pallas** | ~4.62 ปี | รอบปัญญา/กลยุทธ์ |
| **Vesta** | ~3.63 ปี | รอบการอุทิศตน |
| **Ceres** | ~4.60 ปี | รอบการดูแล/การปล่อยวาง |
| **Lilith** (Mean) | ~8.85 ปี | รอบการเรียกคืนพลัง |
| **Eros** | ~1.76 ปี | รอบความปรารถนา (เร็ว) |
| **Nessus** | ~122 ปี | ผลกระทบยาว — Transit by House สำคัญ |
| **Pholus** | ~92 ปี | ผลกระทบยาว — จุดเปลี่ยนใหญ่ |

---

## KEY TRANSITS TO WATCH (Transit สำคัญ)

### Chiron Transits (สำคัญมาก)

**Chiron Return (~อายุ 49-51)**
- เหตุการณ์สำคัญที่สุดของ Chiron
- เผชิญบาดแผลเดิมอีกครั้งเพื่อเยียวยาอย่างสมบูรณ์
- โอกาสในการ "ก้าวข้ามบาดแผล" และกลายเป็นผู้เยียวยา

**Chiron Square Natal Chiron (~อายุ 12-13 และ ~37-38)**
- วิกฤตที่เกี่ยวกับบาดแผลเดิม
- อายุ 12-13: บาดแผลวัยรุ่น
- อายุ 37-38: วิกฤตกลางชีวิต

**Chiron Opposition Natal Chiron (~อายุ 23-25)**
- มองเห็นบาดแผลชัดเจนที่สุด
- ถ้าเผชิญ จะได้ปัญญาอันลึกซึ้ง

**Chiron Transit to Natal Planets**
- Chiron ☌ Sun: วิกฤตตัวตน → เข้าใจตัวเองลึกขึ้น
- Chiron ☌ Moon: วิกฤตอารมณ์ → เยียวยาจิตใจ
- Chiron ☌ Venus: วิกฤตความรัก → เข้าใจความรักที่แท้จริง
- Chiron ☌ Mars: วิกฤตพลัง → เข้าใจวิธีใช้พลังอย่างมีสติ

### Juno Transits (เรื่องความสัมพันธ์)

**Juno Return (ทุก ~4.36 ปี)**
- ประเมินความสัมพันธ์ใหม่
- เปิดรับคู่ครอง / เปลี่ยนแปลงความสัมพันธ์

**Juno Transit to Natal Venus/Mars**
- Juno ☌ Venus: ช่วงที่ดีสำหรับความรัก/การแต่งงาน
- Juno ☌ Mars: ความปรารถนาในความมุ่งมั่น
- Juno □ Venus: ทดสอบความสัมพันธ์

**Juno Transit to Natal 7th House Cusp**
- ช่วงสำคัญสำหรับเรื่องคู่ครอง

### Lilith Transits (เรื่องพลังแฝง)

**Lilith Return (ทุก ~8.85 ปี)**
- เรียกคืนพลังที่ถูกกดทับ
- เผชิญกับ Shadow Self

**Lilith Transit to Natal Sun/Moon**
- Lilith ☌ Sun: เผชิญด้านมืดของตัวเอง ค้นพบพลังใหม่
- Lilith ☌ Moon: อารมณ์ดิบ ความต้องการที่ซ่อนเร้นโผล่ขึ้นมา

---

## TRANSIT INTERPRETATION METHOD (วิธีตีความ Transit)

### Step 1: ระบุ Transit ที่เกิดขึ้น
- ดาว/Asteroid อะไร Transit
- ทำ Aspect อะไร (☌ △ □ ☍ ⚹)
- กับดาว/จุด Natal อะไร
- อยู่ใน House อะไรของ Natal

### Step 2: ประเมินความสำคัญ

**สำคัญมาก:**
- Slow-moving asteroid (Chiron, Nessus, Pholus) Transit to Angle (ASC/MC)
- Asteroid Transit to Natal Sun, Moon, Venus
- Asteroid Return (กลับตำแหน่งเดิม)

**สำคัญปานกลาง:**
- Medium-speed asteroid (Juno, Pallas, Vesta, Ceres) Transit to Natal Planets
- Asteroid Transit to Natal Asteroid (เช่น Transit Chiron ☌ Natal Juno)

**สำคัญน้อย:**
- Fast-moving asteroid (Eros) Transit ผ่านเร็ว ผลน้อย
- Asteroid Transit to Asteroid (ผลน้อยยกเว้น Conjunction)

### Step 3: ระบุช่วงเวลา

**Slow Asteroids (Chiron, Nessus, Pholus):**
- Orb: ±2° = ส่งผลหลายเดือน
- Exact hit = จุดสำคัญที่สุด
- อาจ hit 3 ครั้ง (Direct, Retrograde, Direct)

**Medium Asteroids (Juno, Pallas, Vesta, Ceres, Lilith):**
- Orb: ±1° = ส่งผล 2-4 สัปดาห์
- Exact hit = จุดสำคัญ

**Fast Asteroids (Eros):**
- Orb: ±1° = ส่งผล 2-3 วัน

### Step 4: สร้างคำพยากรณ์

ใช้สูตร: **[Asteroid Energy] + [Aspect Type] + [Natal Planet Energy] + [House Context]**

ตัวอย่าง:
> "Transit Chiron (การเยียวยา) Conjunct (รวมพลัง) Natal Venus (ความรัก) ใน House 7 (ความสัมพันธ์)"
> = "ช่วงเวลาแห่งการเยียวยาบาดแผลทางความรัก โอกาสในการเข้าใจรูปแบบความสัมพันธ์ของตัวเองอย่างลึกซึ้ง"

---

## TRANSIT REPORT TEMPLATE

```
# Transit Report / รายงานพยากรณ์
## [ชื่อ] — ช่วงเวลา: [เดือน/ปี]

### Transit สำคัญในช่วงนี้

#### 1. [Asteroid] [Aspect] Natal [Planet] — [วันที่ Exact]
- **พลังงาน:** ...
- **ด้านชีวิตที่ได้รับผล:** House [#] = ...
- **สิ่งที่อาจเกิดขึ้น:** ...
- **คำแนะนำ:** ...
- **ช่วงเวลาส่งผล:** [วันเริ่ม] - [วันสิ้นสุด]

#### 2. [Transit ถัดไป]
...

### สรุปพลังงานของเดือน/ช่วงเวลา
- ธีมหลัก: ...
- จุดเน้น: ...
- สิ่งที่ควรทำ: ...
- สิ่งที่ควรระวัง: ...
```

---

## PROGRESSION (Secondary Progression)

นอกจาก Transit แล้ว ยังมี Progressed Chart:
- 1 วันหลังเกิด = 1 ปีของชีวิต
- Progressed Moon เปลี่ยนราศีทุก ~2.5 ปี (สำคัญมาก)
- Progressed Sun เปลี่ยนราศีทุก ~30 ปี
- Progressed Asteroid เคลื่อนช้ามาก แต่เมื่อเปลี่ยนราศีหรือ Aspect จะสำคัญ

### Progressed Chiron
- เคลื่อนช้ามาก (~1° ต่อปี)
- เมื่อ Progressed Chiron เปลี่ยนราศี = บทใหม่ของการเยียวยา
- Progressed Chiron Aspect Natal Planets = ช่วงเวลาแห่งการเยียวยาลึก
