# Natal Chart Interpretation Guide

> คู่มือการตีความดวงชะตากำเนิด (Natal Chart) แบบครบวงจร

---

## STEP-BY-STEP INTERPRETATION WORKFLOW

### Phase 1: Chart Overview (ภาพรวมดวงชะตา)

#### 1.1 The Big Three (สามใหญ่)

**Sun Sign (ราศีเกิด/สุริยราศี)**
- ตัวตนหลัก จุดประสงค์ของชีวิต พลังงานพื้นฐาน
- "ฉันเป็นใคร" — Ego, Identity, Life Purpose

**Moon Sign (จันทร์ราศี)**
- อารมณ์ ความต้องการภายใน สัญชาตญาณ
- "ฉันรู้สึกอย่างไร" — Emotions, Needs, Inner Self

**Rising Sign / Ascendant (ลัคนาราศี)**
- หน้ากาก บุคลิกภาพที่แสดงออก ร่างกาย
- "คนอื่นเห็นฉันอย่างไร" — First Impression, Appearance

#### 1.2 Chart Pattern (รูปแบบแผนภูมิ)

วิเคราะห์การกระจายตัวของดาวในแผนภูมิ:

| Pattern | ลักษณะ | ความหมาย |
|---------|--------|----------|
| **Bundle** | ดาวกระจุกใน 120° | โฟกัส เชี่ยวชาญ มุมมองแคบ |
| **Bowl** | ดาวกระจุกใน 180° | มีจุดประสงค์ชัด ต้องการเติมเต็มส่วนที่ว่าง |
| **Bucket** | เหมือน Bowl + ดาว 1 ดวงตรงข้าม | ดาวนอกกลุ่มเป็น Handle = จุดระบายพลัง |
| **Locomotive** | ดาวกระจายใน 240° (ว่าง 120°) | พลังขับเคลื่อน มีเป้าหมายชัด |
| **Seesaw** | ดาวแบ่ง 2 กลุ่มตรงข้าม | ชีวิตสลับไปมาระหว่าง 2 ด้าน |
| **Splash** | ดาวกระจายทั่ว | หลากหลาย สนใจหลายด้าน |
| **Splay** | กระจายไม่สม่ำเสมอ มี Stellium | เอกลักษณ์เฉพาะ ยากจะคาดเดา |

#### 1.3 Element Balance (สมดุลธาตุ)

นับจำนวนดาวในแต่ละธาตุ:

| Element | Thai | Planets in | ลักษณะ |
|---------|------|-----------|--------|
| **Fire** (ไฟ) | เมษ สิงห์ ธนู | ___ ดวง | กระตือรือร้น กล้าหาญ |
| **Earth** (ดิน) | พฤษภ กันย์ มังกร | ___ ดวง | ปฏิบัติ มั่นคง |
| **Air** (ลม) | เมถุน ตุลย์ กุมภ์ | ___ ดวง | ความคิด สื่อสาร |
| **Water** (น้ำ) | กรกฎ พิจิก มีน | ___ ดวง | อารมณ์ สัญชาตญาณ |

- ธาตุที่เด่น = จุดแข็ง
- ธาตุที่ขาด = จุดที่ต้องพัฒนา

#### 1.4 Modality Balance (สมดุลคุณภาพ)

| Mode | Thai | Signs | ลักษณะ |
|------|------|-------|--------|
| **Cardinal** | ริเริ่ม | เมษ กรกฎ ตุลย์ มังกร | เริ่มต้น ผู้นำ |
| **Fixed** | คงที่ | พฤษภ สิงห์ พิจิก กุมภ์ | อดทน มั่นคง |
| **Mutable** | ปรับตัว | เมถุน กันย์ ธนู มีน | ยืดหยุ่น เปลี่ยนแปลง |

---

### Phase 2: Personal Planets (ดาวส่วนตัว)

ตีความดาวพื้นฐาน 7 ดวง — Sign + House + Aspects:

| Planet | Thai | Represents | Keywords |
|--------|------|-----------|----------|
| **Sun** ☉ | อาทิตย์ | ตัวตน จุดประสงค์ | Ego, Identity, Father |
| **Moon** ☽ | จันทร์ | อารมณ์ ความต้องการ | Emotions, Mother, Habits |
| **Mercury** ☿ | พุธ | ความคิด การสื่อสาร | Mind, Communication, Learning |
| **Venus** ♀ | ศุกร์ | ความรัก ความงาม | Love, Beauty, Values |
| **Mars** ♂ | อังคาร | พลัง การกระทำ | Action, Desire, Anger |
| **Jupiter** ♃ | พฤหัสบดี | โชค การขยาย | Luck, Growth, Wisdom |
| **Saturn** ♄ | เสาร์ | ข้อจำกัด บทเรียน | Discipline, Limits, Karma |

### Phase 3: Outer Planets (ดาวนอก)

ดาวนอกส่งผลต่อรุ่น (Generational) แต่สำคัญเมื่ออยู่ใน Angle หรือ Aspect กับดาวส่วนตัว:

| Planet | Thai | Represents | Keywords |
|--------|------|-----------|----------|
| **Uranus** ♅ | ยูเรนัส | การปฏิวัติ | Change, Freedom, Innovation |
| **Neptune** ♆ | เนปจูน | จิตวิญญาณ | Dreams, Illusion, Spirituality |
| **Pluto** ♇ | พลูโต | การเปลี่ยนแปลง | Power, Transformation, Death/Rebirth |

### Phase 4: Important Points (จุดสำคัญ)

| Point | Thai | Represents |
|-------|------|-----------|
| **North Node** ☊ | ราหู / มังกรเหนือ | บทเรียนชีวิตนี้ สิ่งที่ต้องพัฒนา |
| **South Node** ☋ | เกตุ / มังกรใต้ | ชาติก่อน พรสวรรค์ สิ่งที่ต้องปล่อย |
| **Midheaven** MC | จุดสูงสุด | อาชีพ ชื่อเสียง เป้าหมายสูงสุด |
| **IC** | จุดต่ำสุด | รากฐาน ครอบครัว จิตใต้สำนึก |
| **Part of Fortune** ⊕ | จุดโชค | จุดที่ Sun+Moon+ASC ทำงานร่วมกัน = ความสุข |

### Phase 5: Asteroid Integration (รวม Asteroid)

ดู `references/asteroid-guide.md` แล้ววิเคราะห์:

1. **Chiron** — บาดแผลและของขวัญ
2. **Juno** — คู่ครองในอุดมคติ
3. **Pallas** — ปัญญาเชิงกลยุทธ์
4. **Vesta** — สิ่งที่อุทิศตน
5. **Ceres** — วิธีดูแลและถูกดูแล
6. **Lilith** — พลังที่ถูกกดทับ
7. **Eros** — แรงดึงดูดและความปรารถนา
8. **เพิ่มเติม** — Psyche, Nessus, Pholus (ถ้ามีข้อมูล)

### Phase 6: Major Aspect Patterns (รูปแบบ Aspect สำคัญ)

ค้นหารูปแบบพิเศษ:

| Pattern | ลักษณะ | ความหมาย |
|---------|--------|----------|
| **Grand Trine** | 3 ดาว Trine กัน (สามเหลี่ยมด้านเท่า) | พรสวรรค์ ไหลลื่น อาจขี้เกียจ |
| **T-Square** | 2 ดาว Opposition + 1 ดาว Square ทั้งคู่ | ความท้าทายที่ขับเคลื่อนชีวิต |
| **Grand Cross** | 4 ดาว Square + Opposition กัน | ความท้าทายรอบด้าน พลังมหาศาล |
| **Yod** (Finger of God) | 2 ดาว Sextile + 1 ดาว Quincunx ทั้งคู่ | ภารกิจพิเศษ จุดหมายชะตา |
| **Kite** | Grand Trine + 1 ดาว Opposition | พรสวรรค์ที่มีทิศทาง |
| **Stellium** | 3+ ดาวในราศี/เรือนเดียว | พลังเข้มข้นในด้านนั้น |
| **Mystic Rectangle** | 2 Oppositions + 2 Trines + 2 Sextiles | ความสมดุลลึกลับ |

---

## REPORT TEMPLATE (โครงสร้างรายงาน)

เมื่อสร้างรายงาน Natal Chart ให้ใช้โครงสร้างนี้:

```
# Natal Chart Report / รายงานดวงชะตากำเนิด
## [ชื่อ]
### เกิด: [วันที่] | เวลา: [เวลา] | สถานที่: [สถานที่]

---

## 1. ภาพรวมดวงชะตา (Overview)
- ราศีเกิด (Sun Sign): ___
- จันทร์ราศี (Moon Sign): ___
- ลัคนาราศี (Ascendant): ___
- รูปแบบแผนภูมิ (Chart Pattern): ___
- สมดุลธาตุ: ไฟ ___ | ดิน ___ | ลม ___ | น้ำ ___

## 2. ตัวตนและจุดประสงค์ชีวิต (Identity & Purpose)
- Sun in [Sign] House [#] — ...
- Ascendant in [Sign] — ...
- North Node in [Sign] House [#] — ...

## 3. อารมณ์และจิตใจ (Emotions & Inner World)
- Moon in [Sign] House [#] — ...
- Neptune aspects — ...
- House 4 & 12 analysis — ...

## 4. ความรักและความสัมพันธ์ (Love & Relationships)
- Venus in [Sign] House [#] — ...
- Mars in [Sign] House [#] — ...
- Juno in [Sign] House [#] — ...
- Eros in [Sign] House [#] — ...
- House 7 analysis — ...

## 5. อาชีพและเป้าหมาย (Career & Ambition)
- Midheaven in [Sign] — ...
- Saturn in [Sign] House [#] — ...
- Jupiter in [Sign] House [#] — ...
- House 10 analysis — ...

## 6. ปัญญาและการเรียนรู้ (Wisdom & Learning)
- Mercury in [Sign] House [#] — ...
- Pallas in [Sign] House [#] — ...

## 7. บาดแผลและการเยียวยา (Wounds & Healing)
- Chiron in [Sign] House [#] — ...
- Lilith in [Sign] House [#] — ...
- South Node analysis — ...

## 8. พลังแฝงและการอุทิศตน (Hidden Power & Devotion)
- Pluto in [Sign] House [#] — ...
- Vesta in [Sign] House [#] — ...
- Ceres in [Sign] House [#] — ...

## 9. Aspect Patterns สำคัญ
- [รูปแบบที่พบ] — ความหมาย

## 10. สรุปและคำแนะนำ (Summary & Guidance)
- จุดแข็ง 3 ข้อ
- ความท้าทาย 3 ข้อ
- คำแนะนำเชิงปฏิบัติ

---
> Disclaimer / ข้อจำกัดความรับผิดชอบ
```

---

## INTERPRETATION DEPTH GUIDE

**Quick Reading (อ่านเร็ว 5 นาที):**
- Big Three + Chiron + Juno เท่านั้น

**Standard Reading (อ่านมาตรฐาน 15 นาที):**
- ดาวทั้งหมด + Asteroid หลัก 4 ดวง (Chiron, Juno, Pallas, Vesta)

**Deep Reading (อ่านลึก 30+ นาที):**
- ดาวทั้งหมด + Asteroid ทุกดวง + Aspect Patterns + House Rulers
