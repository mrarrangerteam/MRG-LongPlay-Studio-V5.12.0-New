---
name: mrarranger-devops-ai
description: "MRARRANGER DevOps + AI - รวม 8 Skills: DevOps Cloud (Docker, K8s, CI/CD, AWS, GCP, Azure, Terraform), Monitoring (APM, Logging, Alerting, Grafana, Prometheus), WebApp Testing (Unit, Integration, E2E, Playwright, Jest, Cypress), Data Engineer (ETL, Pipeline, Spark, Airflow, dbt, Data Warehouse), Web3 (Blockchain, Smart Contracts, Solidity, DeFi, NFT, dApps), AI ImageGen (Midjourney, DALL-E, Stable Diffusion, Flux, ComfyUI prompts), AI ML Engineer (ML Pipeline, Training, Fine-tuning, RAG, LLM, Vector DB), AI Office (AI Workflow, Document AI, Meeting AI, Email AI). Commands: /devops /docker /k8s /cicd /monitor /test /etl /pipeline /web3 /solidity /imagegen /ml /rag /ai-office"
---

# mrarranger-devops-ai - Combined Skill

> Auto-routing: วิเคราะห์ request แล้วโหลด reference ที่เกี่ยวข้อง

## HOW TO USE
1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง
3. โหลด reference file ที่ตรงกับ request
4. Execute ตาม instructions ใน reference

## SKILL ROUTING TABLE

| Skill | Reference File |
|-------|---------------|
| mrarranger-devops-cloud | references/mrarranger-devops-cloud.md |
| mrarranger-monitoring | references/mrarranger-monitoring.md |
| mrarranger-webapp-testing | references/mrarranger-webapp-testing.md |
| mrarranger-data-engineer | references/mrarranger-data-engineer.md |
| mrarranger-web3 | references/mrarranger-web3.md |
| mrarranger-ai-imagegen | references/mrarranger-ai-imagegen.md |
| mrarranger-ai-ml-engineer | references/mrarranger-ai-ml-engineer.md |
| mrarranger-ai-office | references/mrarranger-ai-office.md |

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ skill ไหนจาก routing table
2. ใช้ `view` tool อ่าน reference file ที่เกี่ยวข้อง
3. ทำตาม instructions ใน reference file นั้นอย่างเคร่งครัด
4. ถ้าเกี่ยวข้องหลาย skills ให้อ่านทุก reference ที่เกี่ยวข้อง
