---
name: mrarranger-webapp-testing
description: |
  MRARRANGER Webapp Testing - ระบบทดสอบ Web Application ครบวงจรด้วย Playwright & Vitest
  รวม E2E Testing, Unit Testing, Integration Testing, Visual Regression, Performance Testing
  ใช้เมื่อ: (1) ทดสอบ web app (2) เขียน E2E tests (3) เขียน unit tests (4) Visual regression testing
  (5) Performance testing (6) ทดสอบ form/flow อัตโนมัติ (7) CI/CD testing pipeline
  (8) อะไรก็ตามที่เกี่ยวกับ testing web applications
  Commands: /test [type], /e2e [flow], /unit [function], /visual [page], /perf [url], /coverage [report]
---

# MRARRANGER Webapp Testing

ระบบทดสอบ Web Application ตั้งแต่ unit ถึง E2E ด้วย Playwright & Vitest

## Quick Commands

```
/test [type]            → เลือก testing strategy
/e2e [flow]             → สร้าง E2E test
/unit [function]        → สร้าง unit test
/visual [page]          → Visual regression test
/perf [url]             → Performance test
/coverage [report]      → Generate coverage report
/smoke [app]            → Quick smoke test
```

---

## Testing Strategy

### Testing Pyramid
```
         /  E2E  \         น้อยที่สุด แต่ cover full flow
        /----------\
       / Integration \     ปานกลาง ทดสอบ module ร่วมกัน
      /----------------\
     /    Unit Tests     \  มากที่สุด ทดสอบ function เดี่ยว
    /____________________\
```

### What to Test
```
ALWAYS TEST:
- User-facing flows (login, checkout, form submission)
- Business logic (calculations, validations, rules)
- API integrations (request/response handling)
- Error handling (what happens when things fail)
- Edge cases (empty states, large data, special characters)

SKIP TESTING:
- Third-party library internals
- CSS styling (ใช้ visual regression แทน)
- Framework features (React rendering, Next.js routing)
- Simple getters/setters
```

---

## E2E Testing with Playwright

### Setup
```bash
npm init playwright@latest
# เลือก TypeScript, tests folder, install browsers
```

### Basic E2E Test
```typescript
import { test, expect } from '@playwright/test';

test.describe('User Authentication', () => {
  test('should login successfully with valid credentials', async ({ page }) => {
    // Navigate
    await page.goto('/login');

    // Fill form
    await page.fill('[name="email"]', 'user@example.com');
    await page.fill('[name="password"]', 'password123');

    // Submit
    await page.click('button[type="submit"]');

    // Verify
    await expect(page).toHaveURL('/dashboard');
    await expect(page.locator('h1')).toContainText('Welcome');
  });

  test('should show error for invalid credentials', async ({ page }) => {
    await page.goto('/login');
    await page.fill('[name="email"]', 'wrong@email.com');
    await page.fill('[name="password"]', 'wrongpassword');
    await page.click('button[type="submit"]');

    await expect(page.locator('.error-message')).toBeVisible();
    await expect(page.locator('.error-message')).toContainText('Invalid');
  });
});
```

### Common Playwright Patterns
```typescript
// Wait for network idle
await page.waitForLoadState('networkidle');

// Wait for specific element
await page.waitForSelector('.data-loaded');

// Take screenshot
await page.screenshot({ path: 'screenshot.png', fullPage: true });

// Handle dialog
page.on('dialog', dialog => dialog.accept());

// File upload
await page.setInputFiles('input[type="file"]', 'test-file.pdf');

// Intercept API calls
await page.route('**/api/data', route => {
  route.fulfill({ body: JSON.stringify(mockData) });
});

// Mobile viewport
await page.setViewportSize({ width: 375, height: 812 });

// Multiple tabs
const [newPage] = await Promise.all([
  page.waitForEvent('popup'),
  page.click('a[target="_blank"]'),
]);
```

### Page Object Model
```typescript
// pages/login-page.ts
export class LoginPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/login');
  }

  async login(email: string, password: string) {
    await this.page.fill('[name="email"]', email);
    await this.page.fill('[name="password"]', password);
    await this.page.click('button[type="submit"]');
  }

  async getErrorMessage() {
    return this.page.locator('.error-message').textContent();
  }
}

// tests/login.spec.ts
test('login flow', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login('user@test.com', 'pass123');
  await expect(page).toHaveURL('/dashboard');
});
```

---

## Unit Testing with Vitest

### Setup
```bash
npm install -D vitest @testing-library/react @testing-library/jest-dom jsdom
```

### Config (vitest.config.ts)
```typescript
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./tests/setup.ts'],
    coverage: { provider: 'v8', reporter: ['text', 'html'] },
  },
});
```

### Unit Test Examples
```typescript
import { describe, it, expect } from 'vitest';

// Pure function test
describe('calculateDiscount', () => {
  it('should apply 10% for orders over 1000 THB', () => {
    expect(calculateDiscount(1500)).toBe(150);
  });

  it('should return 0 for orders under 1000 THB', () => {
    expect(calculateDiscount(500)).toBe(0);
  });

  it('should handle 0 amount', () => {
    expect(calculateDiscount(0)).toBe(0);
  });

  it('should handle negative amount', () => {
    expect(() => calculateDiscount(-100)).toThrow('Invalid amount');
  });
});
```

### React Component Test
```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { Counter } from './counter';

describe('Counter', () => {
  it('should render initial count', () => {
    render(<Counter initialCount={5} />);
    expect(screen.getByText('Count: 5')).toBeInTheDocument();
  });

  it('should increment on button click', () => {
    render(<Counter initialCount={0} />);
    fireEvent.click(screen.getByRole('button', { name: /increment/i }));
    expect(screen.getByText('Count: 1')).toBeInTheDocument();
  });
});
```

---

## Visual Regression Testing

### With Playwright
```typescript
test('homepage visual regression', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot('homepage.png', {
    maxDiffPixels: 100,  // Allow minor differences
    threshold: 0.2,      // 20% pixel diff tolerance
  });
});

test('mobile visual regression', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto('/');
  await expect(page).toHaveScreenshot('homepage-mobile.png');
});
```

---

## Performance Testing

### Lighthouse CI
```bash
# Install
npm install -g @lhci/cli

# Run
lhci autorun --collect.url=http://localhost:3000 --assert.preset=lighthouse:recommended
```

### Web Vitals Targets
```
LCP  (Largest Contentful Paint)  < 2.5s   (Good)
FID  (First Input Delay)         < 100ms  (Good)
CLS  (Cumulative Layout Shift)   < 0.1    (Good)
FCP  (First Contentful Paint)    < 1.8s   (Good)
TTFB (Time to First Byte)        < 800ms  (Good)
```

### Playwright Performance Check
```typescript
test('page should load within 3 seconds', async ({ page }) => {
  const start = Date.now();
  await page.goto('/', { waitUntil: 'networkidle' });
  const loadTime = Date.now() - start;
  expect(loadTime).toBeLessThan(3000);
});
```

---

## Testing Checklist

```
BEFORE DEPLOY:
□ All unit tests pass
□ All E2E tests pass
□ No visual regressions
□ Performance within targets
□ Mobile tested (375px, 768px)
□ Cross-browser (Chrome, Firefox, Safari)
□ Error states tested
□ Empty states tested
□ Loading states tested
□ Auth flows tested
```

## CI/CD Integration

### GitHub Actions
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npx vitest run --coverage
      - run: npx playwright install --with-deps
      - run: npx playwright test
      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: test-results
          path: test-results/
```
