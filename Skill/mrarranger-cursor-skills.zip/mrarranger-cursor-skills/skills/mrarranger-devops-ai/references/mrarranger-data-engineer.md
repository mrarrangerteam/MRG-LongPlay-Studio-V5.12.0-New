---
name: mrarranger-data-engineer
description: "Comprehensive Data Engineering guide: ETL/ELT pipelines, orchestration, warehousing, dbt, streaming, quality, optimization & governance"
commands:
  - /pipeline
  - /etl
  - /dbt
  - /sql-master
  - /stream
  - /warehouse
  - /quality
  - /model-data
aliases: ["data-engineer", "etl-master", "dbt-guide"]
---

# Data Engineer Assistant - ชีวิตวิศวกร ข้อมูล 🚀

ยินดีต้อนรับสู่โลกของวิศวกรข้อมูล! Welcome to the comprehensive Data Engineering skill.

---

## 📋 Table of Contents
1. ETL/ELT Fundamentals
2. Pipeline Orchestration
3. Data Warehousing
4. Data Modeling
5. dbt Mastery
6. Streaming & Real-time
7. Data Quality
8. Database Optimization
9. Data Lakes
10. Python Data Stack
11. SQL Mastery
12. Data Governance
13. CDC & Change Tracking

---

## 1️⃣ ETL/ELT Fundamentals

### ETL vs ELT - เลือกเส้นทาง (Choose Your Path)

**ETL (Extract → Transform → Load)**
- Transform ก่อน load (Transform before loading)
- ใช้ cleaning logic บน staging area
- Ideal for data warehouses with strict schemas

**ELT (Extract → Load → Transform)**
- Load raw data ก่อน transform (Load first, transform later)
- Transform ใน warehouse (Snowflake, BigQuery)
- Modern approach - leverage warehouse compute power

### ETL Pipeline Pattern (Python)

```python
import pandas as pd
from sqlalchemy import create_engine

# Extract
raw_data = pd.read_csv('s3://bucket/raw/sales.csv')

# Transform
cleaned = raw_data.dropna()
cleaned['date'] = pd.to_datetime(cleaned['date'])
cleaned['amount'] = pd.to_numeric(cleaned['amount'])

# Load
engine = create_engine('snowflake://user:password@account/db/schema')
cleaned.to_sql('sales_staging', engine, if_exists='append', index=False)
```

---

## 2️⃣ Pipeline Orchestration - วงออร์เคสตรา (The Orchestra)

### Apache Airflow DAG Example
```python
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'data-engineer',
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'sales_etl_pipeline',
    default_args=default_args,
    schedule_interval='0 2 * * *',  # 2 AM daily
    start_date=datetime(2024, 1, 1),
)

def extract_data():
    # ดึงข้อมูล from source
    pass

def transform_data():
    # แปลงข้อมูล
    pass

def load_data():
    # โหลดไปที่ warehouse
    pass

extract = PythonOperator(task_id='extract', python_callable=extract_data, dag=dag)
transform = PythonOperator(task_id='transform', python_callable=transform_data, dag=dag)
load = PythonOperator(task_id='load', python_callable=load_data, dag=dag)

extract >> transform >> load
```

### Prefect Flow (Modern Alternative)
```python
from prefect import flow, task

@task
def extract():
    return {"data": "extracted"}

@task
def transform(data):
    return {"transformed": True}

@task
def load(data):
    print(f"Loading {data}")

@flow(name="etl-pipeline")
def etl_flow():
    raw = extract()
    processed = transform(raw)
    load(processed)
```

### Comparison:
| Tool | Best For | Complexity | Learning Curve |
|------|----------|-----------|-----------------|
| Airflow | Complex DAGs, enterprises | High | Steep |
| Prefect | Modern flows, flexibility | Medium | Gentle |
| Dagster | Type-safe ops, asset lineage | High | Steep |
| n8n | No-code workflows, integrations | Low | Easy |

---

## 3️⃣ Data Warehousing - คลังข้อมูลศูนย์กลาง

### Snowflake Architecture
```sql
-- Create warehouse cluster (compute resource)
CREATE WAREHOUSE analytics_wh
  WITH WAREHOUSE_SIZE = 'LARGE'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;

-- Create database & schema
CREATE DATABASE analytics_db;
CREATE SCHEMA analytics_db.staging;

-- Create table with data clustering
CREATE TABLE analytics_db.staging.events (
  event_id STRING PRIMARY KEY,
  user_id STRING,
  event_date DATE,
  event_type STRING,
  properties VARIANT
) CLUSTER BY (user_id, event_date);

-- Time travel query (ข้อมูลในอดีต)
SELECT * FROM events AT (TIMESTAMP => '2024-01-01'::timestamp_ntz);
```

### BigQuery Partitioning & Clustering
```sql
-- ส่วนของ Google Cloud
CREATE TABLE `project.dataset.events` (
  event_id STRING,
  user_id STRING,
  event_timestamp TIMESTAMP,
  event_type STRING,
  properties JSON
)
PARTITION BY DATE(event_timestamp)
CLUSTER BY user_id, event_type
OPTIONS(
  description="Event stream partitioned by day",
  partition_expiration_ms=7776000000  -- 90 days
);
```

### Amazon Redshift
```sql
-- Distribution & Sort keys
CREATE TABLE sales (
  sale_id BIGINT PRIMARY KEY,
  customer_id BIGINT,
  sale_date DATE,
  amount DECIMAL(10,2)
)
DISTKEY(customer_id)
SORTKEY(sale_date);

-- Run ANALYZE to update statistics
ANALYZE;
```

---

## 4️⃣ Data Modeling - ดีไซน์โครงสร้างข้อมูล

### Star Schema (most common)
```
                    Date Dimension
                          |
                          |
Product Dim --------- Fact Sales --------- Customer Dim
                          |
                          |
                    Store Dimension
```

```sql
-- Fact table (facts - ข้อเท็จจริง)
CREATE TABLE fact_sales (
  sale_id INT PRIMARY KEY,
  date_id INT,
  product_id INT,
  customer_id INT,
  store_id INT,
  quantity INT,
  amount DECIMAL(10,2),
  FOREIGN KEY (date_id) REFERENCES dim_date(date_id),
  FOREIGN KEY (product_id) REFERENCES dim_product(product_id),
  FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id),
  FOREIGN KEY (store_id) REFERENCES dim_store(store_id)
);

-- Dimension table
CREATE TABLE dim_customer (
  customer_id INT PRIMARY KEY,
  customer_name STRING,
  city STRING,
  country STRING,
  segment STRING,
  joined_date DATE,
  scd_type INT  -- Slowly Changing Dimension type
);
```

### Data Vault (Complex Systems)
```sql
-- Hub (unique business keys)
CREATE TABLE hub_customer (
  customer_key INT PRIMARY KEY,
  customer_id STRING UNIQUE,
  load_date TIMESTAMP,
  source STRING
);

-- Link (relationships)
CREATE TABLE link_customer_product (
  link_key INT PRIMARY KEY,
  customer_key INT,
  product_key INT,
  load_date TIMESTAMP,
  source STRING,
  FOREIGN KEY (customer_key) REFERENCES hub_customer,
  FOREIGN KEY (product_key) REFERENCES hub_product
);

-- Satellite (attributes & history)
CREATE TABLE satellite_customer (
  customer_key INT,
  load_date TIMESTAMP,
  end_date TIMESTAMP,
  name STRING,
  email STRING,
  phone STRING,
  source STRING,
  PRIMARY KEY (customer_key, load_date)
);
```

---

## 5️⃣ dbt (data build tool) - การสร้างข้อมูล

### dbt Project Structure
```
my_analytics/
├── dbt_project.yml
├── models/
│   ├── staging/
│   │   └── stg_customers.sql
│   ├── marts/
│   │   └── dim_customer.sql
│   └── intermediate/
│       └── int_customer_rfm.sql
├── tests/
│   └── assert_positive_amounts.sql
├── macros/
│   └── generate_alias_name.sql
└── snapshots/
    └── snapshot_customers.sql
```

### dbt Model (Jinja + SQL)
```sql
-- models/staging/stg_customers.sql
{{ config(
    materialized='table',
    indexes=[{'columns': ['customer_id']}]
) }}

WITH source AS (
    SELECT
        customer_id,
        first_name,
        last_name,
        email,
        created_at
    FROM {{ source('raw', 'customers') }}
),

renamed AS (
    SELECT
        customer_id,
        CONCAT(first_name, ' ', last_name) AS full_name,
        email,
        created_at
    FROM source
)

SELECT * FROM renamed
```

### dbt Test (Data Quality)
```yaml
# models/staging/stg_customers.yml
models:
  - name: stg_customers
    columns:
      - name: customer_id
        tests:
          - unique
          - not_null
      - name: email
        tests:
          - unique
          - pattern: { pattern: '^[^@]+@[^@]+\.[^@]+$' }

      - name: created_at
        tests:
          - not_null
          - dbt_utils.recency:
              datepart: day
              interval: 1
```

### dbt Snapshot (Change Tracking)
```sql
-- snapshots/snapshot_customers.sql
{% snapshot snapshot_customers %}
    {{
        config(
            target_schema='snapshots',
            unique_key='customer_id',
            strategy='timestamp',
            updated_at='updated_at',
        )
    }}
    SELECT * FROM {{ source('raw', 'customers') }}
{% endsnapshot %}
```

---


## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations and advanced patterns, see:

- **advanced-topics.md**: Advanced techniques and detailed examples

