---
name: mrarranger-ai-office
description: |
  MRARRANGER AI Office - ระบบสร้าง Virtual AI Office + Multi-Agent Standup System
  แบบ OpenClaw Control Center ครบวงจร
  สร้างออฟฟิศ Isometric 2D/3D ที่ AI Agents ทำงานเหมือนพนักงานจริง
  เดินเข้าห้องประชุม, ผลัดกัน report standup, ดึงข้อมูลจาก GitHub/Jira real-time
  ใช้เมื่อ: (1) สร้าง Virtual AI Office (2) ทำ Multi-Agent Dashboard (3) สร้าง Scrum/Standup System
  (4) Visualize agent workflows (5) สร้าง Agent Monitoring UI (6) เชื่อม OpenClaw Gateway
  (7) ออกแบบ Agent Characters + Office Layout (8) สร้าง Voice-driven Agent Control
  Commands: /office, /standup, /agent-viz, /floor-plan, /meeting, /dashboard-office, /voice-agent
---

# MRARRANGER AI Office

ระบบสร้าง Virtual AI Office — ให้ AI Agents ทำงานเหมือนทีมจริง มองเห็นได้ สั่งงานได้

> "จินตนาการออฟฟิศที่พนักงานทุกคนเป็น AI — เดินเข้าห้องประชุม, รายงานงาน, กลับไปทำงานต่อ"

## Quick Commands

```
/office [layout]          → สร้าง Virtual Office Layout
/standup [agents]         → เริ่ม Standup Meeting Protocol
/agent-viz [type]         → Agent Visualization (2D/3D)
/floor-plan [style]       → ออกแบบ Floor Plan (isometric/top-down)
/meeting [protocol]       → Meeting System (standup/retro/planning)
/dashboard-office [data]  → Agent Dashboard + Monitoring
/voice-agent [command]    → Voice-driven Agent Control
```

## Reference Files

```
references/office-implementation.md  → Full implementation guide: SVG floor plan,
                                       React Three Fiber 3D, WebSocket connection,
                                       Agent state machine, Standup Board UI,
                                       Voice control, Deployment
```

---

## Architecture Overview

### ภาพรวมระบบ (ตามที่ OpenClaw Office ใช้จริง)
```
┌─────────────────────────────────────────────────┐
│                   FRONTEND                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │ 2D Floor │  │ 3D Scene │  │  Standup      │  │
│  │ Plan     │  │ (R3F)    │  │  Board UI     │  │
│  │ (SVG)    │  │ Voxel    │  │  Dashboard    │  │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘  │
│       └──────────────┼───────────────┘          │
│                      │ React State              │
│                ┌─────┴─────┐                    │
│                │ WebSocket │                    │
│                │ Client    │                    │
│                └─────┬─────┘                    │
└──────────────────────┼──────────────────────────┘
                       │ ws://gateway/ws
┌──────────────────────┼──────────────────────────┐
│              OPENCLAW GATEWAY                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │ Agent    │  │ Task     │  │ Integration   │  │
│  │ Router   │  │ Queue    │  │ Hub           │  │
│  ├──────────┤  ├──────────┤  ├──────────────┤  │
│  │ Agent 1  │  │ Standup  │  │ GitHub MCP    │  │
│  │ Agent 2  │  │ Protocol │  │ Jira MCP      │  │
│  │ Agent 3  │  │ Meeting  │  │ Slack MCP     │  │
│  │ ...      │  │ Manager  │  │ Voice/TTS     │  │
│  └──────────┘  └──────────┘  └──────────────┘  │
└─────────────────────────────────────────────────┘
```

### Tech Stack
```
LAYER              TECHNOLOGY                PURPOSE
─────────────────────────────────────────────────────
2D Office          SVG + CSS Transforms      Isometric floor plan
3D Office          React Three Fiber (R3F)   Voxel characters, 3D scene
Frontend           Next.js + React 19        UI framework
Styling            Tailwind CSS v4           Design system
Real-time          WebSocket                 Gateway connection
State              Zustand / Jotai           Agent states, office state
Agent Backend      OpenClaw Gateway          Multi-agent orchestration
Integrations       MCP Servers               GitHub, Jira, Slack
Voice Input        Web Speech API / Whisper  Voice commands
Voice Output       ElevenLabs / OpenAI TTS   Agent speech
Audio              Web Audio API             Spatial office sounds
```

---

## Core Concepts

### 1. Agent Model
```typescript
// แต่ละ Agent มี identity, state, position, และ current task
interface Agent {
  id: string;
  name: string;
  avatar: AgentAvatar;           // SVG/3D avatar
  role: string;                   // "developer", "designer", "pm"
  state: AgentState;
  position: { x: number; y: number; zone: string };
  currentTask: string | null;
  recentCommits: Commit[];        // จาก GitHub
  activeTickets: Ticket[];        // จาก Jira/Linear
  blockers: string[];
  isSpeaking: boolean;
}

type AgentState =
  | 'idle'          // นั่งที่โต๊ะ ไม่มีงาน
  | 'working'       // กำลังทำ task (มี speech bubble)
  | 'walking'       // เดินไปจุดหมาย (pathfinding)
  | 'meeting'       // อยู่ในห้องประชุม
  | 'speaking'      // กำลังพูดรายงาน (มี waveform)
  | 'tool_calling'  // กำลังเรียก tool/API
  | 'error'         // เจอปัญหา (แสดงสีแดง)
  | 'break'         // พักผ่อน (โซฟา/โต๊ะปิงปอง)
```

### 2. Office Layout (Zones)
```typescript
// ออฟฟิศแบ่งเป็น zones — agents เดินไปตาม zone ที่เกี่ยวข้อง
interface OfficeLayout {
  zones: Zone[];
  furniture: Furniture[];
  pathGrid: PathNode[][];        // สำหรับ A* pathfinding
}

interface Zone {
  id: string;
  type: 'desk' | 'meeting_room' | 'lounge' | 'server_room' | 'kitchen';
  bounds: { x: number; y: number; width: number; height: number };
  capacity: number;
  assignedAgents: string[];
}

// Zone types ตามที่เห็นในวิดีโอ:
// - Desk zones: โต๊ะทำงานแต่ละคน (6 โต๊ะ)
// - Meeting room: โต๊ะกลมสำหรับ standup
// - Lounge: โซฟา + โต๊ะปิงปอง
// - Server room: ตู้ server + อุปกรณ์
```

### 3. Standup Protocol (หัวใจของระบบ)
```typescript
// Standup Protocol — เหมือนในวิดีโอเป๊ะ
interface StandupProtocol {
  phase: 'idle' | 'gathering' | 'in_progress' | 'complete';
  participants: Agent[];
  currentSpeaker: Agent | null;
  speakerQueue: Agent[];
  arrivedCount: number;
  totalExpected: number;
  board: StandupBoard;
}

interface StandupBoard {
  cards: AgentCard[];
}

interface AgentCard {
  agent: Agent;
  currentTask: string;
  recentCommits: { message: string; repo: string; }[];
  activeTickets: { id: string; title: string; status: string; }[];
  blockers: string[];
  sources: ('github' | 'jira' | 'manual')[];
  isSpeaking: boolean;
}

// Standup Flow (ตามวิดีโอ):
// 1. Trigger: voice command "start standup"
// 2. Phase: gathering — ทุก agent เดินไป meeting room
// 3. Status: "Gathering in meeting room. 1/6 arrived"
// 4. เมื่อครบ: Phase → in_progress
// 5. Speaker rotation: main → agent1 → agent2 → ...
// 6. แต่ละคนรายงาน task + commits + blockers
// 7. Phase: complete → agents เดินกลับโต๊ะ
```

### 4. WebSocket Messages
```typescript
// Client ↔ Gateway protocol
type WSMessage =
  | { type: 'agent:status'; data: { agentId: string; state: AgentState; task: string } }
  | { type: 'agent:move'; data: { agentId: string; target: Position } }
  | { type: 'agent:speak'; data: { agentId: string; text: string; isStreaming: boolean } }
  | { type: 'standup:start'; data: { initiator: string } }
  | { type: 'standup:arrived'; data: { agentId: string; count: number; total: number } }
  | { type: 'standup:speaker'; data: { agentId: string; report: AgentCard } }
  | { type: 'standup:complete'; data: {} }
  | { type: 'tool:call'; data: { agentId: string; tool: string; args: any } }
  | { type: 'tool:result'; data: { agentId: string; result: any } }
  | { type: 'voice:transcription'; data: { text: string } }
```

---

## Implementation Steps

### Step 1: สร้าง Isometric Floor Plan (SVG)
```
เทคนิคหลัก:
- ใช้ CSS transform: rotateX(60deg) rotateZ(45deg) สำหรับ isometric view
- หรือ SVG pre-rendered isometric tiles
- Furniture เป็น SVG components แยก (โต๊ะ, เก้าอี้, ต้นไม้)
- Grid system สำหรับวาง furniture + pathfinding
- Camera: pan (drag) + zoom (scroll) + follow agent

ดู references/office-implementation.md สำหรับโค้ดเต็ม
```

### Step 2: Agent Characters + Animation
```
Character design:
- Voxel-style sprites (เหมือนในวิดีโอ — pixel art ขนาด 32x32 หรือ 64x64)
- 4 ทิศ animation: walk-up, walk-down, walk-left, walk-right
- States: idle (นั่ง), walking, working (พิมพ์), speaking (waveform)
- Name tag: ชื่อ + status dot (green=online, yellow=busy, red=error)
- Speech bubble: แสดง current task text

สำหรับ 3D (React Three Fiber):
- Voxel avatars — deterministically generated จาก agent ID
- Status glow animation (idle=blue, working=green, speaking=yellow)
```

### Step 3: A* Pathfinding
```
ให้ agents เดินไปจุดหมายได้ (ไม่ทะลุกำแพง/โต๊ะ):
1. สร้าง walkable grid จาก floor plan
2. Mark obstacles (furniture, walls)
3. A* algorithm หา shortest path
4. Smooth movement interpolation (lerp between nodes)
5. Collision avoidance เมื่อ agents เดินชนกัน
```

### Step 4: WebSocket Gateway Connection
```
เชื่อมต่อ OpenClaw Gateway:
1. Connect ws://localhost:PORT/gateway-ws
2. Subscribe to agent events
3. Render agent states in real-time
4. Send commands (standup:start, voice input)

หรือถ้าทำ standalone (ไม่ใช้ OpenClaw):
- สร้าง Node.js WebSocket server
- จัดการ agent states ใน memory
- เชื่อม GitHub API + Jira API โดยตรง
```

### Step 5: Standup Board UI
```
Dashboard component:
- Grid 2x3 cards (6 agents)
- แต่ละ card: Participant, Current Task, Recent Commits, Active Tickets, Blockers, Sources
- "SPEAKING" badge highlight
- Header: Phase, Speaker, Progress (x/6 arrived)
- Monospace font theme (เหมือนในวิดีโอ)
- Dark theme with teal/cyan accents
```

### Step 6: Data Integration
```
GitHub MCP / API:
- ดึง recent commits per agent → agent.recentCommits
- ดึง open PRs → แสดงใน Active Tickets
- Branch tracking → Current Task

Jira / Linear MCP:
- ดึง assigned tickets → agent.activeTickets
- ดึง blockers → agent.blockers
- Sprint progress → Standup Board header

Voice Input:
- Web Speech API (browser) หรือ Whisper API
- Transcribe → parse command → trigger action
- "Start standup" → standup:start
- "Assign task to Cory" → task assignment

TTS Output:
- ElevenLabs / OpenAI TTS
- แต่ละ agent มี voice ID ต่างกัน
- พูดรายงานตอน standup (optional)
```

---

## 2 Modes: OpenClaw vs Standalone

### Mode 1: ใช้กับ OpenClaw Gateway (Recommended)
```
ข้อดี: Agents ทำงานจริง ดึงข้อมูลจริง commit จริง
วิธี:
1. ติดตั้ง OpenClaw Gateway → npm install -g openclaw
2. สร้าง agents ใน config (กำหนด role, skills, tools)
3. เชื่อม office frontend ผ่าน WebSocket
4. Agents ทำงานอัตโนมัติ + แสดงผลใน office UI

ต้องการ: openclaw skill ✅ + mrarranger-mcp-builder ✅
```

### Mode 2: Standalone (ไม่ใช้ OpenClaw)
```
ข้อดี: ควบคุมได้ทั้งหมด custom ได้เต็มที่
วิธี:
1. สร้าง Next.js app + WebSocket server
2. สร้าง Agent orchestrator (state machine)
3. เชื่อม GitHub/Jira API โดยตรง
4. สร้าง UI ทั้งหมดเอง

ต้องการ: mrarranger-react-nextjs ✅ + mrarranger-api-master ✅
```

---

## Project Scaffold

```
openclaw-office/
├── app/                        # Next.js App Router
│   ├── page.tsx                # Main office view
│   ├── layout.tsx              # Root layout
│   └── api/
│       └── gateway/route.ts    # WebSocket proxy
├── components/
│   ├── office/
│   │   ├── FloorPlan.tsx       # 2D SVG isometric office
│   │   ├── Agent2D.tsx         # 2D agent sprite
│   │   ├── Furniture.tsx       # Office furniture SVG
│   │   ├── SpeechBubble.tsx    # Task display bubble
│   │   └── Camera.tsx          # Pan + Zoom controls
│   ├── office3d/
│   │   ├── Scene.tsx           # R3F 3D scene
│   │   ├── VoxelAgent.tsx      # 3D voxel character
│   │   └── OfficeModel.tsx     # 3D office model
│   ├── standup/
│   │   ├── StandupBoard.tsx    # Standup dashboard overlay
│   │   ├── AgentCard.tsx       # Per-agent card
│   │   └── StandupHeader.tsx   # Phase + Progress
│   ├── dashboard/
│   │   ├── AgentList.tsx       # Top bar: agent avatars
│   │   ├── StatusBar.tsx       # Bottom: working/idle/error counts
│   │   └── ChatPanel.tsx       # Chat/voice input panel
│   └── voice/
│       ├── VoiceInput.tsx      # Web Speech API
│       └── VoiceOutput.tsx     # TTS playback
├── lib/
│   ├── agents/
│   │   ├── types.ts            # Agent, Office, Standup types
│   │   ├── store.ts            # Zustand state store
│   │   ├── pathfinding.ts      # A* algorithm
│   │   └── standup-protocol.ts # Standup state machine
│   ├── ws/
│   │   ├── client.ts           # WebSocket client
│   │   └── messages.ts         # Message types
│   └── integrations/
│       ├── github.ts           # GitHub API/MCP
│       ├── jira.ts             # Jira/Linear API
│       └── voice.ts            # Speech API wrapper
├── assets/
│   ├── sprites/                # Agent sprite sheets
│   ├── tiles/                  # Office tile set
│   └── sounds/                 # Office ambient, notifications
├── public/
└── package.json
```

---

## Standup Board Design (CSS)

```
สไตล์จากวิดีโอ:
- Background: dark (#0a1628) with slight transparency
- Cards: dark teal (#0d2137) with border (#1a3a5c)
- Text: monospace font (JetBrains Mono / Fira Code)
- Accent: cyan/teal (#00d4aa)
- Speaking badge: teal background
- Commits: darker cards inside (#0a1a2e) with repo name subtitle
- Sources: pill badges (GITHUB, JIRA, MANUAL)
- Header: Phase: in_progress | Speaker: xxx | Progress: 6/6
```

---

## Quick Start Guide

```bash
# 1. สร้าง project
npx create-next-app@latest openclaw-office --typescript --tailwind --app

# 2. ติดตั้ง dependencies
npm install zustand @react-three/fiber @react-three/drei three
npm install socket.io-client   # WebSocket

# 3. สร้าง office layout
# → ใช้ /floor-plan command

# 4. สร้าง agent characters
# → ใช้ /agent-viz command

# 5. เชื่อม OpenClaw Gateway
# → ใช้ openclaw skill สำหรับ setup

# 6. สร้าง standup protocol
# → ใช้ /standup command

# 7. Deploy
npm run build && npm start
```
