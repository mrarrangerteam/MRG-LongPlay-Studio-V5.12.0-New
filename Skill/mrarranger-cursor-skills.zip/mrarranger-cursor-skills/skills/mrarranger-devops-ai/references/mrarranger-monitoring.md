---
name: mrarranger-monitoring
description: ระบบ Monitor และ Observe ครบวงจร - Logs, Metrics, Traces, Error tracking, APM, Alerting, Health checks, and SLO
commands:
  - /monitor
  - /metrics
  - /logs
  - /traces
  - /alerts
  - /dashboard
  - /incident
  - /slo
---

# MRARRANGER Monitoring & Observability

**ระบบ Monitor และ Observe ครบวงจร** - Complete monitoring and observability system.

## 1. Three Pillars of Observability

### Logs (บันทึก Events)
```
What happened?
- Application events
- User actions
- Errors and warnings
- Detailed context

Example:
2024-03-15T10:30:45.123Z INFO auth.js:45 user_login user_id=123 email=john@example.com ip=192.168.1.1
```

### Metrics (วัด Aggregates)
```
How much/many?
- Request count per second
- CPU usage %
- Memory utilization MB
- Database query time ms
- Error rate %

Example:
http_requests_total{method="POST", status="200"} 45670
response_time_ms{p95} 250
error_rate{} 0.02
```

### Traces (Track Flow)
```
What sequence happened?
- Request spans across services
- Database query time
- External API calls
- Async job execution

Example:
POST /api/users
  ├─ Database Query (45ms)
  │  ├─ SELECT (10ms)
  │  └─ INSERT (35ms)
  ├─ Cache Update (5ms)
  └─ Send Email (2000ms)
  Total: 2050ms
```

## 2. Structured Logging

### JSON Log Format
Structured logs enable:
- Easy searching and filtering
- Automated analysis
- Integration with log aggregation systems
- Better debugging context

Key fields: timestamp, level, service, message, user_id, request_id, error info

### Node.js Logging Options

**Winston**: Full-featured logging library
- Multiple transports (files, console, remote)
- Log levels and formatting
- Error stack traces

**Pino**: High-performance logger
- Optimized for production
- Pretty printing for development
- JSON output by default

### Python Logging
Built-in logging module with JSON formatter for structured output.

## 3. Metrics (Prometheus)

### Key Metrics Types

**COUNTER**: Only increases
- Total requests
- Total errors
- Total bytes sent

**GAUGE**: Can go up and down
- Current connections
- Memory usage
- CPU percentage

**HISTOGRAM**: Tracks distributions
- Request duration
- Response size
- Query time

**SUMMARY**: Percentiles
- P50 latency
- P95 latency
- P99 latency

### Prometheus Format
Metrics stored in time-series format with labels for filtering:
```
metric_name{label1="value1", label2="value2"} value
```

### Node.js with prom-client
Create custom metrics with labels, record observations, expose /metrics endpoint.

## 4. Distributed Tracing

### OpenTelemetry
Standard for collecting traces across services.

Components:
- **Tracer Provider**: Creates tracers
- **Spans**: Individual operations
- **Exporters**: Send traces to backends (Jaeger, Datadog, etc.)
- **Propagation**: Pass trace context between services

### Span Context
Connect related spans with parent-child relationships using trace IDs.

## 5. Error Tracking (Sentry)

### Automatic Capture
Sentry captures unhandled exceptions and errors with context.

### Grouping
Errors automatically grouped by:
- Error type and message
- Stack trace similarity
- Source file and line number

### Dashboard Features
- Error frequency timeline
- Affected users
- Browser/OS information
- Full stack traces
- Release tracking

## 6. Application Performance Monitoring (APM)

### Datadog APM
Auto-instruments common libraries:
- HTTP requests
- Database queries
- Cache operations
- External API calls

### Key Metrics Tracked
- Requests per second (RPS)
- Error rate
- Response time (p50, p95, p99)
- Database query time
- Resource usage (CPU, memory, disk I/O)

## 7. Uptime Monitoring

### Health Check Endpoint
Return service status with dependency checks:
- Database connectivity
- Cache availability
- External API accessibility

### Kubernetes Probes
**Liveness Probe**: Is app running? (restart if fails)
**Readiness Probe**: Can app accept traffic? (remove from LB if fails)

## 8. Alerting Best Practices

### Alert Rules Structure
- Condition: What metric and threshold
- Duration: How long before alerting
- Severity: Critical, Warning, Info
- Action: Who to notify

### Alert Fatigue Prevention
Alert only on actionable issues:
- ✓ Error rate > 10% (indicates real problem)
- ✓ Database connection pool exhausted (requires action)
- ✓ Response time p95 > threshold
- ✗ CPU > 70% (normal under load)
- ✗ Cache miss rate high (expected behavior)

### PagerDuty Integration
Trigger alerts programmatically with service, message, severity.

## 9. Dashboard Design (Grafana)

### Organization by Use Case
Organize dashboards around user/operator needs, not technical components:
- Service Health (overall status)
- User Experience (latency, errors, throughput)
- Business Metrics (revenue, conversion, etc.)

### Dashboard Best Practices
1. Show KPIs (Key Performance Indicators)
2. Include thresholds for context
3. Show what's normal
4. Display trends over time
5. Make alerts actionable

### PromQL for Common Queries
Query language for Prometheus metrics to create dashboard visualizations.

## 10. Health Check Types

### Liveness Probe
Determines if application is running.
- Returns 200 if healthy
- Returns 500 if crashed/stuck
- Kubernetes restarts on 500

### Readiness Probe
Determines if application can accept traffic.
- Checks dependencies (database, cache, APIs)
- Returns 200 only if all dependencies ready
- Returns 503 if any dependency unavailable
- Kubernetes removes from load balancer on 503

## 11. Log Aggregation

### ELK Stack
Elasticsearch (search) + Logstash (parse) + Kibana (visualize)

### Loki + Grafana
Lightweight alternative optimized for log querying with Grafana integration.

Key concept: LogQL for querying logs with labels and filters.

## 12. Cost Optimization

### Log Sampling
```
Send 100% of error logs (critical)
Send 10-50% of success logs (sampled)
Reduces log volume while keeping errors
```

### Retention Policies
```
Development: 7 days
Staging: 30 days
Production: 90 days hot, 1 year cold storage

Metrics: 15 days high resolution, 1 year downsampled
Traces: 7 days
```

### Volume Reduction
- Only log valuable data
- Batch logs (send in groups)
- Use appropriate log levels
- Compress storage
- Archive old logs to S3

## 13. Incident Response

### Runbook Structure
- Detection criteria (what alerts/symptoms)
- Immediate actions (0-5 minutes)
- Short-term mitigation (5-30 minutes)
- Long-term fixes (next day)

### Postmortem Process
- Impact summary (downtime, users, revenue)
- Timeline of events
- Root cause analysis
- Immediate actions taken
- Preventive actions for future

### Blameless Culture
Focus on systemic improvements, not individual blame.

## 14. SLI/SLO/SLA

### Service Level Indicators (SLI)
What we measure:
- **Availability**: uptime percentage
- **Latency**: response time percentiles (p95, p99)
- **Error rate**: errors per request
- **Throughput**: requests per second

### Service Level Objectives (SLO)
Targets we commit to:
- Availability: 99.9% (8.76 hours downtime/year)
- Latency p95: < 200ms
- Error rate: < 0.1%

### Service Level Agreements (SLA)
Contractual commitments with customer compensation:
- Miss SLO → refund percentage of fees
- More strict SLA than internal SLO

### Error Budget
```
Error Budget = (1 - SLO) × Total Requests
Example: 99.9% SLO × 1M requests = 1000 errors allowed
```

---

## Reference Files

For complete code examples and detailed implementations, see:
- `references/logging-setup.md` - Winston, Pino, Python logging configurations
- `references/prometheus-metrics.md` - Metric definitions and instrumentation
- `references/distributed-tracing.md` - OpenTelemetry and span examples
- `references/error-tracking.md` - Sentry integration and configuration
- `references/apm-setup.md` - Datadog APM and health checks
- `references/alerting-dashboards.md` - Alert rules and Grafana queries
- `references/incident-templates.md` - Runbooks and postmortem templates

## Commands Summary

- `/monitor [service]` - Setup monitoring infrastructure
- `/metrics [type]` - Configure Prometheus metrics
- `/logs [format]` - Implement structured logging
- `/traces [service]` - Setup distributed tracing
- `/alerts [condition]` - Create alert rules
- `/dashboard [metric]` - Build Grafana dashboards
- `/incident [scenario]` - Document incident response
- `/slo [target]` - Define and monitor SLO

**MRARRANGER Monitoring: Observable, alertable, actionable.**
