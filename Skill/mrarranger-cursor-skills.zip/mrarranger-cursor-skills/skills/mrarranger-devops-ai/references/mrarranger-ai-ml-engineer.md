---
name: mrarranger-ai-ml-engineer
description: "Deep comprehensive guide to modern AI/ML engineering: RAG, Vector DBs, LLM integration, fine-tuning, prompt engineering, agents, MCP, embeddings, safety, eval & MLOps"
commands:
  - /rag
  - /vector
  - /finetune
  - /agent-ai
  - /prompt-eng
  - /llm
  - /mcp-ai
  - /eval
---

# 🤖 AI/ML Engineering Master Guide | มหาวิทยาลัย AI/ML เทพการ

> **ผู้เชี่ยวชาญ AI/ML Engineering** - RAG • Vector Databases • LLM APIs • Fine-tuning • Agents • MCP • Safety & MLOps

## Table of Contents
1. [RAG Systems](#rag-systems)
2. [Vector Databases](#vector-databases)
3. [LLM Integration](#llm-integration)
4. [Fine-tuning Techniques](#fine-tuning)
5. [Prompt Engineering](#prompt-engineering)
6. [Agent Orchestration](#agent-orchestration)
7. [MCP Protocol](#mcp-protocol)
8. [Embeddings & Representations](#embeddings)
9. [AI Safety & Guardrails](#safety)
10. [Evaluation & Benchmarking](#evaluation)
11. [MLOps & Monitoring](#mlops)
12. [Cost Optimization](#cost-optimization)

---

## RAG Systems | ระบบ RAG

**สิ่งสำคัญ**: RAG (Retrieval-Augmented Generation) รวมการค้นหาข้อมูลกับการสร้างข้อความ เพื่อให้ LLM ตอบคำถามที่ถูกต้องและทันสมัย

### Chunking Strategies | กลยุทธ์การตัดข้อมูล

```python
# Method 1: Semantic Chunking
from langchain.text_splitter import RecursiveCharacterTextSplitter

def semantic_chunk(text, chunk_size=1024, overlap=200):
    """แบ่งข้อความตามความหมายและบริบท"""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=overlap,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    chunks = splitter.split_text(text)
    return chunks

# Method 2: Document-Aware Chunking
def doc_aware_chunk(docs, chunk_size=800):
    """แยกหมวดหมู่และระดับของเอกสาร"""
    chunked = []
    for doc in docs:
        metadata = doc.metadata.copy()
        text_chunks = semantic_chunk(doc.page_content, chunk_size)
        for chunk in text_chunks:
            chunked.append({
                'content': chunk,
                'metadata': metadata,
                'source': doc.metadata.get('source', 'unknown')
            })
    return chunked

# Method 3: Sliding Window with Context
def sliding_window_chunk(text, window_size=512, stride=256):
    """ใช้ sliding window เพื่อรักษาบริบท"""
    chunks = []
    tokens = text.split()
    for i in range(0, len(tokens), stride):
        chunk = ' '.join(tokens[i:i+window_size])
        chunks.append(chunk)
    return chunks
```

### Embedding Models | โมเดลเอมเบดดิ้ง

```python
# Use sentence-transformers for high-quality embeddings
from sentence_transformers import SentenceTransformer
import numpy as np

class EmbeddingManager:
    def __init__(self, model_name="all-MiniLM-L6-v2"):
        """เลือกโมเดล: all-MiniLM-L6-v2 (fast), all-mpnet-base-v2 (quality)"""
        self.model = SentenceTransformer(model_name)

    def embed_documents(self, docs):
        """แปลงเอกสารเป็น embeddings"""
        embeddings = self.model.encode(docs, convert_to_tensor=True)
        return embeddings

    def embed_query(self, query):
        """แปลงคำค้นหาเป็น embedding"""
        return self.model.encode([query])[0]

    def cosine_similarity(self, vec1, vec2):
        """คำนวณความคล้ายคลึง"""
        return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
```

### Hybrid Search | การค้นหาแบบผสม

```python
# Combine dense (semantic) + sparse (keyword) retrieval
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import csr_matrix

class HybridRetriever:
    def __init__(self, documents, dense_weight=0.6, sparse_weight=0.4):
        """รวม semantic + keyword search"""
        self.documents = documents
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight

        # Dense retrieval setup
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        self.dense_embeddings = self.embedder.encode(documents)

        # Sparse retrieval setup
        self.tfidf = TfidfVectorizer(max_features=5000)
        self.sparse_matrix = self.tfidf.fit_transform(documents)

    def retrieve(self, query, k=5):
        """ดึงเอกสารจากทั้งสองวิธี"""
        # Dense search
        query_dense = self.embedder.encode([query])[0]
        dense_scores = np.dot(self.dense_embeddings, query_dense)

        # Sparse search
        query_sparse = self.tfidf.transform([query])
        sparse_scores = np.array(query_sparse.dot(self.sparse_matrix.T).toarray()).flatten()

        # Combine scores
        combined_scores = (self.dense_weight * dense_scores +
                          self.sparse_weight * sparse_scores)

        top_k_idx = np.argsort(combined_scores)[-k:][::-1]
        return [self.documents[i] for i in top_k_idx]
```

---

## Vector Databases | ฐานข้อมูลเวกเตอร์

**เปรียบเทียบ Vector DBs**: Pinecone (managed) vs Weaviate (open) vs Qdrant (fast) vs ChromaDB (simple) vs pgvector (PostgreSQL)

### ChromaDB | เก็บเวกเตอร์ในพื้นที่

```python
import chromadb
from chromadb.config import Settings

# ติดตั้ง: pip install chromadb

def setup_chroma():
    """สร้าง ChromaDB collection"""
    client = chromadb.Client()
    collection = client.create_collection(name="ai_docs")
    return collection

def add_documents_to_chroma(collection, docs, embeddings, metadatas):
    """เพิ่มเอกสารพร้อม embeddings"""
    ids = [f"doc_{i}" for i in range(len(docs))]
    collection.add(
        ids=ids,
        embeddings=embeddings.tolist(),
        documents=docs,
        metadatas=metadatas
    )

def query_chroma(collection, query_embedding, k=5):
    """ค้นหาเอกสารที่คล้ายคลึง"""
    results = collection.query(
        query_embeddings=[query_embedding.tolist()],
        n_results=k
    )
    return results
```

### Weaviate | Vector DB โอเพนซอร์ส

```python
import weaviate
from weaviate.connect import ConnectionParams

def setup_weaviate():
    """เชื่อมต่อ Weaviate"""
    client = weaviate.connect_to_local()
    return client

def create_class_schema(client):
    """สร้าง schema สำหรับเอกสาร"""
    class_definition = {
        "class": "Document",
        "vectorizer": "text2vec-openai",
        "vectorIndexConfig": {
            "distance": "cosine",
            "ef": 100,
            "efConstruction": 200
        },
        "properties": [
            {"name": "content", "dataType": ["text"]},
            {"name": "source", "dataType": ["text"]},
            {"name": "timestamp", "dataType": ["date"]}
        ]
    }
    client.collections.create_from_dict(class_definition)

def search_weaviate(client, query_text, k=5):
    """ค้นหาใน Weaviate"""
    response = client.collections.get("Document").query.near_text(
        query=query_text,
        limit=k,
        return_metadata=weaviate.classes.query.MetadataQuery(distance=True)
    )
    return response
```

### Pinecone | Managed Vector Database

```python
import pinecone

def init_pinecone(api_key, environment, index_name):
    """เริ่มต้น Pinecone"""
    pinecone.init(api_key=api_key, environment=environment)

    # สร้าง index
    if index_name not in pinecone.list_indexes():
        pinecone.create_index(index_name, dimension=384, metric="cosine")

    return pinecone.Index(index_name)

def upsert_to_pinecone(index, embeddings, ids, metadata):
    """อัพเดต/เพิ่ม vectors"""
    vectors = [(id_, emb, meta) for id_, emb, meta in
               zip(ids, embeddings, metadata)]
    index.upsert(vectors=vectors)

def query_pinecone(index, query_vector, k=5, namespace=""):
    """ค้นหา k nearest neighbors"""
    results = index.query(
        query_vector,
        top_k=k,
        include_metadata=True,
        namespace=namespace
    )
    return results
```

### pgvector | PostgreSQL Extension

```python
import psycopg2
from pgvector.psycopg2 import register_vector

def setup_pgvector():
    """ตั้งค่า pgvector ใน PostgreSQL"""
    conn = psycopg2.connect("dbname=ai_db user=postgres")
    register_vector(conn)

    cur = conn.cursor()
    cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id SERIAL PRIMARY KEY,
            content TEXT,
            embedding vector(384),
            metadata JSONB
        )
    """)
    cur.execute("CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops)")
    conn.commit()
    return conn

def search_pgvector(conn, query_vector, k=5):
    """ค้นหา KNN ใน PostgreSQL"""
    cur = conn.cursor()
    cur.execute("""
        SELECT id, content, metadata, embedding <-> %s as distance
        FROM documents
        ORDER BY distance
        LIMIT %s
    """, (query_vector.tolist(), k))
    return cur.fetchall()
```

---

## LLM Integration | การรวมโมเดลภาษา

## 📚 Reference Files | ไฟล์อ้างอิง

For comprehensive details on advanced AI/ML topics, see:

- **advanced-implementation.md**: LLM Integration, Fine-tuning, Prompt Engineering, Agents, MCP, Embeddings, Safety, Evaluation, MLOps, and Cost Optimization

