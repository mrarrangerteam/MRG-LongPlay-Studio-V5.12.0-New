# OpenClaw Office — Full Implementation Guide

## 1. Isometric Floor Plan (SVG + CSS)

### CSS Isometric Transform
```css
.office-container {
  perspective: 1000px;
  overflow: hidden;
}

.isometric-floor {
  transform: rotateX(60deg) rotateZ(-45deg);
  transform-style: preserve-3d;
  width: 1200px;
  height: 800px;
  position: relative;
}

.tile {
  width: 64px;
  height: 64px;
  position: absolute;
  transform-style: preserve-3d;
}

.wall {
  transform: rotateX(-90deg) translateZ(32px);
  background: #2a2a3e;
  height: 96px;
}
```

### React Isometric Floor Component
```tsx
interface FloorPlanProps {
  layout: OfficeLayout;
  agents: Agent[];
  onAgentClick: (agent: Agent) => void;
}

export function FloorPlan({ layout, agents, onAgentClick }: FloorPlanProps) {
  const [camera, setCamera] = useState({ x: 0, y: 0, zoom: 1 });

  // Convert grid coords to isometric screen coords
  const toIso = (x: number, y: number) => ({
    screenX: (x - y) * 32 * camera.zoom + camera.x,
    screenY: (x + y) * 16 * camera.zoom + camera.y,
  });

  return (
    <svg viewBox="0 0 1400 900" className="w-full h-full bg-[#1a1a2e]">
      {/* Floor tiles */}
      {layout.tiles.map((tile, i) => {
        const { screenX, screenY } = toIso(tile.x, tile.y);
        return (
          <polygon
            key={i}
            points={isoTilePoints(screenX, screenY)}
            fill={tile.type === 'floor' ? '#f5e6d0' : '#ddd'}
            stroke="#ccc"
            strokeWidth={0.5}
          />
        );
      })}

      {/* Furniture */}
      {layout.furniture.map((item) => (
        <FurnitureSVG key={item.id} item={item} toIso={toIso} />
      ))}

      {/* Agents */}
      {agents.map((agent) => (
        <Agent2D
          key={agent.id}
          agent={agent}
          position={toIso(agent.position.x, agent.position.y)}
          onClick={() => onAgentClick(agent)}
        />
      ))}
    </svg>
  );
}

function isoTilePoints(x: number, y: number): string {
  const w = 64, h = 32;
  return `${x},${y} ${x + w/2},${y + h/2} ${x},${y + h} ${x - w/2},${y + h/2}`;
}
```

### Agent 2D Sprite
```tsx
export function Agent2D({ agent, position, onClick }: Agent2DProps) {
  const statusColor = {
    idle: '#888',
    working: '#00d4aa',
    walking: '#00d4aa',
    meeting: '#ffd700',
    speaking: '#ff6b6b',
    error: '#ff4444',
  }[agent.state] || '#888';

  return (
    <g
      transform={`translate(${position.screenX}, ${position.screenY})`}
      onClick={onClick}
      className="cursor-pointer"
    >
      {/* Shadow */}
      <ellipse rx={12} ry={6} cy={20} fill="rgba(0,0,0,0.3)" />

      {/* Body (voxel-style pixel art) */}
      <image
        href={`/sprites/${agent.id}-${agent.state}.png`}
        width={32} height={48}
        x={-16} y={-40}
      />

      {/* Status indicator (green dot) */}
      <circle cx={18} cy={-30} r={4} fill={statusColor} />

      {/* Name tag */}
      <rect x={-30} y={-55} width={60} height={18} rx={3}
        fill="rgba(0,0,0,0.8)" />
      <text x={0} y={-42} textAnchor="middle"
        fill="white" fontSize={10} fontFamily="monospace">
        {agent.name}
      </text>

      {/* Speech bubble (when working/speaking) */}
      {agent.currentTask && agent.state === 'working' && (
        <SpeechBubble text={agent.currentTask} x={0} y={-70} />
      )}

      {/* Waveform animation (when speaking in standup) */}
      {agent.isSpeaking && (
        <g transform="translate(20, -35)">
          {[0,1,2,3,4].map(i => (
            <rect key={i} x={i * 4} y={0} width={2}
              height={Math.random() * 12 + 4}
              fill="#00d4aa"
              className="animate-pulse"
              style={{ animationDelay: `${i * 100}ms` }}
            />
          ))}
        </g>
      )}
    </g>
  );
}
```

---

## 2. React Three Fiber 3D Scene (Alternative)

```tsx
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

export function Office3D({ agents }: { agents: Agent[] }) {
  return (
    <Canvas camera={{ position: [10, 10, 10], fov: 50 }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 10, 5]} />
      <OrbitControls />

      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[20, 15]} />
        <meshStandardMaterial color="#f5e6d0" />
      </mesh>

      {/* Walls */}
      <mesh position={[0, 1.5, -7.5]}>
        <boxGeometry args={[20, 3, 0.2]} />
        <meshStandardMaterial color="#2a2a3e" />
      </mesh>

      {/* Agent voxel avatars */}
      {agents.map(agent => (
        <VoxelAgent key={agent.id} agent={agent} />
      ))}
    </Canvas>
  );
}

function VoxelAgent({ agent }: { agent: Agent }) {
  const color = {
    idle: '#4a90d9',
    working: '#00d4aa',
    speaking: '#ffd700',
    error: '#ff4444',
  }[agent.state] || '#888';

  return (
    <group position={[agent.position.x * 0.5, 0, agent.position.y * 0.5]}>
      {/* Body */}
      <mesh position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.4, 0.6, 0.3]} />
        <meshStandardMaterial color={color} />
      </mesh>
      {/* Head */}
      <mesh position={[0, 1.1, 0]} castShadow>
        <boxGeometry args={[0.35, 0.35, 0.35]} />
        <meshStandardMaterial color="#f5c6a0" />
      </mesh>
    </group>
  );
}
```

---

## 3. Zustand State Store

```typescript
import { create } from 'zustand';

interface OfficeStore {
  agents: Agent[];
  standup: StandupProtocol;
  officeLayout: OfficeLayout;

  // Agent actions
  updateAgent: (id: string, data: Partial<Agent>) => void;
  moveAgent: (id: string, target: Position) => void;

  // Standup actions
  startStandup: () => void;
  agentArrived: (id: string) => void;
  nextSpeaker: () => void;
  completeStandup: () => void;

  // WebSocket
  connectGateway: (url: string) => void;
  sendMessage: (msg: WSMessage) => void;
}

export const useOfficeStore = create<OfficeStore>((set, get) => ({
  agents: [],
  standup: {
    phase: 'idle',
    participants: [],
    currentSpeaker: null,
    speakerQueue: [],
    arrivedCount: 0,
    totalExpected: 0,
    board: { cards: [] },
  },

  startStandup: () => {
    const { agents, sendMessage } = get();
    set(state => ({
      standup: {
        ...state.standup,
        phase: 'gathering',
        participants: agents,
        speakerQueue: [...agents],
        totalExpected: agents.length,
        arrivedCount: 0,
      }
    }));

    // Tell all agents to walk to meeting room
    const meetingRoom = get().officeLayout.zones
      .find(z => z.type === 'meeting_room');

    agents.forEach(agent => {
      sendMessage({
        type: 'agent:move',
        data: { agentId: agent.id, target: meetingRoom!.bounds }
      });
    });
  },

  agentArrived: (id) => {
    set(state => {
      const newCount = state.standup.arrivedCount + 1;
      const allArrived = newCount >= state.standup.totalExpected;

      return {
        standup: {
          ...state.standup,
          arrivedCount: newCount,
          phase: allArrived ? 'in_progress' : 'gathering',
          currentSpeaker: allArrived ? state.standup.speakerQueue[0] : null,
        }
      };
    });
  },

  nextSpeaker: () => {
    set(state => {
      const queue = state.standup.speakerQueue.slice(1);
      if (queue.length === 0) {
        return { standup: { ...state.standup, phase: 'complete', currentSpeaker: null } };
      }
      return {
        standup: { ...state.standup, speakerQueue: queue, currentSpeaker: queue[0] }
      };
    });
  },

  connectGateway: (url) => {
    const ws = new WebSocket(url);
    ws.onmessage = (event) => {
      const msg: WSMessage = JSON.parse(event.data);
      const { updateAgent, agentArrived, nextSpeaker } = get();

      switch (msg.type) {
        case 'agent:status':
          updateAgent(msg.data.agentId, {
            state: msg.data.state,
            currentTask: msg.data.task
          });
          break;
        case 'standup:arrived':
          agentArrived(msg.data.agentId);
          break;
        case 'standup:speaker':
          // Update board with agent's report
          break;
      }
    };
  },
}));
```

---

## 4. A* Pathfinding

```typescript
interface PathNode {
  x: number;
  y: number;
  walkable: boolean;
  g: number;    // cost from start
  h: number;    // heuristic to end
  f: number;    // g + h
  parent: PathNode | null;
}

export function findPath(
  grid: PathNode[][],
  start: Position,
  end: Position
): Position[] {
  const openSet: PathNode[] = [];
  const closedSet = new Set<string>();

  const startNode = grid[start.y][start.x];
  startNode.g = 0;
  startNode.h = heuristic(start, end);
  startNode.f = startNode.h;
  openSet.push(startNode);

  while (openSet.length > 0) {
    // Get node with lowest f
    openSet.sort((a, b) => a.f - b.f);
    const current = openSet.shift()!;
    const key = `${current.x},${current.y}`;

    if (current.x === end.x && current.y === end.y) {
      return reconstructPath(current);
    }

    closedSet.add(key);

    // Check neighbors (4 directions)
    for (const [dx, dy] of [[0,1],[0,-1],[1,0],[-1,0]]) {
      const nx = current.x + dx;
      const ny = current.y + dy;

      if (nx < 0 || ny < 0 || ny >= grid.length || nx >= grid[0].length) continue;

      const neighbor = grid[ny][nx];
      if (!neighbor.walkable || closedSet.has(`${nx},${ny}`)) continue;

      const tentativeG = current.g + 1;
      if (tentativeG < neighbor.g || !openSet.includes(neighbor)) {
        neighbor.g = tentativeG;
        neighbor.h = heuristic({ x: nx, y: ny }, end);
        neighbor.f = neighbor.g + neighbor.h;
        neighbor.parent = current;

        if (!openSet.includes(neighbor)) openSet.push(neighbor);
      }
    }
  }

  return []; // no path found
}

function heuristic(a: Position, b: Position): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y); // Manhattan
}

function reconstructPath(node: PathNode): Position[] {
  const path: Position[] = [];
  let current: PathNode | null = node;
  while (current) {
    path.unshift({ x: current.x, y: current.y });
    current = current.parent;
  }
  return path;
}
```

---

## 5. Standup Board UI Component

```tsx
export function StandupBoard({ standup }: { standup: StandupProtocol }) {
  if (standup.phase === 'idle') return null;

  return (
    <div className="fixed inset-0 bg-black/80 z-50 p-8 font-mono">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-lg text-gray-400 tracking-wider">STANDUP BOARD</h2>
          <p className="text-sm text-gray-500">Team updates are being presented.</p>
        </div>
        <button className="text-gray-400 hover:text-white">✕ CLOSE</button>
      </div>

      <div className="flex gap-8 text-xs text-gray-500 mb-4">
        <span>Phase: {standup.phase}</span>
        <span>Speaker: {standup.currentSpeaker?.name || 'main'}</span>
        <span>Progress: {standup.arrivedCount}/{standup.totalExpected} arrived</span>
      </div>

      {/* Agent Cards Grid */}
      <div className="grid grid-cols-3 gap-4">
        {standup.board.cards.map(card => (
          <AgentStandupCard
            key={card.agent.id}
            card={card}
            isSpeaking={card.agent.id === standup.currentSpeaker?.id}
          />
        ))}
      </div>
    </div>
  );
}

function AgentStandupCard({ card, isSpeaking }: { card: AgentCard; isSpeaking: boolean }) {
  return (
    <div className={`bg-[#0d2137] border border-[#1a3a5c] rounded-lg p-4
      ${isSpeaking ? 'ring-2 ring-[#00d4aa]' : ''}`}>

      <div className="flex justify-between items-center mb-3">
        <div>
          <span className="text-xs text-gray-500 tracking-wider">PARTICIPANT</span>
          <h3 className="text-lg text-[#00d4aa] font-bold">{card.agent.name}</h3>
        </div>
        {isSpeaking && (
          <span className="bg-[#00d4aa] text-black text-xs px-2 py-1 rounded">
            SPEAKING
          </span>
        )}
      </div>

      {/* Current Task */}
      <div className="mb-3">
        <span className="text-xs text-gray-500 tracking-wider">CURRENT TASK</span>
        <p className="text-sm text-gray-300">{card.currentTask}</p>
      </div>

      {/* Recent Commits */}
      <div className="mb-3">
        <span className="text-xs text-gray-500 tracking-wider">RECENT COMMITS</span>
        <div className="space-y-1 mt-1">
          {card.recentCommits.map((commit, i) => (
            <div key={i} className="bg-[#0a1a2e] rounded p-2">
              <p className="text-sm text-gray-300">{commit.message}</p>
              <p className="text-xs text-gray-600">{commit.repo}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Active Tickets */}
      <div className="mb-3">
        <span className="text-xs text-gray-500 tracking-wider">ACTIVE TICKETS</span>
        <p className="text-sm text-gray-400">
          {card.activeTickets.length > 0
            ? card.activeTickets.map(t => t.title).join(', ')
            : 'No active Jira tickets.'}
        </p>
      </div>

      {/* Blockers */}
      <div className="mb-3">
        <span className="text-xs text-gray-500 tracking-wider">BLOCKERS</span>
        <p className="text-sm text-gray-400">
          {card.blockers.length > 0
            ? card.blockers.join(', ')
            : 'No blockers reported.'}
        </p>
      </div>

      {/* Sources */}
      <div>
        <span className="text-xs text-gray-500 tracking-wider">SOURCES</span>
        <div className="flex gap-2 mt-1">
          {card.sources.map(source => (
            <span key={source}
              className="bg-[#1a3a5c] text-xs text-gray-400 px-2 py-0.5 rounded">
              {source.toUpperCase()}
              {source === 'jira' && ' · JIRA IS DISABLED.'}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
```

---

## 6. Voice Control Integration

```typescript
// Voice Input (Web Speech API)
export function useVoiceInput() {
  const [isListening, setIsListening] = useState(false);

  const startListening = () => {
    const recognition = new (window.SpeechRecognition ||
      window.webkitSpeechRecognition)();
    recognition.continuous = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript;
      handleVoiceCommand(text);
    };

    recognition.start();
    setIsListening(true);
  };

  return { isListening, startListening };
}

function handleVoiceCommand(text: string) {
  const store = useOfficeStore.getState();

  if (text.toLowerCase().includes('start standup')) {
    store.startStandup();
  } else if (text.toLowerCase().includes('assign')) {
    // Parse: "assign [task] to [agent]"
    const match = text.match(/assign (.+) to (.+)/i);
    if (match) {
      store.assignTask(match[2].trim(), match[1].trim());
    }
  }
}

// Voice Output (TTS)
export async function agentSpeak(agent: Agent, text: string) {
  // Option 1: Browser TTS
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.0;
  speechSynthesis.speak(utterance);

  // Option 2: ElevenLabs API (higher quality)
  const response = await fetch('https://api.elevenlabs.io/v1/text-to-speech/VOICE_ID', {
    method: 'POST',
    headers: {
      'xi-api-key': process.env.ELEVENLABS_API_KEY!,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      text,
      model_id: 'eleven_multilingual_v2',
    }),
  });

  const audioBlob = await response.blob();
  const audio = new Audio(URL.createObjectURL(audioBlob));
  audio.play();
}
```

---

## 7. GitHub Integration

```typescript
// ดึง recent commits ของ agent (จาก GitHub username)
export async function getAgentCommits(
  githubUsername: string,
  repos: string[]
): Promise<Commit[]> {
  const commits: Commit[] = [];

  for (const repo of repos) {
    const res = await fetch(
      `https://api.github.com/repos/${repo}/commits?author=${githubUsername}&per_page=5`,
      { headers: { Authorization: `token ${process.env.GITHUB_TOKEN}` } }
    );
    const data = await res.json();

    commits.push(...data.map((c: any) => ({
      message: c.commit.message.split('\n')[0],
      repo,
      sha: c.sha.substring(0, 7),
      date: c.commit.author.date,
    })));
  }

  return commits.sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  ).slice(0, 5);
}
```
