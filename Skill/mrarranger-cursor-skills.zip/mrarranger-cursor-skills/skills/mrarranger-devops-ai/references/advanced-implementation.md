
### Claude API Integration

```python
from anthropic import Anthropic

class ClaudeIntegration:
    def __init__(self, api_key):
        """เชื่อมต่อ Claude API"""
        self.client = Anthropic(api_key=api_key)
        self.model = "claude-3-5-sonnet-20241022"

    def call_claude(self, prompt, system=None, max_tokens=2048):
        """เรียก Claude API"""
        message = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text

    def multi_turn_chat(self, messages):
        """สนทนา multi-turn"""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            messages=messages
        )
        return response.content[0].text
```

### OpenAI API Integration

```python
from openai import OpenAI

def setup_openai(api_key):
    """เชื่อมต่อ OpenAI"""
    return OpenAI(api_key=api_key)

def call_gpt(client, prompt, model="gpt-4", temperature=0.7):
    """เรียก GPT"""
    response = client.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

def call_gpt_with_functions(client, prompt, functions):
    """เรียก GPT ด้วย function calling"""
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        tools=[{"type": "function", "function": fn} for fn in functions]
    )
    return response
```

### Ollama Local Models

```python
import requests
import json

class OllamaIntegration:
    def __init__(self, base_url="http://localhost:11434"):
        """ใช้ Ollama สำหรับ local models"""
        self.base_url = base_url

    def generate(self, model, prompt, stream=False):
        """สร้างข้อความจาก local model"""
        response = requests.post(
            f"{self.base_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": stream}
        )
        return response.json()

    def list_models(self):
        """ดูรายชื่อ models ที่มี"""
        response = requests.get(f"{self.base_url}/api/tags")
        return response.json()
```

### OpenRouter Multi-Provider

```python
import openai

def use_openrouter(api_key, model="gpt-3.5-turbo"):
    """ใช้ OpenRouter สำหรับหลายผู้ให้บริการ"""
    client = openai.OpenAI(
        api_key=api_key,
        base_url="https://openrouter.io/api/v1"
    )

    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": "Hello!"}],
        extra_headers={"HTTP-Referer": "your-site-identifier"}
    )
    return response
```

---

## Fine-tuning | การปรับแต่งโมเดล

### LoRA | Low-Rank Adaptation

```python
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

def setup_lora_finetuning(model_name="mistral-7b"):
    """ตั้งค่า LoRA สำหรับ fine-tuning"""
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto"
    )

    lora_config = LoraConfig(
        r=8,  # rank
        lora_alpha=16,
        target_modules=["q_proj", "v_proj"],  # อะไหน่อยที่ฝึก
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )

    model = get_peft_model(model, lora_config)
    return model, tokenizer
```

### QLoRA | Quantized LoRA

```python
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, BitsAndBytesConfig, AutoTokenizer
import torch

def setup_qlora_finetuning(model_name="mistral-7b"):
    """ใช้ QLoRA สำหรับ memory-efficient fine-tuning"""
    # Quantize เป็น 4-bit
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        quantization_config=bnb_config,
        device_map="auto"
    )

    model = prepare_model_for_kbit_training(model)

    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "v_proj"],
        lora_dropout=0.05,
        bias="none"
    )

    model = get_peft_model(model, lora_config)
    return model, AutoTokenizer.from_pretrained(model_name)
```

### Dataset Preparation

```python
from datasets import Dataset, load_dataset
from transformers import DataCollatorForLanguageModeling

def prepare_training_data(file_path, tokenizer, max_length=512):
    """เตรียมข้อมูลสำหรับ fine-tuning"""

    # โหลดข้อมูล
    with open(file_path, 'r') as f:
        texts = [line.strip() for line in f]

    dataset = Dataset.from_dict({"text": texts})

    def tokenize_function(examples):
        return tokenizer(
            examples["text"],
            max_length=max_length,
            truncation=True,
            padding="max_length"
        )

    tokenized = dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=["text"]
    )

    return tokenized

def create_data_collator(tokenizer):
    """สร้าง collator สำหรับ batch processing"""
    return DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False
    )
```

---

## Prompt Engineering | วิศวกรรมพรอมต์

### System Prompts | ระบบพรอมต์

```python
def create_system_prompt(role, context, constraints):
    """สร้างระบบพรอมต์ที่มีประสิทธิภาพ"""
    return f"""You are {role}.

Context: {context}

Constraints:
{chr(10).join(f"- {c}" for c in constraints)}

Always:
1. Be clear and concise
2. Provide structured responses
3. Ask clarifying questions if needed"""
```

### Few-Shot Learning | การเรียนรู้จากตัวอย่างน้อย

```python
def few_shot_prompt(task_description, examples, query):
    """สร้างพรอมต์ few-shot"""
    prompt = f"Task: {task_description}\n\nExamples:\n"

    for i, (input_ex, output_ex) in enumerate(examples, 1):
        prompt += f"\nExample {i}:\nInput: {input_ex}\nOutput: {output_ex}\n"

    prompt += f"\nNow solve this:\nInput: {query}\nOutput:"
    return prompt
```

### Chain-of-Thought | ลูกโซ่ความคิด

```python
def cot_prompt(question):
    """ใช้ Chain-of-Thought เพื่อการให้เหตุผลที่ดีขึ้น"""
    return f"""{question}

Let's think step by step:
1. First, identify the key information
2. Break down the problem
3. Work through the logic
4. Verify the answer

Answer:"""
```

### Structured Output | เอาต์พุตแบบมีโครงสร้าง

```python
import json
from typing import Optional

def json_structured_prompt(task, schema):
    """บังคับให้ LLM ตอบในรูป JSON"""
    return f"""{task}

Please respond with ONLY valid JSON (no markdown, no extra text).
Schema:
{json.dumps(schema, indent=2)}

Response:"""

# ตัวอย่าง schema
entity_schema = {
    "type": "object",
    "properties": {
        "entities": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "type": {"type": "string"},
                    "confidence": {"type": "number"}
                }
            }
        }
    }
}
```

---


