# Monitoring & Observability - Detailed Guides & Examples

## Winston Logging Setup

```javascript
const winston = require('winston');

const logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

logger.info('user_login', {
  user_id: 123,
  email: 'john@example.com',
  ip: '192.168.1.1',
});

logger.error('auth_failed', {
  reason: 'invalid_password',
  attempt: 3,
  user_id: 123,
});
```

## Pino Logging Setup

```javascript
const pino = require('pino');

const logger = pino({
  timestamp: pino.stdTimeFunctions.isoTime,
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
    },
  },
});

logger.info({ user_id: 123 }, 'user_created');
logger.error({ error: err.message }, 'request_failed');
```

## Python JSON Logging

```python
import logging
import json

class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            'timestamp': self.formatTime(record),
            'level': record.levelname,
            'message': record.getMessage(),
            'service': 'my-service',
            **record.__dict__.get('extra', {})
        })

logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger.addHandler(handler)

# Usage
logger.info('user_login', extra={
    'user_id': 123,
    'email': 'john@example.com'
})
```

## Prometheus Metrics Format

```
# HELP http_requests_total Total HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET", status="200", endpoint="/api/users"} 10000
http_requests_total{method="POST", status="200", endpoint="/api/users"} 500
http_requests_total{method="GET", status="404", endpoint="/api/users"} 15

# HELP http_request_duration_ms Request duration
# TYPE http_request_duration_ms histogram
http_request_duration_ms_bucket{le="100"} 5000
http_request_duration_ms_bucket{le="500"} 9500
http_request_duration_ms_bucket{le="1000"} 10000

# HELP process_memory_bytes Memory usage
# TYPE process_memory_bytes gauge
process_memory_bytes 52428800
```

## prom-client Instrumentation

```javascript
const prometheus = require('prom-client');

// Create metrics
const httpRequestDuration = new prometheus.Histogram({
  name: 'http_request_duration_ms',
  help: 'Request duration in ms',
  labelNames: ['method', 'status', 'endpoint'],
  buckets: [100, 500, 1000, 2000, 5000],
});

const errorCounter = new prometheus.Counter({
  name: 'errors_total',
  help: 'Total errors',
  labelNames: ['error_type', 'service'],
});

// Record metrics
const start = Date.now();
try {
  // ... handle request
  httpRequestDuration
    .labels('GET', '200', '/api/users')
    .observe(Date.now() - start);
} catch (error) {
  errorCounter.labels(error.code, 'auth-service').inc();
}

// Expose metrics endpoint
app.get('/metrics', (req, res) => {
  res.set('Content-Type', prometheus.register.contentType);
  res.end(prometheus.register.metrics());
});
```

## OpenTelemetry Setup

```javascript
const { NodeTracerProvider } = require('@opentelemetry/node');
const { SimpleSpanProcessor } = require('@opentelemetry/tracing');
const { JaegerExporter } = require('@opentelemetry/exporter-jaeger');

// Create provider
const tracerProvider = new NodeTracerProvider();

// Configure Jaeger exporter
const jaegerExporter = new JaegerExporter({
  serviceName: 'my-service',
  host: 'jaeger',
  port: 6832,
});

tracerProvider.addSpanProcessor(new SimpleSpanProcessor(jaegerExporter));

// Get tracer
const tracer = tracerProvider.getTracer('app', '1.0.0');

// Create span
const span = tracer.startSpan('process_user');
span.setAttributes({
  'user_id': 123,
  'action': 'create',
});

// ... do work

span.end();
```

## Distributed Trace Context

```javascript
// Parent request
const parentSpan = tracer.startSpan('POST /api/users');

// Child span (database)
const dbSpan = tracer.startSpan('database_query', {
  parent: parentSpan,
});
dbSpan.setAttribute('query', 'INSERT INTO users...');
dbSpan.end();

// All spans linked by trace_id
// GET /api/users [trace-123]
//   ├─ database_query [span-1]
//   ├─ cache_update [span-2]
//   └─ send_email [span-3]
```

## Sentry Setup

```javascript
const Sentry = require('@sentry/node');

Sentry.init({
  dsn: 'https://key@sentry.io/project',
  tracesSampleRate: 0.1,  // 10% of requests
  integrations: [
    new Sentry.Integrations.Http({ tracing: true }),
    new Sentry.Integrations.OnUncaughtException(),
  ],
});

// Express middleware
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());

// Route error handling
app.get('/api/users', (req, res, next) => {
  try {
    // ... code
  } catch (error) {
    Sentry.captureException(error, {
      tags: {
        endpoint: '/api/users',
        method: 'GET',
      },
    });
    next(error);
  }
});

// Error handler middleware (last)
app.use(Sentry.Handlers.errorHandler());
```

## Datadog APM Setup

```javascript
// Must be at app start
const tracer = require('dd-trace').init({
  service: 'my-service',
  version: '1.0.0',
  env: 'production',
});

const express = require('express');
const app = express();

// Traces all Express routes
app.get('/api/users', (req, res) => {
  res.json([]);
});

// Auto-instruments:
// - HTTP requests
// - Database queries
// - Cache operations
// - External API calls
```

## Health Check Endpoint

```javascript
app.get('/health', (req, res) => {
  const health = {
    status: 'ok',
    database: isConnected ? 'ok' : 'error',
    cache: cacheReady ? 'ok' : 'error',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  };

  const status = Object.values(health).some(v => v === 'error') ? 503 : 200;
  res.status(status).json(health);
});

// Kuma checks this endpoint every minute
// Alerts on failure or slow response (>5s)
```

## Kubernetes Health Probes

```yaml
spec:
  containers:
  - name: app
    livenessProbe:
      httpGet:
        path: /health
        port: 3000
      initialDelaySeconds: 10
      periodSeconds: 10

    readinessProbe:
      httpGet:
        path: /ready
        port: 3000
      initialDelaySeconds: 5
      periodSeconds: 5
```

## PagerDuty Alert Trigger

```javascript
const axios = require('axios');

async function triggerAlert(service, message, severity = 'error') {
  const payload = {
    routing_key: process.env.PAGERDUTY_ROUTING_KEY,
    event_action: 'trigger',
    dedup_key: `${service}-${Date.now()}`,
    payload: {
      summary: message,
      severity: severity,
      source: service,
      timestamp: new Date().toISOString(),
    },
  };

  await axios.post('https://events.pagerduty.com/v2/enqueue', payload);
}

// Trigger alert
if (errorRate > 0.1) {
  triggerAlert('auth-service', 'High error rate detected', 'critical');
}
```

## Grafana PromQL Queries

```promql
# Response time p95
histogram_quantile(0.95, rate(http_request_duration_ms_bucket[5m]))

# Error rate percentage
rate(errors_total[5m]) / rate(requests_total[5m]) * 100

# Memory usage trend
rate(process_memory_bytes[5m])

# Database connection pool
pg_stat_activity_count
```

## Liveness Probe Implementation

```javascript
// Kubernetes will restart if returns 500
app.get('/live', (req, res) => {
  if (isAppCrashed) {
    return res.status(500).send('App crashed');
  }
  res.json({ status: 'alive' });
});
```

## Readiness Probe Implementation

```javascript
// Kubernetes will remove from load balancer if returns 500
app.get('/ready', (req, res) => {
  const checks = {
    database: isConnected,
    cache: cacheReady,
    externalApi: apiAccessible,
  };

  const allReady = Object.values(checks).every(v => v);
  const status = allReady ? 200 : 503;

  res.status(status).json(checks);
});
```

## Loki Configuration

```yaml
# promtail/config.yml
scrape_configs:
  - job_name: varlogs
    static_configs:
      - targets:
          - localhost
        labels:
          job: varlogs
          __path__: /var/log/*.log

# Loki receives logs
# Grafana queries with LogQL
# {service="auth"} | json | status="error"
```

## Log Sampling Strategy

```javascript
// Only send 10% of success logs
// Send 100% of error logs
if (error || Math.random() < 0.1) {
  logger.log({
    level: error ? 'error' : 'info',
    message: 'request_completed',
    ...data,
  });
}
```

## Incident Runbook Template

```markdown
# Incident: High Database Load

## Detection
- Alert: DB connection pool > 90%
- Monitor: Query time p95 > 5s

## Immediate (0-5 min)
1. Check current connections:
   SELECT COUNT(*) FROM pg_stat_activity;

2. Identify slow queries:
   SELECT query, calls, mean_time FROM pg_stat_statements
   ORDER BY mean_time DESC LIMIT 10;

## Short-term (5-30 min)
1. Kill long-running queries:
   SELECT pg_terminate_backend(pid) FROM pg_stat_activity
   WHERE state = 'active' AND duration > 300s;

2. Add connection pool capacity (if possible)

## Long-term (next day)
1. Analyze slow query logs
2. Add indexes if needed
3. Consider query optimization or archiving
4. Review capacity planning
```

## Postmortem Template

```markdown
# Postmortem: Database Outage (2024-03-15)

## Impact
- Service down: 15 minutes
- Users affected: ~5,000
- Revenue lost: ~$2,000

## Timeline
- 10:30 - Alert fired
- 10:32 - On-call engineer paged
- 10:35 - Root cause identified
- 10:45 - Service restored

## Root Cause
Database query N+1 problem in user search endpoint caused connection pool exhaustion.

## Immediate Actions
- Rolled back recent deployment
- Optimized problematic query

## Preventive Actions
1. Add automatic query analysis in PR review
2. Increase alert threshold from 80% to 90%
3. Add load testing to CI/CD
4. Schedule quarterly capacity review

## Blameless Culture
This incident was not caused by human error but by missing monitoring.
We'll improve detection, not blame individuals.
```

## SLO Monitoring Queries

```promql
# Success rate (for 99.9% availability SLO)
rate(requests_total{status=~"2.."}[30d]) / rate(requests_total[30d])

# Latency SLO (p95 < 200ms)
histogram_quantile(0.95, rate(http_request_duration_ms_bucket[30d])) < 200

# Error budget calculation
errors_allowed = (1 - 0.999) * total_requests
errors_actual = errors_total
error_budget_remaining = errors_allowed - errors_actual
```

## Error Grouping Patterns

Errors automatically grouped by:
- Error type + message
- Stack trace similarity
- Source file + line

Sentry dashboard shows:
- Error frequency over time
- Affected users
- Browser/OS/version
- Full stack trace
