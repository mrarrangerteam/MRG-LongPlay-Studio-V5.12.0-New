---
name: mrarranger-web3
description: "ผู้ช่วย Web3 และ Blockchain Development ครอบคลุม Solidity, Smart Contracts, DeFi, NFTs, Security, Gas Optimization, Frontend Web3, Solana, และ Account Abstraction"
commands:
  - "/web3"
  - "/solidity"
  - "/nft"
  - "/defi"
  - "/wallet"
  - "/deploy-web3"
  - "/audit-web3"
  - "/solana"
---

# Web3 & Blockchain Development Assistant

สวัสดีค่ะ! ผมคือ Claude ที่เชี่ยวชาญด้าน Web3 และ Blockchain Development 🚀

## 📚 ความรู้เชี่ยวชาญหลัก

### 1️⃣ Blockchain Fundamentals (พื้นฐาน Blockchain)
- **Consensus Mechanisms**: Proof of Work (PoW), Proof of Stake (PoS), DPoS
- **Block Structure**: Header, Transactions, Merkle Tree, Nonce
- **Transactions**: UTXO vs Account Model, Mempool, Gas concept
- **Wallets**: Hot/Cold wallets, HD wallets, Key derivation (BIP32/BIP39/BIP44)
- **Mining & Staking**: Block rewards, Validator sets, Slashing conditions
- **Distributed Ledger**: Immutability, State management, Fork handling

### 2️⃣ Solidity Smart Contracts (สัญญาอัจฉริยะ)
```solidity
// Data Types & Variables
pragma solidity ^0.8.20;

contract DataTypes {
    // Value types
    bool flag = true;
    uint256 balance = 1000 ether;
    address owner = msg.sender;
    bytes32 hash = keccak256(abi.encodePacked("data"));


    // Reference types
    uint256[] dynamicArray;
    uint256[5] fixedArray;
    mapping(address => uint256) balances;

    struct User {
        string name;
        uint256 age;
        bool active;
    }

    // State variables storage slots
    mapping(address => uint256) public userBalances; // slot 0
    uint256 public totalSupply; // slot 1

    // Functions & Modifiers
    function transfer(address to, uint256 amount) public payable {
        require(amount > 0, "Amount must be positive");
        balances[to] += amount;
        emit Transfer(msg.sender, to, amount);
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    function withdraw() public onlyOwner {
        (bool success,) = owner.call{value: address(this).balance}("");
        require(success, "Transfer failed");
    }

    // Events
    event Transfer(address indexed from, address indexed to, uint256 amount);
    event Approval(address indexed owner, address indexed spender, uint256 amount);

    // Inheritance & Abstract Contracts
    function _beforeTransfer(address from, address to, uint256 amount) internal virtual {}
}
```

### 3️⃣ Smart Contract Patterns

**ERC-20 (Fungible Tokens)**
```solidity
interface IERC20 {
    function transfer(address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function allowance(address owner, address spender) external view returns (uint256);
}

contract MyToken is IERC20 {
    mapping(address => uint256) balances;
    mapping(address => mapping(address => uint256)) allowances;

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balances[msg.sender] >= amount, "Insufficient balance");
        balances[msg.sender] -= amount;
        balances[to] += amount;
        return true;
    }
}
```

**ERC-721 (NFTs)**
```solidity
interface IERC721 {
    function ownerOf(uint256 tokenId) external view returns (address);
    function transferFrom(address from, address to, uint256 tokenId) external;
    function safeTransferFrom(address from, address to, uint256 tokenId) external;
    function approve(address to, uint256 tokenId) external;
    function setApprovalForAll(address operator, bool approved) external;
}

contract MyNFT is IERC721 {
    mapping(uint256 => address) tokenOwners;
    mapping(uint256 => address) tokenApprovals;
    mapping(address => uint256) balances;

    uint256 nextTokenId = 1;

    function mint(address to) external returns (uint256) {
        uint256 tokenId = nextTokenId++;
        tokenOwners[tokenId] = to;
        balances[to]++;
        return tokenId;
    }
}
```

**Proxy Pattern (Upgradeable Contracts)**
```solidity
// Implementation contract
contract Implementation {
    uint256 public value;

    function setValue(uint256 _value) public {
        value = _value;
    }
}

// Proxy with UUPS
contract Proxy {
    address private implementation;

    fallback() external payable {
        address impl = implementation;
        assembly {
            calldatacopy(0, 0, calldatasize())
            let result := delegatecall(gas(), impl, 0, calldatasize(), 0, 0)
            returndatacopy(0, 0, returndatasize())
            switch result
            case 0 { revert(0, returndatasize()) }
            default { return(0, returndatasize()) }
        }
    }
}
```

### 4️⃣ Development Tools (เครื่องมือพัฒนา)
- **Hardhat**: Task runners, scripts, plugins, local network
- **Foundry (Forge/Cast)**: Fast testing, fuzz testing, contract verification
- **Remix IDE**: Browser-based development, debugging
- **OpenZeppelin Contracts**: Standard library (ERC20, ERC721, AccessControl, etc.)
- **ethers.js**: Web3 library for JavaScript
- **Truffle**: Development framework (legacy but still used)

### 5️⃣ Smart Contract Testing
```solidity
// Hardhat Test Example
import { expect } from "chai";
import { ethers } from "hardhat";

describe("Token", function () {
    it("Should transfer tokens", async function () {
        const [owner, addr1] = await ethers.getSigners();
        const Token = await ethers.getContractFactory("Token");
        const token = await Token.deploy();

        await token.transfer(addr1.address, 100);
        expect(await token.balanceOf(addr1.address)).to.equal(100);
    });
});

// Foundry Fuzz Testing
function testTransferFuzz(address to, uint256 amount) public {
    vm.assume(to != address(0));
    vm.assume(amount > 0 && amount <= maxSupply);

    token.transfer(to, amount);
    assertEq(token.balanceOf(to), amount);
}

// Fork Testing (simulate mainnet state)
function testUniswapV3Swap() public {
    uint256 mainnetFork = vm.createFork(MAINNET_RPC_URL);
    vm.selectFork(mainnetFork);

    // Test against real mainnet state
}
```

### 6️⃣ DeFi Concepts (แนวคิด DeFi)
- **AMM (Automated Market Maker)**: Uniswap V2/V3, Curve
- **Lending Protocols**: Aave, Compound (Collateral, Liquidation, Flash loans)
- **Staking**: Validator staking, liquid staking (Lido), LP staking
- **Yield Farming**: LP rewards, governance tokens, composability
- **Liquidity Pools**: Constant product formula (x*y=k), Concentrated liquidity
- **Flash Loans**: Atomic borrowing, arbitrage, liquidation opportunities

```solidity
// Simple AMM Pool
contract AMM {
    uint256 public reserveA;
    uint256 public reserveB;

    function swap(uint256 amountIn, address tokenIn) external returns (uint256) {
        uint256 amountOut = (amountIn * reserveB) / (reserveA + amountIn);
        reserveA += amountIn;
        reserveB -= amountOut;
        return amountOut;
    }

    // Flash loan
    function flashLoan(uint256 amount, bytes calldata data) external {
        uint256 balanceBefore = tokenA.balanceOf(address(this));
        tokenA.transfer(msg.sender, amount);

        IFlashLoanReceiver(msg.sender).executeOperation(amount, data);

        require(tokenA.balanceOf(address(this)) >= balanceBefore, "Loan not repaid");
    }
}
```

### 7️⃣ Frontend Web3 (Web3 Frontend)
```typescript
// ethers.js v6 Example
import { ethers } from "ethers";

const provider = new ethers.JsonRpcProvider("https://eth.llamarpc.com");
const signer = provider.getSigner();

// Contract interaction
const contract = new ethers.Contract(
    "0x...",
    ABI,
    signer
);

const balance = await contract.balanceOf(userAddress);
const tx = await contract.transfer(recipient, amount);
await tx.wait();

// wagmi Example (React hooks for Web3)
import { useContractRead, useContractWrite } from "wagmi";

function BalanceComponent() {
    const { data: balance } = useContractRead({
        address: TOKEN_ADDRESS,
        abi: ERC20_ABI,
        functionName: "balanceOf",
        args: [userAddress],
    });

    const { write: transfer } = useContractWrite({
        address: TOKEN_ADDRESS,
        abi: ERC20_ABI,
        functionName: "transfer",
    });

    return <div>Balance: {balance?.toString()}</div>;
}

// Wallet Connection with RainbowKit
import { RainbowKitProvider, ConnectButton } from "@rainbow-me/rainbowkit";

export function App() {
    return (
        <RainbowKitProvider>
            <ConnectButton />
        </RainbowKitProvider>
    );
}
```

### 8️⃣ IPFS & Decentralized Storage
- **IPFS**: Distributed file storage, content addressing
- **Pinata**: IPFS pinning service, gateway
- **Arweave**: Permanent storage, blockweave consensus
- **Filecoin**: Decentralized storage market

```typescript
// IPFS Upload via Pinata
import FormData from "form-data";
import fs from "fs";
import axios from "axios";

async function uploadToIPFS(filePath: string) {
    const form = new FormData();
    form.append("file", fs.createReadStream(filePath));

    const response = await axios.post(
        "https://api.pinata.cloud/pinning/pinFileToIPFS",
        form,
        {
            headers: {
                pinata_api_key: process.env.PINATA_KEY,
                pinata_secret_api_key: process.env.PINATA_SECRET,
            },
        }
    );

    return `ipfs://${response.data.IpfsHash}`;
}

// NFT Metadata stored on IPFS


## 📚 Reference Files | ไฟล์อ้างอิง

For detailed implementations and advanced patterns, see:

- **defi-and-advanced.md**: Advanced techniques and detailed examples

