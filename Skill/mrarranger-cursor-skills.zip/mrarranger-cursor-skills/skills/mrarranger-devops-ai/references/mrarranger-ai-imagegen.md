---
name: mrarranger-ai-imagegen
description: |
  MRARRANGER AI Image Generation - ระบบสร้างภาพด้วย Code (SVG, Canvas, HTML/CSS, Chart.js, D3)
  สร้าง Posters, Banners, Social Graphics, Infographics, Charts, Diagrams โดยไม่ต้องใช้ AI Image Generator
  Claude สร้าง visual output เป็น PNG/SVG/PDF ได้โดยตรงจาก code
  ใช้เมื่อ: (1) สร้าง poster/banner (2) ทำ infographic (3) สร้าง chart/graph (4) ทำ social media graphics
  (5) สร้าง diagram (6) ออกแบบ logo/icon (7) data visualization (8) สร้าง event poster
  (9) อะไรก็ตามที่ต้องการ visual output ที่ไม่ใช่ photo
  Commands: /image [type], /poster [event], /banner [product], /infographic [data], /chart [type], /diagram [type], /social [platform]
---

# MRARRANGER AI Image Generation

สร้าง visual content ด้วย code - ไม่ต้องพึ่ง Midjourney/DALL-E สำหรับ graphics ที่ไม่ใช่ภาพถ่าย

## Quick Commands

```
/image [type]           → สร้าง image (poster, banner, card)
/poster [event]         → Event poster
/banner [product]       → Product/web banner
/infographic [data]     → Data infographic
/chart [type]           → Chart/graph (bar, line, pie, etc.)
/diagram [type]         → Technical diagram
/social [platform]      → Social media graphic (IG, FB, Twitter)
/logo [brand]           → Logo/icon design
```

---

## Output Formats & Methods

### Decision: ใช้ method ไหน?
```
NEED                         → METHOD
Simple shapes, icons, logos  → SVG (scalable, lightweight)
Complex graphics, posters    → HTML/CSS → screenshot → PNG
Charts & data viz           → Chart.js / D3.js / Recharts
Diagrams & flowcharts       → Mermaid / SVG
Infographics               → HTML/CSS (most flexible)
Social media templates      → HTML/CSS → PNG
PDF output                  → HTML → PDF (puppeteer/playwright)
React components            → JSX with inline styles
```

---

## SVG Generation

### Basic SVG Template
```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630">
  <defs>
    <!-- Gradients -->
    <linearGradient id="bg-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea"/>
      <stop offset="100%" style="stop-color:#764ba2"/>
    </linearGradient>
    <!-- Filters -->
    <filter id="shadow">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-opacity="0.3"/>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="100%" height="100%" fill="url(#bg-gradient)"/>

  <!-- Content -->
  <text x="600" y="280" text-anchor="middle"
        font-family="Arial, sans-serif" font-size="64" font-weight="bold" fill="white">
    Title Text
  </text>
  <text x="600" y="340" text-anchor="middle"
        font-family="Arial, sans-serif" font-size="24" fill="rgba(255,255,255,0.8)">
    Subtitle text here
  </text>

  <!-- Decorative shapes -->
  <circle cx="100" cy="100" r="60" fill="rgba(255,255,255,0.1)"/>
  <rect x="1000" y="400" width="120" height="120" rx="20"
        fill="rgba(255,255,255,0.1)" transform="rotate(15, 1060, 460)"/>
</svg>
```

### SVG Best Practices
```
- viewBox สำหรับ responsive sizing
- ใช้ defs สำหรับ reusable elements (gradients, filters, symbols)
- Text: ใช้ system fonts (Arial, Helvetica) ที่ render ได้ทุกที่
- Export: save เป็น .svg (vector) หรือ convert เป็น .png (raster)
```

---

## Social Media Sizes

```
PLATFORM        SIZE (px)       ASPECT RATIO
Instagram Post  1080 x 1080    1:1
Instagram Story 1080 x 1920    9:16
Facebook Post   1200 x 630     ~1.91:1
Twitter/X Post  1200 x 675     16:9
LinkedIn Post   1200 x 627     ~1.91:1
YouTube Thumb   1280 x 720     16:9
TikTok Cover    1080 x 1920    9:16
Pinterest Pin   1000 x 1500    2:3
OG Image        1200 x 630     ~1.91:1
```

---

## Poster Templates

### Event Poster (HTML → PNG)
```html
<div style="width: 1080px; height: 1920px; background: linear-gradient(135deg, #1a1a2e, #16213e);
     font-family: 'Arial', sans-serif; color: white; position: relative; overflow: hidden;">

  <!-- Decorative background -->
  <div style="position: absolute; top: -100px; right: -100px; width: 400px; height: 400px;
       border-radius: 50%; background: rgba(106, 60, 224, 0.3); filter: blur(80px);"></div>

  <!-- Content -->
  <div style="padding: 80px 60px; position: relative; z-index: 1;">
    <!-- Badge -->
    <div style="display: inline-block; background: #6c3ce0; padding: 8px 20px;
         border-radius: 20px; font-size: 14px; letter-spacing: 2px; text-transform: uppercase;">
      LIVE EVENT
    </div>

    <!-- Title -->
    <h1 style="font-size: 72px; font-weight: 800; line-height: 1.1; margin: 40px 0 20px;
         background: linear-gradient(to right, #a855f7, #06b6d4);
         -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
      Event Title<br>Goes Here
    </h1>

    <!-- Details -->
    <div style="font-size: 24px; color: rgba(255,255,255,0.7); margin-top: 40px;">
      <p>📅 March 20, 2026</p>
      <p>📍 Bangkok Convention Center</p>
      <p>🕐 18:00 - 22:00</p>
    </div>

    <!-- CTA -->
    <div style="position: absolute; bottom: 80px; left: 60px; right: 60px;">
      <div style="background: #6c3ce0; text-align: center; padding: 20px;
           border-radius: 16px; font-size: 20px; font-weight: 700;">
        REGISTER NOW — FREE
      </div>
    </div>
  </div>
</div>
```

---

## Chart Generation

### Chart.js Quick Reference
```javascript
// Bar Chart
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    datasets: [{
      label: 'Revenue (THB)',
      data: [12000, 19000, 15000, 25000, 22000],
      backgroundColor: '#6366f1',
      borderRadius: 8,
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { display: false },
      title: { display: true, text: 'Monthly Revenue', font: { size: 18 } }
    },
    scales: { y: { beginAtZero: true } }
  }
});

// Donut Chart
new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['Product A', 'Product B', 'Product C'],
    datasets: [{
      data: [45, 30, 25],
      backgroundColor: ['#6366f1', '#06b6d4', '#f97316'],
      borderWidth: 0,
    }]
  },
  options: {
    cutout: '65%',
    plugins: { legend: { position: 'bottom' } }
  }
});
```

---

## Infographic Layout Patterns

### Vertical Flow
```
┌─── Header/Title ───────────────────┐
│                                     │
├─── Section 1 ──────────────────────┤
│  Icon  │  Stats  │  Description    │
├─── Section 2 ──────────────────────┤
│  Icon  │  Stats  │  Description    │
├─── Section 3 ──────────────────────┤
│  Icon  │  Stats  │  Description    │
├─── Footer/CTA ────────────────────┤
└─────────────────────────────────────┘
```

### Comparison Layout
```
┌─── Title ──────────────────────────┐
│                                     │
│   OPTION A    vs    OPTION B       │
│  ┌─────────┐     ┌─────────┐      │
│  │ Feature1 │     │ Feature1 │     │
│  │ Feature2 │     │ Feature2 │     │
│  │ Feature3 │     │ Feature3 │     │
│  │ Price    │     │ Price    │     │
│  └─────────┘     └─────────┘      │
│                                     │
│   ★ Winner: Option A               │
└─────────────────────────────────────┘
```

---

## Color Palettes for Graphics

```css
/* Professional */
--chart-1: #6366f1; --chart-2: #06b6d4; --chart-3: #10b981;
--chart-4: #f59e0b; --chart-5: #ef4444; --chart-6: #8b5cf6;

/* Pastel */
--chart-1: #c4b5fd; --chart-2: #a5f3fc; --chart-3: #bbf7d0;
--chart-4: #fde68a; --chart-5: #fecaca; --chart-6: #e9d5ff;

/* Neon Dark */
--chart-1: #a855f7; --chart-2: #22d3ee; --chart-3: #4ade80;
--chart-4: #facc15; --chart-5: #f87171; --chart-6: #c084fc;
```

---

## Quality Checklist

```
□ Resolution เหมาะสมกับ platform (ดู Social Media Sizes)
□ Text อ่านได้ชัด (contrast, size)
□ ไม่มี text ถูกตัด (padding เพียงพอ)
□ Color palette consistent
□ Visual hierarchy ชัดเจน
□ Brand elements ครบ (logo, colors, fonts)
□ File size เหมาะสม (< 500KB for web)
□ Responsive (SVG/viewBox) ถ้าจำเป็น
```
