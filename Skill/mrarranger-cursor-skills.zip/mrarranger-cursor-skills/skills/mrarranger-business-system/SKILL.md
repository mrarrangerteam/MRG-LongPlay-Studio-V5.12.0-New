---
name: mrarranger-business-system
description: "MRARRANGER Business & System - รวม 20 Skills: Business (Proposals, Contracts, Invoices), Legal (Terms, Privacy, Compliance), Course Creation (Curriculum, LMS, Certification), Coordinator (Multi-team Production), Research (Competitor, Market, Trend, SWOT), Data (Database, ETL, Visualization), Data Analysis (Statistical, Insights), Life Planning (Goals, Habits, Productivity), Persona (Character Design, User Profiles), Brain (Decision Frameworks, Mental Models), Logic (System Design, Architecture), Prompt Engineering (500+ Mega Prompts), Guardian QC (5-Agent Quality Control), All-in-One (General Assistant), Ultimate Super AI (Advanced Reasoning), Automation (Workflow, n8n, Pabbly), OpenClaw (AI Agent Framework), Oracle Framework (Knowledge Management), BMAD Method (Dev Methodology). Commands: /business /legal /course /research /data /life /persona /brain /logic /prompt /qc /auto /n8n /oracle /bmad"
---

# MRARRANGER Business & System — 20 Skills Combined

> Routing table for business, research, life, and system skills

## SKILL ROUTING TABLE

| Trigger | Reference File | Use When |
|---------|---------------|----------|
| `/business` `/proposal` `/contract` | `references/mrarranger-business.md` | Business documents |
| `/legal` `/terms` `/privacy` | `references/mrarranger-legal.md` | Legal documents |
| `/course` `/curriculum` `/lms` | `references/mrarranger-course.md` | Course creation |
| `/coordinator` `/team` `/production` | `references/mrarranger-coordinator.md` | Multi-team coordination |
| `/research` `/competitor` `/market` `/swot` | `references/mrarranger-research.md` | Research & analysis |
| `/data` `/database` `/etl` | `references/mrarranger-data.md` | Data management |
| `/analyze` `/stats` `/insights` | `references/data-analysis.md` | Data analysis |
| `/life` `/goals` `/habits` | `references/mrarranger-life.md` | Life planning |
| `/persona` `/character` `/profile` | `references/mrarranger-persona.md` | Persona design |
| `/brain` `/decision` `/mental-model` | `references/mrarranger-brain.md` | Decision frameworks |
| `/logic` `/system-design` `/architecture` | `references/mrarranger-logic.md` | System design |
| `/prompt` `/mega-prompt` | `references/mrarranger-promptlib.md` | Prompt engineering |
| `/qc` `/quality` `/review` | `references/mrarranger-guardian-qc.md` | Quality control |
| `/all-in-one` | `references/mrarranger-all-in-one.md` | General assistant |
| `/super-ai` `/reasoning` | `references/mrarranger-ultimate-super-ai.md` | Advanced reasoning |
| `/auto` `/workflow` | `references/mrarranger-automation.md` | Workflow automation |
| `/n8n` `/pabbly` | `references/mrarranger-n8n.md` | n8n automation |
| `/openclaw` `/agent` | `references/openclaw.md` | AI agent framework |
| `/oracle` `/knowledge` | `references/oracle-framework.md` | Knowledge management |
| `/bmad` `/methodology` | `references/bmad-method.md` | BMAD dev methodology |
