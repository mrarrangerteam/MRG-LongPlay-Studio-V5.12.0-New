# mrarranger-data

**Source:** `/mnt/skills/user/mrarranger-data/SKILL.md`
**Size:** 10094 bytes

---

---
name: mrarranger-data
description: |
  ระบบวิเคราะห์ข้อมูลครบวงจร - Data Analysis, Visualization, Dashboard Design, Excel/Sheets Master, SQL, Data Cleaning
  สร้าง Insights จากข้อมูล พร้อม Dashboard และ Reports ระดับมืออาชีพ
  ใช้เมื่อ: (1) วิเคราะห์ข้อมูล (2) สร้าง Dashboard (3) Excel/Sheets formulas (4) Data Visualization (5) SQL Queries (6) Data Cleaning
  Commands: /analyze [data], /dashboard [kpis], /formula [task], /visualize [type], /sql [query], /clean [data]
---

# MRARRANGER Data Master

## Quick Commands

```
/analyze [data/question]    → วิเคราะห์ข้อมูล
/dashboard [kpis]           → ออกแบบ Dashboard
/formula [task]             → สร้าง Excel/Sheets Formula
/visualize [chart-type]     → แนะนำ Visualization
/sql [question]             → เขียน SQL Query
/clean [data-issue]         → วิธี Clean Data
/pivot [dimensions]         → สร้าง Pivot Table
```

## Data Analysis Framework

### Analysis Process
```
1. QUESTION: ถามคำถามที่ชัด
   - อะไรคือสิ่งที่อยากรู้?
   - ทำไมถึงสำคัญ?
   - ใครจะใช้ insights นี้?

2. DATA: เข้าใจข้อมูล
   - มีข้อมูลอะไรบ้าง?
   - คุณภาพข้อมูลเป็นยังไง?
   - ต้อง clean อะไร?

3. ANALYZE: วิเคราะห์
   - Descriptive: เกิดอะไรขึ้น?
   - Diagnostic: ทำไมถึงเกิด?
   - Predictive: จะเกิดอะไรต่อ?
   - Prescriptive: ควรทำอะไร?

4. VISUALIZE: แสดงผล
   - เลือก chart ที่เหมาะ
   - เน้น insight สำคัญ

5. COMMUNICATE: สื่อสาร
   - Storytelling with data
   - Actionable recommendations
```

## Excel/Sheets Formulas

### Lookup & Reference
```excel
VLOOKUP:
=VLOOKUP(lookup_value, table, col_index, FALSE)

HLOOKUP:
=HLOOKUP(lookup_value, table, row_index, FALSE)

INDEX + MATCH (Better than VLOOKUP):
=INDEX(return_range, MATCH(lookup_value, lookup_range, 0))

XLOOKUP (Excel 365):
=XLOOKUP(lookup_value, lookup_array, return_array)
```

### Conditional
```excel
IF:
=IF(condition, true_value, false_value)

Nested IF:
=IF(A1>90,"A",IF(A1>80,"B",IF(A1>70,"C","F")))

IFS (Multiple conditions):
=IFS(A1>90,"A",A1>80,"B",A1>70,"C",TRUE,"F")

SWITCH:
=SWITCH(A1,1,"One",2,"Two",3,"Three","Other")
```

### Aggregation
```excel
SUMIF:
=SUMIF(range, criteria, sum_range)

SUMIFS (Multiple criteria):
=SUMIFS(sum_range, criteria_range1, criteria1, criteria_range2, criteria2)

COUNTIF / COUNTIFS:
=COUNTIF(range, criteria)
=COUNTIFS(range1, criteria1, range2, criteria2)

AVERAGEIF / AVERAGEIFS:
=AVERAGEIF(range, criteria, average_range)
```

### Text Functions
```excel
CONCATENATE / CONCAT:
=CONCAT(A1, " ", B1)
=A1 & " " & B1

LEFT / RIGHT / MID:
=LEFT(text, num_chars)
=RIGHT(text, num_chars)
=MID(text, start, num_chars)

TRIM (Remove extra spaces):
=TRIM(A1)

CLEAN (Remove non-printable):
=CLEAN(A1)

TEXT (Format numbers):
=TEXT(A1, "0.00%")
=TEXT(A1, "dd/mm/yyyy")
```

### Date Functions
```excel
TODAY / NOW:
=TODAY()
=NOW()

DATEDIF:
=DATEDIF(start_date, end_date, "Y")  // Years
=DATEDIF(start_date, end_date, "M")  // Months
=DATEDIF(start_date, end_date, "D")  // Days

EOMONTH (End of month):
=EOMONTH(date, months)

NETWORKDAYS (Working days):
=NETWORKDAYS(start, end, holidays)
```

### Array Formulas (Excel 365)
```excel
FILTER:
=FILTER(data, criteria)
=FILTER(A:C, B:B>100)

SORT:
=SORT(data, sort_index, order)

UNIQUE:
=UNIQUE(range)

SEQUENCE:
=SEQUENCE(rows, cols, start, step)
```

### Advanced Formulas
```excel
Dynamic Range:
=OFFSET(start, rows, cols, height, width)

Percentage of Total:
=A1/SUM($A$1:$A$10)

Running Total:
=SUM($A$1:A1)

Rank:
=RANK(A1, $A$1:$A$10, 0)

Percentile:
=PERCENTILE(range, k)
```

## Data Visualization

### Chart Selection Guide

```
Comparison:
├── Few categories → Bar Chart
├── Many categories → Horizontal Bar
├── Over time → Line Chart
└── Part of whole → Pie (≤5 items) / Treemap

Trend:
├── Single series → Line Chart
├── Multiple series → Multi-line / Area
└── Cyclical patterns → Line with annotations

Distribution:
├── Single variable → Histogram / Box Plot
├── Two variables → Scatter Plot
└── Categories → Violin Plot

Composition:
├── Static → Pie / Donut / Treemap
├── Over time → Stacked Bar / Area
└── Hierarchical → Treemap / Sunburst

Relationship:
├── Two variables → Scatter Plot
├── Three variables → Bubble Chart
└── Correlation → Heatmap
```

### Visualization Best Practices
```
DO:
✓ Start Y-axis at 0 (for bars)
✓ Use consistent colors
✓ Label clearly
✓ Show data source
✓ Use appropriate scale

DON'T:
✗ 3D charts (distorts)
✗ Too many colors
✗ Pie chart > 5 slices
✗ Dual Y-axis (confusing)
✗ Truncate axis to exaggerate
```

## Dashboard Design

### Dashboard Layout
```
┌─────────────────────────────────────┐
│  Title / Date Range / Filters       │
├─────────┬─────────┬─────────┬──────┤
│  KPI 1  │  KPI 2  │  KPI 3  │ KPI 4│
├─────────┴─────────┼─────────┴──────┤
│                   │                 │
│   Main Chart      │  Secondary      │
│   (Trend/Time)    │  Chart          │
│                   │                 │
├───────────────────┼─────────────────┤
│                   │                 │
│  Detail Table     │  Breakdown      │
│                   │  Chart          │
│                   │                 │
└───────────────────┴─────────────────┘
```

### KPI Card Design
```
┌─────────────────┐
│ [Icon] KPI Name │
│                 │
│    $1.2M        │  ← Main Value
│    ▲ 12.5%      │  ← Change
│ vs Last Month   │  ← Comparison
└─────────────────┘
```

### Dashboard Types

```
Executive Dashboard:
- High-level KPIs
- Trends
- Alerts/Exceptions
- Goal vs Actual

Operational Dashboard:
- Real-time metrics
- Status indicators
- Detailed breakdowns
- Action items

Analytical Dashboard:
- Deep-dive data
- Filters/Slicers
- Drill-down capability
- Export options
```

## SQL Essentials

### Basic Queries
```sql
-- Select
SELECT column1, column2
FROM table
WHERE condition
ORDER BY column1 DESC
LIMIT 100;

-- Aggregate
SELECT category, 
       COUNT(*) as count,
       SUM(amount) as total,
       AVG(amount) as average
FROM sales
GROUP BY category
HAVING COUNT(*) > 10;

-- Join
SELECT a.*, b.name
FROM orders a
LEFT JOIN customers b ON a.customer_id = b.id;
```

### Window Functions
```sql
-- Running Total
SELECT date, amount,
       SUM(amount) OVER (ORDER BY date) as running_total
FROM sales;

-- Rank
SELECT product, sales,
       RANK() OVER (ORDER BY sales DESC) as rank
FROM products;

-- Moving Average
SELECT date, value,
       AVG(value) OVER (
         ORDER BY date 
         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ) as moving_avg_7d
FROM metrics;
```

### Common Patterns
```sql
-- Year-over-Year
SELECT 
  YEAR(date) as year,
  SUM(amount) as total,
  LAG(SUM(amount)) OVER (ORDER BY YEAR(date)) as prev_year,
  (SUM(amount) - LAG(SUM(amount)) OVER (ORDER BY YEAR(date))) 
    / LAG(SUM(amount)) OVER (ORDER BY YEAR(date)) * 100 as yoy_growth
FROM sales
GROUP BY YEAR(date);

-- Cohort Analysis
SELECT 
  first_purchase_month,
  DATEDIFF(MONTH, first_purchase_month, purchase_month) as month_number,
  COUNT(DISTINCT customer_id) as customers
FROM (
  SELECT customer_id, purchase_month,
         MIN(purchase_month) OVER (PARTITION BY customer_id) as first_purchase_month
  FROM purchases
) t
GROUP BY first_purchase_month, month_number;
```

## Data Cleaning

### Common Issues & Solutions
```
Missing Values:
- Delete rows (if few)
- Fill with mean/median/mode
- Forward/backward fill (time series)
- Flag as missing category

Duplicates:
- Identify: GROUP BY + HAVING COUNT > 1
- Remove: DISTINCT or ROW_NUMBER()

Outliers:
- IQR method: < Q1-1.5*IQR or > Q3+1.5*IQR
- Z-score: |z| > 3
- Cap at percentiles (1st, 99th)

Inconsistent Format:
- Dates: Convert to standard format
- Text: TRIM, UPPER/LOWER, CLEAN
- Numbers: Remove currency symbols, commas
```

### Data Quality Checklist
```
□ No duplicates
□ No missing critical values
□ Dates are valid
□ Numbers are in range
□ Categories are consistent
□ No leading/trailing spaces
□ Encoding is correct
□ Data types are correct
```

## Metrics & KPIs

### Business Metrics
```
Revenue:
- Total Revenue
- Revenue per Customer (ARPU)
- Revenue Growth Rate
- Revenue by Channel/Product

Customers:
- Customer Acquisition Cost (CAC)
- Customer Lifetime Value (CLV)
- Churn Rate
- Net Promoter Score (NPS)

Operations:
- Conversion Rate
- Average Order Value (AOV)
- Inventory Turnover
- On-time Delivery Rate
```

### SaaS Metrics
```
MRR (Monthly Recurring Revenue)
ARR (Annual Recurring Revenue)
Churn Rate = Lost Customers / Total Customers
LTV = ARPU × Customer Lifetime
CAC = Marketing Spend / New Customers
LTV:CAC Ratio (Target: > 3:1)
```

## File References

- `references/formulas.md` - Excel/Sheets formula library
- `references/sql-patterns.md` - SQL query patterns
- `references/dashboard-templates.md` - Dashboard layout templates