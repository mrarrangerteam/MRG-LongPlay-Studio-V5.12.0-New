# mrarranger-legal

**Source:** `/mnt/skills/user/mrarranger-legal/SKILL.md`
**Size:** 11157 bytes

---

---
name: mrarranger-legal
description: |
  ระบบเอกสารกฎหมายพื้นฐาน - สัญญา, NDA, MOU, Terms & Conditions, Privacy Policy, Freelance Agreements
  Template พร้อมใช้ ปรับแต่งได้ตามความต้องการ (ไม่ใช่คำปรึกษาทางกฎหมาย)
  ใช้เมื่อ: (1) ร่างสัญญาพื้นฐาน (2) สร้าง NDA (3) เขียน Terms & Conditions (4) สร้าง Privacy Policy (5) สัญญา Freelance
  Commands: /contract [type], /nda [parties], /terms [business], /privacy [app/web], /mou [parties], /agreement [type]
---

# MRARRANGER Legal Templates

## ⚠️ Important Disclaimer

```
เอกสารในที่นี้เป็น TEMPLATE พื้นฐานเพื่อการศึกษาและเริ่มต้นเท่านั้น
ไม่ใช่คำปรึกษาทางกฎหมาย

แนะนำ:
- ปรึกษาทนายความก่อนใช้งานจริง
- ปรับแต่งให้เหมาะกับสถานการณ์เฉพาะ
- ตรวจสอบกฎหมายท้องถิ่นที่เกี่ยวข้อง
```

## Quick Commands

```
/contract [type]       → Template สัญญา
/nda [type]            → Non-Disclosure Agreement
/terms [business]      → Terms & Conditions
/privacy [type]        → Privacy Policy
/mou [parties]         → Memorandum of Understanding
/agreement [type]      → ข้อตกลงทั่วไป
/checklist [doc-type]  → Checklist ก่อนเซ็น
```

## Document Types

### 1. NDA (Non-Disclosure Agreement)

**Unilateral NDA** - ฝ่ายเดียวเปิดเผยข้อมูล
```
ใช้เมื่อ: 
- จ้างงาน freelancer
- Pitch idea ให้นักลงทุน
- ให้ vendor เข้าถึงข้อมูล
```

**Mutual NDA** - ทั้งสองฝ่ายเปิดเผยข้อมูล
```
ใช้เมื่อ:
- Partnership discussions
- M&A negotiations
- Joint ventures
```

**Key Elements:**
```
1. Definition of Confidential Information
   - อะไรคือข้อมูลลับ
   - อะไรไม่รวม (public info, prior knowledge)

2. Obligations
   - ห้ามเปิดเผย
   - ห้ามใช้เพื่อประโยชน์ตัวเอง
   - ต้องปกป้องอย่างเหมาะสม

3. Duration
   - ระยะเวลาของข้อตกลง
   - ระยะเวลาที่ต้องรักษาความลับ

4. Exceptions
   - คำสั่งศาล
   - ข้อมูลที่เป็นสาธารณะแล้ว

5. Remedies
   - การชดเชยเมื่อละเมิด
```

### 2. Service Agreement / สัญญาจ้างงาน

**Key Elements:**
```
1. Scope of Work
   - งานที่ต้องทำ (ละเอียด)
   - Deliverables
   - Timeline / Milestones

2. Payment Terms
   - ค่าตอบแทน
   - Payment schedule
   - วิธีการจ่าย

3. Intellectual Property
   - ใครเป็นเจ้าของผลงาน
   - License ที่ให้

4. Confidentiality
   - การรักษาความลับ

5. Termination
   - เงื่อนไขการยกเลิก
   - Notice period
   - การจ่ายเงินเมื่อยกเลิก

6. Liability
   - ข้อจำกัดความรับผิด
   - Indemnification
```

### 3. Terms & Conditions

**For Website/App:**
```
1. Acceptance of Terms
   - การยอมรับข้อกำหนด

2. User Accounts
   - การสร้าง/ใช้งานบัญชี
   - ความรับผิดชอบของผู้ใช้

3. Acceptable Use
   - สิ่งที่ทำได้/ไม่ได้
   - Prohibited activities

4. Intellectual Property
   - ลิขสิทธิ์ของ content
   - User-generated content

5. Disclaimers
   - ไม่รับประกัน
   - ข้อจำกัดความรับผิด

6. Termination
   - สิทธิ์ในการระงับบัญชี

7. Governing Law
   - กฎหมายที่ใช้บังคับ

8. Changes to Terms
   - การแก้ไขข้อกำหนด
```

### 4. Privacy Policy

**PDPA Compliance (Thailand):**
```
1. ข้อมูลที่เก็บ
   - Personal data ที่เก็บรวบรวม
   - Sensitive data (ถ้ามี)

2. วัตถุประสงค์
   - ทำไมต้องเก็บ
   - จะใช้ทำอะไร

3. ฐานทางกฎหมาย
   - ความยินยอม
   - สัญญา
   - หน้าที่ตามกฎหมาย
   - ประโยชน์โดยชอบ

4. การเปิดเผย
   - เปิดเผยให้ใคร
   - เมื่อไหร่

5. ระยะเวลาเก็บ
   - เก็บนานแค่ไหน

6. สิทธิ์ของเจ้าของข้อมูล
   - เข้าถึง
   - แก้ไข
   - ลบ
   - ระงับการใช้
   - ถอนความยินยอม

7. การรักษาความปลอดภัย
   - มาตรการป้องกัน

8. การติดต่อ DPO
   - ช่องทางติดต่อ
```

### 5. MOU (Memorandum of Understanding)

**Key Elements:**
```
1. Parties
   - ใครบ้างที่เกี่ยวข้อง

2. Purpose
   - วัตถุประสงค์ของความร่วมมือ

3. Scope
   - ขอบเขตความร่วมมือ

4. Responsibilities
   - หน้าที่แต่ละฝ่าย

5. Duration
   - ระยะเวลา

6. Non-binding Clause (ถ้าต้องการ)
   - ระบุว่าไม่มีผลผูกพันทางกฎหมาย

7. Confidentiality
   - การรักษาความลับ

8. Next Steps
   - ขั้นตอนต่อไป
```

### 6. Freelance/Contractor Agreement

**Key Elements:**
```
1. Independent Contractor Status
   - ไม่ใช่ลูกจ้าง
   - รับผิดชอบภาษีเอง

2. Scope of Services
   - งานที่ต้องทำ
   - Deliverables

3. Compensation
   - ค่าตอบแทน
   - Invoice process
   - Payment terms

4. Work Product Ownership
   - IP ownership
   - Work for hire

5. Confidentiality
   - NDA provisions

6. Non-compete (ถ้ามี)
   - ข้อห้ามทำงานกับคู่แข่ง

7. Insurance
   - ความรับผิดชอบด้านประกัน

8. Termination
   - Notice period
   - Kill fee (ถ้ามี)
```

## Contract Checklist

### Before Signing Any Contract:
```
□ อ่านทุกข้อ ไม่ข้าม
□ เข้าใจทุกคำศัพท์
□ ตรวจสอบวันที่และตัวเลข
□ ชื่อและที่อยู่ถูกต้อง
□ Scope of work ชัดเจน
□ Payment terms ชัดเจน
□ Termination clause ยอมรับได้
□ Liability limits เหมาะสม
□ IP ownership ชัดเจน
□ Governing law เหมาะสม
□ มี witness/notary ถ้าจำเป็น
□ เก็บสำเนาไว้
```

## Common Legal Terms

```
Indemnification: การชดใช้ค่าเสียหาย
Liability: ความรับผิด
Force Majeure: เหตุสุดวิสัย
Governing Law: กฎหมายที่ใช้บังคับ
Jurisdiction: เขตอำนาจศาล
Severability: ถ้าข้อใดเป็นโมฆะ ข้ออื่นยังใช้ได้
Amendment: การแก้ไขเพิ่มเติม
Waiver: การสละสิทธิ์
Assignment: การโอนสิทธิ์
Confidential Information: ข้อมูลลับ
Intellectual Property: ทรัพย์สินทางปัญญา
Non-compete: ข้อห้ามแข่งขัน
Non-solicitation: ข้อห้ามชักชวนลูกค้า/พนักงาน
```

## Red Flags to Watch

```
⚠️ ระวังข้อสัญญาเหล่านี้:

- Unlimited liability (รับผิดไม่จำกัด)
- Auto-renewal without notice
- Non-compete ที่กว้างเกินไป
- IP assignment ที่ไม่เป็นธรรม
- Unilateral termination (ยกเลิกฝ่ายเดียว)
- Excessive penalties
- ไม่มี Force majeure clause
- Governing law ที่ไม่เหมาะสม
- ไม่มี limitation period
```

## Quick Templates

### Simple NDA (Thai)
```
สัญญารักษาความลับ

ทำที่ _______________
วันที่ _______________

ระหว่าง
ฝ่ายเปิดเผยข้อมูล: _______________ ("ฝ่าย ก")
ฝ่ายรับข้อมูล: _______________ ("ฝ่าย ข")

ทั้งสองฝ่ายตกลงดังนี้:

1. "ข้อมูลลับ" หมายถึง ข้อมูลทางธุรกิจ เทคนิค การเงิน 
   ที่ฝ่าย ก เปิดเผยแก่ฝ่าย ข

2. ฝ่าย ข ตกลงที่จะ:
   - ไม่เปิดเผยข้อมูลลับแก่บุคคลภายนอก
   - ใช้ข้อมูลลับเฉพาะวัตถุประสงค์ที่ตกลงกัน
   - ปกป้องข้อมูลลับอย่างเหมาะสม

3. ข้อยกเว้น: ข้อมูลที่เป็นสาธารณะ, ฝ่าย ข รู้อยู่แล้ว,
   ได้รับจากบุคคลอื่นโดยชอบ

4. ระยะเวลา: ___ ปี นับจากวันลงนาม

5. การละเมิด: ฝ่ายที่ละเมิดต้องชดใช้ค่าเสียหาย

ลงชื่อ _______________  ลงชื่อ _______________
       (ฝ่าย ก)               (ฝ่าย ข)
```

## File References

- `references/contract-templates.md` - Template สัญญาเต็มรูปแบบ
- `references/legal-terms-th.md` - คำศัพท์กฎหมายไทย-อังกฤษ
- `references/pdpa-guide.md` - PDPA compliance guide