# mrarranger-n8n

**Source:** `/mnt/skills/user/mrarranger-n8n/SKILL.md`
**Size:** 11737 bytes

---

---
name: "mrarranger-n8n"
description: "MRARRANGER Workflow Automation - ระบบสร้าง Automated Workflows ด้วย n8n และ Pabbly Connect ครบวงจร รองรับ Music Production Pipeline, Content Distribution, Sales Funnel Automation, Analytics Collection, และ Multi-Platform Publishing ใช้เมื่อ: (1) สร้าง Workflow Automation (2) เชื่อมต่อ AI Tools (3) Auto-publish Content (4) Sales Funnel Automation (5) Data Collection Pipeline (6) Batch Processing Automation Commands: /n8n /pabbly /workflow /webhook /trigger /automate"
---

# MRARRANGER n8n & Pabbly Automation

ระบบสร้าง Workflow Automation สำหรับ Creator Economy ด้วย n8n (Open Source) และ Pabbly Connect (Lifetime Deal)

## Quick Commands

| Command | การใช้งาน | ตัวอย่าง |
|---------|----------|----------|
| `/n8n [workflow-type]` | สร้าง n8n workflow | `/n8n music-pipeline` |
| `/pabbly [workflow-type]` | สร้าง Pabbly workflow | `/pabbly content-distribute` |
| `/workflow [trigger] → [actions]` | ออกแบบ workflow | `/workflow new-video → youtube,tiktok,ig` |
| `/webhook [platform]` | สร้าง webhook config | `/webhook suno` |
| `/trigger [event]` | กำหนด trigger | `/trigger daily-9am` |
| `/automate [process]` | Automate กระบวนการ | `/automate sales-funnel` |

## Platform Comparison

| Feature | n8n | Pabbly Connect |
|---------|-----|----------------|
| **ราคา** | ฟรี (Self-hosted) | Lifetime Deal (~$249) |
| **Hosting** | Self-hosted / Cloud | Cloud Only |
| **Workflows** | Unlimited | Unlimited |
| **Tasks/Month** | Unlimited | ตาม Plan |
| **Complexity** | สูง (Flexible) | กลาง (Easy) |
| **Best For** | Tech-savvy, Custom needs | Non-tech, Quick setup |

## Workflow Categories

### 🎵 1. Music Production Pipeline
```
Suno Generate → Download → YouTube Upload → Social Posts → Analytics Track
```
- ดู `references/n8n-workflows.md#music-pipeline`
- ดู `references/pabbly-workflows.md#music-pipeline`

### 📹 2. Video Publishing Automation
```
Video Ready → Compress → Multi-Platform Upload → Schedule Posts → Notify
```
- YouTube, TikTok, Instagram Reels, Facebook
- Auto-generate thumbnails
- Cross-platform scheduling

### 📝 3. Content Distribution
```
Content Created → Format Convert → Platform Adapt → Schedule → Publish
```
- Blog → Social snippets
- Long-form → Short-form
- Single → Multi-platform

### 💰 4. Sales Funnel Automation
```
Lead Capture → Email Sequence → Follow-up → CRM Update → Analytics
```
- Landing page integration
- Email automation
- Payment processing
- Customer journey tracking

### 📊 5. Analytics & Reporting
```
Daily Fetch → Aggregate → Calculate → Dashboard Update → Report Send
```
- YouTube Analytics
- Social Media Metrics
- Revenue Tracking
- Performance Reports

### 🔄 6. Batch Processing
```
Mass Input → Process Each → Quality Check → Sort → Distribute
```
- Mass music generation
- Bulk content creation
- Multi-file processing

## n8n Quick Start

### Installation (Self-Hosted)
```bash
# Docker (แนะนำ)
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n

# NPM
npm install n8n -g
n8n start
```

### Core Concepts
| Concept | คำอธิบาย |
|---------|----------|
| **Trigger** | จุดเริ่มต้น workflow (Webhook, Schedule, Event) |
| **Node** | แต่ละ action/step ใน workflow |
| **Connection** | เชื่อม nodes เข้าด้วยกัน |
| **Credential** | API keys, tokens สำหรับ services |
| **Expression** | Dynamic values `{{ $json.field }}` |

### Essential Nodes
| Node | ใช้สำหรับ |
|------|----------|
| **Webhook** | รับ incoming requests |
| **HTTP Request** | เรียก APIs |
| **IF** | Conditional logic |
| **Switch** | Multiple conditions |
| **Set** | Transform data |
| **Function** | Custom JavaScript |
| **Google Sheets** | Read/Write spreadsheets |
| **Gmail** | Send emails |

## Pabbly Connect Quick Start

### Core Concepts
| Concept | คำอธิบาย |
|---------|----------|
| **Trigger** | App ที่เริ่มต้น workflow |
| **Action** | สิ่งที่ทำหลัง trigger |
| **Filter** | กรองข้อมูล |
| **Router** | แยก path ตาม condition |
| **Iterator** | Loop through items |
| **Delay** | หน่วงเวลา |

### Popular Integrations
- Google Sheets, Drive, Gmail
- Facebook, Instagram, YouTube
- Stripe, PayPal, Razorpay
- Mailchimp, ConvertKit
- Slack, Discord, Telegram
- WordPress, Webflow
- Notion, Airtable

## Webhook Configurations

### Universal Webhook Template
```json
{
  "endpoint": "https://your-domain.com/webhook/[workflow-id]",
  "method": "POST",
  "headers": {
    "Content-Type": "application/json",
    "Authorization": "Bearer [token]"
  },
  "payload": {
    "event": "[event-type]",
    "data": {},
    "timestamp": "[ISO-8601]"
  }
}
```

### Security Best Practices
1. ใช้ HTTPS เสมอ
2. Validate webhook signatures
3. ใช้ secret tokens
4. Rate limiting
5. IP whitelisting (ถ้าเป็นไปได้)

## MRARRANGER Integration Map

```
┌─────────────────────────────────────────────────────────────────┐
│                    MRARRANGER ECOSYSTEM                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐     │
│  │  Music  │    │ Visual  │    │ Content │    │  Sales  │     │
│  │ (Suno)  │    │ (Video) │    │ (Blog)  │    │ (Funnel)│     │
│  └────┬────┘    └────┬────┘    └────┬────┘    └────┬────┘     │
│       │              │              │              │           │
│       └──────────────┼──────────────┼──────────────┘           │
│                      │              │                          │
│                      ▼              ▼                          │
│              ┌───────────────────────────┐                     │
│              │   n8n / Pabbly Connect    │                     │
│              │   (Workflow Automation)   │                     │
│              └───────────────────────────┘                     │
│                      │              │                          │
│       ┌──────────────┼──────────────┼──────────────┐           │
│       │              │              │              │           │
│       ▼              ▼              ▼              ▼           │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐     │
│  │ YouTube │    │ TikTok  │    │  Email  │    │   CRM   │     │
│  └─────────┘    └─────────┘    └─────────┘    └─────────┘     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Common Triggers

### Time-Based
| Trigger | n8n | Pabbly |
|---------|-----|--------|
| Every hour | Cron: `0 * * * *` | Schedule: Hourly |
| Daily 9 AM | Cron: `0 9 * * *` | Schedule: Daily |
| Weekly Monday | Cron: `0 9 * * 1` | Schedule: Weekly |
| Monthly 1st | Cron: `0 9 1 * *` | Schedule: Monthly |

### Event-Based
| Event | Trigger Source |
|-------|----------------|
| New YouTube video | YouTube API / RSS |
| Form submission | Webhook |
| Payment received | Stripe/PayPal webhook |
| New email | Gmail trigger |
| File uploaded | Google Drive trigger |

## Error Handling

### n8n Error Workflow
```javascript
// On error, send notification
{
  "nodes": [
    {
      "name": "Error Trigger",
      "type": "n8n-nodes-base.errorTrigger"
    },
    {
      "name": "Send Alert",
      "type": "n8n-nodes-base.telegram",
      "parameters": {
        "text": "⚠️ Workflow Error: {{ $json.workflow.name }}\nError: {{ $json.error.message }}"
      }
    }
  ]
}
```

### Retry Strategy
| Scenario | Strategy |
|----------|----------|
| API rate limit | Exponential backoff |
| Network error | Retry 3x with delay |
| Auth error | Refresh token & retry |
| Data error | Log & skip item |

## Best Practices

### 1. Workflow Design
- แยก workflow ย่อยๆ (modular)
- ใช้ Sub-workflows สำหรับ reusable logic
- ตั้งชื่อ nodes ให้ชัดเจน
- Document workflow purpose

### 2. Data Handling
- Validate input data
- Transform data early
- Handle null/empty values
- Log important steps

### 3. Performance
- ใช้ batch processing
- Avoid unnecessary API calls
- Cache when possible
- Monitor execution time

### 4. Security
- Never hardcode credentials
- Use environment variables
- Encrypt sensitive data
- Regular credential rotation

## Reference Files

| ไฟล์ | เนื้อหา |
|------|--------|
| `references/n8n-workflows.md` | n8n workflow templates พร้อมใช้ |
| `references/pabbly-workflows.md` | Pabbly workflow templates |
| `references/webhook-configs.md` | Webhook configurations ทุก platform |
| `references/integration-recipes.md` | Integration recipes สำหรับ MRARRANGER |

## Quick Recipes

### Recipe 1: Auto-Post New Music to Social
```
Trigger: Suno webhook (song complete)
→ Download MP3
→ Generate cover image (AI)
→ Upload YouTube (as audio visualizer)
→ Post to Instagram (Reels)
→ Post to TikTok
→ Tweet announcement
→ Update tracking sheet
```

### Recipe 2: Daily Content Pipeline
```
Trigger: Daily 6 AM
→ Fetch scheduled content
→ Generate variations
→ Post to each platform
→ Track engagement
→ Send daily report
```

### Recipe 3: Sales Funnel Automation
```
Trigger: New lead (form submit)
→ Add to email list
→ Send welcome email
→ Wait 1 day
→ Send value email
→ Wait 2 days
→ Send offer email
→ Track conversions
→ Update CRM
```

## Troubleshooting

| ปัญหา | สาเหตุ | แก้ไข |
|-------|--------|-------|
| Webhook ไม่ทำงาน | URL ผิด / Server down | ตรวจ URL, ตรวจ logs |
| API error 401 | Token expired | Refresh credentials |
| API error 429 | Rate limited | Add delay, reduce calls |
| Data missing | Field name ผิด | Check JSON path |
| Workflow stuck | Infinite loop | Add exit condition |