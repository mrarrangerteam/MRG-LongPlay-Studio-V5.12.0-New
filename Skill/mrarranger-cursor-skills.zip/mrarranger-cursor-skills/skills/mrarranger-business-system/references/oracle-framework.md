# oracle-framework

**Source:** `/mnt/skills/user/oracle-framework/SKILL.md`
**Size:** 13730 bytes

---

---
name: oracle-framework
description: |
  🔮 Oracle Framework Advanced - ระบบจัดการความรู้และ workflow สำหรับ Claude Code
  
  Philosophy: "The Oracle Keeps the Human Human"
  - Nothing is Deleted (append-only, timestamp = truth)
  - Patterns Over Intentions (สังเกตพฤติกรรม ไม่ใช่คำพูด)
  - External Brain, Not Command (สะท้อนความจริง ไม่สั่งการ)
  
  ใช้เมื่อ:
  (1) เริ่ม session ใหม่ - /recap
  (2) จบ session - /rrr สร้าง retrospective
  (3) บันทึกความรู้เร็ว - /snapshot
  (4) ค้นหาโปรเจค - /trace
  (5) จัดการ focus state
  (6) ทำงาน Multi-Agent (MAW)
  (7) ประสานกับ MRARRANGER skills
  
  Commands: /recap /rrr /snapshot /trace /focus
  
  Structure: ψ/ (Psi) 7 Pillars
  - active/ (งานปัจจุบัน, gitignored)
  - inbox/ (การสื่อสาร, focus.md)
  - memory/ (ฐานความรู้)
  - writing/ (แบบร่างบล็อก)
  - lab/ (การทดลอง)
  - incubate/ (โปรเจคแอคทีฟ - symlinks)
  - learn/ (สื่อการเรียนรู้ - symlinks)
---

# 🔮 Oracle Framework Advanced

> "The Oracle Keeps the Human Human"
> — Nat Weerawan, Soul Brews Studio

## Quick Start

```bash
# 1. Setup ψ/ structure
./scripts/setup-oracle.sh

# 2. Load aliases (optional)
source scripts/oracle-aliases.sh

# 3. Start session
/recap

# 4. End session
/rrr
```

---

## 📜 Philosophy - The Three Pillars

| Pillar | หลักการ | ในทางปฏิบัติ |
|--------|---------|-------------|
| **Nothing is Deleted** | Append-only, timestamp = truth | `echo >> file` ไม่ใช่ `rm file` |
| **Patterns Over Intentions** | สังเกตพฤติกรรมจริง | Activity logs, git history |
| **External Brain, Not Command** | สะท้อนความจริง ไม่สั่งการ | Inform, don't dictate |

> 📖 อ่านเพิ่มเติม: `references/philosophy-deep-dive.md`

---

## 🏗️ ψ/ (Psi) Structure - 7 Pillars

```
ψ/
├── active/          # 📝 งานปัจจุบัน (gitignored)
├── inbox/           # 📬 การสื่อสาร, focus.md, handoff/
├── memory/          # 🧠 ฐานความรู้
│   ├── retrospectives/   # จาก /rrr
│   ├── learnings/        # จาก /snapshot
│   └── logs/             # activity.log
├── writing/         # ✍️ แบบร่างบล็อก
├── lab/             # 🧪 การทดลอง
├── incubate/        # 🌱 โปรเจคแอคทีฟ (symlinks)
└── learn/           # 📚 สื่อการเรียนรู้ (symlinks)
```

| Directory | Purpose | Git Status |
|-----------|---------|------------|
| `active/` | งานที่กำลังทำ, drafts | gitignored |
| `inbox/` | focus.md, handoff files | tracked |
| `memory/` | retrospectives, learnings, logs | tracked |
| `writing/` | blog drafts → published | tracked |
| `lab/` | experiments, prototypes | tracked |
| `incubate/` | symlinks to active projects | tracked |
| `learn/` | symlinks to learning resources | tracked |

---

## ⚡ Essential Commands

### `/recap` - เริ่ม Session

```
ใช้ทุกครั้งที่เริ่ม session ใหม่

จะทำ:
1. อ่าน ψ/inbox/focus.md
2. ดู handoff files ล่าสุด
3. สรุป context จาก retrospectives
4. แสดงสถานะปัจจุบัน

Output:
- Current focus state
- Last session summary
- Pending tasks
- Recommended next actions
```

### `/rrr` - จบ Session (Retrospective)

```
ใช้ทุกครั้งที่จบ session

จะทำ:
1. สร้าง retrospective file
2. บันทึก decisions, learnings
3. Update focus.md → completed
4. สร้าง handoff ถ้าจำเป็น

Output location:
ψ/memory/retrospectives/YYYY-MM-DD_HH-MM.md
```

### `/snapshot` - บันทึกความรู้เร็ว

```
ใช้เมื่อเรียนรู้สิ่งใหม่, ค้นพบ insight

Format:
/snapshot "หัวข้อ"
/snapshot "วิธีแก้ bug X ด้วย Y"

Output location:
ψ/memory/learnings/YYYY-MM-DD_topic.md
```

### `/trace [name]` - ค้นหาโปรเจค

```
ใช้เมื่อต้องการหาโปรเจคหรือไฟล์

Format:
/trace myproject
/trace "component name"

จะค้นหาใน:
1. ψ/incubate/ (symlinks)
2. ghq repositories
3. Recent git activity
```

> 📖 รายละเอียดเพิ่มเติม: `references/commands.md`

---

## 🎯 Focus States

```markdown
# ψ/inbox/focus.md

STATE: working
TASK: Implement feature X
SINCE: 14:30
```

| State | ความหมาย | เมื่อไหร่ใช้ |
|-------|----------|-------------|
| `idle` | ไม่มีงาน | เริ่มต้น, พัก |
| `working` | ทำงานปกติ | งานทั่วไป |
| `focusing` | Deep work | ห้ามรบกวน |
| `pending` | รอ input | รอคนอื่น |
| `completed` | งานเสร็จ | หลัง /rrr |

---

## 🤖 Subagents

Oracle Framework ใช้ subagents เพื่อแบ่งงาน:

| Subagent | Model | Purpose | Use When |
|----------|-------|---------|----------|
| `context-finder` | Haiku | ค้นหาเร็ว | หา context |
| `oracle-keeper` | Opus | ตรวจ mission | ตัดสินใจสำคัญ |
| `security-scanner` | Haiku | ตรวจ secrets | ก่อน commit |
| `repo-auditor` | Haiku | ตรวจขนาดไฟล์ | ก่อน push |
| `coder` | Opus | เขียนโค้ด | งาน complex |
| `executor` | Haiku | รัน bash | งาน simple |

### Delegation Pattern

```
# ถูกต้อง ✅
Task "ค้นหา API endpoint" → context-finder (Haiku, เร็ว, ถูก)
Task "ออกแบบ architecture" → oracle-keeper (Opus, ฉลาด)

# ไม่ถูกต้อง ❌
Task ง่ายๆ → Opus (แพงเกินไป)
Task ซับซ้อน → Haiku (ไม่เก่งพอ)
```

> 📖 รายละเอียดเพิ่มเติม: `references/subagents.md`

---

## 🛡️ Safety Rules

### ❌ NEVER Do

| Action | Why |
|--------|-----|
| `git push --force` | ลบ history ของคนอื่น |
| `git checkout --force` | ลบ uncommitted changes |
| `git clean -fd` without asking | ลบ untracked files |
| Direct push to main | ต้องผ่าน PR |
| Auto-merge PRs | ต้อง human review |
| Commit secrets | Security breach |

### ✅ ALWAYS Do

| Action | How |
|--------|-----|
| Create feature branch | `git checkout -b feature/x` |
| Small, focused commits | หนึ่ง commit หนึ่งเรื่อง |
| Write clear commit messages | `type: description` |
| Ask before destructive ops | Confirm with human |
| Run security scan | Before commit |
| Create PR for review | ไม่ merge เอง |

---

## 🔄 Session Workflow

### Start Session

```bash
# 1. Load context
/recap

# 2. Check focus
cat ψ/inbox/focus.md

# 3. Update focus
oracle-focus working "Task description"
# or manually edit ψ/inbox/focus.md

# 4. Log start
oracle-log working "Started: task description"
```

### During Session

```bash
# Log important activities
oracle-log completed "Finished: subtask"
oracle-log blocked "Waiting for: X"

# Capture insights
/snapshot "Learned: how to do Y"
```

### End Session

```bash
# 1. Create retrospective
/rrr

# 2. Focus auto-updates to 'completed'

# 3. Create handoff if needed
# (ถ้างานยังไม่เสร็จ จะสร้าง handoff อัตโนมัติ)
```

---

## 🔗 Git Workflow

### Feature Development

```bash
# 1. Start from main
git checkout main
git pull --rebase

# 2. Create feature branch
git checkout -b feature/my-feature

# 3. Work and commit
git add .
git commit -m "feat: add new feature"

# 4. Push and create PR
git push -u origin feature/my-feature
gh pr create --fill

# 5. Wait for human review
# ❌ ห้าม merge เอง
```

### Commit Message Format

```
type: description

Types:
- feat: new feature
- fix: bug fix
- docs: documentation
- style: formatting
- refactor: code restructure
- test: add tests
- chore: maintenance
```

---

## 🤝 Multi-Agent Workflow (MAW)

ใช้หลาย Claude instances ทำงานพร้อมกัน:

```
┌──────────────┐
│ Orchestrator │
│   (Human)    │
└──────┬───────┘
       │
   ┌───┼───┐
   │   │   │
   ▼   ▼   ▼
┌───┐ ┌───┐ ┌───┐
│ A │ │ B │ │ C │
└─┬─┘ └─┬─┘ └─┬─┘
  │     │     │
  └─────┼─────┘
        │
   Git Worktrees
```

### Setup MAW

```bash
# Create worktrees
git worktree add ../agent-a feature/backend
git worktree add ../agent-b feature/testing
git worktree add ../agent-c feature/frontend

# Assign each Claude to a worktree
```

### Coordination

- ใช้ `ψ/inbox/shared/status.md` เป็น status board
- Update ทุก 30 นาที
- Human merge ทุกครั้ง

> 📖 รายละเอียดเพิ่มเติม: `references/maw-workflow.md`

---

## 🔗 MRARRANGER Integration

Oracle ทำงานร่วมกับ MRARRANGER skills:

```
Oracle                    MRARRANGER
──────                    ──────────
/rrr (retrospective)  →   /blog (publish learnings)
/snapshot (insight)   →   /thread (share on social)
Research complete     →   /content (document)
```

### Example Pipeline

```
1. /snapshot "AI Music insight"     # Oracle
2. /blog "AI Music Guide"           # mrarranger-content
3. /thread [from blog]              # mrarranger-social
4. /seo "ai music thailand"         # mrarranger-seo
5. oracle-log completed "Published" # Oracle
```

> 📖 รายละเอียดเพิ่มเติม: `references/mrarranger-integration.md`

---

## 📂 Files & Templates

### Scripts

| File | Purpose | Usage |
|------|---------|-------|
| `scripts/setup-oracle.sh` | สร้าง ψ/ structure | `./scripts/setup-oracle.sh` |
| `scripts/oracle-aliases.sh` | Shell aliases | `source scripts/oracle-aliases.sh` |
| `scripts/pre-commit.sh` | Security hook | Copy to `.git/hooks/` |

### Templates

| File | Purpose | Generated By |
|------|---------|--------------|
| `templates/retrospective.md` | Session retrospective | `/rrr` |
| `templates/snapshot.md` | Quick learning | `/snapshot` |
| `templates/handoff.md` | Context handoff | Auto when needed |

---

## 🎯 Quick Reference

### Shell Aliases (after sourcing)

```bash
# Navigation
psi           # cd ψ
psi-memory    # cd ψ/memory
psi-inbox     # cd ψ/inbox

# Oracle functions
oracle-focus [state] [task]    # Update focus
oracle-log [state] [desc]      # Log activity
oracle-snapshot [title]        # Quick snapshot
oracle-activity [n]            # View recent logs
oracle-check                   # Verify setup

# Git aliases (safe)
gs   # git status
gd   # git diff
gl   # git log --oneline -20
gco  # git checkout
gcob # git checkout -b

# Oracle git functions
oracle-feature [name]   # Start feature branch
oracle-pr               # Create PR
oracle-commit [type] [msg]  # Conventional commit
oracle-scan             # Security scan
```

---

## ⚠️ Common Mistakes

| Mistake | Problem | Solution |
|---------|---------|----------|
| ลืม /recap | ไม่มี context | ทำทุกครั้งที่เริ่ม |
| ลืม /rrr | สูญเสีย learnings | ทำทุกครั้งที่จบ |
| Push to main | ข้าม review | ใช้ feature branch + PR |
| Force push | ลบ history | ห้ามทำเด็ดขาด |
| ไม่ update focus | ไม่รู้สถานะ | Update ทุกครั้งที่เปลี่ยน |
| ไม่ใช้ symlinks | Duplicate repos | ghq + symlink |

---

## 📚 References

| File | Content |
|------|---------|
| `references/commands.md` | Command details |
| `references/subagents.md` | Subagent patterns |
| `references/maw-workflow.md` | Multi-Agent Workflow |
| `references/mrarranger-integration.md` | MRARRANGER integration |
| `references/philosophy-deep-dive.md` | Philosophy explanation |

---

## 🔗 External Resources

- [Oracle Framework Advanced](https://github.com/Soul-Brews-Studio/oracle-framework-advanced)
- [Soul Brews Studio](https://github.com/Soul-Brews-Studio)
- [Nat Weerawan Subscribers](https://www.facebook.com/groups/natweerawan)

---

## 🚀 Getting Started Checklist

- [ ] Run `./scripts/setup-oracle.sh`
- [ ] Source `scripts/oracle-aliases.sh` (add to .bashrc/.zshrc)
- [ ] Copy `scripts/pre-commit.sh` to `.git/hooks/pre-commit`
- [ ] Run `oracle-check` to verify setup
- [ ] Start first session with `/recap`
- [ ] End session with `/rrr`

---

*"The Oracle Keeps the Human Human."*

*Version 2.0 - Enhanced Edition*
*Based on Oracle Framework Advanced by Nat Weerawan*