# mrarranger-business

**Source:** `/mnt/skills/user/mrarranger-business/SKILL.md`
**Size:** 6067 bytes

---

---
name: "mrarranger-business"
description: "MRARRANGER Business Documents - สร้างเอกสารธุรกิจครบวงจร (Proposal, Invoice, Contract, Report, Pitch Deck). ใช้เมื่อ (1) เขียน Proposal (2) สร้าง Invoice (3) ร่าง Contract (4) ทำ Report (5) สร้าง Pitch Deck outline. Commands /proposal /invoice /contract /report /pitch /brief"
---

# MRARRANGER Business Documents

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/proposal [โปรเจค]` | Proposal | Full proposal document |
| `/invoice [รายละเอียด]` | Invoice | Invoice พร้อมใช้ |
| `/contract [ประเภท]` | Contract | Contract template |
| `/report [หัวข้อ]` | Report | Professional report |
| `/pitch [ธุรกิจ]` | Pitch Deck | Slide outline + content |
| `/brief [โปรเจค]` | Project Brief | Brief document |

## Document Templates

### Proposal Structure
```
1. COVER PAGE
   - โลโก้/ชื่อบริษัท
   - ชื่อโปรเจค
   - วันที่
   - เตรียมให้: [ชื่อลูกค้า]

2. EXECUTIVE SUMMARY (1 หน้า)
   - สรุปปัญหา
   - Solution ที่เสนอ
   - Key benefits
   - Investment overview

3. UNDERSTANDING (1-2 หน้า)
   - Current situation
   - Challenges
   - Goals

4. PROPOSED SOLUTION (2-3 หน้า)
   - Approach
   - Methodology
   - Deliverables
   - Timeline

5. TEAM/CREDENTIALS (1 หน้า)
   - Team members
   - Relevant experience
   - Case studies

6. INVESTMENT (1 หน้า)
   - Pricing breakdown
   - Payment terms
   - What's included

7. NEXT STEPS
   - How to proceed
   - Contact info
   - Validity period

8. APPENDIX (optional)
   - Portfolio
   - Testimonials
   - Terms & Conditions
```

### Invoice Template
```
╔════════════════════════════════════════╗
║           INVOICE                      ║
╠════════════════════════════════════════╣
║ From: [Your Company]                   ║
║ To: [Client Name]                      ║
║ Invoice #: INV-[YYYY]-[XXX]           ║
║ Date: [Date]                           ║
║ Due Date: [Date + Terms]               ║
╠════════════════════════════════════════╣
║ Description          Qty    Rate   Amt ║
║ ─────────────────────────────────────  ║
║ [Item 1]             1      X,XXX  X,XXX║
║ [Item 2]             1      X,XXX  X,XXX║
╠════════════════════════════════════════╣
║                      Subtotal: XX,XXX  ║
║                      VAT (7%): X,XXX   ║
║                      TOTAL: XX,XXX THB ║
╠════════════════════════════════════════╣
║ Payment: [Bank Details]                ║
║ Terms: [Net 30 / Due on Receipt]       ║
╚════════════════════════════════════════╝
```

### Contract Essentials
```
1. PARTIES
   - Full legal names
   - Addresses
   - Contact info

2. SCOPE OF WORK
   - Detailed deliverables
   - Timeline
   - Milestones

3. COMPENSATION
   - Total amount
   - Payment schedule
   - Late payment terms

4. INTELLECTUAL PROPERTY
   - Who owns what
   - Usage rights
   - License terms

5. CONFIDENTIALITY
   - What's confidential
   - Duration
   - Exceptions

6. TERMINATION
   - How to end
   - Notice period
   - Refund policy

7. LIABILITY
   - Limitations
   - Indemnification

8. GENERAL
   - Governing law
   - Dispute resolution
   - Amendments

9. SIGNATURES
   - Both parties
   - Date
   - Witness (if needed)
```

### Report Structure
```
1. TITLE PAGE
2. EXECUTIVE SUMMARY
3. TABLE OF CONTENTS
4. INTRODUCTION
   - Background
   - Objectives
   - Methodology
5. FINDINGS
   - Data/Analysis
   - Key insights
6. RECOMMENDATIONS
7. CONCLUSION
8. APPENDICES
```

### Pitch Deck (10-12 Slides)
```
Slide 1: Title + Tagline
Slide 2: Problem (Pain point)
Slide 3: Solution (Your product)
Slide 4: Market Size (TAM/SAM/SOM)
Slide 5: Business Model (How you make money)
Slide 6: Traction (Proof it works)
Slide 7: Competition (Why you win)
Slide 8: Team (Why you'll succeed)
Slide 9: Financials (Projections)
Slide 10: The Ask (What you need)
Slide 11: Use of Funds
Slide 12: Contact/Q&A
```

### Project Brief
```
1. PROJECT OVERVIEW
   - Project name
   - Client
   - Date

2. BACKGROUND
   - Context
   - Why now

3. OBJECTIVES
   - Primary goal
   - Secondary goals
   - KPIs

4. TARGET AUDIENCE
   - Demographics
   - Psychographics
   - Pain points

5. SCOPE
   - In scope
   - Out of scope

6. DELIVERABLES
   - List all outputs
   - Specifications

7. TIMELINE
   - Key milestones
   - Deadlines

8. BUDGET
   - Total budget
   - Breakdown

9. STAKEHOLDERS
   - Decision makers
   - Approvers

10. SUCCESS CRITERIA
    - How to measure success
```

## Output Formats

| Document | Primary Format | Alternative |
|----------|---------------|-------------|
| Proposal | DOCX | PDF, MD |
| Invoice | PDF | XLSX, DOCX |
| Contract | DOCX | PDF |
| Report | DOCX | PDF, PPTX |
| Pitch | PPTX | PDF, MD |
| Brief | DOCX | MD, Notion |

## Chain Integration

```
/brief → /proposal → /contract → /invoice → /report
   ↓
   └── Full project lifecycle automation
```

## Customization

ถามข้อมูลเพิ่มเติมเมื่อจำเป็น:
- Company branding (logo, colors)
- Payment terms preference
- Legal jurisdiction
- Industry-specific requirements