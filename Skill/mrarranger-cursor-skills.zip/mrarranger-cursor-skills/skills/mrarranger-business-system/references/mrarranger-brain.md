# mrarranger-brain

**Source:** `/mnt/skills/user/mrarranger-brain/SKILL.md`
**Size:** 10721 bytes

---

---
name: mrarranger-brain
description: |
  ระบบคิด วิเคราะห์ ตัดสินใจ แบบ Expert-Level รวม 20+ Mental Models, 15+ Decision Frameworks, Strategic Thinking Tools
  ใช้เมื่อ: (1) ต้องการวิเคราะห์ปัญหาซับซ้อน (2) ตัดสินใจสำคัญ (3) วางแผนกลยุทธ์ (4) แก้ปัญหาอย่างเป็นระบบ (5) ต้องการมุมมองรอบด้าน (6) คิดแบบ CEO/Consultant
  Commands: /think [problem], /decide [options], /strategy [goal], /analyze [situation], /model [framework], /consult [topic]
---

# MRARRANGER Brain - Expert Thinking System

## Quick Commands

```
/think [problem]      → วิเคราะห์ปัญหาแบบลึก
/decide [options]     → ช่วยตัดสินใจ
/strategy [goal]      → วางแผนกลยุทธ์
/analyze [situation]  → วิเคราะห์สถานการณ์
/model [framework]    → ใช้ Mental Model เฉพาะ
/consult [topic]      → ให้คำปรึกษาแบบ Expert
```

## Core Thinking Process

### MRARRANGER Thinking Protocol

เมื่อได้รับปัญหา ให้ดำเนินการตามลำดับ:

```
1. CLARIFY - เข้าใจปัญหาที่แท้จริง
   - อะไรคือปัญหาจริงๆ?
   - ใครได้รับผลกระทบ?
   - อะไรคือ root cause?

2. CONTEXT - รวบรวมบริบท
   - ข้อจำกัดคืออะไร?
   - ทรัพยากรที่มี?
   - Timeline?

3. CONSIDER - พิจารณาทางเลือก
   - มีทางเลือกอะไรบ้าง?
   - ข้อดี/ข้อเสียแต่ละทาง?
   - What if scenarios?

4. CONCLUDE - สรุปและแนะนำ
   - Recommendation ที่ชัดเจน
   - เหตุผลสนับสนุน
   - Action steps
```

## Mental Models Library

### First Principles Thinking
```
แยกปัญหาออกเป็นส่วนพื้นฐานที่สุด:
1. ระบุ assumptions ทั้งหมด
2. ถามว่า "นี่จริงหรือ?"
3. สร้างใหม่จากความจริงพื้นฐาน

ใช้เมื่อ: ต้องการนวัตกรรม, แก้ปัญหาแบบใหม่
```

### Second-Order Thinking
```
คิดถึงผลกระทบของผลกระทบ:
1. ถ้าทำ X จะเกิด Y (First order)
2. แล้ว Y จะทำให้เกิด Z (Second order)
3. Z จะนำไปสู่อะไรอีก?

ใช้เมื่อ: ตัดสินใจที่มีผลระยะยาว
```

### Inversion
```
คิดกลับด้าน:
1. แทนที่จะถามว่า "ทำอย่างไรให้สำเร็จ?"
2. ถามว่า "ทำอะไรจะทำให้ล้มเหลวแน่ๆ?"
3. แล้วหลีกเลี่ยงสิ่งเหล่านั้น

ใช้เมื่อ: ลด risk, หลีกเลี่ยงความผิดพลาด
```

### Pareto Principle (80/20)
```
หา 20% ที่ให้ผลลัพธ์ 80%:
1. ลิสต์ inputs/efforts ทั้งหมด
2. วัดผลลัพธ์ของแต่ละอัน
3. Focus ที่ high-impact items

ใช้เมื่อ: จัดลำดับความสำคัญ, optimize effort
```

### Opportunity Cost
```
ทุกการเลือกมีต้นทุนของสิ่งที่ไม่ได้เลือก:
1. ถ้าเลือก A จะพลาด B, C
2. มูลค่าของ B, C คือเท่าไหร่?
3. A คุ้มกว่าจริงไหม?

ใช้เมื่อ: ตัดสินใจลงทุน (เงิน/เวลา)
```

### Circle of Competence
```
รู้ขอบเขตความสามารถของตัวเอง:
1. อะไรที่รู้จริง vs คิดว่ารู้?
2. เล่นในสนามที่ถนัด
3. ถ้าออกนอกวง ต้องเรียนรู้หรือหาคนช่วย

ใช้เมื่อ: ตัดสินใจเรื่องสำคัญ
```

### Margin of Safety
```
เผื่อ buffer สำหรับความผิดพลาด:
1. คาดว่าจะใช้เวลา X → วางแผน 1.5X
2. คาดว่าจะได้ revenue Y → plan for 0.7Y
3. Murphy's Law: อะไรพังได้ จะพัง

ใช้เมื่อ: วางแผน, ประมาณการ
```

## Decision Frameworks

### RAPID Framework
```
R - Recommend: ใครเสนอทางเลือก?
A - Agree: ใครต้องเห็นด้วย?
P - Perform: ใครลงมือทำ?
I - Input: ใครให้ข้อมูล?
D - Decide: ใครตัดสินใจสุดท้าย?

ใช้เมื่อ: ตัดสินใจในทีม/องค์กร
```

### Eisenhower Matrix
```
         Urgent      Not Urgent
Important   DO NOW     SCHEDULE
            (Crisis)   (Planning)

Not Imp.   DELEGATE    ELIMINATE
           (Interrupt) (Time waste)

ใช้เมื่อ: จัดลำดับงาน
```

### 10/10/10 Rule
```
ถามตัวเอง:
- จะรู้สึกอย่างไรกับการตัดสินใจนี้ใน 10 นาที?
- ใน 10 เดือน?
- ใน 10 ปี?

ใช้เมื่อ: ตัดสินใจที่กลัว/ลังเล
```

### Pre-Mortem Analysis
```
สมมติว่าโปรเจกต์ล้มเหลวแล้ว:
1. "เราอยู่ในอนาคต โปรเจกต์พังแล้ว"
2. "อะไรทำให้มันพัง?"
3. ลิสต์เหตุผลทั้งหมด
4. กลับมาป้องกันตอนนี้

ใช้เมื่อ: เริ่มโปรเจกต์สำคัญ
```

### Regret Minimization
```
Jeff Bezos Framework:
1. ลองนึกภาพตัวเองอายุ 80
2. มองย้อนกลับมา
3. จะเสียใจกับการตัดสินใจไหน?
4. เลือกทางที่จะเสียใจน้อยที่สุด

ใช้เมื่อ: ตัดสินใจครั้งใหญ่ในชีวิต
```

## Strategic Analysis Tools

### SWOT Analysis
```
Strengths (จุดแข็ง):
- เราเก่งอะไร? มีอะไรที่คนอื่นไม่มี?

Weaknesses (จุดอ่อน):
- เราอ่อนอะไร? ขาดอะไร?

Opportunities (โอกาส):
- แนวโน้มไหนเป็นประโยชน์?

Threats (อุปสรรค):
- อะไรคุกคามเรา?
```

### Porter's Five Forces
```
1. การแข่งขันในอุตสาหกรรม (Rivalry)
2. อำนาจต่อรองของ Supplier
3. อำนาจต่อรองของ Buyer
4. ภัยคุกคามจาก New Entrants
5. ภัยคุกคามจาก Substitutes

ใช้เมื่อ: วิเคราะห์อุตสาหกรรม/ตลาด
```

### Jobs To Be Done (JTBD)
```
ลูกค้าไม่ได้ซื้อสินค้า แต่ "จ้าง" มันมาทำงาน:
1. งานอะไรที่ลูกค้าต้องการให้เสร็จ?
2. Functional job: ทำอะไร?
3. Emotional job: รู้สึกอย่างไร?
4. Social job: คนอื่นมองอย่างไร?

ใช้เมื่อ: พัฒนาสินค้า, เข้าใจลูกค้า
```

## Problem-Solving Templates

### Issue Tree
```
Main Problem
├── Sub-issue 1
│   ├── Cause A
│   └── Cause B
├── Sub-issue 2
│   ├── Cause C
│   └── Cause D
└── Sub-issue 3
    └── Cause E

ใช้เมื่อ: แยกปัญหาใหญ่ออกเป็นส่วนย่อย
```

### 5 Whys
```
ปัญหา: [X]
Why 1: ทำไม X? → เพราะ Y
Why 2: ทำไม Y? → เพราะ Z
Why 3: ทำไม Z? → เพราะ A
Why 4: ทำไม A? → เพราะ B
Why 5: ทำไม B? → เพราะ C (Root Cause)

ใช้เมื่อ: หา root cause
```

### MECE Framework
```
Mutually Exclusive: ไม่ซ้อนทับกัน
Collectively Exhaustive: ครอบคลุมทั้งหมด

ตัวอย่าง: แบ่งลูกค้า
✓ MECE: B2B vs B2C
✗ ไม่ MECE: "ลูกค้าใหญ่" vs "ลูกค้า enterprise"

ใช้เมื่อ: จัดหมวดหมู่, วิเคราะห์
```

## Consulting Output Format

เมื่อให้คำปรึกษา ใช้โครงสร้าง:

```
## Executive Summary
[1-2 ประโยค สรุปคำแนะนำหลัก]

## Situation Analysis
[บริบทและปัญหาปัจจุบัน]

## Key Findings
1. [Finding 1 + evidence]
2. [Finding 2 + evidence]
3. [Finding 3 + evidence]

## Recommendations
1. [Action 1] - [ทำไม] - [ผลที่คาด]
2. [Action 2] - [ทำไม] - [ผลที่คาด]
3. [Action 3] - [ทำไม] - [ผลที่คาด]

## Implementation
- Phase 1 (Week 1-2): [actions]
- Phase 2 (Week 3-4): [actions]
- Phase 3 (Month 2): [actions]

## Risks & Mitigation
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|

## Next Steps
1. [Immediate action]
2. [Short-term action]
3. [Follow-up]
```

## File References

- `references/mental-models.md` - 50+ Mental Models เพิ่มเติม
- `references/decision-frameworks.md` - Decision frameworks ละเอียด
- `references/business-analysis.md` - Business analysis tools
- `references/problem-solving.md` - Problem-solving techniques