# mrarranger-research

**Source:** `/mnt/skills/user/mrarranger-research/SKILL.md`
**Size:** 6466 bytes

---

---
name: "mrarranger-research"
description: "MRARRANGER Research & Analysis - วิจัยและวิเคราะห์ข้อมูลครบวงจร (Competitor Analysis, Market Research, Trend Analysis, SWOT). ใช้เมื่อ (1) วิเคราะห์คู่แข่ง (2) Research ตลาด (3) หา Trends (4) ทำ SWOT (5) วิเคราะห์ Content Performance. Commands /competitor /market /trend /swot /analyze"
---

# MRARRANGER Research & Analysis

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/competitor [ชื่อ/URL]` | วิเคราะห์คู่แข่ง | Full competitor report |
| `/market [industry]` | Market Research | Market overview |
| `/trend [หัวข้อ]` | Trend Analysis | Trend report + predictions |
| `/swot [ธุรกิจ]` | SWOT Analysis | SWOT matrix + strategy |
| `/analyze [content/data]` | Content Analysis | Performance insights |

## Research Frameworks

### Competitor Analysis Template
```
## COMPETITOR PROFILE: [Name]

### 1. OVERVIEW
- Company: 
- Founded:
- Size:
- Revenue (est.):
- Funding:

### 2. PRODUCT/SERVICE
- Core offering:
- Pricing:
- USP (Unique Selling Proposition):
- Target market:

### 3. ONLINE PRESENCE
| Platform | Followers | Engagement | Frequency |
|----------|-----------|------------|-----------|
| Website  | Traffic   | Bounce     | Updates   |
| IG       | XXK       | X.X%       | X/week    |
| FB       | XXK       | X.X%       | X/week    |
| YouTube  | XXK       | X.X%       | X/month   |
| TikTok   | XXK       | X.X%       | X/week    |

### 4. CONTENT STRATEGY
- Content types:
- Top performing content:
- Posting frequency:
- Tone/Voice:

### 5. STRENGTHS
- 
- 
- 

### 6. WEAKNESSES
- 
- 
- 

### 7. OPPORTUNITIES (for us)
- 
- 

### 8. KEY TAKEAWAYS
- What to copy:
- What to avoid:
- What to differentiate:
```

### Market Research Template
```
## MARKET RESEARCH: [Industry/Niche]

### 1. MARKET OVERVIEW
- Market size (Global/Local):
- Growth rate:
- Key segments:

### 2. TARGET AUDIENCE
Demographics:
- Age:
- Gender:
- Location:
- Income:

Psychographics:
- Interests:
- Pain points:
- Buying behavior:

### 3. KEY PLAYERS
| Company | Market Share | Positioning |
|---------|-------------|-------------|
| [A]     | XX%         | Premium     |
| [B]     | XX%         | Mid-range   |
| [C]     | XX%         | Budget      |

### 4. TRENDS
- Current trends:
- Emerging trends:
- Declining trends:

### 5. OPPORTUNITIES
- Underserved segments:
- Gaps in market:
- New channels:

### 6. THREATS
- New entrants:
- Substitutes:
- Regulations:

### 7. RECOMMENDATIONS
- 
- 
```

### Trend Analysis Framework
```
## TREND REPORT: [Topic]

### 1. CURRENT STATE
- Trend description:
- Origin/Timeline:
- Current adoption:

### 2. DATA POINTS
- Search volume: [data]
- Social mentions: [data]
- News coverage: [data]

### 3. TREND LIFECYCLE
□ Emerging (< 5% adoption)
□ Growing (5-25% adoption)
□ Mainstream (25-75% adoption)
□ Mature (75%+ adoption)
□ Declining

### 4. KEY DRIVERS
- Technology:
- Consumer behavior:
- Economic factors:
- Social factors:

### 5. PREDICTIONS
- Short-term (6 months):
- Medium-term (1-2 years):
- Long-term (3-5 years):

### 6. ACTION ITEMS
If Early Adopter:
- 
If Fast Follower:
- 
If Wait & See:
- 
```

### SWOT Analysis Template
```
## SWOT ANALYSIS: [Business/Product]

┌─────────────────────┬─────────────────────┐
│     STRENGTHS       │     WEAKNESSES      │
│     (Internal +)    │     (Internal -)    │
├─────────────────────┼─────────────────────┤
│ •                   │ •                   │
│ •                   │ •                   │
│ •                   │ •                   │
│ •                   │ •                   │
├─────────────────────┼─────────────────────┤
│    OPPORTUNITIES    │       THREATS       │
│     (External +)    │     (External -)    │
├─────────────────────┼─────────────────────┤
│ •                   │ •                   │
│ •                   │ •                   │
│ •                   │ •                   │
│ •                   │ •                   │
└─────────────────────┴─────────────────────┘

### STRATEGIC IMPLICATIONS

SO Strategies (Strengths + Opportunities):
- Use [strength] to capture [opportunity]

WO Strategies (Weaknesses + Opportunities):
- Improve [weakness] to capture [opportunity]

ST Strategies (Strengths + Threats):
- Use [strength] to defend against [threat]

WT Strategies (Weaknesses + Threats):
- Minimize [weakness] to avoid [threat]

### PRIORITY ACTIONS
1. [Immediate]
2. [Short-term]
3. [Long-term]
```

### Content Performance Analysis
```
## CONTENT ANALYSIS: [Platform/Account]

### 1. OVERVIEW
- Period analyzed:
- Total posts:
- Total engagement:

### 2. TOP PERFORMERS
| Content | Type | Engagement | Why It Worked |
|---------|------|------------|---------------|
| [1]     | XX   | XX,XXX     | [reason]      |
| [2]     | XX   | XX,XXX     | [reason]      |
| [3]     | XX   | XX,XXX     | [reason]      |

### 3. PATTERNS
Best performing:
- Content type:
- Format:
- Topic:
- Length:
- Time posted:

Worst performing:
- Content type:
- Format:
- Topic:

### 4. RECOMMENDATIONS
Do more:
- 

Do less:
- 

Test:
- 
```

## Data Sources

เมื่อทำ research ให้ใช้:
- Web search (real-time data)
- Social media (engagement data)
- User-provided data (analytics)
- Industry reports (cite sources)

## Output Format

ทุก research output:
1. **Executive Summary** (1 paragraph)
2. **Full Report** (structured)
3. **Key Takeaways** (bullet points)
4. **Action Items** (prioritized)

## Chain Integration

```
/competitor → mrarranger-content (create differentiated content)
/trend → mrarranger-social (ride the trend)
/market → mrarranger-business (create targeted proposal)
/swot → mrarranger-seo (optimize strategy)
```