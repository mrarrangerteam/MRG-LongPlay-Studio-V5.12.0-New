# mrarranger-automation

**Source:** `/mnt/skills/user/mrarranger-automation/SKILL.md`
**Size:** 5908 bytes

---

---
name: "mrarranger-automation"
description: "MRARRANGER Automation Hub - ระบบจัดการ Output และเชื่อมต่อกับ Tools ภายนอก (Notion, Google Sheets, Airtable, Trello). ใช้เมื่อ (1) บันทึก output ลง Notion (2) สร้าง spreadsheet (3) จัดการ Tasks (4) Track ผลงาน (5) สร้าง Database. Commands /notion /sheet /track /database /export"
---

# MRARRANGER Automation Hub

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/notion [action]` | Notion integration | Create/Update pages |
| `/sheet [data]` | Google Sheets | Spreadsheet data |
| `/track [type]` | Tracking system | Tracker template |
| `/database [schema]` | Database design | DB structure |
| `/export [format]` | Export data | Multiple formats |

## Notion Integration

### Page Templates

**Content Calendar:**
```
Database Properties:
- Title (title)
- Status (select): Idea, Writing, Review, Published
- Platform (multi-select): Blog, IG, Twitter, YouTube
- Publish Date (date)
- Content Type (select): Post, Reel, Thread, Video
- Assignee (person)
- Link (url)
- Notes (rich text)
```

**Project Tracker:**
```
Database Properties:
- Project Name (title)
- Client (relation)
- Status (status): Not Started, In Progress, Done
- Priority (select): High, Medium, Low
- Due Date (date)
- Budget (number)
- Deliverables (multi-select)
- Files (files)
```

**Client Database:**
```
Database Properties:
- Name (title)
- Company (text)
- Email (email)
- Phone (phone)
- Status (select): Lead, Active, Completed
- Total Revenue (rollup)
- Projects (relation)
- Notes (rich text)
```

### Quick Actions
```
/notion page [title] - สร้างหน้าใหม่
/notion db [name] - สร้าง database
/notion template [type] - ใช้ template
/notion update [page] - อัพเดทหน้า
```

## Google Sheets Templates

### Content Tracker
```
| Date | Platform | Content | Status | Reach | Engagement | Link |
|------|----------|---------|--------|-------|------------|------|
| DATE | IG/TW/YT | Title   | Draft  | XXX   | XX%        | URL  |
```

### Revenue Tracker
```
| Date | Client | Project | Amount | Status | Invoice# | Paid Date |
|------|--------|---------|--------|--------|----------|-----------|
| DATE | Name   | Desc    | ฿XX,XXX| Paid   | INV-XXX  | DATE      |
```

### Expense Tracker
```
| Date | Category | Description | Amount | Payment | Receipt |
|------|----------|-------------|--------|---------|---------|
| DATE | Software | Tool name   | ฿X,XXX | Card    | Link    |
```

### Analytics Dashboard
```
| Week | Platform | Posts | Reach | Engagement | Followers | Revenue |
|------|----------|-------|-------|------------|-----------|---------|
| W1   | IG       | 7     | XXK   | X.X%       | +XXX      | ฿XX,XXX |
```

## Tracking Systems

### Content Production Tracker
```
Workflow Stages:
1. IDEATION → 2. OUTLINE → 3. DRAFT → 4. EDIT → 5. DESIGN → 6. SCHEDULE → 7. PUBLISHED

Track:
- Time spent per stage
- Bottlenecks
- Output per week
```

### Goal Tracker (OKR Style)
```
OBJECTIVE: [Main goal]
├── KR1: [Measurable result] → Progress: XX%
├── KR2: [Measurable result] → Progress: XX%
└── KR3: [Measurable result] → Progress: XX%

Weekly Check-in:
- What got done:
- Blockers:
- Next week focus:
```

### Habit Tracker
```
| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total |
|-------|-----|-----|-----|-----|-----|-----|-----|-------|
| Post  | ✓   | ✓   | ✓   | ✓   | ✓   | -   | -   | 5/5   |
| Write | ✓   | -   | ✓   | -   | ✓   | ✓   | -   | 4/7   |
| Learn | ✓   | ✓   | ✓   | ✓   | ✓   | ✓   | ✓   | 7/7   |
```

## Database Schemas

### Creator Economy DB
```
Tables:
1. Content (posts, videos, articles)
2. Platforms (connected accounts)
3. Analytics (daily metrics)
4. Revenue (income streams)
5. Collaborations (brand deals)
6. Audience (segments)

Relationships:
Content → Platforms (many-to-many)
Content → Analytics (one-to-many)
Revenue → Content (many-to-one)
```

### Freelance Business DB
```
Tables:
1. Clients
2. Projects
3. Tasks
4. Time Entries
5. Invoices
6. Expenses

Relationships:
Clients → Projects (one-to-many)
Projects → Tasks (one-to-many)
Projects → Invoices (one-to-many)
Time Entries → Tasks (many-to-one)
```

## Export Formats

| Format | Use Case | Command |
|--------|----------|---------|
| CSV | Spreadsheet import | `/export csv` |
| JSON | API/Database | `/export json` |
| MD | Documentation | `/export md` |
| PDF | Sharing | `/export pdf` |
| XLSX | Excel | `/export xlsx` |

## Automation Workflows

### Daily Content Pipeline
```
Morning:
1. Check content calendar
2. Generate content ideas
3. Create drafts

Afternoon:
4. Edit & polish
5. Create visuals
6. Schedule posts

Evening:
7. Check analytics
8. Update tracker
9. Plan tomorrow
```

### Weekly Review
```
Every Sunday:
1. Pull weekly analytics
2. Update all trackers
3. Review goals progress
4. Plan next week
5. Generate report
```

### Monthly Report
```
End of month:
1. Compile all data
2. Calculate KPIs
3. Generate visualizations
4. Create report document
5. Archive to Notion
```

## Chain Integration

```
Any Skill Output → /track → Notion/Sheets
mrarranger-business → /database → Client Management
mrarranger-content → /notion → Content Calendar
mrarranger-seo → /sheet → Analytics Dashboard
```

## Quick Automations

```
/track content - บันทึก content ที่สร้าง
/track revenue - บันทึกรายได้
/track task - บันทึก task ที่ทำ
/track analytics - บันทึก metrics

ทุก track จะ:
1. บันทึกลง local file
2. Format สำหรับ Notion/Sheets
3. พร้อม export
```