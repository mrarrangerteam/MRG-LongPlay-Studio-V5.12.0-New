# mrarranger-life

**Source:** `/mnt/skills/user/mrarranger-life/SKILL.md`
**Size:** 11875 bytes

---

---
name: mrarranger-life
description: |
  ระบบพัฒนาตัวเองครบวงจร - Goal Setting, Productivity, Habit Building, Life Planning, Time Management, Self Reflection
  Framework และ Template สำหรับออกแบบชีวิตที่ดีขึ้น
  ใช้เมื่อ: (1) ตั้งเป้าหมาย (2) วางแผนชีวิต (3) สร้างนิสัย (4) เพิ่ม Productivity (5) Review ตัวเอง (6) ตัดสินใจเรื่องสำคัญในชีวิต
  Commands: /goal [area], /plan [timeframe], /habit [behavior], /review [period], /decide [life-decision], /routine [type]
---

# MRARRANGER Life System

## Quick Commands

```
/goal [area]              → ตั้งเป้าหมาย
/plan [timeframe]         → วางแผน (year/quarter/month/week)
/habit [behavior]         → ออกแบบนิสัยใหม่
/review [period]          → Review ตัวเอง
/decide [decision]        → ช่วยตัดสินใจชีวิต
/routine [morning/evening] → สร้าง Routine
/energy [optimize]        → จัดการพลังงาน
```

## Goal Setting

### SMART Goals
```
S - Specific: ชัดเจน เจาะจง
M - Measurable: วัดได้
A - Achievable: ทำได้จริง
R - Relevant: เกี่ยวข้องกับชีวิต
T - Time-bound: มีกำหนดเวลา

Example:
❌ "อยากรวย"
✅ "มี passive income 50,000 บาท/เดือน ภายในสิ้นปี 2025"
```

### OKR (Objectives & Key Results)
```
Objective: เป้าหมายที่สร้างแรงบันดาลใจ
Key Results: ผลลัพธ์ที่วัดได้ 3-5 ข้อ

Example:
Objective: สุขภาพดีที่สุดในชีวิต

Key Results:
- KR1: ออกกำลังกาย 4 ครั้ง/สัปดาห์ (วัดจาก tracking)
- KR2: น้ำหนักลดเหลือ 70 kg (จาก 80 kg)
- KR3: วิ่ง 5 km ได้ใน 30 นาที
- KR4: นอนหลับ 7+ ชม. ทุกคืน (90% ของวัน)
```

### Life Areas Wheel
```
ให้คะแนน 1-10 ในแต่ละด้าน:

1. Career/Work: ___/10
2. Finance: ___/10
3. Health/Fitness: ___/10
4. Relationships: ___/10
5. Family: ___/10
6. Personal Growth: ___/10
7. Fun/Recreation: ___/10
8. Physical Environment: ___/10

Focus on: ด้านที่คะแนนต่ำสุด 2-3 ด้าน
```

## Life Planning

### Vision Exercise
```
5-Year Vision:
ถ้าทุกอย่างเป็นไปตามที่หวัง ชีวิตในอีก 5 ปีเป็นยังไง?

- อาศัยอยู่ที่ไหน?
- ทำงานอะไร?
- รายได้เท่าไหร่?
- ความสัมพันธ์เป็นยังไง?
- สุขภาพเป็นยังไง?
- ใช้เวลาว่างทำอะไร?
- รู้สึกยังไงกับชีวิต?
```

### Annual Planning Template
```
## Year [YYYY] Plan

### Theme: [คำหรือวลีที่สรุปปีนี้]

### Top 3 Goals:
1. _______________
2. _______________
3. _______________

### Quarterly Breakdown:
Q1: _______________
Q2: _______________
Q3: _______________
Q4: _______________

### Key Habits to Build:
1. _______________
2. _______________
3. _______________

### Things to Stop:
1. _______________
2. _______________

### Learning Goals:
- _______________
- _______________

### Financial Targets:
- Income: _______________
- Savings: _______________
- Investment: _______________
```

### Weekly Planning
```
## Week of [Date]

### Top 3 Priorities:
1. _______________
2. _______________
3. _______________

### Schedule:
Mon: _______________
Tue: _______________
Wed: _______________
Thu: _______________
Fri: _______________
Sat: _______________
Sun: _______________

### Habits Tracker:
□ Exercise: M T W T F S S
□ Read: M T W T F S S
□ Meditate: M T W T F S S
```

## Habit Building

### Habit Loop
```
Cue → Routine → Reward

Example - สร้างนิสัยออกกำลังกายเช้า:
Cue: นาฬิกาปลุก 6:00
Routine: ออกกำลังกาย 30 นาที
Reward: กาแฟโปรด + ความภูมิใจ
```

### Habit Stacking
```
"หลังจาก [นิสัยเดิม] ฉันจะ [นิสัยใหม่]"

Examples:
- หลังตื่นนอน → ดื่มน้ำ 1 แก้ว
- หลังแปรงฟัน → Meditate 5 นาที
- หลังกินข้าวเที่ยง → เดิน 10 นาที
- หลังเข้านอน → อ่านหนังสือ 10 หน้า
```

### 2-Minute Rule
```
เริ่มนิสัยใหม่ด้วยเวอร์ชันที่ใช้เวลาไม่เกิน 2 นาที:

- "อ่านหนังสือ" → อ่าน 1 หน้า
- "ออกกำลังกาย" → ใส่ชุดออกกำลังกาย
- "เรียนภาษา" → เปิด app 
- "เขียน journal" → เขียน 1 ประโยค
- "ทำสมาธิ" → นั่งหายใจ 3 ครั้ง
```

### Habit Scorecard
```
ให้คะแนนนิสัยปัจจุบัน:
+ = นิสัยดี
- = นิสัยไม่ดี
= = neutral

Morning:
+ ตื่น 6 โมง
= เช็คโทรศัพท์
- Scroll social media 30 นาที
+ อาบน้ำ
= กินข้าว
...

แล้วหาทางเปลี่ยน - เป็น + หรือ =
```

## Productivity Systems

### Time Blocking
```
06:00-07:00  Morning Routine
07:00-09:00  Deep Work Block 1
09:00-09:30  Break + Email
09:30-12:00  Deep Work Block 2
12:00-13:00  Lunch + Rest
13:00-15:00  Meetings / Collaboration
15:00-17:00  Deep Work Block 3
17:00-18:00  Admin / Planning
18:00+       Personal Time
```

### Pomodoro Technique
```
25 min work → 5 min break
(repeat 4x)
→ 15-30 min long break

Tips:
- เลือก 1 task ต่อ 1 pomodoro
- ไม่รับ interruption ระหว่าง work
- พักจริงๆ ไม่เช็คโทรศัพท์
```

### Eisenhower Matrix
```
         URGENT          NOT URGENT
        ┌─────────────┬─────────────┐
IMPORT- │    DO       │   SCHEDULE  │
ANT     │   (Now)     │   (Calendar)│
        ├─────────────┼─────────────┤
NOT     │  DELEGATE   │   ELIMINATE │
IMPORT- │   (Others)  │   (Delete)  │
ANT     │             │             │
        └─────────────┴─────────────┘
```

### MIT (Most Important Tasks)
```
ทุกวันเลือก 3 MIT:
1. _____ (ถ้าทำได้แค่อย่างเดียว)
2. _____ 
3. _____

ทำ MIT ก่อนสิ่งอื่น
```

## Morning & Evening Routines

### Morning Routine Template
```
## Morning Routine (60-90 min)

Physical:
□ ดื่มน้ำ 1 แก้ว
□ ออกกำลังกาย ___ นาที
□ อาบน้ำ

Mental:
□ Meditation ___ นาที
□ Journal / Gratitude
□ อ่านหนังสือ ___ นาที

Planning:
□ Review goals
□ Plan today's MIT
□ Check calendar
```

### Evening Routine Template
```
## Evening Routine (30-60 min)

Shutdown:
□ Review today (what went well?)
□ Plan tomorrow
□ Prepare clothes/bag
□ Clear desk

Wind Down:
□ No screens after ___
□ Read ___ นาที
□ Journal / Reflection
□ Gratitude (3 things)

Sleep:
□ เข้านอนเวลา ___
□ Room temp ___°C
□ No phone in bedroom
```

## Self Reflection

### Weekly Review
```
## Weekly Review - Week of [Date]

### Wins:
1. _______________
2. _______________
3. _______________

### Lessons:
1. _______________
2. _______________

### What didn't get done:
1. _______________ (why? reschedule?)

### Next week's focus:
1. _______________
2. _______________
3. _______________

### How am I feeling? ___/10
```

### Monthly Review
```
## Monthly Review - [Month Year]

### Goals Progress:
- Goal 1: ___% complete
- Goal 2: ___% complete
- Goal 3: ___% complete

### Highlights:
1. _______________
2. _______________
3. _______________

### Challenges:
1. _______________

### Key Metrics:
- Income: ___
- Savings: ___
- Exercise days: ___/30
- Books read: ___

### Adjustments for next month:
1. _______________
```

### Annual Review
```
## Year [YYYY] Review

### Rate the year: ___/10

### Top Accomplishments:
1. _______________
2. _______________
3. _______________

### Biggest Lessons:
1. _______________
2. _______________
3. _______________

### Regrets / Things to do differently:
1. _______________

### Surprises:
1. _______________

### Gratitude:
- People: _______________
- Experiences: _______________
- Growth: _______________

### Word/Theme for next year: _______________
```

## Life Decisions Framework

### 10/10/10 Analysis
```
สำหรับการตัดสินใจที่ลังเล:

ถ้าตัดสินใจแบบนี้...
- ใน 10 นาที จะรู้สึกยังไง?
- ใน 10 เดือน จะรู้สึกยังไง?
- ใน 10 ปี จะรู้สึกยังไง?
```

### Regret Minimization
```
จินตนาการตัวเองอายุ 80:

"เมื่อมองย้อนกลับไป ฉันจะเสียใจไหม
ถ้าไม่ได้ลอง _______________?"

ถ้าคำตอบคือ "ใช่" → ลงมือทำ
```

### Fear Setting
```
1. Define: สิ่งที่กลัวที่สุดถ้าทำ ___ คืออะไร?
   - _______________
   - _______________
   - _______________

2. Prevent: ทำอย่างไรให้ไม่เกิด?
   - _______________

3. Repair: ถ้าเกิดขึ้น จะแก้ไขอย่างไร?
   - _______________

4. Cost of inaction: ถ้าไม่ทำ จะเสียอะไร?
   - ใน 6 เดือน: _______________
   - ใน 1 ปี: _______________
   - ใน 3 ปี: _______________
```

## Energy Management

### Energy Audit
```
เมื่อไหร่พลังงานสูงสุด? _______________
เมื่อไหร่พลังงานต่ำสุด? _______________

Activities that give energy:
+ _______________
+ _______________

Activities that drain energy:
- _______________
- _______________

→ จัด Deep Work ตอนพลังงานสูง
→ จัด Admin/Easy tasks ตอนพลังงานต่ำ
```

### SEEDS of Energy
```
S - Sleep: นอนให้พอ 7-9 ชม.
E - Exercise: ขยับร่างกายทุกวัน
E - Eat: กินอาหารดี
D - Downtime: พักผ่อน มีเวลาว่าง
S - Social: เชื่อมต่อกับคน
```

## File References

- `references/planning-templates.md` - Templates การวางแผนเพิ่มเติม
- `references/habit-library.md` - ไอเดียนิสัยดีๆ 100+ อย่าง
- `references/reflection-prompts.md` - คำถาม reflection