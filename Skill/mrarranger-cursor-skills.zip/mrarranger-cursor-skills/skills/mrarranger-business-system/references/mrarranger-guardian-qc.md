# mrarranger-guardian-qc

**Source:** `/mnt/skills/user/mrarranger-guardian-qc/SKILL.md`
**Size:** 11976 bytes

---

---
name: mrarranger-guardian-qc
description: ระบบตรวจสอบคุณภาพอัตโนมัติ 5 Agents - Content Auditor, Technical Validator, UX Reviewer, Strategy Checker, Final Polish ตรวจสอบทุก Output ก่อนส่งมอบ
---

# 🛡️ MRARRANGER GUARDIAN - QC Team

> **Philosophy: "ไม่มี Output ไหนออกไปโดยไม่ผ่าน QC"**
> ระบบตรวจสอบคุณภาพอัตโนมัติก่อนส่งมอบงานให้ User

---

## 📋 Overview

MRARRANGER GUARDIAN เป็น Quality Control System ที่:

1. **ตรวจสอบอัตโนมัติ** - ทุก Output ผ่าน QC ก่อนส่ง
2. **หลายมุมมอง** - ตรวจทั้ง Content, Technical, UX
3. **ให้ Feedback** - บอกปัญหาและวิธีแก้
4. **Continuous Improvement** - เรียนรู้และปรับปรุง

---

## 👥 QC Team Agents

### Agent 1: Content Auditor 📝

**หน้าที่**: ตรวจสอบเนื้อหา

```yaml
checks:
  - accuracy: ข้อมูลถูกต้อง ไม่มี misinformation
  - completeness: ครบทุกหัวข้อที่ request
  - clarity: เข้าใจง่าย ไม่กำกวม
  - tone_consistency: tone สม่ำเสมอตลอด
  - grammar_spelling: ไม่มี typo, grammar ถูก
  - relevance: ตรงประเด็น ไม่ออกนอกเรื่อง
  - value: มีคุณค่า actionable
```

**Scoring**: 0-100 per category

---

### Agent 2: Technical Validator ⚙️

**หน้าที่**: ตรวจสอบทางเทคนิค

```yaml
checks:
  - format: format ถูกต้องตาม spec
  - syntax: code/prompt syntax ถูกต้อง
  - compatibility: ใช้งานได้กับ platform ที่ระบุ
  - links: links ทำงาน (ถ้ามี)
  - structure: โครงสร้างเหมาะสม
  - export_ready: พร้อม export ใช้งาน
```

**Validation Methods**:
- Schema validation
- Syntax checking
- Format verification

---

### Agent 3: UX Reviewer 🎨

**หน้าที่**: ตรวจสอบ User Experience

```yaml
checks:
  - readability: อ่านง่าย flow ดี
  - scannability: scan ได้เร็ว มี headers
  - visual_hierarchy: จัดลำดับความสำคัญดี
  - actionability: user รู้ว่าต้องทำอะไรต่อ
  - accessibility: ทุกคนเข้าถึงได้
```

**UX Principles Applied**:
- F-pattern reading
- Progressive disclosure
- Clear CTAs

---

### Agent 4: Strategy Checker 🎯

**หน้าที่**: ตรวจสอบ Strategic Alignment

```yaml
checks:
  - goal_alignment: ตรงกับ goal ที่ user ต้องการ
  - audience_fit: เหมาะกับ target audience
  - brand_consistency: ตรงกับ brand voice
  - competitive_edge: มี unique value
  - feasibility: ทำได้จริง realistic
```

**Strategic Framework**:
- SMART goals validation
- Audience persona matching
- Competitive positioning

---

### Agent 5: Final Polish 💎

**หน้าที่**: ขัดเกลาสุดท้าย

```yaml
checks:
  - presentation: format สวย professional
  - consistency: style สม่ำเสมอ
  - brevity: ไม่ยาวเกินไป กระชับ
  - impact: opening และ closing แข็งแรง
  - ready_to_use: พร้อมใช้งานทันที
```

**Polish Actions**:
- Remove redundancy
- Strengthen headlines
- Improve flow
- Add finishing touches

---

## 🔄 QC Workflow

### Standard QC Flow

```
Output Created
     ↓
┌─────────────────┐
│ Content Auditor │ → Score + Issues
└────────┬────────┘
         ↓
┌─────────────────────┐
│ Technical Validator │ → Pass/Fail + Fixes
└────────┬────────────┘
         ↓
┌──────────────┐
│ UX Reviewer  │ → Score + Suggestions
└──────┬───────┘
       ↓
┌──────────────────┐
│ Strategy Checker │ → Alignment Score
└────────┬─────────┘
         ↓
┌──────────────┐
│ Final Polish │ → Refined Output
└──────┬───────┘
       ↓
   QC Report + Final Output
```

### Express QC Flow (Speed Mode)

```
Output → Quick Scan → Critical Issues Only → Pass/Flag
```

### Deep QC Flow (Precision Mode)

```
Output → All 5 Agents → Full Reports → Multiple Revisions → Perfect Output
```

---

## 📊 QC Report Format

### Summary Section

```
═══════════════════════════════════════════
🛡️ GUARDIAN QC REPORT
═══════════════════════════════════════════

📋 Overall Score: 87/100 ⭐⭐⭐⭐

✅ Content:    92/100 - Excellent
✅ Technical:  PASSED
✅ UX:         85/100 - Good
✅ Strategy:   88/100 - Good
✅ Polish:     83/100 - Good

Status: ✅ APPROVED FOR DELIVERY
```

### Detailed Issues

```
📝 ISSUES FOUND:

[MINOR] Line 45: Typo "teh" → "the"
[MINOR] Section 3: Could be more concise
[SUGGESTION] Add example after explanation

🔧 AUTO-FIXED:
- Corrected 2 typos
- Improved heading hierarchy
- Added missing comma

💡 RECOMMENDATIONS:
- Consider adding visual diagram
- Could benefit from case study
```

### Quality Certificate

```
═══════════════════════════════════════════
✅ QUALITY CERTIFIED

This output has been verified by 
MRARRANGER GUARDIAN QC Team

Score: 87/100
Date: 2025-01-27
Hash: QC-2025-0127-A7B3
═══════════════════════════════════════════
```

---

## ⚡ QC Commands

### Main Commands

| Command | Description |
|---------|-------------|
| `/qc` | Run full QC on last output |
| `/qc-express` | Quick QC (critical issues only) |
| `/qc-deep` | Deep QC with full analysis |
| `/qc-report` | Show detailed QC report |
| `/qc-fix` | Auto-fix detected issues |

### Configuration Commands

| Command | Description |
|---------|-------------|
| `/qc-level [1-5]` | Set strictness (1=lenient, 5=strict) |
| `/qc-focus [area]` | Focus on specific area |
| `/qc-skip` | Skip QC for this output |
| `/qc-always` | Always run QC (default) |

---

## 🎯 QC Checklists by Output Type

### Blog Post / Article

```checklist
□ Title is compelling and accurate
□ Introduction hooks the reader
□ Main points are clear and supported
□ Examples/evidence included
□ Conclusion has clear takeaway
□ CTA is present if needed
□ SEO elements (if requested)
□ Proper formatting (headers, lists)
□ No spelling/grammar errors
□ Appropriate length
```

### Social Media Post

```checklist
□ Hook in first line
□ Platform-appropriate format
□ Hashtags relevant (if used)
□ CTA clear
□ Character count within limit
□ Tone matches brand
□ No broken links
□ Emojis appropriate (if used)
```

### Sales Copy

```checklist
□ Headline grabs attention
□ Problem clearly stated
□ Solution positioned well
□ Benefits > Features
□ Social proof included
□ Objections addressed
□ CTA strong and clear
□ Urgency/scarcity appropriate
□ No hype or false claims
□ Compliant with platform rules
```

### Email Sequence

```checklist
□ Subject lines compelling
□ Preview text optimized
□ Personalization tokens correct
□ Flow logical
□ Value in each email
□ CTAs in each email
□ Unsubscribe compliant
□ Mobile-friendly
□ Links working
□ Timing appropriate
```

### Technical Document

```checklist
□ Structure clear
□ Technical accuracy
□ Code syntax correct
□ Examples work
□ Dependencies noted
□ Installation steps clear
□ Troubleshooting included
□ Version compatibility noted
```

### Prompt (AI Generation)

```checklist
□ Clear instruction
□ Style/tone specified
□ Constraints included
□ Format specified
□ Examples if needed
□ Platform-specific syntax
□ No conflicting instructions
□ Length appropriate
```

---

## 🔧 Auto-Fix Capabilities

### What GUARDIAN Can Auto-Fix

```yaml
auto_fixable:
  - typos and spelling errors
  - basic grammar issues
  - formatting inconsistencies
  - missing punctuation
  - incorrect capitalization
  - broken markdown syntax
  - duplicate content
  - excessive whitespace
```

### What Requires Human Decision

```yaml
requires_approval:
  - content accuracy changes
  - tone/style changes
  - structural reorganization
  - adding new content
  - removing sections
  - changing claims/facts
```

---

## 📈 Quality Metrics

### Scoring System

```
90-100: Excellent ⭐⭐⭐⭐⭐
80-89:  Good      ⭐⭐⭐⭐
70-79:  Average   ⭐⭐⭐
60-69:  Below Avg ⭐⭐
<60:    Needs Work ⭐
```

### Pass/Fail Thresholds

```yaml
thresholds:
  minimum_overall: 70
  minimum_per_category: 60
  technical_must_pass: true
  critical_issues_max: 0
  major_issues_max: 3
```

### Quality Gates

```
Gate 1: No Critical Issues
Gate 2: Technical Validation Pass
Gate 3: Overall Score ≥ 70
Gate 4: All Categories ≥ 60
Gate 5: Strategy Alignment ≥ 70
```

---

## 🔄 Continuous Improvement

### Learning from QC

```
Each QC run:
1. Logs issues found
2. Tracks patterns
3. Updates preferences
4. Improves future outputs
```

### Pattern Detection

```
If same issue appears 3+ times:
→ Add to prevention checklist
→ Adjust generation parameters
→ Alert for root cause fix
```

### Feedback Integration

```
User feedback:
👍 = Reinforce current approach
👎 = Flag for review
Comments = Update guidelines
```

---

## ⚙️ Configuration

### Default Settings

```yaml
guardian_config:
  enabled: true
  default_level: 3  # 1-5 strictness
  auto_fix: true
  show_report: summary  # none, summary, full
  block_on_fail: false
  
  thresholds:
    pass: 70
    warn: 80
    excellent: 90
    
  focus_areas:
    content: true
    technical: true
    ux: true
    strategy: true
    polish: true
```

### Per-Project Settings

```yaml
project_qc:
  project_name: "AI Music Course"
  strictness: 4
  mandatory_checks:
    - brand_voice
    - audience_fit
    - seo_optimization
  skip_checks:
    - code_syntax  # not relevant
```

---

## 💡 Best Practices

### 1. Trust the System
GUARDIAN catches most issues automatically

### 2. Review Suggestions
Not all suggestions need action, use judgment

### 3. Iterate When Needed
If score < 80, consider revision

### 4. Learn from Reports
Patterns show areas for improvement

### 5. Adjust Strictness
Higher for public-facing content
Lower for drafts/internal

---

## 🔗 Integration with ULTIMATE

```
ULTIMATE Super AI Mode:
1. Generate Content
2. Auto-run GUARDIAN
3. Auto-fix issues
4. Re-check if needed
5. Deliver with QC Certificate
```

---

## 📚 Related Skills

- [MRARRANGER ULTIMATE](./mrarranger-ultimate-superai-SKILL.md) - Master Skill
- [Oracle Framework](../oracle-framework/SKILL.md) - Knowledge Management
- [Content Master](../mrarranger-content-master/SKILL.md) - Content Creation

---

**Version**: 1.0.0
**Last Updated**: 2025-01-27
**Author**: MRARRANGER Team

> 🛡️ "ไม่มี Output ไหนออกไปโดยไม่ผ่าน QC"