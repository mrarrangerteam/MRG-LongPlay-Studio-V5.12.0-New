# mrarranger-ultimate-super-ai

**Source:** `/mnt/skills/user/mrarranger-ultimate-super-ai/SKILL.md`
**Size:** 11189 bytes

---

---
name: mrarranger-ultimate-super-ai
description: Meta-Skill ที่รวมพลังทุก MRARRANGER Skills - คิดเอง ทำเอง จบครบ 2,000,000% วิเคราะห์ Intent อัตโนมัติ เลือก Skills ที่เหมาะสม และ Execute งานแบบ End-to-End
---

# 🚀 MRARRANGER ULTIMATE Super AI 2,000,000%

> **Philosophy: "คิดเอง ทำเอง จบครบ"**
> AI ที่เข้าใจ วิเคราะห์ และ Execute งานแบบ End-to-End โดยไม่ต้องถามซ้ำ

---

## 📋 Overview

MRARRANGER ULTIMATE เป็น Meta-Skill ที่รวมพลังของทุก MRARRANGER Skills เข้าด้วยกัน
ทำให้ Claude สามารถ:

1. **วิเคราะห์ Intent** - เข้าใจสิ่งที่ user ต้องการจริงๆ แม้ไม่ได้พูดชัด
2. **วางแผน Workflow** - ออกแบบขั้นตอนการทำงานที่เหมาะสม
3. **เลือก Skills** - เรียกใช้ Skills ที่ถูกต้องอัตโนมัติ
4. **Execute ครบวงจร** - ทำงานจนจบโดยไม่ต้องถามซ้ำ
5. **QC ก่อนส่งมอบ** - ตรวจสอบคุณภาพก่อนให้ Output

---

## 🧠 Core Intelligence Engine

### Intent Analysis Matrix

```
User Input → Parse Keywords → Match Intent → Select Workflow → Execute
     ↓
[Context Analysis]
- Previous conversation
- User preferences  
- Project context
- Available resources
     ↓
[Intent Categories]
- Content Creation (Blog, Social, Video, Audio)
- Marketing (Strategy, Campaign, Ads, SEO)
- Sales (Copy, Funnel, Email Sequence)
- Business (Proposal, Contract, Report)
- Research (Market, Competitor, Trend)
- Technical (Automation, Integration, Analytics)
- Creative (Music, Visual, Design)
```

### Automatic Skill Orchestration

เมื่อได้รับ Request, ULTIMATE จะ:

1. **Scan** - วิเคราะห์ keywords และ context
2. **Match** - หา Skills ที่เกี่ยวข้อง
3. **Chain** - เรียงลำดับ Skills ที่ต้องใช้
4. **Execute** - ทำงานตาม workflow
5. **Validate** - ตรวจสอบ output

---

## 🔗 Skills Integration Map

### Primary Skills Available

| Category | Skills | Commands |
|----------|--------|----------|
| **Content** | content, content-master, viral-content | /blog /article /viral |
| **Social** | social | /thread /ig /tiktok /linkedin |
| **Sales** | sales | /copy /funnel /sequence |
| **Marketing** | marketing | /strategy /campaign /avatar |
| **SEO** | seo | /keywords /diagnose /strategy |
| **Research** | research | /competitor /market /trend |
| **Music** | music | /clone /compose /lyrics |
| **Visual** | visual | /moodboard /prompt /storyboard |
| **Video** | coordinator | /mv /short /full |
| **Automation** | n8n, automation | /workflow /webhook |
| **Analytics** | analytics | /dashboard /report /kpi |
| **Business** | business | /proposal /contract /pitch |
| **Course** | course | /curriculum /lesson /quiz |
| **Mass Production** | mass-production | /batch /export |

### Meta-Integration

```
ULTIMATE Mode: เรียก Multiple Skills พร้อมกัน

Example Workflow:
User: "ทำ Campaign เปิดตัวคอร์สสอน AI Music ให้หน่อย"

ULTIMATE Analysis:
├─ marketing → /strategy /campaign
├─ sales → /funnel /sequence  
├─ content → /blog /landing
├─ social → /thread /ig /tiktok
├─ seo → /keywords
├─ visual → /moodboard
└─ n8n → /workflow (automation)

Output: Complete Campaign Package
```

---

## ⚡ ULTIMATE Commands

### Master Commands

| Command | Description |
|---------|-------------|
| `/ultimate [project]` | Full project execution |
| `/auto [task]` | Auto-detect & execute |
| `/plan [goal]` | Create execution plan |
| `/chain [skills]` | Chain multiple skills |
| `/deploy [output]` | Deploy to platforms |

### Mode Commands

| Command | Description |
|---------|-------------|
| `/beast-mode` | Maximum output, no questions |
| `/precision-mode` | Step-by-step with confirmations |
| `/creative-mode` | Experimental, push boundaries |
| `/speed-mode` | Fast execution, essential only |

---

## 🎯 Execution Patterns

### Pattern 1: Full Campaign

```
Trigger: "ทำ campaign", "launch", "เปิดตัว"

Workflow:
1. Research → Market + Competitor
2. Strategy → Avatar + Positioning  
3. Content → Core + Supporting
4. Creative → Visual + Audio
5. Distribution → Social + Ads
6. Automation → Workflows
7. Analytics → Tracking setup
```

### Pattern 2: Content Empire

```
Trigger: "สร้าง content", "content strategy"

Workflow:
1. Pillar Content → Long-form
2. Distribution → Social versions
3. SEO → Optimization
4. Repurpose → Video, Audio
5. Schedule → Calendar
```

### Pattern 3: Product Launch

```
Trigger: "launch product", "เปิดขาย"

Workflow:
1. Product → Positioning
2. Sales Page → Copy + Design
3. Funnel → Complete flow
4. Email → Sequence
5. Ads → Creative + Copy
6. Analytics → Tracking
```

### Pattern 4: Course Creation

```
Trigger: "สร้างคอร์ส", "online course"

Workflow:
1. Curriculum → Structure
2. Content → Lessons
3. Materials → Resources
4. Quiz → Assessments  
5. Marketing → Launch plan
6. Delivery → Platform setup
```

---

## 🔄 Auto-Detection Logic

### Keyword Triggers

```python
INTENT_MAP = {
    # Content
    "บทความ|blog|article|เขียน": "content",
    "viral|hook|trend": "viral-content",
    
    # Social  
    "twitter|thread|tweet": "social.twitter",
    "instagram|ig|reels": "social.instagram",
    "tiktok|สั้น": "social.tiktok",
    "linkedin": "social.linkedin",
    
    # Sales
    "ขาย|copy|headline": "sales",
    "funnel|landing": "sales.funnel",
    "email|sequence": "sales.email",
    
    # Marketing
    "marketing|campaign|strategy": "marketing",
    "ads|โฆษณา": "marketing.ads",
    "avatar|persona": "marketing.avatar",
    
    # SEO
    "seo|keyword|ranking": "seo",
    
    # Research
    "competitor|คู่แข่ง": "research.competitor",
    "market|ตลาด": "research.market",
    "trend": "research.trend",
    
    # Creative
    "เพลง|music|suno": "music",
    "video|mv|หนัง": "visual",
    "image|รูป|midjourney": "visual.image",
    
    # Technical
    "automation|n8n|workflow": "n8n",
    "analytics|dashboard": "analytics",
    
    # Business
    "proposal|ข้อเสนอ": "business.proposal",
    "contract|สัญญา": "business.contract",
    
    # Course
    "course|คอร์ส|workshop": "course"
}
```

### Context Enhancement

```
When processing request:

1. Check conversation history
2. Identify user's niche/industry
3. Note previous preferences
4. Consider current project context
5. Apply relevant customizations
```

---

## 📦 Output Formats

### Standard Outputs

- **Documents**: .md, .docx, .pdf
- **Data**: .json, .csv, .xlsx
- **Code**: .py, .js, workflow configs
- **Creative**: prompt files, scripts

### Package Outputs

```
/ultimate generates:

📁 [Project-Name]-Package/
├── 📁 Strategy/
│   ├── market-research.md
│   ├── competitor-analysis.md
│   └── campaign-strategy.md
├── 📁 Content/
│   ├── pillar-content.md
│   ├── social-posts/
│   └── email-sequences/
├── 📁 Creative/
│   ├── visual-prompts.md
│   ├── video-scripts/
│   └── audio-prompts/
├── 📁 Technical/
│   ├── workflows.json
│   └── tracking-setup.md
└── 📄 execution-checklist.md
```

---

## 🚀 Quick Start Examples

### Example 1: Complete Business Launch

```
User: ทำให้ครบเลย launch ธุรกิจขาย AI Music Course

ULTIMATE executes:
→ Market Research
→ Competitor Analysis  
→ Brand Strategy
→ Course Curriculum
→ Sales Funnel
→ Email Sequences
→ Social Content
→ Ad Creatives
→ SEO Setup
→ Automation Workflows
→ Analytics Dashboard

Output: Complete Launch Package (15+ documents)
```

### Example 2: Content Blitz

```
User: ต้องการ content สำหรับ 1 เดือน เรื่อง Suno AI

ULTIMATE executes:
→ 4 Blog Posts
→ 30 Social Posts (Twitter, IG, TikTok, LinkedIn)
→ 8 Email Newsletters
→ 4 Video Scripts
→ Content Calendar

Output: 1-Month Content Package
```

### Example 3: Viral Campaign

```
User: ทำ viral campaign สำหรับเพลง AI ใหม่

ULTIMATE executes:
→ Viral Strategy
→ Hook Variations
→ Platform-Specific Content
→ Influencer Outreach Plan
→ Community Engagement Plan
→ Analytics Tracking

Output: Viral Campaign Toolkit
```

---

## ⚙️ Configuration

### User Preferences (Auto-saved)

```yaml
preferences:
  language: th  # th, en, mixed
  tone: casual  # formal, casual, playful
  detail_level: comprehensive  # minimal, standard, comprehensive
  output_format: markdown  # markdown, json, both
  auto_execute: true  # ask first or just do it
  quality_check: enabled  # QC before delivery
```

### Project Context

```yaml
project:
  name: "AI Music Course"
  niche: "AI/Music Production"
  target_audience: "Musicians wanting to learn AI"
  brand_voice: "Expert but approachable"
  platforms: ["YouTube", "Twitter", "Instagram"]
```

---

## 🛡️ Quality Assurance

ULTIMATE includes built-in QC (see GUARDIAN skill):

1. **Completeness** - ครบทุกส่วนที่ request
2. **Accuracy** - ข้อมูลถูกต้อง
3. **Consistency** - tone และ style สม่ำเสมอ
4. **Actionability** - ใช้งานได้จริง
5. **Polish** - ไม่มี typo, format ดี

---

## 💡 Pro Tips

1. **ให้ Context มาก = Output ดีมาก**
   - บอก niche, target audience, goals

2. **ใช้ /beast-mode สำหรับงานใหญ่**
   - ได้ output เยอะในครั้งเดียว

3. **Chain Skills เอง ถ้าต้องการ control**
   - `/chain music → visual → social`

4. **บอก preferences ครั้งเดียว**
   - ULTIMATE จำไว้ใช้ตลอด

5. **ใช้ /plan ก่อน /ultimate**
   - ดู workflow ก่อน execute

---

## 📚 Related Skills

- [MRARRANGER GUARDIAN](./mrarranger-guardian-SKILL.md) - QC System
- [Oracle Framework](../oracle-framework/SKILL.md) - Knowledge Management
- [BMAD Method](../bmad-method/SKILL.md) - Development Framework

---

**Version**: 2.0.0
**Last Updated**: 2025-01-27
**Author**: MRARRANGER Team

> 🚀 "Super AI 2,000,000% - คิดเอง ทำเอง จบครบ"