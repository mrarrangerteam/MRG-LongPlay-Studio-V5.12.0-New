# openclaw

**Source:** `/mnt/skills/user/openclaw/SKILL.md`
**Size:** 28953 bytes

---

---
name: openclaw
description: |
  OpenClaw AI Personal Assistant - ระบบจัดการ Open-Source AI Agent ครบวงจร
  ติดตั้ง ตั้งค่า จัดการ OpenClaw Gateway, Channels, Tools, Skills, Agents, Automation
  รองรับ Multi-Channel (WhatsApp, Telegram, Slack, Discord, Signal, iMessage, MS Teams, Matrix, Zalo)
  Multi-Agent Routing, Multi-Model Config (Kimi, GLM, Claude, OpenAI, Ollama, OpenRouter)
  Browser Control, Voice, Canvas, Cron Jobs, Webhooks, ClawHub Skills Registry
  ใช้เมื่อ: (1) ติดตั้ง/ตั้งค่า OpenClaw (2) จัดการ Channels (3) สร้าง/จัดการ Skills
  (4) ตั้งค่า Model switching/failover (5) Multi-Agent routing (6) ClawHub skills
  (7) Troubleshooting/Doctor (8) Automation/Webhooks
  Commands: /install, /channels, /skills, /model, /agent, /doctor, /clawhub
---

# 🦞 OpenClaw — Personal AI Assistant (Complete Skill)

> **Version**: Feb 2026 | **GitHub**: 150k+ ⭐ | **Creator**: Peter Steinberger
> **Docs**: https://docs.openclaw.ai | **Registry**: https://clawhub.ai
> **Formerly**: Clawdbot → Moltbot → OpenClaw

OpenClaw เป็น open-source personal AI assistant ที่รันบนเครื่องของคุณเอง
เชื่อมต่อกับ messaging platforms ที่ใช้อยู่แล้ว (WhatsApp, Telegram, Discord, Slack ฯลฯ)
รองรับ multi-model, multi-agent, voice, browser control, skills ecosystem

---

## 📋 TABLE OF CONTENTS

1. [Installation](#-installation)
2. [CLI Commands Reference](#-cli-commands-reference)
3. [Model Configuration & Multi-Model](#-model-configuration--multi-model-switching)
4. [Channel Setup](#-channel-setup)
5. [Multi-Agent Routing](#-multi-agent-routing)
6. [Skills & ClawHub Registry](#-skills--clawhub-registry)
7. [Troubleshooting & Doctor](#-troubleshooting--doctor)
8. [Advanced Configuration](#-advanced-configuration)
9. [Security](#-security-best-practices)

---

## 🚀 INSTALLATION

### Requirements

- **Runtime**: Node.js ≥ 22
- **OS**: macOS, Linux, Windows (WSL2 strongly recommended)
- **Auth**: OpenAI API key / Anthropic API key / Claude setup-token / OpenRouter key

### Method 1: One-Liner Install (แนะนำ)

```bash
# ติดตั้งทุกอย่างรวม Node.js อัตโนมัติ
curl -fsSL https://openclaw.ai/install.sh | bash
```

สิ่งที่ one-liner ทำให้:
- ติดตั้ง Node.js (ถ้ายังไม่มี)
- ติดตั้ง OpenClaw CLI global
- เปิด Onboarding Wizard อัตโนมัติ
- ตั้งค่า daemon service (launchd/systemd)

### Method 2: npm Install

```bash
# Install global
npm install -g openclaw@latest
# หรือ
pnpm add -g openclaw@latest

# เริ่ม Onboarding Wizard + ติดตั้ง daemon
openclaw onboard --install-daemon
```

### Method 3: Build from Source

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
pnpm install
pnpm ui:build        # auto-installs UI deps
pnpm build
pnpm openclaw onboard --install-daemon

# Dev loop (auto-reload)
pnpm gateway:watch
```

### Method 4: Docker

```bash
docker build -t openclaw .
docker-compose up -d
```

### Method 5: Nix

```bash
# ดู docs: https://docs.openclaw.ai/start/nix
nix profile install github:openclaw/openclaw
```

### Post-Install: Onboarding Wizard

Wizard จะถาม step-by-step:

1. **Auth** — OpenAI OAuth / Anthropic API key / OpenRouter key
2. **Bot Name** — ตั้งชื่อ assistant
3. **Channels** — เลือก messaging platforms (WhatsApp QR, Telegram token ฯลฯ)
4. **Hooks** — เลือก hooks ที่ต้องการ (session memory, etc.)
5. **Daemon** — ติดตั้ง background service

```bash
# ถ้าเคยติดตั้งแล้ว ต้องการ re-configure
openclaw onboard

# Non-interactive install (สำหรับ automation)
openclaw onboard --non-interactive --auth-choice anthropic-api-key
```

### Verify Installation

```bash
# เช็คสถานะ
openclaw health

# Debug report (ดีที่สุดสำหรับ troubleshooting)
openclaw status --all

# เปิด Gateway
openclaw gateway --port 18789 --verbose

# Dashboard (local)
# http://127.0.0.1:18789/
```

### Updating

```bash
# อัปเดตเป็นเวอร์ชันล่าสุด
npm install -g openclaw@latest

# หลังอัปเดตให้รัน doctor เสมอ
openclaw doctor

# สลับ channel (stable/beta/dev)
openclaw update --channel stable
openclaw update --channel beta
openclaw update --channel dev
```

---

## 🖥️ CLI COMMANDS REFERENCE

### Core Commands

| Command | Description |
|---------|-------------|
| `openclaw onboard` | เริ่ม Onboarding Wizard ตั้งค่าทุกอย่าง |
| `openclaw onboard --install-daemon` | ติดตั้ง + daemon service |
| `openclaw gateway` | เริ่ม Gateway server |
| `openclaw gateway --port 18789 --verbose` | เริ่มพร้อม verbose log |
| `openclaw health` | เช็คสถานะ Gateway |
| `openclaw status --all` | Debug report แบบละเอียด |
| `openclaw doctor` | วินิจฉัยปัญหาทั้งหมด |
| `openclaw doctor --fix` | วินิจฉัย + แก้ไขอัตโนมัติ |
| `openclaw config` | เปิด interactive config menu |

### Terminal UI (TUI)

```bash
# เปิด Terminal UI — คุยกับ bot ผ่าน terminal
openclaw-tui

# TUI เหมาะสำหรับ:
# - First-time setup (เห็น personality config แบบ real-time)
# - Quick testing ก่อนเชื่อม channels
# - Troubleshooting (ดู response โดยตรง)
```

### Agent Commands

```bash
# ส่งข้อความให้ agent
openclaw agent --message "Ship checklist" --thinking high

# ส่งข้อความพร้อมส่งกลับไปยัง channel
openclaw agent --message "สรุปงานวันนี้" --deliver whatsapp

# ดูรายชื่อ agents
openclaw agent list
```

### Message Commands

```bash
# ส่งข้อความตรง
openclaw message send --to +1234567890 --message "Hello from OpenClaw"

# ส่งไฟล์
openclaw message send --to +1234567890 --file ./report.pdf
```

### Pairing (DM Security)

```bash
# ดูรายการ pairing codes ที่รอ approve
openclaw pairing list whatsapp
openclaw pairing list telegram

# Approve user
openclaw pairing approve whatsapp <code>
openclaw pairing approve telegram <code>

# Default: unknown DMs จะได้ pairing code ต้อง approve ก่อน bot จะตอบ
```

### Model CLI Commands

```bash
# ดูรายการ models ที่ตั้งค่าไว้
openclaw models list
openclaw models list --all
openclaw models list --provider anthropic

# เปลี่ยน primary model
openclaw models set anthropic/claude-opus-4-6
openclaw models set moonshot/kimi-k2-0905-preview
openclaw models set zai/glm-4.7

# เปลี่ยน image model
openclaw models set-image anthropic/claude-sonnet-4-5

# จัดการ aliases
openclaw models aliases list
openclaw models aliases add kimi moonshot/kimi-k2-0905-preview
openclaw models aliases add opus anthropic/claude-opus-4-6
openclaw models aliases add glm zai/glm-4.7
openclaw models aliases remove <alias>

# จัดการ fallbacks
openclaw models fallbacks list
openclaw models fallbacks add zai/glm-4.7
openclaw models fallbacks add anthropic/claude-sonnet-4-5
openclaw models fallbacks remove <model>
openclaw models fallbacks clear          # ปิด fallback ทั้งหมด

# Image fallbacks
openclaw models image-fallbacks list
openclaw models image-fallbacks add openai/gpt-4o

# Auth management
openclaw models auth list
openclaw models auth add                 # interactive
openclaw models auth setup-token         # paste Claude setup-token
openclaw models auth status              # เช็ค auth + OAuth expiry

# Model status
openclaw models status                   # detailed: auth, endpoint, api mode
openclaw models status --plain           # แค่ resolved primary model
openclaw models status --json            # JSON format
openclaw models status --check           # exit 1 if missing, exit 2 if expiring

# Scan free models (OpenRouter)
openclaw models scan                     # หา free models
openclaw models scan --probe             # ทดสอบ tool/image support
openclaw models scan --set-primary       # ตั้งเป็น primary เลย
openclaw models scan --set-image         # ตั้งเป็น image model
```

### Slash Commands (ใน chat)

```bash
# สลับ model ขณะคุยได้เลย
/model                    # ดู model ปัจจุบัน
/model list               # ดูรายการทั้งหมด
/model 3                  # เลือกจาก list (หมายเลข)
/model opus               # ใช้ alias
/model moonshot/kimi-k2.5 # ใช้ full ref
/model status             # ดูรายละเอียด auth + endpoint

# Session management
/new                      # เริ่ม session ใหม่
/clear                    # ล้าง context

# Thinking mode
/think                    # เปิด thinking
/think high               # thinking level สูง
/think off                # ปิด thinking
```

### Skill CLI Commands

```bash
# Validate skill
openclaw skill validate ./my-skill

# Test skill
openclaw skill test ./my-skill --verbose

# Install skill locally
openclaw skill install ./my-skill --local

# List loaded skills
openclaw skill list
```

---

## 🧠 MODEL CONFIGURATION & MULTI-MODEL SWITCHING

### Config File Location

```
~/.openclaw/openclaw.json
```

### ✅ ตัวอย่าง: Kimi เป็นหลัก + GLM 5 Fallback + Claude Max ($100/mo)

```jsonc
{
  // === Environment Variables ===
  "env": {
    "MOONSHOT_API_KEY": "sk-your-moonshot-key",
    "ANTHROPIC_API_KEY": "sk-ant-your-key"
    // GLM (Z.AI) ใช้ built-in provider ตั้ง auth ผ่าน CLI
  },

  // === Agent Defaults ===
  "agents": {
    "defaults": {
      // Primary Model: Kimi K2.5 (Moonshot AI)
      "model": {
        "primary": "moonshot/kimi-k2-0905-preview",
        "fallbacks": [
          "zai/glm-4.7",                    // GLM 5 (Z.AI) — coding/tool calling ดี
          "anthropic/claude-sonnet-4-5"       // Claude Sonnet — fallback สุดท้าย
        ]
      },

      // Image Model (สำหรับรับรูป/vision)
      "imageModel": {
        "primary": "anthropic/claude-sonnet-4-5",
        "fallbacks": [
          "openai/gpt-4o"
        ]
      },

      // Model Allowlist + Aliases
      "models": {
        "moonshot/kimi-k2-0905-preview": { "alias": "kimi" },
        "zai/glm-4.7": { "alias": "glm" },
        "anthropic/claude-sonnet-4-5": { "alias": "sonnet" },
        "anthropic/claude-opus-4-6": { "alias": "opus" }
      }
    }
  },

  // === Custom Provider: Moonshot (Kimi) ===
  "models": {
    "mode": "merge",
    "providers": {
      "moonshot": {
        "baseUrl": "https://api.moonshot.ai/v1",
        "apiKey": "${MOONSHOT_API_KEY}",
        "api": "openai-completions",
        "models": [
          { "id": "kimi-k2-0905-preview", "name": "Kimi K2.5" },
          { "id": "kimi-k2", "name": "Kimi K2" }
        ]
      }
    }
  }
}
```

### CLI วิธีตั้งค่าแบบไม่แก้ไฟล์

```bash
# 1. ตั้ง Kimi เป็น primary
openclaw models set moonshot/kimi-k2-0905-preview

# 2. เพิ่ม GLM เป็น fallback
openclaw models fallbacks add zai/glm-4.7

# 3. เพิ่ม Claude เป็น fallback ที่ 2
openclaw models fallbacks add anthropic/claude-sonnet-4-5

# 4. สร้าง aliases สำหรับสลับเร็ว
openclaw models aliases add kimi moonshot/kimi-k2-0905-preview
openclaw models aliases add glm zai/glm-4.7
openclaw models aliases add sonnet anthropic/claude-sonnet-4-5
openclaw models aliases add opus anthropic/claude-opus-4-6

# 5. ตั้ง auth
openclaw models auth add                 # interactive menu
openclaw models auth setup-token         # สำหรับ Anthropic (Claude)
```

### สลับ Model ขณะใช้งาน

```bash
# ใน chat พิมพ์:
/model kimi       # สลับไป Kimi (งานทั่วไป)
/model glm        # สลับไป GLM (coding/tool calling)
/model opus       # สลับไป Claude Opus (งานซับซ้อน)
/model sonnet     # สลับไป Claude Sonnet (balance)

# กลับไป primary
/model kimi
```

### Claude Max ($100/mo) — Community Proxy

Claude Max subscription ($100/mo) สามารถใช้กับ OpenClaw ผ่าน community proxy:

```jsonc
// วิธีที่ 1: ใช้ claude setup-token (แนะนำ)
// รัน claude setup-token แล้ว paste ใน:
// openclaw models auth setup-token

// วิธีที่ 2: OpenCode Zen (Claude Max proxy)
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "opencode/claude-opus-4-5"
      }
    }
  }
}
```

```bash
# ตั้งค่า OpenCode Zen
openclaw onboard --auth-choice opencode-zen
openclaw models set opencode/claude-opus-4-5
openclaw models list
```

### Built-in Providers (ไม่ต้อง config เพิ่ม)

| Provider | Models | Auth |
|----------|--------|------|
| **Anthropic** | Claude Opus/Sonnet/Haiku | API key / setup-token |
| **OpenAI** | GPT-4o, GPT-5, o-series | API key / OAuth |
| **Z.AI (GLM)** | GLM-4.7, GLM-4.6 | API key |
| **Google** | Gemini 3 Flash/Pro | API key |
| **OpenRouter** | 200+ models | API key |
| **Cerebras** | GLM models (zai-glm-4.7) | API key |
| **xAI** | Grok models | API key |
| **Groq** | Fast inference | API key |
| **Ollama** | Local models | Local (no key) |

### Custom Providers (ต้อง config)

| Provider | Config Key | Notes |
|----------|-----------|-------|
| **Moonshot (Kimi)** | `moonshot` | OpenAI-compatible endpoint |
| **Kimi Code** | `kimi-code` | Dedicated coding endpoint |
| **MiniMax** | `minimax` | Good for writing/vibes |
| **Qwen** | `qwen` | Alibaba models |
| **Venice AI** | `venice` | Privacy-focused |

### Model Failover Flow

```
1. Primary Model (e.g., Kimi K2.5)
   ↓ (fail: rate limit / auth expired / unavailable)
2. Auth Profile Rotation (ลอง key/token อื่นของ provider เดียวกัน)
   ↓ (all profiles fail)
3. Fallback 1 (e.g., GLM 4.7)
   ↓ (fail)
4. Fallback 2 (e.g., Claude Sonnet)
   ↓ (fail)
5. Error → return to user
```

### Cost Optimization Tips

```
งานง่าย (heartbeat, status) → ใช้ model ถูก (Gemini Flash-Lite $0.50/M)
งานทั่วไป (chat, research)  → Kimi K2.5 (free tier มี / paid ถูก)
งาน coding/tools             → GLM 4.7 (ดีสำหรับ tool calling)
งานซับซ้อน (architecture)    → Claude Opus ($15/$75 per M tokens)

# ใช้ OpenRouter Auto Model ประหยัดสุด
openclaw models set openrouter/openrouter/auto
```

---

## 📱 CHANNEL SETUP

### Supported Channels

| Channel | Type | Setup |
|---------|------|-------|
| **WhatsApp** | QR Code scan | Dedicated phone # recommended |
| **Telegram** | Bot Token | @BotFather → token |
| **Discord** | Bot Token | Developer Portal → token |
| **Slack** | Bot Token | Slack App → token |
| **Signal** | Phone # | Signal CLI |
| **iMessage** | BlueBubbles | macOS only |
| **MS Teams** | Plugin | Teams App |
| **Google Chat** | Bot | Google Workspace |
| **Matrix** | Homeserver | Element/Synapse |
| **Zalo** | API | Zalo Developers |
| **WebChat** | Built-in | http://127.0.0.1:18789 |

### Quick Channel Setup

```bash
# Wizard จัดการให้ (แนะนำ)
openclaw onboard

# หรือ config manual:
openclaw config
# → เลือก "Channels" → เลือก platform → ใส่ credentials
```

### WhatsApp Setup

```bash
# 1. Wizard จะแสดง QR code ใน terminal
# 2. เปิด WhatsApp → Settings → Linked Devices → Scan QR
# 3. Credentials เก็บที่ ~/.openclaw/credentials/whatsapp/

# Tips:
# - ใช้เบอร์แยก (dedicated) ดีกว่า
# - VoIP numbers ไม่แนะนำ (โดน block ง่าย)
# - WhatsApp ตอบข้อความที่ส่งหาตัวเอง
```

### Telegram Setup

```bash
# 1. คุยกับ @BotFather บน Telegram
# 2. สร้าง bot → ได้ token
# 3. ใส่ token ใน wizard หรือ config

# DM Security:
# - DM แรกจะได้ pairing code
# - ต้อง approve ก่อน bot จะตอบ
openclaw pairing list telegram
openclaw pairing approve telegram <code>
```

### DM Policy

```jsonc
// openclaw.json
{
  "channels": {
    "discord": {
      "dmPolicy": "pairing"     // default: ต้อง approve
      // "dmPolicy": "open"     // เปิดรับทุกคน (⚠️ ระวัง)
    },
    "slack": {
      "dmPolicy": "pairing",
      "allowFrom": ["user1@company.com"]
    }
  }
}
```

```bash
# เช็ค DM policy ที่อาจมีปัญหา
openclaw doctor
```

---

## 🤖 MULTI-AGENT ROUTING

### Concept

OpenClaw สามารถมีหลาย agents แต่ละตัวมี:
- Workspace แยก (skills, memory, sessions)
- Model config แยก
- Channel bindings แยก

### Config Example

```jsonc
{
  "agents": {
    "defaults": {
      "model": { "primary": "moonshot/kimi-k2-0905-preview" }
    },
    "list": [
      {
        "id": "general",
        "name": "Assistant",
        "model": { "primary": "moonshot/kimi-k2-0905-preview" },
        "bindings": {
          "channels": ["whatsapp", "telegram"]
        }
      },
      {
        "id": "coder",
        "name": "Code Agent",
        "model": { "primary": "zai/glm-4.7" },
        "bindings": {
          "channels": ["discord"]
        }
      },
      {
        "id": "writer",
        "name": "Writer Agent",
        "model": { "primary": "anthropic/claude-opus-4-6" },
        "bindings": {
          "channels": ["slack"]
        }
      }
    ]
  }
}
```

---

## 📦 SKILLS & CLAWHUB REGISTRY

### Registry Stats (Feb 2026)

| Metric | Value |
|--------|-------|
| **Total Skills** | 5,705+ |
| **Curated List** | 3,002 (awesome-openclaw-skills) |
| **Categories** | 31 |
| **Downloads** | 1.5M+ |
| **Registry** | https://clawhub.ai |
| **CLI** | `npm i -g clawhub` |

### Skill Installation

```bash
# Install ClawHub CLI
npm i -g clawhub

# ค้นหา skill (semantic search)
clawhub search "send email with attachments"
clawhub search "youtube video transcription"

# ตรวจสอบก่อนติดตั้ง
clawhub inspect <slug>

# ติดตั้ง
clawhub install github
clawhub install agent-browser
clawhub install tavily

# Pin version
clawhub install my-skill --version 1.2.3

# อัปเดตทั้งหมด
clawhub update --all

# Preview updates
clawhub sync --dry-run
```

### Essential Starter Packs

```bash
# 🔧 Developer
clawhub install github
clawhub install coding-agent
clawhub install frontend-design
clawhub install agent-browser
clawhub install tavily

# 🎵 Content Creator
clawhub install fal-ai
clawhub install veo
clawhub install ffmpeg-video-editor
clawhub install youtube-api
clawhub install x-articles

# ☁️ DevOps
clawhub install cloudflare
clawhub install vercel
clawhub install docker-essentials
clawhub install kubernetes
clawhub install senior-devops

# 📋 Productivity
clawhub install better-notion
clawhub install slack
clawhub install calctl
clawhub install smtp-send
clawhub install context-recovery

# 🏠 Smart Home
clawhub install home-assistant
clawhub install hass-cli
clawhub install appletv

# 🔍 Research & AI
clawhub install tavily
clawhub install firecrawl-search
clawhub install deepwiki
clawhub install chromadb-memory
clawhub install proactive-research
```

### Top Categories (31 categories)

| Category | Skills | Top Examples |
|----------|--------|-------------|
| Developer Tools | 976 | github, coding-agent, senior-fullstack |
| Productivity | 822 | notion, logseq, calctl |
| AI & LLMs | 159 | gemini, chromadb-memory, agenticflow |
| Search & Research | 148 | tavily, exa-plus, firecrawl |
| DevOps & Cloud | 144 | cloudflare, vercel, kubernetes |
| Marketing & Sales | 94 | activecampaign, linkedin, x-articles |
| Browser & Automation | 69 | agent-browser, playwright, n8n |
| Communication | 58 | slack, discord, smtp-send |
| Smart Home & IoT | 50 | home-assistant, switchbot |
| Image & Video Gen | 41 | fal-ai, veo, comfyui |

### Skill File Locations

| Priority | Path | Scope |
|----------|------|-------|
| 1 (highest) | `<workspace>/skills/` | Project-specific |
| 2 | `~/.openclaw/skills/` | User-global |
| 3 (lowest) | Bundled skills | OpenClaw built-in |

### Three-Tier Loading System

```
Tier 1: NAME + DESCRIPTION only (30-50 tokens per skill)
   → Agent รู้ว่ามี skill อะไรบ้าง

Tier 2: Full SKILL.md body loaded
   → เมื่อ agent ตัดสินใจว่า skill เกี่ยวข้อง

Tier 3: Reference files loaded on-demand
   → เมื่อต้องการ deep knowledge
```

### Create Custom Skill

```bash
# สร้างโครงสร้าง
mkdir -p ~/.openclaw/skills/my-skill/references
mkdir -p ~/.openclaw/skills/my-skill/scripts

# สร้าง SKILL.md
cat > ~/.openclaw/skills/my-skill/SKILL.md << 'EOF'
---
name: my-skill
description: Description with trigger keywords
metadata:
  openclaw:
    emoji: "🚀"
    requires:
      bins: ["node"]
---

# My Skill

## Instructions
[Your instructions here]

## Reference Files
For API docs, see `{baseDir}/references/api-docs.md`
Run helper: `python3 {baseDir}/scripts/process.py`
EOF

# Validate
openclaw skill validate ~/.openclaw/skills/my-skill

# Test
openclaw skill test ~/.openclaw/skills/my-skill --verbose
```

### Publish to ClawHub

```bash
clawhub login
openclaw skill validate ./my-skill
clawhub publish ./my-skill \
  --slug my-skill \
  --name "My Skill" \
  --version 1.0.0
```

### Skill Config in openclaw.json

```jsonc
{
  "skills": {
    "load": {
      "enabled": true,
      "allowBundled": [],           // empty = load all
      "extraDirs": ["/shared/team-skills"]
    },
    "entries": {
      "github": {
        "env": { "GITHUB_TOKEN": "ghp_xxx" }
      },
      "tavily": {
        "apiKey": "tvly-xxx"
      }
    }
  }
}
```

---

## 🩺 TROUBLESHOOTING & DOCTOR

### openclaw doctor

```bash
# วินิจฉัยปัญหาทั้งหมด
openclaw doctor

# วินิจฉัย + แก้ไขอัตโนมัติ
openclaw doctor --fix
```

Doctor เช็ค:
- ✅ Node.js version
- ✅ Gateway daemon status
- ✅ Auth credentials (API keys, OAuth expiry)
- ✅ DM policy security
- ✅ Channel connections
- ✅ Skill loading
- ✅ Config syntax

### Common Issues & Fixes

**Bot ไม่ตอบ DM**
```bash
# เช็ค pairing
openclaw pairing list whatsapp
openclaw pairing approve whatsapp <code>
```

**"No API key found for provider"**
```bash
# เพิ่ม auth
openclaw models auth add
# หรือ setup-token สำหรับ Anthropic
openclaw models auth setup-token
```

**"Model is not allowed"**
```bash
# เพิ่ม model ใน allowlist
openclaw models list --all
openclaw models set <provider/model>
```

**Gateway ไม่เริ่ม**
```bash
openclaw health
openclaw gateway --port 18789 --verbose
# ดู logs
journalctl -u openclaw -f          # Linux
log show --predicate 'subsystem == "openclaw"' --last 1h   # macOS
```

**OAuth expired**
```bash
openclaw models auth status
# ถ้า expiring/expired:
openclaw models auth setup-token    # Anthropic
openclaw onboard --auth-choice openai-oauth  # OpenAI
```

**WhatsApp disconnected**
```bash
# Re-scan QR
openclaw config
# → Channels → WhatsApp → Re-link
```

### Debug Commands

```bash
# Full status report (best for sharing)
openclaw status --all

# Check model auth
openclaw models status --check
# exit 0 = OK, exit 1 = missing, exit 2 = expiring

# Verbose gateway
openclaw gateway --verbose
```

---

## ⚙️ ADVANCED CONFIGURATION

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `OPENCLAW_HOME` | Home directory for internal paths |
| `OPENCLAW_STATE_DIR` | Override state directory |
| `OPENCLAW_CONFIG_PATH` | Override config file path |
| `ANTHROPIC_API_KEY` | Anthropic auth |
| `OPENAI_API_KEY` | OpenAI auth |
| `OPENROUTER_API_KEY` | OpenRouter auth |
| `MOONSHOT_API_KEY` | Moonshot (Kimi) auth |

### Voice & Talk Mode

```bash
# macOS/iOS/Android: always-on speech
# ต้องการ ElevenLabs API key

# Wake words (global)
# Config: voice.wake.words
```

### Canvas

```bash
# Live Canvas — render visual content
# ใช้ผ่าน Control UI
# http://127.0.0.1:18789/
```

### Cron Jobs / Webhooks

```jsonc
{
  "automation": {
    "cron": [
      {
        "schedule": "0 9 * * *",         // ทุกวัน 9:00
        "message": "สรุปข่าววันนี้",
        "channel": "whatsapp"
      }
    ],
    "webhooks": {
      "enabled": true,
      "endpoints": [
        {
          "path": "/webhook/github",
          "secret": "my-secret"
        }
      ]
    }
  }
}
```

### Headless Server Setup

```bash
# สำหรับ VPS/server ที่ไม่มี browser:
# 1. ทำ OAuth บนเครื่องที่มี browser ก่อน
# 2. Copy oauth.json ไปยัง server

scp ~/.openclaw/credentials/oauth.json user@server:~/.openclaw/credentials/

# 3. รัน onboard บน server
openclaw onboard --install-daemon
```

---

## 🔒 SECURITY BEST PRACTICES

### DM Security

- Default `dmPolicy: "pairing"` — unknown users ต้อง approve
- ใช้ `openclaw doctor` เช็ค risky DM policies
- อย่าตั้ง `dmPolicy: "open"` ถ้าไม่จำเป็น

### Skill Security

```bash
# ⚠️ ClawHavoc Alert (Feb 2026): 341 malicious skills found!

# ก่อนติดตั้ง skill ใดๆ:
# 1. Check VirusTotal — ดูที่ ClawHub page
# 2. Review SKILL.md — permissions, env vars, network calls
# 3. Check author — GitHub age ≥1 week, profile
# 4. Test in sandbox — sandbox.mode: "non-main"
# 5. Inspect first — clawhub inspect <slug>
```

### Red Flags 🚩

- Skill ขอติดตั้ง "prerequisites" จาก external links
- Code ที่ obfuscated/minified
- ขอ permissions มากเกินไป
- Download external scripts at runtime
- ไม่มี VirusTotal report

### Agent Safety

- OpenClaw มี system access — treat เหมือน programmable assistant
- คำสั่งที่คลุมเครืออาจทำให้ modify files, overwrite data
- ใช้ sandbox mode สำหรับ skill ที่ไม่ไว้ใจ
- Review ก่อนให้ agent รัน shell commands

---

## 📚 USEFUL LINKS

| Resource | URL |
|----------|-----|
| **Official Docs** | https://docs.openclaw.ai |
| **GitHub** | https://github.com/openclaw/openclaw |
| **ClawHub Registry** | https://clawhub.ai |
| **Skills.sh** | https://skills.sh |
| **DeepWiki** | https://deepwiki.com/openclaw/openclaw |
| **Discord Community** | Friends of the Crustacean 🦞 |
| **Awesome OpenClaw** | github.com/VoltAgent/awesome-openclaw-skills |
| **npm** | https://www.npmjs.com/package/openclaw |
| **OpenRouter Guide** | https://openrouter.ai/docs/guides/openclaw-integration |

---

## 🎯 QUICK START CHECKLIST

```
□ 1. ติดตั้ง: curl -fsSL https://openclaw.ai/install.sh | bash
□ 2. Onboard: openclaw onboard --install-daemon
□ 3. Auth: ตั้ง API key (Anthropic/OpenAI/Moonshot/OpenRouter)
□ 4. Channel: เชื่อม WhatsApp/Telegram/Discord
□ 5. Test: openclaw-tui (คุยผ่าน terminal)
□ 6. Doctor: openclaw doctor --fix
□ 7. Skills: clawhub install github agent-browser tavily
□ 8. Model: openclaw models set <preferred-model>
□ 9. Alias: openclaw models aliases add kimi moonshot/kimi-k2-0905-preview
□ 10. Done! 🦞
```