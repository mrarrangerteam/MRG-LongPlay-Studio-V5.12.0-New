# mrarranger-promptlib

**Source:** `/mnt/skills/user/mrarranger-promptlib/SKILL.md`
**Size:** 5936 bytes

---

---
name: mrarranger-promptlib
description: |
  คลัง Mega Prompts 500+ สำหรับทุก AI Platform พร้อมใช้งานทันที รองรับ Suno, Midjourney, DALL-E, Runway, Kling, Veo, ChatGPT, Gemini, Stable Diffusion, Flux, Leonardo, Ideogram และอื่นๆ
  ใช้เมื่อ: (1) ต้องการ prompt สำหรับ AI ใดๆ (2) สร้าง prompt คุณภาพสูง (3) ต้องการ template prompt (4) batch สร้าง prompts (5) optimize prompt ให้ดีขึ้น (6) แปลง idea เป็น prompt
  Commands: /prompt [platform] [type], /mega [platform], /batch [platform] [count], /optimize [prompt], /convert [from] [to]
---

# MRARRANGER Prompt Library

## Quick Start

```
/prompt midjourney portrait     → สร้าง portrait prompt สำหรับ MJ
/mega suno                      → Mega prompt เพลงสำหรับ Suno
/batch runway 10                → สร้าง 10 video prompts
/optimize [your prompt]         → ปรับปรุง prompt ให้ดีขึ้น
```

## Supported Platforms

### 🎵 Music AI
- **Suno** - ดู references/suno-prompts.md
- **Udio** - ดู references/udio-prompts.md

### 🎨 Image AI
- **Midjourney** - ดู references/midjourney-prompts.md
- **DALL-E** - ดู references/dalle-prompts.md
- **Stable Diffusion/Flux** - ดู references/sd-flux-prompts.md
- **Leonardo** - ดู references/leonardo-prompts.md
- **Ideogram** - ดู references/ideogram-prompts.md

### 🎬 Video AI
- **Runway/Gen-3** - ดู references/runway-prompts.md
- **Kling** - ดู references/kling-prompts.md
- **Veo/Sora** - ดู references/veo-sora-prompts.md
- **Pika/Luma** - ดู references/pika-luma-prompts.md

### 🤖 LLM Prompts
- **System Prompts** - ดู references/system-prompts.md
- **Chain-of-Thought** - ดู references/cot-prompts.md
- **Role Prompts** - ดู references/role-prompts.md

## Core Prompt Formulas

### Universal Mega Prompt Formula
```
[SUBJECT] + [STYLE] + [MOOD] + [TECHNICAL] + [PLATFORM-SPECIFIC]
```

### Platform-Specific Patterns

**Midjourney Pattern:**
```
[subject], [style descriptors], [lighting], [camera], [mood] --ar [ratio] --v [version] --s [stylize]
```

**Suno Pattern:**
```
[Genre], [Subgenre], [Mood], [Instruments], [Tempo], [Vocal Style], [Era/Influence]
```

**Runway Pattern:**
```
[Camera Movement]: [Subject Action] in [Environment], [Lighting], [Style], [Duration hint]
```

## Prompt Enhancement Techniques

### 1. Specificity Ladder
```
Level 1: A cat
Level 2: A fluffy orange cat
Level 3: A fluffy orange Persian cat sitting on velvet cushion
Level 4: A majestic fluffy orange Persian cat with golden eyes, sitting regally on a deep purple velvet cushion, soft window light, shallow depth of field
```

### 2. Style Injection
```
Base: Portrait of a woman
+ Art Style: Portrait of a woman in the style of Alphonse Mucha
+ Era: Art Nouveau portrait of a woman, 1890s aesthetic
+ Technical: Art Nouveau portrait, ornate floral borders, muted gold and sage palette, lithograph texture
```

### 3. Negative Prompt Strategy
```
Universal Negatives: blurry, low quality, distorted, ugly, bad anatomy, watermark, signature, text
Style-Specific: [varies by desired output]
```

## Batch Generation System

### Template Variables
```
{subject} - Main subject
{style} - Art/visual style
{mood} - Emotional tone
{color} - Color palette
{setting} - Environment/background
{camera} - Camera angle/type
{lighting} - Light source/quality
```

### Batch Example
```python
# Generate 10 variations
template = "{subject} in {setting}, {lighting}, {style} style, {mood} atmosphere"
variables = {
    "subject": ["warrior", "dancer", "musician"],
    "setting": ["ancient temple", "neon city", "misty forest"],
    "lighting": ["golden hour", "dramatic shadows", "soft diffused"],
    "style": ["cinematic", "anime", "oil painting"],
    "mood": ["epic", "serene", "mysterious"]
}
```

## Quality Checklist

Before finalizing any prompt:
- [ ] Subject clearly defined
- [ ] Style/aesthetic specified
- [ ] Technical parameters included
- [ ] Platform-specific syntax correct
- [ ] Negative prompts added (if applicable)
- [ ] Aspect ratio/duration specified
- [ ] Version/model specified

## Commands Reference

| Command | Description | Example |
|---------|-------------|---------|
| `/prompt [platform] [type]` | สร้าง prompt เดี่ยว | `/prompt midjourney cyberpunk` |
| `/mega [platform]` | Mega prompt แบบละเอียด | `/mega suno` |
| `/batch [platform] [n]` | สร้าง n prompts | `/batch runway 20` |
| `/optimize [prompt]` | ปรับปรุง prompt | `/optimize a cat sitting` |
| `/convert [from] [to]` | แปลง prompt ข้าม platform | `/convert midjourney dalle` |
| `/style [name]` | Apply style preset | `/style cinematic` |
| `/negative [platform]` | แนะนำ negative prompts | `/negative sd` |

## Advanced: Prompt DNA Analysis

เมื่อได้รับ prompt ที่ดี สามารถวิเคราะห์ DNA:
```
1. Subject Analysis - อะไรคือ subject หลัก
2. Style Markers - คำไหนกำหนด style
3. Technical Specs - parameters อะไรบ้าง
4. Mood Indicators - อะไรสร้าง mood
5. Unique Elements - อะไรทำให้ prompt นี้พิเศษ
```

## File References

สำหรับ prompts เฉพาะทาง ให้อ่านไฟล์ใน references/:
- `references/suno-prompts.md` - 100+ Suno prompts by genre
- `references/midjourney-prompts.md` - 100+ MJ prompts by style
- `references/runway-prompts.md` - 50+ video prompts
- `references/system-prompts.md` - 50+ system prompts for LLMs
- `references/mega-templates.md` - Mega prompt templates