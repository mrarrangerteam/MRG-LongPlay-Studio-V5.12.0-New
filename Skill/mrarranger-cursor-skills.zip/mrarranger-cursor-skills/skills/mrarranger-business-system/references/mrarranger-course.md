# mrarranger-course

**Source:** `/mnt/skills/user/mrarranger-course/SKILL.md`
**Size:** 11465 bytes

---

---
name: "mrarranger-course"
description: "MRARRANGER Course & Education - ระบบสร้าง Online Course, Workshop, และ Educational Content รองรับ Course Structure, Curriculum Design, Lesson Scripts, และ Learning Materials ใช้เมื่อ: (1) ออกแบบ Online Course (2) สร้าง Workshop (3) เขียน Curriculum (4) สร้าง Lesson Plans (5) ทำ Learning Materials (6) สร้าง Quiz/Assessment Commands: /course /workshop /curriculum /lesson /quiz /module /outline"
---
  Commands: /course /workshop /curriculum /lesson /quiz /module /outline
---

# MRARRANGER Course & Education Creator

## Quick Commands

| Command | Output |
|---------|--------|
| `/course [topic]` | Full course structure + curriculum |
| `/workshop [topic]` | Workshop outline + activities |
| `/curriculum [course]` | Detailed curriculum breakdown |
| `/lesson [topic]` | Lesson plan + script |
| `/quiz [topic]` | Quiz/Assessment questions |
| `/module [topic]` | Single module design |
| `/outline [topic]` | Quick course outline |

## Course Design Framework

### ADDIE Model
```
A = ANALYZE   → Who is the learner? What do they need?
D = DESIGN    → Learning objectives, structure, assessment
D = DEVELOP   → Create content, materials, activities
I = IMPLEMENT → Deliver the course
E = EVALUATE  → Measure results, improve
```

### Course Structure Template
```
📚 COURSE: [Course Name]
🎯 Target: [Who is this for]
⏱️ Duration: [Total hours]
📋 Modules: [Number of modules]

═══════════════════════════════════════

🎯 LEARNING OUTCOMES
By the end of this course, students will be able to:
1. [Outcome 1 - action verb + skill]
2. [Outcome 2 - action verb + skill]
3. [Outcome 3 - action verb + skill]
4. [Outcome 4 - action verb + skill]

📋 COURSE OUTLINE

Module 1: [Foundation]
├── Lesson 1.1: [Topic]
├── Lesson 1.2: [Topic]
├── Lesson 1.3: [Topic]
└── Quiz 1

Module 2: [Core Skills]
├── Lesson 2.1: [Topic]
├── Lesson 2.2: [Topic]
├── Lesson 2.3: [Topic]
└── Quiz 2

Module 3: [Advanced]
├── Lesson 3.1: [Topic]
├── Lesson 3.2: [Topic]
├── Lesson 3.3: [Topic]
└── Quiz 3

Module 4: [Application]
├── Project Workshop
├── Case Studies
└── Final Assessment

🎁 BONUSES
• Bonus 1: [Resource/Template]
• Bonus 2: [Community Access]
• Bonus 3: [1-on-1 Session]
```

## Lesson Plan Template

### Single Lesson Structure
```
📖 LESSON: [Lesson Title]
📚 Module: [Module Name]
⏱️ Duration: [X minutes]
🎯 Objective: [What student will learn/do]

═══════════════════════════════════════

📋 LESSON OUTLINE

1. HOOK (2-3 min)
   • [Attention grabber]
   • [Why this matters]
   • [Preview of lesson]

2. TEACH (10-15 min)
   • Concept 1: [Explanation]
   • Concept 2: [Explanation]
   • Concept 3: [Explanation]

3. SHOW (5-10 min)
   • Demo/Example 1
   • Demo/Example 2
   • Common mistakes to avoid

4. DO (10-15 min)
   • Exercise/Activity
   • Practice problem
   • Hands-on task

5. REVIEW (2-3 min)
   • Key takeaways
   • Action items
   • Preview next lesson

📎 MATERIALS
• Slides: [Link]
• Worksheet: [Link]
• Resources: [Links]

✅ ASSESSMENT
• Quick quiz: [3-5 questions]
• Assignment: [Task description]
```

## Video Lesson Script Template

```
🎬 VIDEO LESSON: [Title]
⏱️ Duration: [X minutes]
🎯 Objective: [Learning goal]

═══════════════════════════════════════

[0:00-0:30] HOOK
"[Opening line that grabs attention]"

"In this lesson, you'll learn [outcome] so that you can [benefit]."

"Let's dive in!"

---

[0:30-2:00] CONTEXT
"Before we start, let's understand why this matters..."

"[Background/context information]"

"[Connect to their goals/pain points]"

---

[2:00-X:00] MAIN CONTENT

## Section 1: [Topic]
"[Teach concept]"

"[Show example]"

"[Key point to remember]"

## Section 2: [Topic]
"[Teach concept]"

"[Show example]"

"[Key point to remember]"

## Section 3: [Topic]
"[Teach concept]"

"[Show example]"

"[Key point to remember]"

---

[X:00-X:30] RECAP
"Let's quickly recap what we covered:"

"1. [Key point 1]"
"2. [Key point 2]"
"3. [Key point 3]"

---

[X:30-END] CALL TO ACTION
"Your action step for this lesson is: [specific task]"

"Complete this before moving to the next lesson."

"I'll see you in the next video where we'll cover [next topic]!"

═══════════════════════════════════════

📝 NOTES FOR RECORDING
• B-roll needed: [List]
• Screen recordings: [List]
• Graphics/animations: [List]
• Props: [List]
```

## Workshop Design Template

```
🎓 WORKSHOP: [Workshop Name]
⏱️ Duration: [X hours]
👥 Participants: [Number]
🎯 Outcome: [What participants will achieve]

═══════════════════════════════════════

📋 WORKSHOP AGENDA

[TIME] Welcome & Icebreaker (15 min)
• Introduction
• Expectations setting
• Quick icebreaker activity

[TIME] Session 1: [Topic] (45 min)
• Teaching: [20 min]
• Activity: [20 min]
• Q&A: [5 min]

[TIME] Break (10 min)

[TIME] Session 2: [Topic] (45 min)
• Teaching: [20 min]
• Activity: [20 min]
• Q&A: [5 min]

[TIME] Session 3: [Topic] (45 min)
• Teaching: [15 min]
• Hands-on exercise: [25 min]
• Share results: [5 min]

[TIME] Break (10 min)

[TIME] Implementation Planning (30 min)
• Personal action plan
• Accountability partner pairing
• Resource distribution

[TIME] Wrap-up & Next Steps (15 min)
• Key takeaways
• Q&A
• Feedback collection

═══════════════════════════════════════

📎 MATERIALS NEEDED
• Slides: [X slides]
• Worksheets: [List]
• Tools: [List]
• Handouts: [List]

🎯 ACTIVITIES

Activity 1: [Name]
• Objective: [What they'll learn/do]
• Instructions: [Step-by-step]
• Time: [X minutes]
• Materials: [What they need]

Activity 2: [Name]
• Objective: [What they'll learn/do]
• Instructions: [Step-by-step]
• Time: [X minutes]
• Materials: [What they need]

✅ SUCCESS METRICS
• Participant satisfaction: [Target]
• Learning retention: [How to measure]
• Implementation rate: [How to track]
```

## Quiz/Assessment Templates

### Multiple Choice
```
❓ QUESTION [Number]:
[Question text]

A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]

✅ Correct: [Letter]
💡 Explanation: [Why this is correct]
```

### True/False
```
❓ QUESTION [Number]:
[Statement]

⭕ True    ⭕ False

✅ Correct: [True/False]
💡 Explanation: [Why]
```

### Short Answer
```
❓ QUESTION [Number]:
[Question text]

📝 Expected Answer:
[Key points that should be included]

🎯 Grading Criteria:
• [Criterion 1]: [Points]
• [Criterion 2]: [Points]
• [Criterion 3]: [Points]
```

### Practical Assignment
```
📋 ASSIGNMENT: [Name]
⏱️ Estimated Time: [X hours]
📅 Due: [Date]

═══════════════════════════════════════

🎯 OBJECTIVE
[What student will demonstrate]

📝 INSTRUCTIONS
1. [Step 1]
2. [Step 2]
3. [Step 3]
4. [Step 4]

📎 DELIVERABLES
• [What to submit 1]
• [What to submit 2]

✅ GRADING RUBRIC
┌────────────────┬────────┬────────┬────────┬────────┐
│ Criteria       │ Poor   │ Fair   │ Good   │ Excellent│
├────────────────┼────────┼────────┼────────┼────────┤
│ [Criterion 1]  │ 1      │ 2      │ 3      │ 4      │
│ [Criterion 2]  │ 1      │ 2      │ 3      │ 4      │
│ [Criterion 3]  │ 1      │ 2      │ 3      │ 4      │
└────────────────┴────────┴────────┴────────┴────────┘
Total: /12 points
```

## Course Pricing Framework

### Value-Based Pricing
```
💰 PRICING STRATEGY

Step 1: Calculate Value
• What result does this create? ฿[X]
• How long would it take to learn alone? [X] hours
• What would alternatives cost? ฿[X]

Step 2: Set Price
• Mini Course (1-2 hrs): ฿990 - ฿2,990
• Full Course (5-10 hrs): ฿4,990 - ฿14,990
• Comprehensive (20+ hrs): ฿19,990 - ฿49,990
• Premium + Coaching: ฿49,990+

Step 3: Create Tiers
┌────────────────┬────────────┬────────────┬────────────┐
│ Feature        │ Basic      │ Pro        │ Premium    │
├────────────────┼────────────┼────────────┼────────────┤
│ Core Modules   │ ✅         │ ✅         │ ✅         │
│ Worksheets     │ ✅         │ ✅         │ ✅         │
│ Community      │ ❌         │ ✅         │ ✅         │
│ Q&A Sessions   │ ❌         │ ✅         │ ✅         │
│ 1-on-1 Call    │ ❌         │ ❌         │ ✅         │
│ Lifetime Updates│ ❌        │ ✅         │ ✅         │
├────────────────┼────────────┼────────────┼────────────┤
│ Price          │ ฿[X]       │ ฿[X]       │ ฿[X]       │
└────────────────┴────────────┴────────────┴────────────┘
```

## Reference Files

| File | เมื่อไหร่ต้องอ่าน |
|------|-----------------|
| `references/course-templates.md` | Course structure ทุกประเภท |
| `references/learning-objectives.md` | เขียน Learning Outcomes |
| `references/assessment-bank.md` | Quiz และ Assignment templates |

## Learning Objective Verbs (Bloom's Taxonomy)

### Remember (Knowledge)
```
Define, List, Name, Recall, Recognize, State, Identify
```

### Understand (Comprehension)
```
Describe, Explain, Summarize, Interpret, Classify, Compare
```

### Apply (Application)
```
Apply, Demonstrate, Solve, Use, Implement, Execute
```

### Analyze (Analysis)
```
Analyze, Differentiate, Examine, Compare, Contrast, Organize
```

### Evaluate (Evaluation)
```
Evaluate, Assess, Critique, Judge, Justify, Recommend
```

### Create (Synthesis)
```
Create, Design, Develop, Construct, Produce, Compose
```

## Rules

1. **Learner-Centered** - ทุก content ต้องคิดจากมุมผู้เรียน
2. **Outcome-Based** - กำหนด outcome ก่อน ค่อยสร้าง content
3. **Practical** - เน้น application ไม่ใช่แค่ theory
4. **Engaging** - มี activities และ interaction
5. **Measurable** - มี assessment วัดผลได้