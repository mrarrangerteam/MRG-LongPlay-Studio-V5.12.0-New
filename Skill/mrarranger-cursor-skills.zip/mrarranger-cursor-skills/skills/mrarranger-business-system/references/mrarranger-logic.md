# mrarranger-logic

**Source:** `/mnt/skills/user/mrarranger-logic/SKILL.md`
**Size:** 8206 bytes

---

---
name: mrarranger-logic
description: |
  ระบบ Logic และ Programming ขั้นสูง - Algorithm Design, Data Structures, System Design, Problem Solving, Debugging, Code Optimization
  แก้ปัญหาเชิงตรรกะทุกรูปแบบ ออกแบบระบบ Scale ได้
  ใช้เมื่อ: (1) ออกแบบ Algorithm (2) เลือก Data Structure (3) System Design (4) Debug โค้ด (5) Optimize Performance (6) แก้ Logic Problems
  Commands: /algo [problem], /system [requirements], /debug [code], /optimize [code], /structure [data], /solve [problem]
---

# MRARRANGER Logic System

## Quick Commands

```
/algo [problem]           → ออกแบบ Algorithm
/system [requirements]    → System Design
/debug [code/error]       → หาและแก้ Bug
/optimize [code]          → ปรับปรุง Performance
/structure [data-type]    → เลือก Data Structure
/solve [problem]          → แก้ปัญหา Logic
/complexity [code]        → วิเคราะห์ Time/Space
```

## Problem Solving Framework

### UMPIRE Method
```
U - Understand: เข้าใจปัญหาให้ชัด
    - Input อะไร? Output อะไร?
    - Edge cases?
    - Constraints?

M - Match: จับคู่กับ Pattern ที่รู้
    - เคยเจอปัญหาคล้ายๆ ไหม?
    - Pattern ไหนใช้ได้?

P - Plan: วางแผนก่อนเขียน
    - Pseudocode
    - Step-by-step

I - Implement: เขียนโค้ด
    - ทำตาม Plan
    - เขียนให้อ่านง่าย

R - Review: ตรวจสอบ
    - Test cases
    - Edge cases

E - Evaluate: ประเมิน
    - Time Complexity?
    - Space Complexity?
    - ทำดีกว่าได้ไหม?
```

## Algorithm Patterns

### 1. Two Pointers
```
ใช้เมื่อ: Array/String ที่ sorted หรือหา pair
Pattern:
- left = 0, right = n-1
- เลื่อนเข้าหากัน based on condition

Example Problems:
- Two Sum (sorted array)
- Container with Most Water
- Valid Palindrome
```

### 2. Sliding Window
```
ใช้เมื่อ: หา subarray/substring ที่ optimize อะไรบางอย่าง
Pattern:
- Fixed window: ขนาดคงที่
- Dynamic window: ขยาย/หดตาม condition

Example Problems:
- Maximum Sum Subarray of Size K
- Longest Substring Without Repeating
- Minimum Window Substring
```

### 3. Binary Search
```
ใช้เมื่อ: Sorted data, หาค่าที่ต้องการ
Pattern:
- left, right, mid
- ลดครึ่งทุกรอบ → O(log n)

Example Problems:
- Search in Sorted Array
- Find Peak Element
- Search in Rotated Array
```

### 4. BFS/DFS
```
BFS (Breadth-First): Level by level
- ใช้ Queue
- Shortest path (unweighted)
- Level order traversal

DFS (Depth-First): ลึกก่อน
- ใช้ Stack/Recursion
- Path finding
- Connected components
```

### 5. Dynamic Programming
```
ใช้เมื่อ: Optimal substructure + Overlapping subproblems
Pattern:
1. Define state
2. Find recurrence relation
3. Base case
4. Build up (bottom-up) or memoize (top-down)

Example Problems:
- Fibonacci
- Longest Common Subsequence
- Knapsack
- Coin Change
```

### 6. Greedy
```
ใช้เมื่อ: Local optimal → Global optimal
Pattern:
- Make best choice at each step
- Never reconsider

Example Problems:
- Activity Selection
- Huffman Coding
- Fractional Knapsack
```

### 7. Backtracking
```
ใช้เมื่อ: หาทุก combinations/permutations
Pattern:
- Try → Check → Backtrack if fail
- Recursive exploration

Example Problems:
- N-Queens
- Sudoku Solver
- Generate Parentheses
```

## Data Structures

### When to Use What

```
Array/List:
- Index access O(1)
- Sequential data
- Known size

Linked List:
- Frequent insert/delete at ends
- Unknown size
- No random access needed

Stack (LIFO):
- Undo operations
- Parsing (parentheses)
- DFS

Queue (FIFO):
- BFS
- Task scheduling
- Buffer

Hash Table/Dict:
- O(1) lookup
- Key-value pairs
- Counting/Frequency

Set:
- Unique elements
- O(1) contains check
- Intersection/Union

Heap/Priority Queue:
- Get min/max O(1)
- Insert O(log n)
- Top K problems

Tree:
- Hierarchical data
- Search O(log n) if balanced
- Prefix matching (Trie)

Graph:
- Relationships between entities
- Networks
- Dependencies
```

### Complexity Cheat Sheet

```
Array:
- Access: O(1)
- Search: O(n)
- Insert/Delete: O(n)

Hash Table:
- Access: O(1) avg
- Search: O(1) avg
- Insert/Delete: O(1) avg

Binary Search Tree (balanced):
- Access: O(log n)
- Search: O(log n)
- Insert/Delete: O(log n)

Heap:
- Find min/max: O(1)
- Insert: O(log n)
- Delete min/max: O(log n)
```

## System Design

### Design Process
```
1. Requirements
   - Functional: ทำอะไรได้บ้าง
   - Non-functional: Scale, Performance, Availability
   
2. Capacity Estimation
   - Users, QPS, Storage, Bandwidth
   
3. High-Level Design
   - Components, Data flow
   
4. Deep Dive
   - Database schema
   - API design
   - Algorithms
   
5. Trade-offs
   - CAP theorem
   - Consistency vs Availability
```

### Scalability Patterns

```
Horizontal Scaling:
- Add more machines
- Load balancer
- Stateless services

Vertical Scaling:
- Bigger machine
- More RAM/CPU
- Has limits

Caching:
- CDN for static
- Redis/Memcached for data
- Cache invalidation strategy

Database:
- Read replicas
- Sharding
- NoSQL for scale

Message Queue:
- Async processing
- Decouple services
- Handle spikes
```

### Common System Designs

```
URL Shortener:
- Hash function
- Base62 encoding
- Database + Cache

Rate Limiter:
- Token bucket
- Sliding window
- Distributed: Redis

Chat System:
- WebSocket
- Message queue
- Online status

News Feed:
- Push vs Pull
- Fan-out
- Ranking algorithm
```

## Debugging Framework

### Systematic Debug Process
```
1. Reproduce
   - ทำให้ bug เกิดซ้ำได้
   - หา minimal test case
   
2. Isolate
   - Binary search หาจุดที่พัง
   - Comment out ทีละส่วน
   
3. Identify
   - Print/Log ค่า
   - Debugger breakpoints
   - ดู state ที่ผิดปกติ
   
4. Fix
   - แก้ root cause ไม่ใช่ symptom
   - ระวัง side effects
   
5. Verify
   - Test case ที่พังต้องผ่าน
   - Test อื่นยังผ่านอยู่
```

### Common Bug Types
```
Off-by-one: index ผิด 1
Null/undefined: ไม่เช็ค null
Race condition: timing issue
Memory leak: ไม่ release
Integer overflow: เลขล้น
Infinite loop: condition ไม่เป็น false
Wrong comparison: == vs ===
```

## Code Optimization

### Performance Tips
```
1. Choose right data structure
   - O(n) → O(1) ด้วย hash table
   
2. Avoid unnecessary work
   - Early return
   - Break/Continue
   
3. Cache results
   - Memoization
   - Precompute
   
4. Batch operations
   - Bulk insert
   - Reduce I/O
   
5. Lazy evaluation
   - Compute when needed
   - Generator/Iterator
```

### Big O Comparison
```
O(1)        - Constant (best)
O(log n)    - Logarithmic (great)
O(n)        - Linear (good)
O(n log n)  - Linearithmic (okay)
O(n²)       - Quadratic (bad)
O(2^n)      - Exponential (terrible)
O(n!)       - Factorial (worst)

For n = 1,000,000:
O(1)     = 1
O(log n) = 20
O(n)     = 1,000,000
O(n²)    = 1,000,000,000,000 ❌
```

## Logic Puzzles Patterns

### Common Patterns
```
Math-based:
- Modulo for cycles
- GCD/LCM
- Prime numbers

Bit Manipulation:
- XOR for find unique
- AND/OR for flags
- Shift for multiply/divide by 2

State Machine:
- Define states
- Transitions
- Finite automata

Simulation:
- Follow rules step by step
- Track state changes
```

## File References

- `references/algorithms.md` - Algorithm templates ทุกประเภท
- `references/system-design.md` - System design examples
- `references/complexity.md` - Big O analysis guide