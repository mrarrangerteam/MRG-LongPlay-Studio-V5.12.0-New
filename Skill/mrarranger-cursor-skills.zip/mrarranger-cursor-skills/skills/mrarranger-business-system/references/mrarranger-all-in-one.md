# mrarranger-all-in-one

**Source:** `/mnt/skills/user/mrarranger-all-in-one/SKILL.md`
**Size:** 92574 bytes

---

---
name: "mrarranger-all-in-one"
description: "MRARRANGER AI Studio - ระบบสร้าง Content ครบวงจร รวม Music (Suno AI), Visual (Video/Image), SEO (YouTube), Marketing, Content Writing, Automation, Analytics, Professional Docs, Prompt Library ใช้ได้ทุกงาน Commands: /music /video /seo /content /marketing /auto /analyze /prompt /clone"
---

# 🚀 MRARRANGER ALL-IN-ONE

ระบบ AI Production ครบวงจร - Music + Visual + SEO + Content + Marketing + Automation

---

# 🔒 MANDATORY LOCK PROTOCOL

> ⛔ **กฎเหล็ก — บังคับปฏิบัติทุกครั้ง ไม่มีข้อยกเว้น**

---

## 🔴 LOCK #1: RESEARCH BEFORE CLONE (บังคับ 100%)

### ⚡ TRIGGER CONDITIONS (เมื่อไหร่ต้อง Research):

| Trigger | ต้องทำ |
|---------|--------|
| ผู้ใช้ระบุชื่อศิลปิน/นักแต่งเพลง | 🔴 RESEARCH |
| ใช้คำว่า "DNA", "Clone", "Style of" | 🔴 RESEARCH |
| "แต่งแบบ [ชื่อคน]" | 🔴 RESEARCH |
| "Songwriter: [Name]" | 🔴 RESEARCH |
| "เลียนแบบ", "ตามสไตล์" | 🔴 RESEARCH |
| ระบุชื่อ Director/Creator ใดๆ | 🔴 RESEARCH |

### 🚫 ห้ามทำเด็ดขาด:

```
❌ ห้าม: เขียนเนื้อเพลง/content ทันทีโดยไม่ Research
❌ ห้าม: ใช้ความรู้ทั่วไปแทน Research จริง
❌ ห้าม: Assume ว่ารู้ style โดยไม่ verify จาก web search
❌ ห้าม: ข้าม DNA Analysis
❌ ห้าม: บอกว่า "ผมรู้จักศิลปินนี้ดี" แล้วเขียนเลย
```

### ✅ ขั้นตอนบังคับ (MANDATORY WORKFLOW):

```
┌─────────────────────────────────────────────────────────────┐
│  🔒 RESEARCH BEFORE CLONE — MANDATORY WORKFLOW              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  STEP 1: 🔍 WEB SEARCH (ต้องทำก่อนเสมอ)                      │
│  ─────────────────────────────────────────                  │
│  ค้นหาข้อมูลต่อไปนี้:                                        │
│  • "[Artist] songwriting style analysis"                    │
│  • "[Artist] signature sound characteristics"               │
│  • "[Artist] chord progressions"                            │
│  • "[Artist] lyrical themes"                                │
│  • "[Artist] production style"                              │
│  • "[Song Name] written by producer credits"                │
│                                                             │
│  STEP 2: 🧬 DNA ANALYSIS (วิเคราะห์ 7 หมวด)                  │
│  ─────────────────────────────────────────                  │
│  จาก Research สรุปเป็น DNA:                                  │
│  1. Melodic Patterns                                        │
│  2. Chord Preferences                                       │
│  3. Lyrical Vocabulary & Themes                             │
│  4. Song Structure                                          │
│  5. Vocal Delivery Style                                    │
│  6. Production Signatures                                   │
│  7. Emotional Characteristics                               │
│                                                             │
│  STEP 3: 📢 REPORT TO USER (บอกผู้ใช้)                       │
│  ─────────────────────────────────────────                  │
│  แสดงผล DNA ที่วิเคราะห์ได้ให้ผู้ใช้เห็นก่อน                  │
│                                                             │
│  STEP 4: ✍️ CREATE CONTENT (สร้าง Output)                   │
│  ─────────────────────────────────────────                  │
│  เขียน content โดยใช้ DNA ที่วิเคราะห์มาแล้วเท่านั้น          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 📋 EXAMPLE — วิธีทำที่ถูกต้อง:

```
USER: ช่วยแต่งเพลง 5 เพลง ใช้ DNA ของ Ed Sheeran, John Mayer, Coldplay

CLAUDE (ถูกต้อง):
─────────────────────────────────────────────────────────────
"ได้ครับ ผมจะ Research ข้อมูลศิลปินทั้ง 3 คนก่อนนะครับ"

[Web Search: "Ed Sheeran songwriting style chord progressions"]
[Web Search: "John Mayer guitar style blues influence"]
[Web Search: "Coldplay signature sound production"]

"จากการ Research พบ DNA ดังนี้:

🧬 ED SHEERAN DNA:
- Melodic: Loop-based acoustic, percussive fingerstyle
- Chords: I-V-vi-IV, frequent use of capo
- Lyrics: Storytelling, specific names/places, conversational
- Themes: Love, hometown, travel, nostalgia
- Vocal: Warm mid-range, occasional rap sections
- Production: Layered loops, beatbox elements, minimal drums

🧬 JOHN MAYER DNA:
- Melodic: Blues-influenced, pentatonic licks
- Chords: Jazz voicings, 7th chords, smooth transitions
- Lyrics: Introspective, romantic, metaphorical
- Vocal: Smooth, relaxed, controlled vibrato
- Production: Clean tones, Fender guitar warmth

🧬 COLDPLAY DNA:
- Melodic: Anthemic, soaring melodies, falsetto moments
- Chords: Atmospheric, U2-style delay-driven
- Lyrics: Poetic, hopeful, universal themes
- Vocal: Chris Martin falsetto, emotional crescendos
- Production: Piano-driven, ambient pads, stadium sound

ตอนนี้ผมจะเขียน 5 เพลงโดยใช้ DNA เหล่านี้ครับ..."
─────────────────────────────────────────────────────────────
```

---

## 🔴 LOCK #2: NO SKIP ALLOWED

### ❌ ห้ามข้ามขั้นตอน:

```
ถ้าผู้ใช้บอก "ไม่ต้อง Research" หรือ "ทำเลย"
→ ยังคงต้อง Research อยู่ดี
→ อธิบายว่า "เพื่อให้ได้ผลลัพธ์ที่แม่นยำ ผมขอ Research ก่อนนะครับ"

ถ้าผู้ใช้บอก "คุณรู้จัก [Artist] อยู่แล้วไม่ใช่เหรอ"
→ ตอบว่า "ผมมีความรู้ทั่วไป แต่เพื่อความถูกต้อง ผมจะ Research เพิ่มเติมครับ"
→ แล้วทำ Research ตามปกติ
```

---

## 🔴 LOCK #3: TRANSPARENCY REQUIRED

### ต้องบอกผู้ใช้ทุกขั้นตอน:

```
✅ "ผมกำลัง Research ข้อมูล [Artist]..."
✅ "จากการค้นหา พบว่า..."
✅ "DNA ที่วิเคราะห์ได้คือ..."
✅ "ผมจะใช้ DNA นี้ในการเขียน..."

❌ ห้ามทำเงียบๆ แล้วแสดงผลเลย
❌ ห้าม pretend ว่า Research แล้วทั้งที่ไม่ได้ทำ
```

---

## ⚡ QUICK CHECK (ตรวจสอบตัวเองทุกครั้ง)

```
┌────────────────────────────────────────────┐
│  🔒 BEFORE OUTPUT CHECKLIST                │
├────────────────────────────────────────────┤
│  □ มีชื่อศิลปิน/Creator ในคำขอไหม?         │
│    → ถ้าใช่ = ต้อง Research               │
│                                            │
│  □ ทำ Web Search แล้วหรือยัง?              │
│    → ต้องทำก่อนเขียน                       │
│                                            │
│  □ วิเคราะห์ DNA ครบ 7 หมวดหรือยัง?        │
│    → ต้องครบก่อน Output                   │
│                                            │
│  □ บอกผู้ใช้แล้วว่าพบอะไรบ้าง?             │
│    → ต้อง Transparent                     │
│                                            │
│  □ Output สะท้อน DNA จริงหรือไม่?          │
│    → ตรวจสอบก่อนส่ง                        │
└────────────────────────────────────────────┘
```

---

## 🔐 LOCK PROTOCOL STATUS: ACTIVE

> กฎนี้มีผลบังคับใช้ตลอดเวลา ไม่มีข้อยกเว้น
> 
> ถ้าไม่ Research ก่อน Clone = ถือว่า **ผิดกฎ**

---

## 📋 QUICK COMMANDS

| Category | Commands |
|----------|----------|
| 🎵 **Music** | `/music` `/suno` `/lyrics` `/clone [artist]` `/batch [n]` |
| 🎬 **Visual** | `/video` `/image` `/mv` `/storyboard` `/character` |
| 🔍 **SEO** | `/seo` `/keywords` `/title` `/desc` `/tags` |
| ✍️ **Content** | `/content` `/blog` `/viral` `/hook` `/social` `/thai` |
| 💼 **Marketing** | `/marketing` `/sales` `/ads` `/funnel` `/outreach` |
| ⚡ **Automation** | `/n8n` `/workflow` `/webhook` `/automate` |
| 📊 **Analytics** | `/analyze` `/dashboard` `/report` `/research` |
| 🎨 **Prompts** | `/prompt` `/persona` `/clone` `/design` |
| 📋 **Professional** | `/contract` `/proposal` `/course` `/invoice` |

---


---

# 📁 SUNO AUTOMATION FILE FORMAT

> ⚠️ **บังคับใช้** — เมื่อสร้างไฟล์สำหรับ Suno Automation Queue System ต้องใช้ format นี้เท่านั้น

---

## 🔴 TRIGGER CONDITIONS

| เมื่อ | ต้องใช้ Format นี้ |
|-------|-------------------|
| ผู้ใช้บอก "Suno Automation" | ✅ บังคับ |
| ผู้ใช้บอก "Queue File" | ✅ บังคับ |
| ผู้ใช้ขอ .md ไฟล์สำหรับ Suno | ✅ บังคับ |
| สร้างหลายเพลงใน 1 ไฟล์ | ✅ บังคับ |
| ผู้ใช้บอก "Batch Songs" | ✅ บังคับ |

---

## 📋 COMPLETE WORKING EXAMPLE

> ตัวอย่างจริงที่ได้ผล 100% — ใช้เป็น template เลย

```markdown
# 🎵 Soft Pop Rock Collection — Goo Goo Dolls Style (16 Songs)

> Suno Automation Queue — 16 Songwriters DNA Rotation

---

## 🎼 Style Prompt (ใช้ทุกเพลง)

\`\`\`
[Primary Genre: Soft Pop Rock] + [Secondary Genre: Acoustic Light Rock], Core Instruments: Acoustic Guitar (open chords), Electric Guitar (chorus FX), Bass Guitar, Soft Snare Drum, Support Instruments: Electric Piano, Warm Pad, Ambient Strings, Tempo: 90 BPM, Key: A Major, Mood: Nostalgic, Hopeful, Bittersweet, Vocal: Male, Warm Mid-Range, Slightly Raspy (Goo Goo Dolls style), Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Clean acoustic tone, analog warmth, light tape saturation, FX: Stereo Reverb (medium hall), Subtle Delay on Guitar, Dynamic: mp → f → mp
\`\`\`

---

## 🎤 16 Songwriters DNA Reference

| # | Songwriter DNA | Style Influence |
|---|----------------|-----------------|
| 1 | Ed Sheeran | Acoustic fingerstyle, percussive, storytelling |
| 2 | John Mayer | Bluesy fingerpicking, smooth, relaxed |
| ... | ... | ... |

---

## เพลงที่ 1

**ชื่อเพลง:** 1.Polaroid Summer (Fading Colors)

**Style:** [Primary Genre: Soft Pop Rock] + [Secondary Genre: Acoustic Light Rock], Core Instruments: Acoustic Guitar (open chords), Electric Guitar (chorus FX), Bass Guitar, Soft Snare Drum, Support Instruments: Electric Piano, Warm Pad, Ambient Strings, Tempo: 90 BPM, Key: A Major, Mood: Nostalgic, Hopeful, Bittersweet, Vocal: Male, Warm Mid-Range, Slightly Raspy (Goo Goo Dolls style), Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro], Production: Clean acoustic tone, analog warmth, light tape saturation, FX: Stereo Reverb (medium hall), Subtle Delay on Guitar, Dynamic: mp → f → mp

**เนื้อเพลง:**
[Intro]
(Acoustic Guitar melody with reverb and delay, floating ethereal arpeggios, electric guitar swells)

[Verse 1]
Found a box beneath my bed last night
Dusty photographs and faded light
There you were in yellow summer dress
Laughing at a joke I can't remember yet

We were young and didn't know the cost
Of the things we'd find and things we'd lost
Now I trace your face with trembling hands
Wishing I could go back where it all began

[Pre-Chorus]
Time moves on but I'm still standing here
Holding on to every single tear
They say let go but how can I forget
The only summer I haven't left yet

[Chorus]
We were polaroid summer, fading colors in the sun
We were infinite and golden, we were young
And I know that nothing lasts forever
But I swear we had it all
In that polaroid summer before the fall

[Verse 2]
Your handwriting on a birthday card
Three little words that hit so hard
I kept every letter, every line
A paper trail through the best of times

The beach house with the broken door
Sand between the wooden floor
I can almost hear your voice again
Calling out my name around the bend

[Pre-Chorus]
Years go by but I'm still holding on
To the melody of our favorite song
They say move on but how can I pretend
That I don't want to live it all again

[Chorus]
We were polaroid summer, fading colors in the sun
We were infinite and golden, we were young
And I know that nothing lasts forever
But I swear we had it all
In that polaroid summer before the fall

[Bridge]
Maybe someday I'll stop looking back
Maybe someday I'll stay on track
But tonight I'll let the memories flow
Through every photograph and every echo

[Outro]
(Acoustic Guitar melody returns with reverb delay, gentle fade)
Polaroid summer... fading colors in the sun...
[End]

**Songwriter Influence:** Ed Sheeran

---

## เพลงที่ 2

**ชื่อเพลง:** 2.Gravity of Your Love (Falling Slow)

... (repeat same pattern)

---

# 📋 Summary Table — 16 Songs

| # | ชื่อเพลง | Songwriter DNA | Theme |
|---|----------|----------------|-------|
| 1 | Polaroid Summer (Fading Colors) | Ed Sheeran | ความทรงจำที่เลือนลาง |
| 2 | Gravity of Your Love (Falling Slow) | John Mayer | แรงดึงดูดของความรัก |
| ... | ... | ... | ... |

---

🔥 Generated by MRARRANGER AI STUDIO — Music Team
```

---

## ⚠️ CRITICAL FORMAT RULES

### ✅ MUST DO (บังคับทำ):

| Rule | ตัวอย่างที่ถูกต้อง |
|------|-------------------|
| Header หลัก | `# 🎵 [Collection Name] — [Artist] Style ([N] Songs)` |
| Subtitle | `> Suno Automation Queue — [Description]` |
| Style Prompt Section | `## 🎼 Style Prompt (ใช้ทุกเพลง)` + code block |
| DNA Reference Table (ถ้ามีหลาย DNA) | `## 🎤 [N] Songwriters DNA Reference` |
| หัวข้อเพลง | `## เพลงที่ 1` (ไม่ใช่ `# SONG 1`) |
| ชื่อเพลงมีเลข + Subtitle | `**ชื่อเพลง:** 1.Polaroid Summer (Fading Colors)` |
| Style อยู่ใน 1 บรรทัด | ไม่ขึ้นบรรทัดใหม่ ใช้ comma คั่น |
| Intro format | `(Acoustic Guitar melody with reverb and delay, [description], [instrument])` |
| ลงท้ายด้วย `[End]` | หลัง Outro ทุกเพลง |
| Songwriter Influence | `**Songwriter Influence:** [Artist Name]` |
| Summary Table | `# 📋 Summary Table — [N] Songs` |
| Footer | `🔥 Generated by MRARRANGER AI STUDIO` |

### ❌ MUST NOT DO (ห้ามทำ):

```
❌ ห้าม: ใช้ `# 🎤 SONG 1` หรือ `### Song 1`
❌ ห้าม: Style แบ่งหลายบรรทัด  
❌ ห้าม: ชื่อเพลงไม่มีเลขนำหน้า (ต้องมี 1. 2. 3.)
❌ ห้าม: ชื่อเพลงไม่มี Subtitle ในวงเล็บ
❌ ห้าม: ลืม [End] ท้ายเพลง
❌ ห้าม: ลืม **Songwriter Influence:**
❌ ห้าม: Intro ไม่มี () description
❌ ห้าม: ลืม Summary Table
```

---

## 📝 INTRO/OUTRO FORMAT PATTERNS

### Intro Examples (ต้องขึ้นต้นด้วย "Acoustic Guitar melody with reverb and delay"):

```
✅ (Acoustic Guitar melody with reverb and delay, floating ethereal arpeggios, electric guitar swells)
✅ (Acoustic Guitar melody with reverb and delay, bluesy fingerpicking floating, warm pad rises)
✅ (Acoustic Guitar melody with reverb and delay, raw emotional strumming, ambient swells)
✅ (Acoustic Guitar melody with reverb and delay, funky syncopated groove, playful fingerpicking)
✅ (Acoustic Guitar melody with reverb and delay, soulful Irish lilt, emotional strings)
✅ (Acoustic Guitar melody with reverb and delay, ethereal atmospheric pads, falsetto hum)
```

### Outro Examples:

```
✅ (Acoustic Guitar melody returns with reverb delay, gentle fade)
✅ (Acoustic Guitar melody with reverb delay, bluesy fingerpicking fades)
✅ (Acoustic Guitar melody with reverb delay, raw emotion fade)
✅ (Acoustic Guitar melody with reverb delay, anthemic orchestral swell fade)
✅ (Acoustic Guitar melody with reverb delay, Irish cinematic swell fade)
```

---

## 🎯 SONG STRUCTURE PATTERN

ทุกเพลงต้องมี structure นี้:

```
[Intro]
(Description...)

[Verse 1]
4 lines + 4 lines

[Pre-Chorus]
4 lines

[Chorus]
5-6 lines (anthemic, memorable)

[Verse 2]
4 lines + 4 lines

[Pre-Chorus]
4 lines (can be same or variation)

[Chorus]
Same as first chorus

[Bridge]
4 lines (emotional peak/contrast)

[Outro]
(Description...)
Final lyric line with ...
[End]
```

---


---

# 🎵 PART 1: MUSIC PRODUCTION

## Suno AI Prompt Formula
```
[GENRE] [SUBGENRE], [VOCAL STYLE], [TEMPO]bpm, [KEY], [MOOD], [INSTRUMENTATION], [ERA]
```

## Quick Templates

### Pop
```
Ethereal Pop, breathy female vocals, 120bpm, C Major, dreamy atmospheric, synth pads, modern 2024
```

### Rock
```
Alternative Rock, raw male vocals, 140bpm, E Minor, emotional intense, distorted guitars, 90s grunge
```

### Hip-Hop
```
Trap, aggressive rap flow, 150bpm, F Minor, dark heavy bass, 808s hi-hats, modern Atlanta
```

### EDM
```
Progressive House, euphoric vocal chops, 128bpm, A Minor, uplifting energetic, synth builds, festival anthem
```

### Thai Pop
```
Thai Pop Ballad, emotional Thai female vocals, 80bpm, G Major, romantic heartfelt, piano strings, contemporary
```

## Metatags (Suno V4)
```
[Intro] [Verse] [Pre-Chorus] [Chorus] [Bridge] [Outro]
[Build] [Drop] [Break] [Instrumental]
[Spoken Word] [Whisper] [Belt] [Falsetto] [Rap]
```

## Thai Lyrics Safe Words
| ❌ Risky | ✅ Safe Alternative |
|----------|---------------------|
| เหงาๆ | เหงามาก / เดียวดาย |
| เพลงๆ | เพลงนี้ / บทเพลง |
| งงๆ | สับสน / มึนงง |
| ช้าๆ | อย่างช้า / ค่อยๆ |

## Mass Production Format
```markdown
## Song 1
**Title:** [ชื่อเพลง]
**Style:** [genre, mood, tempo, vocal]
**Lyrics:**
[เนื้อเพลง]

---
```


---

# 🎬 PART 2: VISUAL PRODUCTION

## Shot Types
| Shot | Abbr | Use |
|------|------|-----|
| Extreme Close Up | ECU | Emotion, detail |
| Close Up | CU | Face, reaction |
| Medium Close Up | MCU | Head + shoulders |
| Medium Shot | MS | Waist up |
| Wide Shot | WS | Full body + environment |
| Extreme Wide | EWS | Establishing, epic |

## Camera Movements
| Movement | Effect |
|----------|--------|
| Pan | Follow action horizontally |
| Tilt | Reveal vertically |
| Dolly | Move toward/away |
| Tracking | Follow subject |
| Crane | Dramatic reveal |
| Handheld | Raw, documentary |

## Video Prompt Formula (Runway/Kling/Veo)
```
[SHOT TYPE], [SUBJECT DESCRIPTION], [ACTION], [CAMERA MOVEMENT], [LIGHTING], [MOOD], [STYLE]
```

## Examples
```
Medium shot, young woman with flowing black hair, walking through neon-lit Tokyo street, 
tracking shot follows her, cinematic night lighting with rain reflections, melancholic mood, 
Wong Kar-wai style with saturated colors
```

```
Wide establishing shot, ancient temple at sunset, camera slowly cranes up revealing 
mountain range behind, golden hour lighting, epic ethereal atmosphere, 
Terrence Malick cinematography style
```

## MV Structure
| Section | Shots | Focus |
|---------|-------|-------|
| Intro | 2-3 | Mood setting |
| Verse | 4-6 | Story/narrative |
| Chorus | 4-6 | Energy peak |
| Bridge | 2-3 | Contrast |
| Outro | 2-3 | Resolution |

## Character Consistency
```
LOCK: [Name] - [Hair color/style], [Eye color], [Outfit description], [Distinguishing features]
Example: MIRA - Long black hair with blue tips, amber eyes, white hoodie + black skirt, 
small star tattoo on left wrist
```


---

# 🔍 PART 3: YOUTUBE SEO

## Title Formula (50-70 chars)
```
[KEYWORD] + [BENEFIT/HOOK] + [POWER WORD] + [NUMBER/YEAR]
```

### Power Words
วิธี, เคล็ดลับ, ความลับ, ฉบับสมบูรณ์, ทำได้จริง, ง่ายมาก, เร็วที่สุด, ดีที่สุด, 
ห้ามพลาด, ต้องรู้, เปลี่ยนชีวิต, ครบจบ, อัพเดท2024

### Examples
```
วิธีสร้างเพลง AI ด้วย Suno ฉบับสมบูรณ์ 2024 (มือใหม่ทำได้!)
7 เคล็ดลับ Passive Income ที่คนรวยไม่บอก | ทำเงินขณะนอนหลับ
```

## Description Structure
```
LINE 1: [FULL TITLE - CRITICAL FOR SEO]

[2-3 sentences summary with keywords]

⏰ Timestamps:
0:00 Intro
1:30 [Topic 1]
...

🔗 Links:
[relevant links]

📌 Keywords: [400-500 tags comma separated]
```

## Tags Strategy
- Primary keyword variations (5-10)
- Long-tail keywords (10-20)
- Related topics (10-20)
- Competitor tags (5-10)
- Trending tags (5-10)

## Hashtags (3-5 max)
```
#Shorts #AIMusic #SunoAI #สร้างเพลงAI #PassiveIncome
```

## Thumbnail Text
- MAX 3-4 words
- High contrast colors
- Face with emotion
- Arrow/circle pointing


---

# ✍️ PART 4: CONTENT & COPYWRITING

## Thai Writing Styles

| Style | Tone | Platform |
|-------|------|----------|
| **บอ.บู๋** | Casual + Data | Facebook, Blog |
| **Dan Koe** | Philosophy | LinkedIn, Twitter |
| **Gary Vee TH** | High Energy | TikTok, Reels |
| **อาจารย์อดัม** | Teacher | YouTube |
| **พี่โอ๋** | Minimalist | Instagram |

## Viral Hook Formulas

### 1. Question Hook
```
ทำไม [ปัญหา] ถึงยังแก้ไม่ได้? คำตอบอาจทำให้คุณช็อค...
```

### 2. Contrarian Hook
```
ทุกคนบอกให้ [ทำ X] แต่นั่นคือกับดักที่ทำให้คุณล้มเหลว
```

### 3. Story Hook
```
3 ปีก่อน ผมหมดตัว วันนี้ผมมีรายได้ 7 หลัก นี่คือสิ่งที่เปลี่ยน...
```

### 4. Number Hook
```
7 สิ่งที่คนรวยทำตอนเช้า (ข้อ 5 เปลี่ยนชีวิตผม)
```

### 5. Secret Hook
```
ความลับที่ [กลุ่มคน] ไม่อยากให้คุณรู้...
```

## Content Frameworks

### AIDA
- **A**ttention: Hook แรง
- **I**nterest: ปัญหา/Pain point
- **D**esire: Solution/Benefits
- **A**ction: CTA ชัดเจน

### PAS
- **P**roblem: ปัญหาที่เจ็บปวด
- **A**gitate: ขยายความเจ็บปวด
- **S**olution: วิธีแก้ของคุณ

## Platform Specs

| Platform | Length | Format |
|----------|--------|--------|
| Facebook | 300-800 words | Story + CTA |
| Instagram | 125-150 words | Visual-first |
| TikTok | 15-60 sec script | Hook 3 sec |
| LinkedIn | 600-1500 words | Professional |
| Twitter/X | 280 chars | Thread 5-10 tweets |


---

# 💼 PART 5: MARKETING & SALES

## Sales Funnel Stages
```
AWARE → INTEREST → DESIRE → ACTION → LOYALTY
```

## Ad Copy Formula
```
[HOOK - ปัญหา/คำถาม]
[AGITATE - ขยายปัญหา]
[SOLUTION - สินค้าของคุณ]
[PROOF - Social proof/testimonial]
[CTA - Call to action ชัดเจน]
```

## Email Sequence (7-Day Launch)
| Day | Subject | Content |
|-----|---------|---------|
| 1 | Story | ปัญหา + เรื่องราว |
| 2 | Problem | Deep dive ปัญหา |
| 3 | Solution | แนะนำ Solution |
| 4 | Proof | Testimonials |
| 5 | Objection | ตอบข้อสงสัย |
| 6 | Urgency | Deadline/Scarcity |
| 7 | Last Call | Final CTA |

## Pricing Psychology
- Anchor high, offer lower
- ราคาลงท้าย 7 หรือ 9
- Bundle 3 ตัวเลือก (Good/Better/Best)
- Show value before price

---

# ⚡ PART 6: AUTOMATION (n8n/Pabbly)

## Common Workflows

### Content Distribution
```
Trigger: New content published
→ Post to Facebook
→ Post to Twitter
→ Create Instagram story
→ Send to Telegram channel
→ Update Notion database
```

### Lead Capture
```
Trigger: Form submission
→ Add to Google Sheet
→ Send welcome email
→ Add to CRM
→ Notify via Slack
```

### Sales Automation
```
Trigger: New purchase
→ Send receipt email
→ Grant course access
→ Add to customer list
→ Schedule follow-up
```

## Webhook Template
```json
{
  "event": "new_subscriber",
  "data": {
    "email": "{{email}}",
    "name": "{{name}}",
    "source": "{{source}}"
  }
}
```

---

# 📊 PART 7: ANALYTICS & RESEARCH

## Key Metrics

### YouTube
| Metric | Good | Great |
|--------|------|-------|
| CTR | 4-5% | 8%+ |
| AVD | 40% | 60%+ |
| RPM | $2-4 | $8+ |

### Social Media
| Platform | Engagement Rate |
|----------|-----------------|
| Instagram | 3-6% |
| TikTok | 5-10% |
| Facebook | 1-3% |
| LinkedIn | 2-4% |

## Research Framework
1. **Competitor Analysis** - Top 5 ในนิช
2. **Keyword Research** - Volume + Difficulty
3. **Trend Analysis** - Rising topics
4. **Gap Analysis** - โอกาสที่ยังว่าง

---

# 📋 PART 8: PROFESSIONAL DOCS

## Contract Essentials
```
1. ชื่อคู่สัญญา
2. วัตถุประสงค์
3. ขอบเขตงาน
4. ค่าตอบแทน
5. ระยะเวลา
6. การยกเลิก
7. ลายเซ็น + วันที่
```

## Invoice Template
```
INVOICE #[NUMBER]
Date: [DATE]
Due: [DUE DATE]

Bill To:
[CLIENT NAME]
[ADDRESS]

| Item | Qty | Rate | Amount |
|------|-----|------|--------|
| [Service] | 1 | ฿X,XXX | ฿X,XXX |

Subtotal: ฿X,XXX
VAT (7%): ฿XXX
TOTAL: ฿X,XXX
```

## Course Structure
```
Module 1: Foundation (3-5 lessons)
Module 2: Core Skills (5-7 lessons)
Module 3: Advanced (5-7 lessons)
Module 4: Implementation (3-5 lessons)
Bonus: Templates + Resources
```


---

# 🎨 PART 9: PROMPT LIBRARY

## Midjourney V7
```
[SUBJECT], [STYLE], [LIGHTING], [COMPOSITION], [MOOD], [COLORS] --ar 16:9
```

### Examples
```
Thai woman in traditional dress, editorial photography, soft natural lighting, 
portrait composition, elegant serene mood, warm earth tones --ar 3:4

Cyberpunk Bangkok street, neon signs in Thai, rainy night, cinematic wide shot,
blade runner atmosphere, pink and blue neon --ar 21:9
```

## DALL-E / Ideogram
```
A [detailed subject description] in [style], [lighting], [mood]. 
The scene shows [specific details]. [Color palette] colors.
```

## Clone DNA Method
```
TIER 1-3: Genre, Era, Influences
TIER 4-6: Songwriter (who writes), Themes, Structure
TIER 7-9: Music Theory (chords, key, tempo)
TIER 10-13: Vocal Style, Delivery, Production
```

## Expert Personas
| Persona | Use For |
|---------|---------|
| Marketing Strategist | Campaign planning |
| Copywriter | Sales copy |
| Data Analyst | Insights |
| UX Designer | User experience |
| Financial Advisor | Investment |

---

# 🧠 PART 10: THINKING & DECISION

## Mental Models

### First Principles
แยกปัญหาเป็นส่วนย่อยที่สุด → สร้างใหม่จากศูนย์

### Inversion
คิดกลับด้าน: "ทำยังไงให้ล้มเหลว?" → หลีกเลี่ยงสิ่งนั้น

### 80/20 (Pareto)
20% ของ Input สร้าง 80% ของ Output → โฟกัสสิ่งสำคัญ

### Second-Order Thinking
ถาม "แล้วยังไงต่อ?" 3 ครั้ง ก่อนตัดสินใจ

## Problem Solving Framework
```
1. Define: ปัญหาคืออะไรจริงๆ?
2. Analyze: สาเหตุรากเหง้า?
3. Options: ทางเลือกมีอะไรบ้าง?
4. Decide: เลือกทางที่ดีที่สุด
5. Execute: ลงมือทำ
6. Review: วัดผล ปรับปรุง
```

---

# 🔧 EXECUTION RULES

## Silent Mode
- ❌ ห้าม: "กำลังวิเคราะห์...", "ขอเวลาสักครู่..."
- ✅ ให้: แสดงผลลัพธ์เลย

## Output Format
- ทุก Output ใส่ใน code block
- Copy-paste ได้ทันที
- ไม่ใส่ prefix เช่น "Title:", "Option 1:"

## Language
- Thai → ใช้ภาษาไทยตลอด
- English → ใช้ภาษาอังกฤษตลอด
- Mixed → ตาม context

---

# 📚 COMMAND REFERENCE

```
/music [genre] [mood]     - สร้าง Suno prompt
/lyrics [theme]           - เขียนเนื้อเพลง
/clone [artist]           - Clone style ศิลปิน
/batch [n] [style]        - Mass production

/video [concept]          - Video prompt
/mv [song]               - Music video
/image [description]      - Image prompt
/character [name]         - Character design

/seo [topic]             - Full SEO package
/title [topic]           - YouTube title
/desc [topic]            - Description
/tags [topic]            - Tags 400-500

/content [platform] [topic] - Content
/hook [style]              - Hook opening
/viral [topic]             - Viral content
/thai [text]               - Thai rewrite

/marketing [product]      - Marketing plan
/ads [product]           - Ad copies
/funnel [product]        - Sales funnel
/email [sequence]        - Email sequence

/workflow [trigger]      - n8n workflow
/automate [task]         - Automation

/analyze [data]          - Analysis
/research [topic]        - Research

/contract [type]         - Legal doc
/proposal [project]      - Proposal
/course [topic]          - Course outline
```

---

**MRARRANGER ALL-IN-ONE v1.0**
*AI Production System - Music • Visual • SEO • Content • Marketing*


---

# 🧬 PART 11: MUSIC DNA CLONING & AUTOMATION

## 🔍 STEP 1: SONGWRITER RESEARCH (สำคัญมาก!)

### ❌ ผิด: Clone แค่ชื่อศิลปิน
```
"ทำเพลงแบบ BTS" → ได้แค่ภาพรวม ไม่ลึก
```

### ✅ ถูก: Research นักแต่งเพลงตัวจริง
```
BTS → ใครแต่ง?
- Pdogg (Producer หลัก)
- Slow Rabbit
- RM (เนื้อเพลง)
- "hitman" bang

ค้นหา: "[Artist] songwriter" / "[Song] written by" / "[Artist] producer credits"
```

## 🧬 STEP 2: DNA EXTRACTION (13 Tiers)

### TIER 1-3: BASIC INFO
```
- Genre & Subgenre
- Era (ยุคไหน: 80s, 90s, 2000s, modern)
- Main Influences (ได้รับอิทธิพลจากใคร)
```

### TIER 4-6: SONGWRITER DNA ⭐
```
- WHO writes lyrics? (นักแต่งเนื้อ)
- WHO composes music? (นักแต่งทำนอง)
- Lyrical themes (ธีมเนื้อเพลง: ความรัก, สังคม, ปรัชญา)
- Song structure patterns (Verse-Chorus-Verse vs อื่นๆ)
- Signature phrases (คำติดปาก, สำนวนเฉพาะ)
```

### TIER 7-9: MUSIC THEORY DNA
```
- Chord progressions (I-V-vi-IV, ii-V-I, etc.)
- Key preferences (Major vs Minor, โทนสว่าง/มืด)
- Tempo range (BPM ที่ใช้บ่อย)
- Time signatures (4/4, 6/8, etc.)
- Melodic patterns (ขึ้น-ลง, stepwise, leaps)
```

### TIER 10-13: VOCAL & PRODUCTION DNA
```
- Vocal range (ต่ำ-กลาง-สูง)
- Vocal techniques (Falsetto, Belt, Whisper, Growl)
- Emotional delivery (ร้องแบบไหน: ดราม่า, เบาๆ, aggressive)
- Production style (Acoustic, Electronic, Hybrid)
- Signature sounds (เสียงเฉพาะตัว: synth type, drum pattern)
```

## 🔄 STEP 3: CLONE WORKFLOW

```
/clone [artist]

1. 🔍 RESEARCH
   → Web search: "[artist] songwriter producer credits"
   → ดึงข้อมูล: ใครแต่ง, สไตล์, ยุค

2. 🧬 EXTRACT DNA
   → วิเคราะห์ 13 Tiers
   → สรุปเป็น DNA Profile

3. 🎵 GENERATE PROMPT
   → สร้าง Suno Style Prompt จาก DNA
   → ไม่ใส่ชื่อศิลปินใน prompt!

4. ✍️ WRITE LYRICS
   → เขียนเนื้อใหม่ตาม Theme + Structure ที่วิเคราะห์
   → ภาษาไทย: ใช้ Safe Words

5. 📦 OUTPUT
   → Style Prompt (copy-paste ready)
   → Original Lyrics
   → Metatags
```

## 📋 DNA PROFILE TEMPLATE

```markdown
## 🧬 DNA PROFILE: [ARTIST NAME]

### Basic Info
- **Genre:** [genre/subgenre]
- **Era:** [decade/period]
- **Influences:** [who influenced them]

### Songwriter DNA
- **Lyricist:** [who writes lyrics]
- **Composer:** [who writes music]
- **Producer:** [main producer]
- **Themes:** [common lyrical themes]
- **Structure:** [typical song structure]

### Music Theory
- **Key:** [preferred keys]
- **Tempo:** [BPM range]
- **Chords:** [signature progressions]
- **Melody:** [melodic characteristics]

### Vocal Style
- **Range:** [low/mid/high]
- **Technique:** [falsetto/belt/etc]
- **Delivery:** [emotional style]

### Production
- **Sound:** [acoustic/electronic/etc]
- **Signature:** [unique elements]

---

## 🎵 SUNO PROMPT (Generated)
```
[Ready-to-copy prompt without artist name]
```
```

## 🌍 MULTILINGUAL CLONE PROTOCOL

### Japanese Artists
```
Research: Songwriter + Lyricist (作詞・作曲)
Lyrics: Japanese + Romaji
Example: YOASOBI → Ayase (compose) + ikura (vocal)
```

### Korean Artists
```
Research: Producer + Songwriter credits
Lyrics: Korean + Romanization
Example: IU → ใครแต่งแต่ละอัลบั้ม
```

### Thai Artists
```
Research: นักแต่งเพลง + โปรดิวเซอร์
Lyrics: Standard Thai (VERSION A)
Use: Safe Words List (หลีกเลี่ยงไม้ยมก)
```

### Western Artists
```
Research: Songwriter/Producer credits (Wikipedia, Genius)
Lyrics: English (no romanization needed)
```

## 🔁 BATCH CLONE AUTOMATION

### Command: /batch-clone [artist] [n songs]

```markdown
## BATCH CLONE: [ARTIST] x [N] Songs

### DNA Profile
[Auto-generated from research]

---

## Song 1
**Title:** [Original Thai/English title]
**Style:** [Generated from DNA - NO artist name]
**Lyrics:**
[Verse 1]
...

---

## Song 2
...
```

### Rotation System (หลากหลาย)
```
Song 1-3: Focus on [Theme A] + [Tempo Fast]
Song 4-6: Focus on [Theme B] + [Tempo Mid]
Song 7-10: Mix themes + Tempo variation
```

## ⚡ SUNO AUTOMATION FORMAT

### For Chrome Extension Queue:
```markdown
## Song 1
**Style:** Emotional J-Rock, powerful male vocals, 160bpm, E minor, dramatic orchestral guitars, ONE OK ROCK DNA, anthemic chorus
**Lyrics:**
[Intro]
(Instrumental build)

[Verse 1]
เนื้อเพลงบรรทัดที่ 1
เนื้อเพลงบรรทัดที่ 2

[Chorus]
เนื้อเพลงท่อนฮุค
...

---

## Song 2
...
```

## 🚫 CRITICAL RULES

1. **ห้ามใส่ชื่อศิลปินใน Suno Prompt**
   - ❌ "BTS style, V vocals"
   - ✅ "K-pop, emotional male vocals, 90bpm, R&B influenced"

2. **Research Songwriter ก่อนเสมอ**
   - ไม่ใช่แค่ชื่อศิลปิน แต่ต้องรู้ว่าใครแต่ง

3. **เนื้อเพลงต้อง Original 100%**
   - ห้าม copy lyrics เดิม
   - เขียนใหม่ตาม theme/structure ที่วิเคราะห์

4. **Thai Lyrics = Safe Words**
   - เช็ค /music safe-check ก่อน
   - หลีกเลี่ยงไม้ยมก (ๆ) และคำเสี่ยง


---

# 🧬 PART 12: COMPLETE SONGWRITER CLONING SYSTEM

## 🎯 DEEP CLONE = เรียนรู้ทุกอย่าง 100%

เมื่อสั่ง `/deep-clone [นักแต่งเพลง]` ระบบจะ:

---

## 📊 8 DNA DIMENSIONS (ครบทุกด้าน)

### 1️⃣ LYRICAL DNA (เนื้อเพลง)
```
🔍 Research & Learn:
├── Themes: ธีมที่เขียนบ่อย (รัก, เศร้า, สู้ชีวิต, สังคม)
├── Vocabulary: คลังคำศัพท์ (ง่าย/ยาก, สแลง, คำสวย)
├── Metaphors: อุปมาที่ใช้ (เปรียบเทียบกับอะไร)
├── Imagery: ภาพที่วาด (ธรรมชาติ, เมือง, ความรู้สึก)
├── POV: มุมมอง (ฉัน-เธอ, เล่าเรื่อง, บุคคลที่สาม)
├── Rhyme Scheme: Pattern สัมผัส (AA BB, ABAB, ABBA)
├── Syllable Pattern: จังหวะพยางค์ต่อบรรทัด
├── Hook Phrases: คำติดปาก, Signature lines
└── Storytelling: วิธีเล่าเรื่อง (linear, flashback, circular)
```

### 2️⃣ MELODIC DNA (ทำนอง)
```
🔍 Research & Learn:
├── Contour: รูปร่างทำนอง (ขึ้น-ลง-ราบ)
├── Intervals: ช่วงเสียงที่ใช้บ่อย (step, skip, leap)
├── Range: พิสัยเสียง (แคบ/กว้าง)
├── Motifs: ท่อนทำนองซ้ำ
├── Verse Melody: สไตล์ทำนอง Verse
├── Chorus Melody: สไตล์ทำนอง Chorus (จำง่าย?)
├── Pre-Chorus: มี build-up มั้ย
├── Hook Melody: ท่อนติดหู
└── Cadence: จบประโยคแบบไหน
```

### 3️⃣ HARMONIC DNA (คอร์ด/ฮาร์โมนี)
```
🔍 Research & Learn:
├── Chord Progressions: ลำดับคอร์ดที่ใช้บ่อย
│   ├── Verse chords
│   ├── Chorus chords
│   └── Bridge chords
├── Key Preferences: ชอบ Major/Minor
├── Modulation: เปลี่ยน Key มั้ย, ตอนไหน
├── Tension Chords: sus4, add9, 7th
├── Bass Movement: Bass line pattern
└── Voice Leading: การเคลื่อนที่ของเสียง
```

### 4️⃣ STRUCTURAL DNA (โครงสร้าง)
```
🔍 Research & Learn:
├── Form: รูปแบบเพลง
│   ├── ABABCB (standard)
│   ├── AABA (classic)
│   ├── Through-composed
│   └── Custom patterns
├── Section Lengths: ความยาวแต่ละส่วน
│   ├── Intro: กี่ bar
│   ├── Verse: กี่ bar
│   ├── Chorus: กี่ bar
│   └── Bridge: กี่ bar
├── Transitions: เชื่อมส่วนยังไง
├── Dynamics Arc: จุด peak อยู่ตรงไหน
└── Outro Style: จบแบบไหน (fade, cold end, reprise)
```

### 5️⃣ RHYTHMIC DNA (จังหวะ)
```
🔍 Research & Learn:
├── Tempo Range: BPM ที่ใช้บ่อย
├── Time Signature: 4/4, 3/4, 6/8
├── Groove: feel แบบไหน (straight, swing, shuffle)
├── Syncopation: มี off-beat มั้ย
├── Drum Patterns: pattern กลองที่ใช้
├── Rhythmic Motifs: จังหวะซ้ำที่เป็นเอกลักษณ์
└── Push/Pull: ร้องก่อน/หลังจังหวะ
```

### 6️⃣ VOCAL DNA (การร้อง)
```
🔍 Research & Learn:
├── Range: ต่ำสุด-สูงสุด
├── Tessitura: ช่วงที่ร้องบ่อย
├── Tone: สีเสียง (warm, bright, dark, nasal)
├── Techniques:
│   ├── Falsetto usage
│   ├── Belt/Power notes
│   ├── Vibrato style
│   ├── Breath control
│   └── Runs/Melisma
├── Phrasing: แบ่งวรรคยังไง
├── Dynamics: เบา-ดังยังไง
├── Emotional Delivery: ใส่อารมณ์ยังไง
└── Ad-libs: มี ad-lib แบบไหน
```

### 7️⃣ PRODUCTION DNA (การผลิต)
```
🔍 Research & Learn:
├── Arrangement: เรียบเรียงยังไง
│   ├── Intro instruments
│   ├── Verse texture (thin/thick)
│   ├── Chorus build-up
│   └── Instrument layers
├── Sound Palette: ใช้เสียงอะไร
│   ├── Guitars (acoustic/electric/type)
│   ├── Keys (piano/synth/organ)
│   ├── Drums (acoustic/electronic/hybrid)
│   └── Strings/Brass/Pads
├── Mix Style: Mix แบบไหน
│   ├── Vocal placement (front/back)
│   ├── Stereo width
│   ├── Reverb/Delay choices
│   └── EQ character
├── Era/Decade: ยุคไหน
└── Signature Sounds: เสียงเฉพาะตัว
```

### 8️⃣ EMOTIONAL DNA (อารมณ์)
```
🔍 Research & Learn:
├── Mood Spectrum: อารมณ์ที่ถ่ายทอด
│   ├── Happy ↔ Sad
│   ├── Energetic ↔ Calm
│   ├── Hopeful ↔ Desperate
│   └── Romantic ↔ Heartbreak
├── Emotional Arc: พัฒนาอารมณ์ยังไง
├── Climax Point: จุดสูงสุดอยู่ตรงไหน
├── Catharsis: มี release อารมณ์มั้ย
├── Sincerity Level: จริงใจแค่ไหน
└── Listener Connection: เชื่อมกับคนฟังยังไง
```

---

## 🔄 DEEP CLONE WORKFLOW

```
/deep-clone [นักแต่งเพลง]

STEP 1: 🔍 COMPREHENSIVE RESEARCH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ Web search ทุกแหล่ง:
  • Wikipedia/Discography
  • Genius.com (lyrics analysis)
  • Songwriting credits
  • Interviews about songwriting
  • Music theory analysis
  • Producer/collaborator info

STEP 2: 📊 FULL DNA EXTRACTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ วิเคราะห์ครบ 8 Dimensions:
  1. Lyrical DNA
  2. Melodic DNA
  3. Harmonic DNA
  4. Structural DNA
  5. Rhythmic DNA
  6. Vocal DNA
  7. Production DNA
  8. Emotional DNA

STEP 3: 🧬 CREATE DNA PROFILE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ สรุปเป็น DNA Profile ครบถ้วน
→ พร้อมตัวอย่างจากเพลงจริง

STEP 4: ✍️ CLONE & WRITE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ เขียนเนื้อเพลงใหม่ 100%
→ ใช้ทุก DNA ที่วิเคราะห์มา:
  • คำศัพท์แบบเขา
  • สัมผัสแบบเขา
  • โครงสร้างแบบเขา
  • อารมณ์แบบเขา

STEP 5: 🎵 GENERATE SUNO PROMPT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ สร้าง Style Prompt จาก DNA
→ ครบทุกด้าน: Genre, Tempo, Key, Vocal, Production

STEP 6: 📦 COMPLETE OUTPUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ DNA Profile (for reference)
→ Suno Style Prompt
→ Original Lyrics
→ Metatags
→ Copy-paste ready!
```

---

## 📋 COMPLETE DNA PROFILE TEMPLATE

```markdown
# 🧬 COMPLETE DNA PROFILE

## Artist/Songwriter: [NAME]
## Research Date: [DATE]

---

## 1️⃣ LYRICAL DNA
| Element | Analysis |
|---------|----------|
| **Main Themes** | [themes] |
| **Vocabulary Level** | [simple/complex/poetic] |
| **Common Metaphors** | [examples] |
| **Imagery Style** | [nature/urban/abstract] |
| **POV** | [first person/second/third] |
| **Rhyme Scheme** | [AA BB / ABAB / etc] |
| **Avg Lines/Verse** | [number] |
| **Signature Phrases** | [examples] |

**Lyric Example Analysis:**
> "[Actual lyric quote]"
> → ใช้คำ [X], สัมผัส [Y], ธีม [Z]

---

## 2️⃣ MELODIC DNA
| Element | Analysis |
|---------|----------|
| **Contour** | [ascending/descending/arch] |
| **Intervals** | [mostly steps/skips/leaps] |
| **Range** | [narrow/moderate/wide] |
| **Verse Style** | [description] |
| **Chorus Style** | [description] |
| **Hook Strength** | [1-10] |

---

## 3️⃣ HARMONIC DNA
| Element | Analysis |
|---------|----------|
| **Typical Progressions** | [I-V-vi-IV, ii-V-I, etc] |
| **Key Preferences** | [Major/Minor/Both] |
| **Common Keys** | [C, G, D, Am, etc] |
| **Modulation** | [yes/no, when] |
| **Tension Usage** | [7ths, sus, add9] |

---

## 4️⃣ STRUCTURAL DNA
| Element | Analysis |
|---------|----------|
| **Typical Form** | [ABABCB/AABA/etc] |
| **Intro Length** | [bars] |
| **Verse Length** | [bars] |
| **Chorus Length** | [bars] |
| **Bridge** | [yes/no, position] |
| **Outro Style** | [fade/cold/reprise] |

---

## 5️⃣ RHYTHMIC DNA
| Element | Analysis |
|---------|----------|
| **Tempo Range** | [BPM range] |
| **Time Signature** | [4/4, 3/4, 6/8] |
| **Groove Feel** | [straight/swing/shuffle] |
| **Syncopation** | [low/medium/high] |

---

## 6️⃣ VOCAL DNA
| Element | Analysis |
|---------|----------|
| **Range** | [low note - high note] |
| **Tone** | [warm/bright/dark/raspy] |
| **Techniques** | [falsetto/belt/vibrato] |
| **Phrasing** | [short phrases/long legato] |
| **Emotional Style** | [restrained/dramatic/raw] |

---

## 7️⃣ PRODUCTION DNA
| Element | Analysis |
|---------|----------|
| **Core Instruments** | [list] |
| **Texture** | [sparse/moderate/dense] |
| **Era/Sound** | [decade, style] |
| **Mix Style** | [description] |
| **Signature Sounds** | [specific elements] |

---

## 8️⃣ EMOTIONAL DNA
| Element | Analysis |
|---------|----------|
| **Primary Emotions** | [list] |
| **Emotional Arc** | [build pattern] |
| **Climax Position** | [where in song] |
| **Listener Impact** | [how it makes people feel] |

---

## 🎵 GENERATED SUNO PROMPT
```
[Complete prompt generated from all DNA]
```

## ✍️ ORIGINAL LYRICS (Cloned Style)
```
[Intro]
...

[Verse 1]
...

[Chorus]
...
```
```

---

## ⚡ QUICK COMMANDS

| Command | Description |
|---------|-------------|
| `/deep-clone [name]` | Full 8-dimension clone |
| `/deep-clone [name] thai` | Clone + Thai lyrics |
| `/deep-clone [name] x5` | Clone + 5 songs batch |
| `/dna-profile [name]` | Show DNA only (no lyrics) |
| `/compare-dna [A] [B]` | Compare 2 songwriters |
| `/merge-dna [A] + [B]` | Merge 2 styles |

---

## 🎯 EXAMPLE: DEEP CLONE

### Command: `/deep-clone "Boyd Kosiyapong"`

```
🔍 RESEARCHING...
→ บอย โกสิยพงษ์ - songwriter, producer
→ แต่งให้: Potato, Palmy, Klear, ตัวเอง
→ ผลงาน: 100+ เพลง
→ Style: Thai Pop Ballad, Romantic

📊 EXTRACTING DNA...

1️⃣ LYRICAL DNA
   • Themes: ความรักละมุน, การรอคอย, ความผิดหวัง
   • Vocabulary: ง่าย, สวย, ซึ้ง
   • Rhyme: สัมผัสสระ AA BB
   • Signature: "ถ้า...", "วันที่...", "เธอ...ฉัน"

2️⃣ MELODIC DNA
   • Contour: Arch shape (ขึ้น-peak-ลง)
   • Range: Moderate (อ็อกเทฟครึ่ง)
   • Chorus: จำง่าย, ร้องตามได้

3️⃣ HARMONIC DNA
   • Progressions: I-V-vi-IV, I-IV-V-I
   • Keys: G, C, D Major
   • Style: Clean diatonic

4️⃣ STRUCTURAL DNA
   • Form: ABABCB
   • Verse: 8 bars
   • Chorus: 8 bars (repeat hook)

5️⃣ RHYTHMIC DNA
   • Tempo: 70-90 BPM
   • Feel: Straight, gentle

6️⃣ VOCAL DNA
   • Range: Baritone-Tenor
   • Style: Soft, emotional, breathy

7️⃣ PRODUCTION DNA
   • Core: Piano, Acoustic Guitar, Strings
   • Mix: Vocal forward, warm

8️⃣ EMOTIONAL DNA
   • Mood: Romantic, Bittersweet, Hopeful
   • Arc: Gentle build to emotional chorus

✅ DNA PROFILE COMPLETE!
━━━━━━━━━━━━━━━━━━━━━━━━

🎵 SUNO PROMPT:
Thai Pop Ballad, emotional male vocals, 80bpm, G Major,
romantic bittersweet mood, piano-driven, gentle acoustic guitar,
warm strings, intimate production, soft breathy delivery,
memorable chorus hook, Boyd Kosiyapong DNA

✍️ ORIGINAL LYRICS:
[Verse 1]
วันที่ฟ้าเปลี่ยนสี ฉันก็ยังคงคิดถึงเธอ
ทุกความทรงจำที่มี ยังคงวนอยู่ในใจ
...
```

---

## 🚫 RULES

1. **Research ก่อนเสมอ** - ต้อง search หาข้อมูลจริง
2. **ครบ 8 Dimensions** - ไม่ข้ามขั้นตอน
3. **Original Lyrics 100%** - เขียนใหม่ทั้งหมด
4. **ห้ามใส่ชื่อใน Prompt** - ใช้ DNA descriptors แทน
5. **Thai = Safe Words** - เช็คคำเสี่ยงเสมอ


---

# 🧬 PART 12: ULTIMATE SONGWRITER DEEP CLONING SYSTEM

## 🎯 PHILOSOPHY: CLONE ทุกอย่าง 100%

```
ไม่ใช่แค่ "แต่งเพลงแบบ [ศิลปิน]"
แต่คือ "เป็น [นักแต่งเพลง] คนนั้นเลย"
```

---

## 🔬 8 DNA DIMENSIONS (ต้อง Clone ทุกมิติ)

### 1️⃣ LYRICAL DNA - วิธีเขียนเนื้อ
```
📝 RESEARCH:
- Vocabulary Level: ง่าย/กลาง/ซับซ้อน
- Word Frequency: คำที่ใช้บ่อย (list 20 คำ)
- Signature Phrases: สำนวนเฉพาะตัว
- Pronouns: ฉัน/ผม/เธอ/คุณ (ใช้แบบไหน)
- Tense: อดีต/ปัจจุบัน/อนาคต
- POV: First person / Second person / Third person
- Storytelling: เล่าเรื่องแบบไหน (linear/flashback/abstract)

📋 OUTPUT:
- Word Bank: 50 คำที่ใช้บ่อย
- Phrase Bank: 20 สำนวนเฉพาะ
- Writing Rules: 5 กฎการเขียนของคนนี้
```

### 2️⃣ THEMATIC DNA - ธีมเนื้อหา
```
📝 RESEARCH:
- Primary Themes: ธีมหลัก (ความรัก/สังคม/ปรัชญา/ชีวิต)
- Sub-themes: ธีมรอง
- Emotional Range: อารมณ์ที่ถ่ายทอด
- Message Style: สอน/เล่า/ถาม/ปลอบ
- Perspective: มองโลกแบบไหน (optimist/realist/pessimist)
- Cultural References: อ้างอิงวัฒนธรรมอะไร
- Taboo Topics: หัวข้อที่ไม่แตะ

📋 OUTPUT:
- Theme Map: แผนที่ธีม
- Emotion Palette: 10 อารมณ์ที่ใช้บ่อย
- Message Framework: วิธีสื่อสาร
```

### 3️⃣ RHYME & PHONETIC DNA - สัมผัสและเสียง
```
📝 RESEARCH:
- Rhyme Scheme: AA BB / AB AB / ABC ABC
- Internal Rhyme: สัมผัสในบรรทัด
- End Rhyme: สัมผัสท้ายบรรทัด
- Assonance: สัมผัสสระ
- Consonance: สัมผัสพยัญชนะ
- Syllable Pattern: จำนวนพยางค์ต่อบรรทัด
- Flow: ลื่นไหล/สะดุด/มีจังหวะ

📋 OUTPUT:
- Rhyme Rules: กฎสัมผัส
- Syllable Template: Template พยางค์
- Sound Patterns: Pattern เสียง
```

### 4️⃣ MELODIC DNA - ทำนอง
```
📝 RESEARCH:
- Melodic Contour: ขึ้น-ลง-ราบ pattern
- Interval Preferences: ใช้ interval ไหนบ่อย (2nd, 3rd, 5th)
- Range: กี่ octave
- Hook Style: ท่อนฮุคแบบไหน
- Verse vs Chorus: ทำนอง verse ต่างจาก chorus ยังไง
- Signature Melodic Motif: motif เฉพาะตัว
- Phrasing: ยาว/สั้น/ผสม

📋 OUTPUT:
- Melodic Rules: กฎทำนอง
- Contour Templates: Template ขึ้น-ลง
- Hook Formula: สูตรท่อนฮุค
```

### 5️⃣ HARMONIC DNA - คอร์ดและ Harmony
```
📝 RESEARCH:
- Key Preferences: ชอบ key ไหน (Major/Minor ratio)
- Chord Progressions: progression ที่ใช้บ่อย
- Chord Extensions: ใช้ 7th, 9th, sus ไหม
- Modulation: เปลี่ยน key ระหว่างเพลงไหม
- Bass Movement: bass เดินยังไง
- Tension-Resolution: สร้าง tension ยังไง

📋 OUTPUT:
- Chord Bank: 10 progressions ที่ใช้บ่อย
- Key Map: key ที่ชอบใช้
- Harmonic Rules: กฎ harmony
```

### 6️⃣ RHYTHMIC DNA - จังหวะ
```
📝 RESEARCH:
- Tempo Range: BPM ที่ใช้บ่อย
- Time Signature: 4/4, 3/4, 6/8
- Groove Style: straight/swing/syncopated
- Rhythmic Density: หนาแน่น/โปร่ง
- Accent Patterns: เน้นจังหวะไหน
- Rhythmic Hooks: จังหวะติดหู

📋 OUTPUT:
- Tempo Profile: range BPM
- Groove Templates: Template จังหวะ
- Rhythmic Rules: กฎจังหวะ
```

### 7️⃣ STRUCTURAL DNA - โครงสร้างเพลง
```
📝 RESEARCH:
- Song Length: ความยาวเฉลี่ย
- Section Order: ลำดับ sections
- Section Length: ความยาวแต่ละ section (กี่ bars)
- Intro Style: เปิดเพลงยังไง
- Outro Style: จบเพลงยังไง
- Bridge Usage: ใช้ bridge บ่อยไหม
- Pre-Chorus: มี pre-chorus ไหม
- Repetition: ซ้ำมากน้อยแค่ไหน

📋 OUTPUT:
- Structure Templates: 3-5 โครงสร้างที่ใช้บ่อย
- Section Rules: กฎแต่ละ section
- Length Guidelines: ความยาวมาตรฐาน
```

### 8️⃣ PRODUCTION & ARRANGEMENT DNA - เรียบเรียง
```
📝 RESEARCH:
- Instrumentation: เครื่องดนตรีที่ใช้บ่อย
- Arrangement Style: เรียบเรียงแบบไหน
- Layering: กี่ชั้นเสียง
- Dynamics: ดัง-เบา pattern
- Intro Instrument: เปิดด้วยเครื่องอะไร
- Build-up Style: สร้าง build ยังไง
- Signature Sounds: เสียงเฉพาะตัว
- Mix Style: mix แบบไหน (dry/wet, wide/narrow)

📋 OUTPUT:
- Instrument Palette: เครื่องดนตรีหลัก
- Arrangement Template: Template การเรียบเรียง
- Production Rules: กฎ production
```

---

## 🔄 DEEP CLONE WORKFLOW

```
/deep-clone [นักแต่งเพลง]

ระบบจะ:

PHASE 1: RESEARCH (5-10 นาที)
├── Web Search: ประวัติ, discography, interviews
├── Song Analysis: วิเคราะห์ 10-20 เพลงที่แต่ง
├── Lyrics Study: อ่านเนื้อเพลง 20+ เพลง
├── Music Theory: วิเคราะห์ chords, melody, structure
└── Style Patterns: หา patterns ที่ทำซ้ำ

PHASE 2: LEARN (สร้าง DNA Profile)
├── Extract: ดึง DNA ทั้ง 8 มิติ
├── Pattern Recognition: หา patterns
├── Rule Generation: สร้างกฎการแต่ง
├── Template Creation: สร้าง templates
└── Voice Modeling: จับเสียงเฉพาะตัว

PHASE 3: CLONE (สร้าง Clone System)
├── Word Bank: คลังคำ 100+ คำ
├── Phrase Bank: คลังสำนวน 50+ สำนวน
├── Chord Bank: คลัง progressions 20+
├── Structure Templates: 5 โครงสร้าง
├── Melody Rules: กฎทำนอง
└── Production Guide: คู่มือ production

PHASE 4: GENERATE (สร้างเพลง)
├── Apply DNA: ใช้ DNA ที่วิเคราะห์
├── Write Lyrics: เขียนเนื้อใหม่ 100%
├── Compose Melody: แต่งทำนองตาม rules
├── Build Structure: ใช้ structure template
└── Output: Suno-ready prompt + lyrics
```

---

## 📋 DEEP CLONE OUTPUT TEMPLATE

```markdown
# 🧬 DEEP CLONE PROFILE: [SONGWRITER NAME]

## 📊 BASIC INFO
- **Name:** [Full name]
- **Active Years:** [Years]
- **Notable Works:** [5-10 famous songs]
- **Collaborators:** [Common collaborators]
- **Awards:** [Notable awards]

---

## 1️⃣ LYRICAL DNA

### Vocabulary
- **Level:** [ง่าย/กลาง/ซับซ้อน]
- **Top 20 Words:** [คำที่ใช้บ่อย]
- **Signature Phrases:** [สำนวนเฉพาะ]

### Writing Style
- **POV:** [First/Second/Third person]
- **Tense:** [Past/Present/Future]
- **Storytelling:** [Linear/Flashback/Abstract]

### Word Bank (50 คำ)
```
[คำ 1], [คำ 2], [คำ 3]...
```

### Phrase Bank (20 สำนวน)
```
[สำนวน 1]
[สำนวน 2]
...
```

---

## 2️⃣ THEMATIC DNA

### Primary Themes
1. [Theme 1] - [% ของเพลง]
2. [Theme 2] - [%]
3. [Theme 3] - [%]

### Emotional Palette
- **Dominant:** [Main emotion]
- **Secondary:** [Supporting emotions]
- **Range:** [Emotional spectrum]

### Message Style
- [How they communicate messages]

---

## 3️⃣ RHYME & PHONETIC DNA

### Rhyme Scheme
- **Primary:** [AA BB / AB AB / etc]
- **Verse:** [Scheme]
- **Chorus:** [Scheme]

### Syllable Pattern
- **Verse Line:** [X syllables per line]
- **Chorus Line:** [X syllables per line]

### Sound Rules
1. [Rule 1]
2. [Rule 2]

---

## 4️⃣ MELODIC DNA

### Contour Patterns
- **Verse:** [ascending/descending/wave]
- **Chorus:** [pattern]
- **Hook:** [pattern]

### Interval Preferences
- **Common:** [3rd, 5th, octave]
- **Signature:** [Specific interval]

### Range
- **Typical:** [X octaves]
- **Sweet Spot:** [Note range]

---

## 5️⃣ HARMONIC DNA

### Key Preferences
- **Major:** [X%] - Favorites: [Keys]
- **Minor:** [X%] - Favorites: [Keys]

### Top 5 Chord Progressions
1. [Progression 1] - used in [songs]
2. [Progression 2]
3. [Progression 3]
4. [Progression 4]
5. [Progression 5]

### Harmonic Tricks
- [Signature harmonic move]

---

## 6️⃣ RHYTHMIC DNA

### Tempo Profile
- **Ballad:** [X-X BPM]
- **Mid-tempo:** [X-X BPM]
- **Upbeat:** [X-X BPM]
- **Most Common:** [X BPM]

### Groove Style
- [Straight/Swing/Syncopated]

### Rhythmic Signature
- [Unique rhythmic element]

---

## 7️⃣ STRUCTURAL DNA

### Typical Structure
```
[Intro] X bars
[Verse 1] X bars
[Pre-Chorus] X bars
[Chorus] X bars
[Verse 2] X bars
[Chorus] X bars
[Bridge] X bars
[Final Chorus] X bars
[Outro] X bars
```

### Section Characteristics
- **Intro:** [How they start]
- **Verse:** [Verse style]
- **Chorus:** [Chorus style]
- **Bridge:** [Bridge style]
- **Outro:** [How they end]

---

## 8️⃣ PRODUCTION DNA

### Core Instruments
- [Instrument 1]
- [Instrument 2]
- [Instrument 3]

### Arrangement Style
- [Description]

### Signature Sounds
- [Unique production element]

### Dynamic Pattern
- [How dynamics flow]

---

## 🎵 SUNO PROMPT (Generated from DNA)

```
[Complete Suno-ready prompt based on all DNA]
```

---

## ✍️ LYRICS TEMPLATE (Following DNA)

```
[Verse 1]
[Template with syllable counts and rhyme markers]
_____ _____ _____ (8) [A]
_____ _____ _____ (8) [A]
_____ _____ _____ (7) [B]
_____ _____ _____ (7) [B]

[Chorus]
_____ _____ _____ (6) [C]
_____ _____ _____ (6) [C]
...
```

---

## 🎯 CLONE RULES (10 กฎทอง)

1. [Rule 1]
2. [Rule 2]
3. [Rule 3]
4. [Rule 4]
5. [Rule 5]
6. [Rule 6]
7. [Rule 7]
8. [Rule 8]
9. [Rule 9]
10. [Rule 10]
```

---

## ⚡ QUICK COMMANDS

```
/deep-clone [songwriter]
→ Full 8-dimension DNA analysis + Clone system

/clone-write [songwriter] [theme]
→ เขียนเนื้อเพลงใหม่ด้วย DNA ของ songwriter

/clone-batch [songwriter] [n songs]
→ สร้าง n เพลงด้วย DNA เดียวกัน

/clone-compare [songwriter1] [songwriter2]
→ เปรียบเทียบ DNA 2 คน

/clone-merge [songwriter1] [songwriter2]
→ ผสม DNA 2 คนเข้าด้วยกัน

/clone-adapt [songwriter] [genre]
→ เอา DNA ไปใส่ genre ใหม่
```

---

## 🌍 LANGUAGE-SPECIFIC CLONING

### Thai Songwriters
```
เพิ่ม:
- วรรณยุกต์ Analysis (สามัญ/เอก/โท/ตรี/จัตวา)
- สัมผัสสระ/พยัญชนะ Pattern
- Safe Words Check
- ไม้ยมก Avoidance
- Cultural References (Thai-specific)
```

### Japanese Songwriters
```
เพิ่ม:
- Hiragana/Katakana/Kanji Balance
- Japanese Rhyme Patterns
- Seasonal References (四季)
- Romaji Output
```

### Korean Songwriters
```
เพิ่ม:
- Hangul Patterns
- Korean Rhyme System
- K-pop Structure Conventions
- Romanization Output
```

### English Songwriters
```
Standard:
- Perfect/Slant Rhyme Analysis
- Meter Analysis (Iambic, etc.)
- Colloquial vs Formal
```

---

## 🚫 CLONE ETHICS

1. ✅ Clone วิธีการ/สไตล์ = OK
2. ✅ เขียนเนื้อใหม่ 100% = OK
3. ❌ Copy เนื้อเพลงเดิม = ห้าม
4. ❌ ใส่ชื่อศิลปินใน Suno = ห้าม
5. ❌ อ้างว่าเป็นเพลงของศิลปิน = ห้าม


---

# 🎼 PART 13: ADVANCED MELODIC DNA ANALYSIS

## 🎯 วิเคราะห์การเคลื่อนที่ของ Melody + ท่อนที่เพราะที่สุด

---

## 📊 MELODIC MOVEMENT DIMENSIONS (12 มิติ)

### 1️⃣ CONTOUR SHAPES (รูปร่างทำนอง)
```
📝 วิเคราะห์:

ASCENDING (ขึ้น) ↗
└── เริ่มต่ำ → ไต่สูงขึ้น
└── สร้าง: ความหวัง, พลัง, build-up
└── ใช้ตอน: Pre-chorus, ก่อน climax

DESCENDING (ลง) ↘
└── เริ่มสูง → ค่อยๆ ลง
└── สร้าง: ความเศร้า, สงบ, resolution
└── ใช้ตอน: หลัง climax, outro

ARCH (โค้ง) ∩
└── ต่ำ → สูง → ต่ำ
└── สร้าง: complete phrase, satisfaction
└── ใช้ตอน: Chorus ส่วนใหญ่

INVERTED ARCH (โค้งกลับ) ∪
└── สูง → ต่ำ → สูง
└── สร้าง: tension, unresolved feeling
└── ใช้ตอน: Verse ที่ต้องการ mystery

WAVE (คลื่น) ∿
└── ขึ้น-ลง-ขึ้น-ลง ต่อเนื่อง
└── สร้าง: flowing, continuous motion
└── ใช้ตอน: Verse ยาว

PLATEAU (ราบ) ─
└── อยู่ระดับเดียว หรือเคลื่อนน้อย
└── สร้าง: stability, anticipation
└── ใช้ตอน: Verse เล่าเรื่อง, rap sections

SPIKE (พุ่ง) ⌃
└── ราบๆ แล้วพุ่งขึ้นทันที
└── สร้าง: surprise, emotional peak
└── ใช้ตอน: Hook, climax word
```

### 2️⃣ INTERVAL ANALYSIS (ช่วงเสียง)
```
📝 วิเคราะห์ Interval ที่นักแต่งใช้บ่อย:

STEP (2nd) - ขั้นเดียว
├── Minor 2nd (ครึ่งเสียง): tension, chromatic
├── Major 2nd (เต็มเสียง): smooth, natural
└── Feel: ลื่นไหล, ง่าย, เล่าเรื่อง

SKIP (3rd) - ข้ามขั้น
├── Minor 3rd: sad, minor feel
├── Major 3rd: happy, bright
└── Feel: melodic, singable, memorable

LEAP (4th, 5th) - กระโดด
├── Perfect 4th: strong, anthem-like
├── Perfect 5th: powerful, open
└── Feel: dramatic, attention-grabbing

BIG LEAP (6th, 7th, Octave) - กระโดดใหญ่
├── 6th: romantic, yearning
├── 7th: tension, jazz feel
├── Octave: dramatic, climactic
└── Feel: emotional peak, goosebumps moment

📋 OUTPUT: Interval Profile
- Primary: [ใช้บ่อยสุด]
- Secondary: [ใช้รอง]
- Signature: [Interval เฉพาะตัว]
- Avoid: [ไม่ค่อยใช้]
```

### 3️⃣ MELODIC TENSION & RELEASE
```
📝 วิเคราะห์จุด Tension และ Release:

TENSION BUILDERS (สร้างความตึงเครียด):
├── Ascending sequence (ไต่ขึ้นเรื่อยๆ)
├── Suspension on non-chord tone
├── High note hold
├── Repeated pattern building
├── Chromatic movement
└── Unresolved phrase ending

RELEASE METHODS (ปลดปล่อย):
├── Descending to tonic
├── Resolving to chord tone
├── Big leap down after climb
├── Long note after busy passage
├── Return to familiar motif
└── Cadential phrase

📋 OUTPUT: Tension Map
- Build points: [ตรงไหนของเพลง]
- Peak moments: [จุดสูงสุด]
- Release points: [จุดปลดปล่อย]
- Emotional arc: [กราฟอารมณ์]
```

### 4️⃣ SIGNATURE MELODIC PHRASES (ท่อนทำนองเฉพาะตัว)
```
📝 วิเคราะห์ Melodic Fingerprint:

OPENING MOTIF: ท่อนเปิดที่ใช้บ่อย
├── Pattern: [describe]
├── Intervals: [specific intervals]
└── Examples: [เพลงที่ใช้]

HOOK FORMULA: สูตรท่อนฮุค
├── Contour: [shape]
├── Length: [กี่ notes/beats]
├── Repetition: [ซ้ำกี่ครั้ง]
└── Placement: [อยู่ตรงไหนของ chorus]

CADENTIAL PHRASE: ท่อนจบประโยค
├── Pattern: [describe]
├── Resolution: [จบยังไง]
└── Feel: [ความรู้สึก]

TRANSITIONAL LICKS: ท่อนเชื่อม
├── Verse→Chorus: [pattern]
├── Chorus→Verse: [pattern]
└── Into Bridge: [pattern]
```

### 5️⃣ "SWEET SPOTS" - ท่อนที่เพราะที่สุด
```
📝 วิเคราะห์ว่าทำไมท่อนนั้นเพราะ:

GOOSEBUMPS MOMENTS:
├── Position: อยู่ตรงไหนของเพลง (เช่น Chorus bar 3)
├── Melodic Feature: อะไรทำให้เพราะ
│   ├── Unexpected interval leap
│   ├── High note climax
│   ├── Tension resolution
│   ├── Melodic surprise
│   └── Perfect word-melody match
├── Harmonic Support: คอร์ดช่วยยังไง
├── Lyric Sync: คำตรงกับทำนองยังไง
└── Production: เสียงดนตรีช่วยยังไง

ANALYSIS TEMPLATE:
┌─────────────────────────────────────────┐
│ 🌟 SWEET SPOT #1                        │
├─────────────────────────────────────────┤
│ Location: Chorus, bar 5-6               │
│ Melody: ↗ leap up 5th → hold → ↘ resolve│
│ Why Beautiful:                          │
│ - Unexpected 5th leap creates surprise  │
│ - Lands on highest note of song         │
│ - Perfect sync with emotional word      │
│ - Chord changes to IV (bright lift)     │
│ - Strings swell at this moment          │
└─────────────────────────────────────────┘
```

### 6️⃣ MELODIC RHYTHM (จังหวะของทำนอง)
```
📝 วิเคราะห์ Rhythmic Melody:

NOTE DENSITY: ความหนาแน่นของโน้ต
├── Sparse: น้อย, โน้ตยาว (ballad feel)
├── Moderate: ปานกลาง (pop standard)
├── Dense: หนาแน่น, โน้ตสั้นเยอะ (energetic)
└── Mixed: ผสม (variety)

RHYTHMIC PATTERNS:
├── On-beat: ร้องตรงจังหวะ (straightforward)
├── Syncopated: ร้องก่อน/หลังจังหวะ (groove)
├── Anticipation: ร้องก่อน beat (urgent)
├── Laid-back: ร้องหลัง beat (relaxed)
└── Rubato: ยืดหยุ่น (emotional)

PHRASE RHYTHM:
├── Short phrases: 2-4 beats (punchy)
├── Long phrases: 8+ beats (flowing)
├── Call-response: สลับสั้น-ยาว
└── Building phrases: สั้น→ยาวขึ้นเรื่อยๆ
```

### 7️⃣ RANGE & TESSITURA
```
📝 วิเคราะห์พิสัยเสียง:

TOTAL RANGE: ช่วงกว้างสุด
├── Lowest note: [note]
├── Highest note: [note]
├── Span: [X octaves + X notes]
└── Compare: [กว้าง/แคบกว่า average]

TESSITURA: ช่วงที่ร้องบ่อย
├── Comfort zone: [note range]
├── % of melody: [กี่ % อยู่ในช่วงนี้]
└── Character: [warm/bright/powerful]

STRATEGIC HIGH NOTES:
├── Frequency: กี่ครั้งต่อเพลง
├── Placement: อยู่ตรงไหน
├── Approach: ไปถึงยังไง (step/leap)
└── Purpose: ทำไมใช้ (climax/emotion/hook)

STRATEGIC LOW NOTES:
├── Frequency: กี่ครั้งต่อเพลง
├── Placement: อยู่ตรงไหน
└── Purpose: ทำไมใช้ (intimacy/contrast)
```

### 8️⃣ MELODIC DEVELOPMENT
```
📝 วิเคราะห์การพัฒนาทำนอง:

VERSE 1 → VERSE 2:
├── Same: เหมือนเดิม
├── Variation: เปลี่ยนเล็กน้อย
├── Development: พัฒนาต่อ
└── Pattern: [describe]

CHORUS 1 → FINAL CHORUS:
├── Same: เหมือนเดิม
├── Higher: ขึ้นไปอีก key
├── Ad-libs: เพิ่ม ad-lib
├── Extended: ยาวขึ้น
└── Pattern: [describe]

MOTIF TRANSFORMATION:
├── Original motif: [describe]
├── Variation 1: [how it changes]
├── Variation 2: [how it changes]
└── Final form: [conclude]
```

### 9️⃣ WORD-MELODY RELATIONSHIP
```
📝 วิเคราะห์ความสัมพันธ์คำกับทำนอง:

WORD PAINTING: ทำนองวาดภาพคำ
├── "High/สูง" → melody goes up
├── "Fall/ตก" → melody descends
├── "Heart/หัวใจ" → warm notes
├── "Cry/ร้องไห้" → descending, minor
└── Pattern: [นักแต่งทำแบบนี้บ่อยไหม]

STRESS ALIGNMENT: เน้นคำตรงจังหวะ
├── Important words on strong beats
├── Important words on high notes
└── Pattern: [describe]

SYLLABLE MATCHING:
├── 1 note per syllable (syllabic)
├── Multiple notes per syllable (melismatic)
├── Mix: [ratio]
└── Style: [describe]
```

### 🔟 MELODIC HOOKS ANALYSIS
```
📝 วิเคราะห์ท่อนติดหู:

PRIMARY HOOK: ท่อนฮุคหลัก
├── Melody: [describe contour]
├── Length: [กี่ beats/bars]
├── Repetition: [ซ้ำกี่ครั้งใน chorus]
├── Lyrics: [คำที่ใช้กับ hook]
└── Why Catchy: [ทำไมติดหู]

SECONDARY HOOKS: ท่อนฮุครอง
├── Verse hook: [if any]
├── Instrumental hook: [if any]
├── Ad-lib hook: [if any]
└── Intro hook: [if any]

HOOK FORMULA ของนักแต่งคนนี้:
┌─────────────────────────────────────────┐
│ 1. Interval: [ใช้ interval อะไร]        │
│ 2. Rhythm: [จังหวะแบบไหน]              │
│ 3. Repetition: [ซ้ำยังไง]              │
│ 4. Contour: [รูปร่างยังไง]             │
│ 5. Range: [ช่วงเสียงไหน]               │
└─────────────────────────────────────────┘
```

---

## 📋 COMPLETE MELODIC DNA PROFILE TEMPLATE

```markdown
# 🎼 MELODIC DNA PROFILE: [SONGWRITER]

## OVERVIEW
- **Melodic Signature:** [1-2 sentence summary]
- **Difficulty Level:** [Easy/Moderate/Hard to sing]
- **Memorable Factor:** [1-10 scale]

---

## 1. CONTOUR PREFERENCES
| Section | Primary Shape | Secondary | Example |
|---------|---------------|-----------|---------|
| Verse | [shape] | [shape] | [song] |
| Pre-Chorus | [shape] | [shape] | [song] |
| Chorus | [shape] | [shape] | [song] |
| Bridge | [shape] | [shape] | [song] |

**Signature Contour:**
```
[Visual representation]
e.g., Verse: ─↗─↘  Chorus: ↗↗↗↘
```

---

## 2. INTERVAL PROFILE
| Interval | Frequency | Usage |
|----------|-----------|-------|
| Step (2nd) | [%] | [when used] |
| Skip (3rd) | [%] | [when used] |
| 4th | [%] | [when used] |
| 5th | [%] | [when used] |
| 6th+ | [%] | [when used] |

**Signature Interval:** [e.g., "Perfect 5th leap on emotional words"]

---

## 3. SWEET SPOTS (เพราะที่สุด)

### Sweet Spot #1: [Song Name]
- **Location:** [where in song]
- **Melody Move:** [describe]
- **Why Beautiful:** [analysis]
- **Recreate Rule:** [how to clone this]

### Sweet Spot #2: [Song Name]
- **Location:** [where]
- **Melody Move:** [describe]
- **Why Beautiful:** [analysis]
- **Recreate Rule:** [how to clone]

### Sweet Spot #3: [Song Name]
...

---

## 4. HOOK FORMULA
```
┌─────────────────────────────────────────┐
│ [SONGWRITER]'s HOOK RECIPE:             │
├─────────────────────────────────────────┤
│ ✓ Start with: [describe]                │
│ ✓ Move by: [interval]                   │
│ ✓ Shape: [contour]                      │
│ ✓ Repeat: [X times]                     │
│ ✓ End with: [describe]                  │
│ ✓ Total length: [X beats/bars]          │
└─────────────────────────────────────────┘
```

---

## 5. TENSION-RELEASE MAP
```
Verse:      ░░░░░░░░░░ (low tension, storytelling)
Pre-Chorus: ░░░░░████░ (building)
Chorus:     ██████████ (peak)
            ████░░░░░░ (release)
Bridge:     ░░░░██████ (rebuild to final)
Final:      ██████████ (biggest peak)
            ░░░░░░░░░░ (complete release)
```

---

## 6. MELODIC RULES (10 กฎทำนอง)

1. [Rule 1 - e.g., "Always leap up on emotional keywords"]
2. [Rule 2 - e.g., "Verse stays within 5th range"]
3. [Rule 3 - e.g., "Chorus hits highest note on hook word"]
4. [Rule 4 - e.g., "Uses arch shape for satisfying phrases"]
5. [Rule 5 - e.g., "Pre-chorus always ascending"]
6. [Rule 6 - e.g., "Bridge introduces new melodic idea"]
7. [Rule 7 - e.g., "Final chorus goes up a step"]
8. [Rule 8 - e.g., "Syncopated rhythm on verse"]
9. [Rule 9 - e.g., "Long notes on important words"]
10. [Rule 10 - e.g., "Resolves to tonic at end of sections"]

---

## 7. RANGE PROFILE
```
         ┌─ Highest: [note] (used [X] times, on [moments])
         │
    ████████ Sweet Spot / Tessitura
    ████████ (most melody here)
         │
         └─ Lowest: [note] (used [X] times, on [moments])

Total Range: [X octaves]
Tessitura: [note] to [note]
```

---

## 8. CLONE INSTRUCTIONS

### To Write Melody Like [SONGWRITER]:

**VERSE:**
- Start in [range]
- Use mostly [intervals]
- Shape: [contour]
- Keep tension [low/building]

**PRE-CHORUS:**
- Move [up/down] from verse range
- Build with [technique]
- End on [type of note] for anticipation

**CHORUS:**
- Start with [describe]
- Hit peak at [moment]
- Hook uses [interval] + [rhythm]
- Repeat hook [X] times
- Release at end with [technique]

**BRIDGE:**
- [Instructions]

**FINAL CHORUS:**
- [How to make it bigger]
```

---

## ⚡ QUICK COMMANDS

| Command | Description |
|---------|-------------|
| `/melody-dna [songwriter]` | วิเคราะห์ Melodic DNA ครบ |
| `/sweet-spots [songwriter]` | หาท่อนเพราะที่สุด 5 ท่อน |
| `/hook-formula [songwriter]` | สูตรท่อนฮุค |
| `/contour-map [songwriter]` | แผนที่ขึ้น-ลงของทำนอง |
| `/clone-melody [songwriter] [theme]` | เขียนทำนองใหม่ตาม DNA |

---

# 🤖 PART 14: SUNO AUTOMATION FORMAT

## รูปแบบไฟล์ .md สำหรับ Suno Automation Chrome Extension

**สำคัญ:** รูปแบบนี้ทดสอบแล้วว่าใช้งานได้จริงกับ Extension

---

## 📋 โครงสร้างไฟล์ Automation Queue

```markdown
# 🎵 [Collection Name] ([X] Songs)

## 🎵 Style Prompt (ใช้เหมือนกันทุกเพลง)

` ` `
[Primary Genre: ...] + [Secondary Genre: ...]
Core Instruments: ...
Support Instruments: ...
Tempo: XXX BPM | Key: X Major/Minor
Mood: ...
Vocal: ...
Structure: [Intro][Verse][Pre-Chorus][Chorus][Bridge][Outro]
Production: ...
FX: ...
Dynamic: mp → f → mp
` ` `

---

## 🎤 Songwriter DNA Reference (ถ้ามีการใช้ DNA หลายคน)

| # | Songwriter DNA | Style Influence |
|---|----------------|-----------------|
| 1 | Artist Name | Style description |
| 2 | Artist Name | Style description |

---

## เพลงที่ 1

**ชื่อเพลง:** 1.Song Title (Subtitle)

**Style:** [Primary Genre: ...] + [Secondary Genre: ...], Core Instruments: ..., Tempo: XXX BPM, Key: X Major, Mood: ..., Vocal: ..., Production: ..., FX: ...

**เนื้อเพลง:**
[Intro]
(Instrument description)

[Verse 1]
Lyrics line 1
Lyrics line 2

[Pre-Chorus]
Lyrics...

[Chorus]
Hook lyrics...

[Verse 2]
Lyrics...

[Bridge]
Lyrics...

[Outro]
(Instrument description)
Final lyrics.
[End]

**Songwriter Influence:** Artist Name

---

## เพลงที่ 2
(repeat format...)

---

# 📋 Summary Table — X Songs

| # | ชื่อเพลง | Songwriter DNA | Theme |
|---|----------|----------------|-------|
| 1 | Song Title | Artist | Theme |
| 2 | Song Title | Artist | Theme |

---

🔥 Generated by MRARRANGER AI STUDIO — Music Team
```

---

## ⚠️ กฎสำคัญสำหรับ Automation Format

### 1. Field Names (ต้องใช้ภาษาไทย)
```
✅ **ชื่อเพลง:**
✅ **เนื้อเพลง:**
✅ **Songwriter Influence:**

❌ **TITLE:**
❌ **LYRICS:**
❌ **Song Title:**
```

### 2. Song Numbering
```
✅ ## เพลงที่ 1
✅ **ชื่อเพลง:** 1.Song Title (Subtitle)

❌ ## SONG 1 of 15
❌ **ชื่อเพลง:** Song Title
```

### 3. Style Format (Inline, ไม่มี line breaks)
```
✅ **Style:** [Primary Genre: Pop Rock] + [Secondary Genre: Acoustic], Core Instruments: Guitar, Bass, Drums, Tempo: 120 BPM, Key: C Major, Mood: Happy

❌ **Style:** 
[Primary Genre: Pop Rock]
Core Instruments: Guitar
```

### 4. Lyrics Sections
```
✅ **เนื้อเพลง:**
[Intro]
(Guitar fingerstyle)

[Verse 1]
Walking down...

❌ **เนื้อเพลง:**
**[Intro]**
Guitar fingerstyle
```

### 5. Song Separator
```
✅ ---

❌ ===
❌ ***
```

---

## 📝 COMPLETE EXAMPLE (1 Song)

```markdown
## เพลงที่ 1

**ชื่อเพลง:** 1.Photograph of Us (Old Streets)

**Style:** [Primary Genre: Soft Pop Rock] + [Secondary Genre: Acoustic Light Rock], Core Instruments: Acoustic Guitar (open chords), Electric Guitar (chorus FX), Bass Guitar, Soft Snare Drum, Support Instruments: Electric Piano, Warm Pad, Ambient Strings, Tempo: 90 BPM, Key: A Major, Mood: Nostalgic, Hopeful, Bittersweet, Vocal: Male, Warm Mid-Range, Slightly Raspy, Production: Clean acoustic tone, analog warmth, light tape saturation, FX: Stereo Reverb, Subtle Delay on Guitar, Dynamic: mp → f → mp

**เนื้อเพลง:**
[Intro]
(Acoustic Guitar fingerstyle)

[Verse 1]
Walking down the pavement where we used to run
Chasing setting suns before the day was done
I remember how the light would hit your face
In this crowded place, yeah, we found our space

[Pre-Chorus]
Time moves fast, they say it never waits
But I'm still standing here outside your gates

[Chorus]
So keep me in your pocket like a faded note
Remember all the words that we never wrote
Oh, darling, we were young, but we had it all
I'm waiting for the moment that you call
Back home

[Verse 2]
Coffee cups and stains on the kitchen floor
Shadows dancing 'round behind the bedroom door
We were messy, we were loud, we were everything
Now I'm strumming on this broken G-string

[Chorus]
So keep me in your pocket like a faded note
Remember all the words that we never wrote
Oh, darling, we were young, but we had it all
I'm waiting for the moment that you call
Back home

[Bridge]
If the world stops turning, I'll be holding on
To the echo of a love that isn't gone

[Chorus]
So keep me in your pocket like a faded note
Remember all the words that we never wrote
Oh, darling, we were young, but we had it all
I'm waiting for the moment that you call
Back home

[Outro]
(Acoustic Guitar gentle picking)
Mmm... back home.
[End]

**Songwriter Influence:** Ed Sheeran

---
```

---

## ⚡ AUTOMATION COMMANDS

| Command | Description |
|---------|-------------|
| `/auto [n] [genre]` | สร้าง Automation Queue n เพลง |
| `/auto-batch [theme] [n]` | Batch create ตาม Theme |
| `/auto-dna [songwriter] [n]` | สร้าง n เพลงจาก Songwriter DNA |
| `/auto-export` | Export เป็น .md file |
| `/auto-queue [playlist]` | สร้าง Queue จาก Playlist concept |

---

## 🔧 WORKFLOW สำหรับสร้าง Automation Queue

### Step 1: วางแผน
```
- จำนวนเพลง: [X]
- Genre/Style: [specify]
- Songwriter DNA: [list if using rotation]
- Theme ของ Collection: [describe]
```

### Step 2: สร้าง Style Prompt รวม
```
- กำหนด Genre หลัก + รอง
- เลือก Instruments
- ตั้ง Tempo, Key, Mood
- กำหนด Vocal Style
- กำหนด Production Style
```

### Step 3: สร้าง Songwriter DNA Table (ถ้าใช้)
```
- List songwriters ที่จะ rotate
- ระบุ Style Influence แต่ละคน
```

### Step 4: Generate Songs
```
- ใช้ format ที่กำหนด
- ระวังเรื่อง field names (ภาษาไทย)
- ใส่เลขลำดับที่ชื่อเพลง
```

### Step 5: Summary Table
```
- สรุปทุกเพลงในตาราง
- ใส่ Theme แต่ละเพลง
```

### Step 6: Export
```
- Save เป็น .md file
- ตั้งชื่อให้จำง่าย: [genre]_[n]_songs.md
```

---

## 📊 STYLE PROMPT TEMPLATES

### Template 1: Soft Pop Rock
```
[Primary Genre: Soft Pop Rock] + [Secondary Genre: Acoustic Light Rock], Core Instruments: Acoustic Guitar (open chords), Electric Guitar (chorus FX), Bass Guitar, Soft Snare Drum, Support Instruments: Electric Piano, Warm Pad, Ambient Strings, Tempo: 90 BPM, Key: A Major, Mood: Nostalgic, Hopeful, Bittersweet, Vocal: Male, Warm Mid-Range, Slightly Raspy, Production: Clean acoustic tone, analog warmth, light tape saturation, FX: Stereo Reverb, Subtle Delay on Guitar, Dynamic: mp → f → mp
```

### Template 2: Modern Pop
```
[Primary Genre: Modern Pop] + [Secondary Genre: Synth Pop], Core Instruments: Synth Bass, Drum Machine, Electric Piano, Support Instruments: Pad Synth, Pluck Synth, Vocal Chops, Tempo: 110 BPM, Key: C Major, Mood: Uplifting, Catchy, Fun, Vocal: Female, Clear, Bright, Production: Polished modern, compressed, FX: Sidechain, Reverb, Delay, Dynamic: p → f → mf
```

### Template 3: Emotional Ballad
```
[Primary Genre: Pop Ballad] + [Secondary Genre: Piano Ballad], Core Instruments: Grand Piano, Strings Section, Soft Drums, Support Instruments: Cello, Violin, Warm Pad, Tempo: 70 BPM, Key: G Major, Mood: Emotional, Heartfelt, Tender, Vocal: Male/Female, Emotional, Breathy, Production: Intimate, spacious, natural reverb, FX: Hall Reverb, Subtle Compression, Dynamic: pp → mf → pp
```

### Template 4: Indie Folk
```
[Primary Genre: Indie Folk] + [Secondary Genre: Acoustic], Core Instruments: Acoustic Guitar (fingerpicking), Upright Bass, Brushed Drums, Support Instruments: Banjo, Mandolin, Harmonica, Tempo: 100 BPM, Key: D Major, Mood: Warm, Organic, Storytelling, Vocal: Male, Natural, Warm, Production: Organic, minimal processing, live room feel, FX: Room Reverb, Tape Warmth, Dynamic: mp → mf → mp
```

### Template 5: R&B Soul
```
[Primary Genre: R&B] + [Secondary Genre: Neo Soul], Core Instruments: Rhodes Piano, Bass Guitar (groove), Drums (pocket), Support Instruments: Brass Section, Strings, Organ, Tempo: 85 BPM, Key: Eb Major, Mood: Smooth, Sensual, Groovy, Vocal: Male/Female, Soulful, Melismatic, Production: Warm, vintage, analog saturation, FX: Tape Echo, Plate Reverb, Dynamic: mp → f → mf
```

### Template 6: Thai Pop
```
[Primary Genre: Thai Pop] + [Secondary Genre: Thai Ballad], Core Instruments: Acoustic Guitar, Piano, Bass Guitar, Drums, Support Instruments: Strings, Pad Synth, Thai Traditional (optional), Tempo: 85 BPM, Key: G Major, Mood: Emotional, Romantic, Bittersweet, Vocal: Thai Male/Female, Emotional, Clear, Production: Clean, modern Thai pop, FX: Reverb, Light Delay, Dynamic: p → f → mp
```

---

## 🎯 15 SONGWRITERS DNA ROTATION TEMPLATE

```markdown
## 🎤 15 Songwriters DNA Reference

| # | Songwriter DNA | Style Influence |
|---|----------------|-----------------|
| 1 | Ed Sheeran | Acoustic fingerstyle, percussive, storytelling |
| 2 | Taylor Swift | Conversational, detailed imagery, pop-country |
| 3 | Coldplay | Anthemic falsetto, U2-style delay, ethereal |
| 4 | Jason Mraz | Funky syncopation, playful, jazzy |
| 5 | The Script | Soulful Irish lilt, emotional rasp, explosive |
| 6 | Radiohead | Ethereal falsetto, atmospheric, hypnotic |
| 7 | John Mayer | Bluesy fingerpicking, smooth, relaxed |
| 8 | Maroon 5 | Funky pop, high tenor, catchy hooks |
| 9 | OneRepublic | Anthemic, orchestral, driving |
| 10 | James Bay | Raspy, raw emotion, organic rock |
| 11 | Brandon Boyd (Incubus) | Spiritual, relaxed, soaring |
| 12 | The 1975 | Modern pop, wordy, British inflection |
| 13 | Hozier | Deep soulful, gospel influence, poetic |
| 14 | Goo Goo Dolls | Raspy rock, anthemic, open tuning |
| 15 | Lifehouse | Post-grunge, intimate, wall of sound |
```

---

## ✅ CHECKLIST ก่อน Export

```
☐ หัวข้อ: # 🎵 [Collection Name] (X Songs)
☐ Style Prompt รวมใน code block
☐ Songwriter DNA Table (ถ้ามี rotation)
☐ ทุกเพลงใช้ ## เพลงที่ X
☐ **ชื่อเพลง:** มีเลขลำดับ X.Title (Subtitle)
☐ **Style:** เป็น inline (ไม่มี line breaks)
☐ **เนื้อเพลง:** มี section tags ครบ
☐ **Songwriter Influence:** ระบุชัดเจน
☐ --- คั่นระหว่างเพลง
☐ Summary Table ท้ายไฟล์
☐ Footer: 🔥 Generated by MRARRANGER AI STUDIO
```