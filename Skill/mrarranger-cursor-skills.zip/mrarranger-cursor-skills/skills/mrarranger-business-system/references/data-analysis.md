# data-analysis

**Source:** `/mnt/skills/user/data-analysis/SKILL.md`
**Size:** 3178 bytes

---

---
name: data-analysis
description: Data analysis skill for exploring datasets, generating insights, and creating reports. Use when analyzing CSV files, comments data, lead data, or any structured data to find patterns and make recommendations.
---

# Data Analysis

## When to use this skill

* **Data exploration**: Understand a new dataset
* **Report generation**: Derive data-driven insights
* **Quality validation**: Check data consistency
* **Decision support**: Make data-driven recommendations
* **Comment analysis**: Analyze TikTok/social media comments to find patterns

## Instructions

### Step 1: Load and explore data

**Python (Pandas)**:

```python
import pandas as pd
import numpy as np

# Load CSV
df = pd.read_csv('data.csv')

# Basic info
print(df.info())
print(df.describe())
print(df.head(10))

# Check missing values
print(df.isnull().sum())
```

### Step 2: Data cleaning

```python
# Handle missing values
df['column'].fillna(df['column'].mean(), inplace=True)
df.dropna(subset=['required_column'], inplace=True)

# Remove duplicates
df.drop_duplicates(inplace=True)

# Type conversions
df['date'] = pd.to_datetime(df['date'])
```

### Step 3: Statistical analysis

```python
# Descriptive statistics
print(df['numeric_column'].describe())

# Grouped analysis
grouped = df.groupby('category').agg({
    'value': ['mean', 'sum', 'count'],
})
print(grouped)

# Pivot table
pivot = pd.pivot_table(df,
    values='sales',
    index='region',
    columns='month',
    aggfunc='sum'
)
```

### Step 4: Visualization

```python
import matplotlib.pyplot as plt
import seaborn as sns

# Bar chart
df.groupby('category')['value'].sum().plot(kind='bar')
plt.title('Value by Category')
plt.savefig('chart.png')

# Time series
df.groupby('date')['value'].sum().plot()
plt.title('Trend over Time')
plt.savefig('timeseries.png')
```

### Step 5: Derive insights

```python
# Top/bottom analysis
top_10 = df.nlargest(10, 'value')

# Trend analysis
df['month'] = df['date'].dt.to_period('M')
monthly_trend = df.groupby('month')['value'].sum()
growth = monthly_trend.pct_change() * 100

# Segment analysis
segments = df.groupby('segment').agg({
    'revenue': 'sum',
    'customers': 'nunique',
})
```

## Output format

### Analysis report structure

```
# Data Analysis Report

## 1. Dataset overview
- Dataset: [name]
- Records: X,XXX
- Columns: XX

## 2. Key findings
- Insight 1
- Insight 2
- Insight 3

## 3. Statistical summary
| Metric | Value |
|--------|-------|
| Total  | X,XXX |
| Top category | X |

## 4. Recommendations
1. Recommendation 1
2. Recommendation 2
```

## Best practices

1. **Understand the data first**: Learn structure and meaning before analysis
2. **Incremental analysis**: Move from simple to complex analyses
3. **Use visualization**: Use charts to spot patterns
4. **Validate assumptions**: Always verify assumptions about the data
5. **Reproducibility**: Document analysis code and results

## Constraints

### Required rules (MUST)

1. Preserve raw data (work on a copy)
2. Document the analysis process
3. Validate results

### Prohibited (MUST NOT)

1. Do not expose sensitive personal data
2. Do not draw unsupported conclusions