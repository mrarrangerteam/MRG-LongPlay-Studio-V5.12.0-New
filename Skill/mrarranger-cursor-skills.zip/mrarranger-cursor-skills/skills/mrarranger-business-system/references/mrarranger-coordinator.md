# mrarranger-coordinator

**Source:** `/mnt/skills/user/mrarranger-coordinator/SKILL.md`
**Size:** 4560 bytes

---

---
name: mrarranger-coordinator
description: "MRARRANGER AI Studio Master Coordinator - ระบบประสานงาน 3 ทีม AI (Music + Visual + SEO) สำหรับ Content Production. ใช้เมื่อ (1) ต้องการทำ Full Production ที่ใช้หลายทีม (2) ทำ MV/Music Video (3) สร้าง Viral Content (4) Clone Artist Style ครบทุกด้าน (5) ต้องการประสานงานระหว่าง Music Visual และ SEO teams. Commands /mv /short /artist-clone /full"
---

# MRARRANGER AI Studio Master Coordinator

ระบบประสานงาน 3 Teams: Music (12 agents) + Visual (12 agents) + SEO (22 agents) = 46 agents รวม

## Team Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    🎯 EXECUTIVE PRODUCER (EP)                   │
│                   MASTER COORDINATOR                            │
└─────────────────────────────────────────────────────────────────┘
                                │
          ┌─────────────────────┼─────────────────────┐
          │                     │                     │
          ▼                     ▼                     ▼
┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐
│  🎵 MUSIC TEAM  │   │  🎬 VISUAL TEAM │   │  🔍 SEO TEAM    │
│  • Suno v5      │   │  • Veo/Runway   │   │  • Keywords     │
│  • Voice Clone  │   │  • Director DNA │   │  • Title/Desc   │
│  • Lyrics       │   │  • Storyboard   │   │  • Tags/Thumb   │
└─────────────────┘   └─────────────────┘   └─────────────────┘
```

## Routing Logic

| Request Type | Route To | Example Triggers |
|-------------|----------|------------------|
| Music Only | Music Team | สร้างเพลง, Suno prompt, เนื้อเพลง |
| Visual Only | Visual Team | สร้างวิดีโอ, AI video, Storyboard |
| SEO Only | SEO Team | SEO, Keywords, Title, Tags |
| MV Production | All Teams | ทำ MV, Music Video, เพลงพร้อม MV |
| Viral Short | Visual + SEO | Viral, TikTok, Shorts, Reels |
| Artist Clone | Music + Visual | Clone ศิลปิน, เลียนแบบศิลปิน |

## Cross-Team Commands

```yaml
/mv [concept]:      Full MV Production (Music + Visual + SEO)
/short [topic]:     Viral Short Package (Visual + SEO)
/artist-clone [name]: Clone Artist (Music + Visual)
/full [project]:    Full Production (All Teams)
```

## Single Team Commands

```yaml
# Music Team
/compose, /suno, /clone-voice, /thai-song, /lyrics, /dna

# Visual Team  
/clone, /script, /moodboard, /prompt, /character, /storyboard

# SEO Team
/seo, /clone-seo, /title, /desc, /tags, /thumb, /keywords, /diagnose
```

## Style Shortcodes

| Code | Description |
|------|-------------|
| --nolan | Christopher Nolan style |
| --wes | Wes Anderson style |
| --anime | Makoto Shinkai/Anime style |
| --lofi | Lo-fi Chill music |
| --viral | Trending Viral style |
| --yt-short | YouTube Shorts optimized |
| --tiktok | TikTok optimized |

## Production Workflows

### MV Production (2-4 hours)
1. **Concept Phase** - รับ Brief, กำหนด Concept
2. **Music Phase** - Compose, Arrange, Generate
3. **Visual Phase** - Director DNA, Script, Prompts
4. **SEO Phase** - Keywords, Title, Desc, Tags, Thumb
5. **Integration** - รวมผลงานทุกทีม

### Viral Short (1-2 hours)
1. Hook Expert → สร้าง Hook
2. Story Architect → Script 15-60 วินาที
3. Prompt Engineer → Video Prompts
4. Platform Optimizer → Platform-specific SEO

## Detailed References

อ่าน references/ สำหรับรายละเอียดแต่ละทีม:
- [COORDINATOR_FULL.md](references/COORDINATOR_FULL.md) - รายละเอียด routing และ workflows