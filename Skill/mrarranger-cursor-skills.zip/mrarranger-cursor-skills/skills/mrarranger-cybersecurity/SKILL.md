---
name: mrarranger-cybersecurity
description: "MRARRANGER Cybersecurity - รวม Penetration Testing, Incident Response, Threat Modeling, SOC Operations, OWASP Top 10, Vulnerability Assessment, Network Security, Cloud Security, Zero Trust Architecture, Security Compliance (ISO 27001, SOC2, PCI-DSS), Malware Analysis, Forensics, Bug Bounty, Security Awareness Training. Commands: /pentest /incident /threat /soc /owasp /vuln /netsec /cloudsec /zerotrust /compliance /forensics /bugbounty. Triggers: cybersecurity, security audit, penetration test, vulnerability, incident response, threat model, OWASP, SOC, compliance, forensics"
---

# Cybersecurity & Threat Defense Skill

## Overview

This skill provides comprehensive guidance on cybersecurity, threat defense, and risk management. It covers both defensive and offensive security practices, compliance frameworks, and incident management.

## Core Competencies

### 1. Penetration Testing & Vulnerability Assessment

**Methodology**: White-box, Gray-box, Black-box testing approaches

**Framework**: NIST SP 800-115, OWASP Testing Guide, PTES (Penetration Testing Execution Standard)

**Phases**:
- Reconnaissance (passive & active information gathering)
- Scanning (network discovery, service enumeration)
- Enumeration (detailed service probing)
- Vulnerability identification and validation
- Exploitation (controlled, authorized testing)
- Post-exploitation (impact assessment)
- Reporting (findings, remediation prioritization)

**Common Tools**: Nmap, Burp Suite, Metasploit Framework, Nessus, Qualys, Wireshark, SQLMap, ZAP

**Best Practices**:
- Always obtain written authorization before testing
- Document scope boundaries and exclusions clearly
- Test in non-production environments when possible
- Follow responsible disclosure practices
- Maintain detailed logs of all testing activities
- Prioritize findings by risk and business impact

### 2. Incident Response & Management

**IR Lifecycle**:
1. Preparation (tools, processes, training)
2. Detection & Analysis (alerting, investigation)
3. Containment (short-term, long-term strategies)
4. Eradication (root cause removal)
5. Recovery (service restoration)
6. Post-incident (review, lessons learned)

**Response Team Structure**:
- Incident Commander (overall coordination)
- Security Lead (technical investigation)
- Operations Lead (system stability)
- Communications Lead (stakeholder updates)
- Legal/Compliance (documentation, reporting)

**Documentation Template**:
- Incident ID, date/time, severity level
- Affected assets and systems
- Timeline of events
- Actions taken and by whom
- Impact assessment
- Root cause analysis
- Remediation steps
- Preventive measures

**Key Metrics**: MTTR (Mean Time to Response), MTTD (Mean Time to Detect), RTO (Recovery Time Objective), RPO (Recovery Point Objective)

### 3. Threat Modeling

**Methodologies**:
- STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)
- PASTA (Process for Attack Simulation and Threat Analysis)
- Attack Trees
- Data Flow Diagrams (DFD)

**Process**:
1. Define system scope and boundaries
2. Create data flow diagrams
3. Identify assets and trust boundaries
4. Enumerate threats using STRIDE/PASTA
5. Assess likelihood and impact
6. Develop mitigation strategies
7. Validate and iterate

**Tools**: Microsoft Threat Modeling Tool, draw.io, Lucidchart, IriusRisk

### 4. SOC (Security Operations Center) Operations

**Key Functions**:
- 24/7 monitoring and alerting
- Log aggregation and analysis (SIEM)
- Threat intelligence integration
- Escalation procedures
- Alert triage and response
- Compliance monitoring
- Reporting and metrics

**Tool Stack**: Splunk, ELK Stack, Sumo Logic, Datadog, Microsoft Sentinel

**Alert Management**:
- Define alert thresholds and baselines
- Implement alert fatigue reduction
- Create runbooks for common alerts
- Establish escalation procedures
- Track metrics (true positive/false positive rates)

### 5. OWASP Top 10

**Current Top 10 (2021)**:
1. Broken Access Control - Fix through role-based access control (RBAC), principle of least privilege
2. Cryptographic Failures - Use strong encryption, secure key management
3. Injection - Input validation, parameterized queries, prepared statements
4. Insecure Design - Threat modeling, secure SDLC, design reviews
5. Security Misconfiguration - Security hardening, least privilege defaults, config management
6. Vulnerable Components - Dependency tracking, version management, patch management
7. Authentication Failures - Strong authentication, multi-factor authentication, session management
8. Data Integrity Failures - Message signing, secure serialization, code integrity checks
9. Logging & Monitoring Failures - Comprehensive logging, alerting, audit trails
10. SSRF (Server-Side Request Forgery) - Input validation, network segmentation, disable unnecessary protocols

**Remediation for Each**:
- Code review and testing
- Implement security controls
- Security training for developers
- Penetration testing and validation
- Regular assessments

### 6. Network Security

**Key Areas**:
- Firewall configuration and management
- Intrusion Detection/Prevention Systems (IDS/IPS)
- Network segmentation and zero-trust principles
- VPN and encrypted communications
- DDoS mitigation strategies
- DNS security (DNSSEC)
- Border protection

**Architecture Best Practices**:
- Defense in depth (multiple layers)
- Network segmentation (DMZ, internal zones)
- Zero Trust architecture (never trust, always verify)
- Encrypted communications by default
- Monitoring and logging at network boundaries

### 7. Cloud Security

**Key Domains**:
- Cloud Infrastructure Security (AWS, Azure, GCP)
- Identity and Access Management (IAM)
- Data protection in transit and at rest
- Container security (Docker, Kubernetes)
- Serverless security
- Cloud-native compliance

**Best Practices**:
- Regular cloud security assessments
- Implement least privilege IAM policies
- Enable encryption for sensitive data
- Use cloud security posture management (CSPM) tools
- Monitor cloud logs (CloudTrail, Cloud Audit Logs)
- Regular backup and disaster recovery testing
- API security

### 8. Zero Trust Architecture

**Core Principles**:
- Never trust, always verify (implicit distrust)
- Assume breach mentality
- Verify every access request
- Principle of least privilege
- Microsegmentation
- Continuous monitoring and validation

**Implementation Steps**:
1. Map network and identify data flows
2. Establish microsegments
3. Implement strong identity verification
4. Deploy network access controls
5. Monitor and validate continuously
6. Evolve based on threat intelligence

**Technologies**: Identity providers, network access controls, behavioral analytics, encryption

### 9. Security Compliance Frameworks

**ISO 27001:2022**
- Information Security Management System (ISMS)
- 14 clauses covering governance to incident management
- Certification path: Gap assessment → implementation → audit

**SOC 2 (Type I & II)**
- Trust Service Criteria: Security, Availability, Processing Integrity, Confidentiality, Privacy
- Type I: Point-in-time assessment
- Type II: 6-12 month operational assessment
- Common for SaaS companies and service providers

**PCI-DSS (Payment Card Industry Data Security Standard)**
- 12 requirements for handling card data
- Network security, access control, encryption
- Regular testing and monitoring
- Compliance levels based on transaction volume

**HIPAA** (healthcare data)
- Privacy Rule, Security Rule, Breach Notification Rule
- Technical, administrative, physical safeguards
- Business associate agreements

**GDPR** (European privacy regulation)
- Data protection by design
- Consent management
- Data subject rights (right to be forgotten)
- Privacy Impact Assessments

**Compliance Roadmap**:
1. Gap assessment
2. Create remediation plan
3. Implement controls
4. Test and validate
5. Document evidence
6. Internal audit
7. Third-party audit/certification

### 10. Malware Analysis

**Static Analysis**:
- File hashing and reputation checks (VirusTotal)
- Binary examination (Ghidra, IDA Pro)
- String extraction
- Import/export analysis
- Packing detection

**Dynamic Analysis**:
- Sandbox execution (Cuckoo, Any.run)
- Behavioral monitoring
- Network traffic analysis
- Process monitoring
- Registry/file system changes

**Indicators of Compromise (IoCs)**:
- File hashes
- IP addresses
- Domain names
- URLs
- Email headers
- Malware signatures

### 11. Digital Forensics

**Incident Forensics**:
- Preserve evidence (chain of custody)
- Acquire forensic images
- Timeline analysis
- Memory forensics (RAM analysis)
- Disk forensics
- Log analysis
- Network forensics (packet capture analysis)

**Tools**: FTK (Forensic Toolkit), EnCase, Volatility, Sleuth Kit, Autopsy

**Legal Considerations**:
- Maintain chain of custody
- Document all procedures
- Preserve original evidence
- Create forensic images
- Expert witness preparation

### 12. Bug Bounty Programs

**Program Setup**:
- Platform selection (HackerOne, Bugcrowd, Intigriti)
- Scope definition (in-scope assets, vulnerabilities)
- Severity rating system
- Reward structure (fixed or tiered)
- Response SLA
- Disclosure policy

**Running Effectively**:
- Clear vulnerability submission form
- Fast triage and response
- Fair reward assessment
- Regular communication
- Quarterly reporting and metrics
- Legal protection (safe harbor clause)

**Common Vulnerabilities Reported**:
- XSS (Cross-Site Scripting)
- CSRF (Cross-Site Request Forgery)
- SQLi (SQL Injection)
- RCE (Remote Code Execution)
- Business logic flaws
- Privilege escalation
- Data disclosure

### 13. Security Awareness Training

**Program Components**:
- Phishing simulation
- Policy training (acceptable use, data protection)
- Role-specific training (developers, administrators)
- Incident reporting training
- Social engineering awareness
- Password security
- Remote work security

**Delivery Methods**:
- Online modules
- In-person workshops
- Lunch-and-learn sessions
- Simulations
- Posters and reminders
- Newsletter communications

**Metrics**:
- Training completion rates
- Phishing click rates
- Security incident reports
- Policy acknowledgment
- Awareness assessment scores

## Implementation Guide

### For Security Teams

1. **Assessment Phase**
   - Evaluate current security posture
   - Identify gaps and weaknesses
   - Prioritize areas for improvement

2. **Planning Phase**
   - Define security roadmap
   - Allocate resources
   - Set realistic timelines

3. **Implementation Phase**
   - Deploy controls and tools
   - Configure and test
   - Train staff

4. **Monitoring Phase**
   - Continuous monitoring
   - Regular assessments
   - Incident response readiness

5. **Improvement Phase**
   - Analyze metrics
   - Update processes
   - Incorporate lessons learned

### For Development Teams

1. **Secure SDLC Integration**
   - Threat modeling in design phase
   - Security code reviews
   - Static and dynamic testing
   - Dependency scanning
   - Penetration testing

2. **Vulnerability Management**
   - Track and prioritize vulnerabilities
   - Patch management process
   - Security hotfix procedures

### For Leadership

1. **Risk Management**
   - Identify key assets and threats
   - Calculate risk scores
   - Prioritize investments
   - Communicate risks to board/stakeholders

2. **Compliance Management**
   - Maintain compliance calendars
   - Track audit findings
   - Manage remediation
   - Report to regulators

## Quick Reference

### Common Commands & Triggers
- `/pentest` - Penetration testing guidance
- `/incident` - Incident response procedures
- `/threat` - Threat modeling assistance
- `/soc` - SOC operations guidance
- `/owasp` - OWASP Top 10 remediation
- `/vuln` - Vulnerability assessment methodology
- `/netsec` - Network security best practices
- `/cloudsec` - Cloud security guidance
- `/zerotrust` - Zero Trust architecture
- `/compliance` - Compliance framework guidance
- `/forensics` - Digital forensics procedures
- `/bugbounty` - Bug bounty program setup

## Resources & Tools

### Essential Tools
- **SIEM**: Splunk, ELK, Sumo Logic
- **Vulnerability Scanning**: Nessus, Qualys, OpenVAS
- **Penetration Testing**: Burp Suite, Metasploit, Kali Linux
- **Network Analysis**: Wireshark, Zeek
- **Cloud Security**: CloudMapper, Prowler
- **Forensics**: FTK, EnCase, Volatility
- **Threat Intelligence**: MITRE ATT&CK, AlienVault OTX

### Learning Resources
- SANS Institute courses
- CompTIA Security+, CEH
- Certified Ethical Hacker (CEH)
- Offensive Security Certified Professional (OSCP)
- GIAC Certifications
- PortSwigger Web Security Academy

## Conclusion

Effective cybersecurity requires a comprehensive approach covering preventive, detective, and responsive measures. This skill provides frameworks, methodologies, and best practices across all major security domains to help build and maintain robust security programs.
