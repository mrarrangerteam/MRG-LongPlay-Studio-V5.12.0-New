---
name: mrarranger-trading-suite
description: |
  MRARRANGER Trading Suite — 18-Module Prediction Market System (Polymarket/Kalshi/Manifold). Core: Edge Analysis, Backtesting, Signal Detection, Risk Management, Trading Bot, Phase Planning. Advanced: AI Ensemble Forecasting, Market Making, Copy Trading, Whale Tracking, On-Chain Analytics, Correlation Arbitrage, Infrastructure/Deployment, Dashboard, Legal/Compliance, Multi-Platform. Commands: /edge /backtest /signal /risk /phase /scan /insider /cs2 /forecast /mm /copy /whale /onchain /deploy /dashboard /legal. Triggers: polymarket, prediction market, kalshi, trading edge, insider wallet, esports bot, NegRisk, NO arbitrage, whale tracking, market scanner, backtest, EV calculation, Kelly criterion, market making, on-chain analytics, position sizing, bankroll, kill switch, trading signal, deploy bot, เทรด polymarket, วิเคราะห์ edge, สร้าง bot, บริหารความเสี่ยง, สัญญาณเทรด
---

# MRARRANGER Trading Suite v2.0 — Fintech Startup Grade

> 18-Module Prediction Market Trading System
> Architecture: 4-Layer Agent Design (Information → Analysis → Strategy → Execution)
> Level: Production-Ready Startup Team

---

## 4-LAYER ARCHITECTURE

```
┌─────────────────────────────────────────────────────────┐
│ LAYER 1: INFORMATION                                     │
│ On-Chain Analytics │ Polymarket APIs │ Multi-Platform     │
│ Whale Tracking     │ News/Social Feed │ Esports Data      │
├─────────────────────────────────────────────────────────┤
│ LAYER 2: ANALYSIS                                        │
│ AI Ensemble Forecast │ Quant Analyst │ Trading Analysis   │
│ Correlation Arb      │ On-Chain Forensics │ Edge Decay    │
├─────────────────────────────────────────────────────────┤
│ LAYER 3: STRATEGY                                        │
│ Trading Signal │ Risk Management │ Trading Plan           │
│ Market Making  │ Copy Trading    │ Backtesting            │
├─────────────────────────────────────────────────────────┤
│ LAYER 4: EXECUTION                                       │
│ Algorithmic Trading │ Infrastructure │ Dashboard          │
│ Legal/Compliance    │ Multi-Platform │ Polymarket Master   │
└─────────────────────────────────────────────────────────┘
```

## HOW TO USE

1. รับ request จากผู้ใช้
2. ดู routing table ด้านล่าง → หา reference file ที่ตรง
3. ใช้ `Read` tool อ่าน reference file (อ่านหลายตัวได้ถ้าเกี่ยวข้อง)
4. Execute ตาม instructions ใน reference
5. ใช้ MULTI-SKILL COMBOS สำหรับ complex requests

---

## SKILL ROUTING TABLE

| # | Module | Reference File | Commands | ใช้เมื่อ |
|---|--------|---------------|----------|---------|
| 1 | Polymarket Master | references/polymarket-trading-master.md | /edge /scan /insider /cs2 /negrisk /noarb /pivot | Edge Library, Insider Tracker, CS2 Parser, NegRisk, NO Arb, Phase Plan |
| 2 | Trading Analysis | references/trading-analysis.md | /analysis /competitive /timing | Market Structure, VRIO, Competitive Landscape, Edge Decay, Timing |
| 3 | Trading Plan | references/trading-plan-generator.md | /plan /routine /phase | Phase 0-4 Plan, Daily Routine, Pivot Playbook, Milestones |
| 4 | Backtesting | references/backtesting-trading-strategies.md | /backtest | Monte Carlo, Historical Data, Strategy Simulation, Validation |
| 5 | Quant Analyst | references/quant-analyst.md | /ev /kelly /sharpe | EV Calc, Bayesian Update, Kelly Criterion, Market Efficiency |
| 6 | Algorithmic Trading | references/algorithmic-trading.md | /bot /deploy | Bot Architecture, CLOB Execution, WebSocket, Multi-Strategy |
| 7 | Risk Management | references/risk-management.md | /risk | Position Sizing, Bankroll, Kill Switches, Correlation Guard |
| 8 | Trading Signal | references/trading-signal.md | /signal | Insider Signal, NegRisk Gap, CS2 Round, NO Arb Screen |
| 9 | **AI Ensemble** | references/ai-ensemble-forecasting.md | /forecast /ensemble | Multi-LLM Probability, GPT+Claude+Gemini Aggregate |
| 10 | **Market Making** | references/market-making.md | /mm /spread | Spread Capture, Inventory Mgmt, Dynamic Quoting, Liquidity |
| 11 | **Copy Trading** | references/copy-trading-whale-tracking.md | /copy /whale | Real-time Wallet Monitor, Auto-Copy, Leaderboard Tracking |
| 12 | **Correlation Arb** | references/correlation-arbitrage.md | /corr | Logical Arb, Cross-Market, Dependent Market Detection |
| 13 | **On-Chain** | references/on-chain-analytics.md | /onchain | Wallet Forensics, Cluster Analysis, Fund Flow, Age Check |
| 14 | **Infrastructure** | references/infrastructure-deployment.md | /infra /docker | Docker, VPS, CI/CD, Health Monitor, Auto-restart |
| 15 | **Polymarket APIs** | references/polymarket-apis.md | /api /clob | py-clob-client, Gamma API, WebSocket, EIP-712, CTF Exchange |
| 16 | **Legal/Compliance** | references/legal-compliance.md | /legal /compliance | Regulatory Tracker, Geo-restriction, Tax, ToS Risk |
| 17 | **Dashboard** | references/performance-dashboard.md | /dashboard /pnl | 9-Tab Monitor, Equity Curve, P&L, Trade Attribution |
| 18 | **Multi-Platform** | references/multi-platform.md | /kalshi /manifold | Kalshi + Manifold + PredictIt APIs, Cross-Platform Arb |

---

## QUICK COMMANDS (40+)

| Command | ทำอะไร | Route to |
|---------|--------|----------|
| `/edge [name]` | วิเคราะห์ edge เฉพาะ | #1 Master |
| `/backtest [edge] [capital]` | จำลอง ROI | #4 Backtesting |
| `/signal` | scan markets ตอนนี้ | #8 Signal |
| `/risk [bankroll]` | คำนวณ position size | #7 Risk |
| `/phase [target $]` | วางแผน phase | #3 Plan |
| `/scan negrisk` | scan NegRisk arb | #1 Master |
| `/scan noarb` | scan sensational markets | #1 Master |
| `/insider` | analyze wallet pattern | #1 + #13 On-Chain |
| `/cs2 [event]` | CS2 live edge | #1 Master |
| `/valorant [event]` | Valorant live edge | #1 Master |
| `/fifa [event]` | FIFA live edge | #1 Master |
| `/ev [price] [prob]` | คำนวณ EV | #5 Quant |
| `/kelly [prob] [price]` | optimal bet size | #5 Quant |
| `/sharpe` | Sharpe ratio | #5 Quant |
| `/bot` | สร้าง trading bot | #6 Algo |
| `/deploy` | deploy bot บน VPS | #6 + #14 Infra |
| `/plan` | สร้างแผนเทรดเต็ม | #3 Plan |
| `/routine` | daily trading routine | #3 Plan |
| `/analysis` | deep market analysis | #2 Analysis |
| `/competitive` | competitive landscape | #2 Analysis |
| `/timing` | best time to trade | #2 Analysis |
| `/pivot` | edge หมดแล้วทำไงต่อ | #1 + #3 |
| `/forecast [market]` | AI multi-model forecast | #9 Ensemble |
| `/ensemble` | setup ensemble pipeline | #9 Ensemble |
| `/mm [market]` | market making strategy | #10 MM |
| `/spread` | spread analysis | #10 MM |
| `/copy [wallet]` | copy trading setup | #11 Copy |
| `/whale` | whale tracking dashboard | #11 + #13 |
| `/corr` | correlation arb scan | #12 Corr |
| `/onchain [wallet]` | on-chain wallet forensics | #13 On-Chain |
| `/infra` | infrastructure setup guide | #14 Infra |
| `/docker` | Docker deployment | #14 Infra |
| `/api` | Polymarket API reference | #15 APIs |
| `/clob` | CLOB API quick start | #15 APIs |
| `/legal` | legal risk assessment | #16 Legal |
| `/compliance` | compliance checklist | #16 Legal |
| `/dashboard` | performance dashboard setup | #17 Dashboard |
| `/pnl` | P&L analysis | #17 Dashboard |
| `/kalshi` | Kalshi platform guide | #18 Multi |
| `/manifold` | Manifold platform guide | #18 Multi |

---

## MULTI-SKILL COMBOS (Complex Requests)

| User Request | Modules to Load |
|-------------|----------------|
| "อยากเริ่มเทรด Polymarket" | #3 Plan + #1 Master + #7 Risk + #15 APIs |
| "วิเคราะห์ edge แล้ว backtest" | #2 Analysis + #4 Backtest + #5 Quant |
| "สร้าง bot เทรด CS2" | #6 Algo + #1 Master + #8 Signal + #14 Infra |
| "ควรใส่เงินเท่าไหร่" | #7 Risk + #5 Quant (Kelly) |
| "หา signal ตอนนี้" | #8 Signal + #1 Master + #13 On-Chain |
| "edge หมดแล้วทำไงต่อ" | #1 Pivot + #3 Plan + #2 Analysis |
| "สร้าง AI forecast bot" | #9 Ensemble + #6 Algo + #14 Infra |
| "อยาก market making" | #10 MM + #7 Risk + #15 APIs + #17 Dashboard |
| "copy whale trader" | #11 Copy + #13 On-Chain + #7 Risk |
| "หา correlation arb" | #12 Corr + #5 Quant + #8 Signal |
| "deploy bot บน VPS" | #14 Infra + #6 Algo + #17 Dashboard |
| "เทรดหลาย platform" | #18 Multi + #12 Corr + #7 Risk |
| "ทำครบ production-ready" | #14 Infra + #16 Legal + #17 Dashboard + #7 Risk |
| "full startup team setup" | ALL 18 MODULES |

---

## INSTRUCTIONS

เมื่อผู้ใช้ request เข้ามา:
1. วิเคราะห์ว่าเกี่ยวกับ module ไหนจาก routing table
2. ใช้ `Read` tool อ่าน reference file ที่เกี่ยวข้อง (อ่านหลายตัวได้)
3. ทำตาม instructions ใน reference file อย่างเคร่งครัด
4. ถ้า request ซับซ้อน ให้ดู MULTI-SKILL COMBOS
5. ถ้าเป็น production build ให้อ่าน Infra + Legal + Dashboard ด้วยเสมอ

## DISCLAIMER

```
⚠️ สำหรับการศึกษาและ research เท่านั้น
- Polymarket บล็อก Thailand — ต้องใช้ VPN (ผิด ToS, มีความเสี่ยงถูกแบน)
- Insider trading อาจมีกฎหมายในอนาคต
- การเทรดทุกประเภทมีความเสี่ยง รวมถึงการเสียเงินทั้งหมด
- 92% ของ Polymarket traders ขาดทุน
- บทความนี้ไม่ใช่คำแนะนำทางการเงิน
```
