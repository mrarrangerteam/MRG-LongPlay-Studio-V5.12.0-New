# TRADING PLAN GENERATOR

## Plan Template: $300 → $100k (Scenario B)

---

### EXECUTIVE SUMMARY

```
Goal: $100,000 from $300 starting capital
Strategy: Multi-Edge Bot Stack (Insider + CS2 + NO Arb)
Timeline: 5–8 months (if edges hold)
Probability of success: ~35%
Max loss scenario: $300 (accept full loss)
Key risks: Edge decay, platform changes, legal shifts
```

---

### PHASE 0: FOUNDATION (Day 1–3)

**Objective:** Technical setup complete, ready to trade

```
Day 1 Checklist:
□ Create MetaMask wallet (dedicated, anonymous)
□ Install VPN (Mullvad: €5/mo, no-log policy)
□ Bridge USDC to Polygon network
□ Create Polymarket account
□ Verify API access (Gamma + CLOB)
□ Install Python 3.11
□ Install packages: pip install py-clob-client requests websockets

Day 2 Checklist:
□ Test Polymarket API call (list markets)
□ Create Telegram Bot (BotFather)
□ Test Telegram alert works on phone
□ Set up trade log spreadsheet
□ Create paper trade tracking sheet

Day 3 Checklist:
□ Clone insider-tracker from GitHub (pselamy/polymarket-insider-tracker)
□ Run test scan on Gamma API
□ Identify first 3 NO Arb candidates manually
□ Set up Hetzner VPS (€3.79/month)

Success Gate: Can receive Telegram alerts + API working
```

---

### PHASE 1: FIRST PROOF (Week 1–2)

**Objective:** Validate edge exists, achieve first profit

**Capital: $300 → Target $600+**

```
Budget Allocation:
- NO Arb (manual): $60 (20%)
- Paper trade only: CS2 + NegRisk
- Hold: $240 (80%) — don't deploy until proven

Week 1 Tasks:
□ Buy NO on 2–3 sensational markets ($20–30 each)
□ Run NegRisk scanner daily, log opportunities (paper)
□ Run CS2 scanner during BLAST Rotterdam (Mar 18–29)
□ Log ALL paper trades with entry, thesis, and actual outcome

Week 2 Decision:
IF paper CS2 win rate > 60% over 20+ rounds:
  → Deploy $50 real money on CS2
IF NegRisk found gaps > 3%:
  → Deploy $50 real money on best opportunity
ELSE:
  → Continue paper trading, do not go live yet

KPIs:
- Paper Win Rate target: >55%
- Real Win Rate target: >50% (expected worse than paper)
- Max loss: $60 (NO Arb budget)
```

---

### PHASE 2: SCALE TO $1k–3k (Month 1–2)

**Objective:** All 3 legs live, compound growing

**Capital: $300–600 → Target $1,000–3,000**

```
Monthly Tasks:
□ Deploy Hetzner VPS with bot running 24/7
□ CS2 parser automated (not manual)
□ NegRisk scanner automated (alert only, manual execute)
□ Insider tracker running every 2 min
□ Review trade log every Monday

Scaling Rules:
- Reinvest 80% of profits
- Keep 20% as cash reserve (don't compound 100%)
- Increase CS2 size proportionally with bankroll
- Never exceed 40% bankroll in any single leg

Catalyst Events:
- Mar 18–29: BLAST Rotterdam (CS2 volume spike)
- April: ESL Pro League S23

KPIs:
- Monthly ROI target: >80%
- Win rate: CS2 >65%, NO Arb >70%
- Max drawdown: <20%
- Milestone: $1,000 bankroll within 6 weeks
```

---

### PHASE 3: SCALE TO $10k (Month 2–4)

**Objective:** All legs optimized, add Valorant

**Capital: $1k–3k → Target $10,000**

```
Technical Upgrades:
□ Direct Polygon RPC node (reduce latency for insider copy)
□ Add Valorant parser (new tournaments)
□ Build 2026 US Midterm tracker (Nov 2026)
□ NegRisk scanner: fully automated execution

New Edge: Valorant live parsing
- API: Riot Games official Valorant API
- Markets: Growing on Polymarket (still low competition)
- Expected win rate: 68–75%

Risk Management Upgrade:
- Stop loss per leg: If leg down 30% from peak → reduce size 50%
- Correlation guard: Check open positions before new CS2 bet
- Kelly calculator: Auto-size every trade

Milestone Action: At $10,000 → withdraw $2,000 to external wallet
This locks in first real profit regardless of what happens next
```

---

### PHASE 4: $10k → $100k (Month 4–8)

**Objective:** Compound with larger capital, catch insider events

**Capital: $10k → Target $100,000**

```
The Math:
Path A (Pure compound): $10k × 100%/mo × 4 months = $160k possible
Path B (Insider event): $10k → insider event → $50–100k in single day
Path C (Hybrid): compound to $30k, then insider push to $100k

Key Catalyst Events:
- June 2026: FIFA World Cup → massive prediction market volume
- November 2026: US Midterm Elections → insider patterns WILL repeat

At $50k bankroll:
- Insider event allocation: up to $20,000 per event
- If event pays 5x: +$100,000 in one trade
- WITHDRAW 50% ($25k) when hitting $50k milestone

Edge Maintenance:
□ Monitor edge decay weekly (win rate trend)
□ If CS2 edge fades → shift to Valorant/FIFA
□ If NO Arb overcrowded → move to NegRisk only
□ Track competitors: if similar bots appear on leaderboard → prepare pivot
```

---

### DAILY ROUTINE

```
08:00 — Morning Check (15 min)
  □ Check overnight Telegram alerts
  □ Review open positions
  □ Check CS2/esports match schedule for today
  □ Scan NO Arb watchlist for price changes

Throughout Day — Bot Monitors Automatically
  □ NegRisk scanner (every 5 min)
  □ Insider wallet scanner (every 2 min)
  □ CS2 live matches (during tournaments)

20:00 — Evening Review (30 min)
  □ Log all trades to spreadsheet
  □ Calculate daily PnL
  □ Check win rate trend (last 20 trades)
  □ Flag any edge degradation
  □ Plan tomorrow (any big tournaments? news events?)

Weekly Sunday — Performance Review (1 hour)
  □ Weekly PnL vs target
  □ Win rate per edge
  □ Drawdown from peak
  □ Are edges still valid?
  □ Any platform changes?
  □ Adjust next week plan
```

---

### PIVOT PLAYBOOK

```
Scenario: CS2 edge fades (win rate drops below 60%)
Timeline: Typically 2–4 months after becoming public
Pivot to: Valorant (less crowded) + FIFA World Cup markets

Scenario: Insider tracking becomes illegal
Timeline: Potential legislation in Q3 2026
Pivot to: Full NO Arb + Midterm elections NegRisk

Scenario: Polymarket adds fees to all sports markets
Timeline: Could happen anytime
Pivot to: Insider only + cross-platform arb (Polymarket vs Kalshi)

Scenario: Polymarket blocked via VPN too
Timeline: Unlikely but possible
Pivot to: Kalshi (CFTC regulated, US accessible) or wait for platform pivot

Scenario: All edges exhausted simultaneously
Pivot to: Sell tool/scanner as product to other traders
         OR use bankroll for actual investment (stocks, crypto)
```

---

### REVIEW TRIGGERS (When to Update This Plan)

```
Update plan when:
✓ Any edge win rate drops below target for 2 consecutive weeks
✓ New edge is discovered with better metrics
✓ Platform changes fees or rules
✓ Legal/regulatory development
✓ Reached a major capital milestone ($1k, $10k, $50k, $100k)
✓ Drawdown hits 25% from peak (emergency review)
```


---

### PHASE 5: SUSTAINABILITY ($100k+, Month 8+)

**Objective:** Maintain profits, diversify, reduce single-platform risk

Post-$100k Strategy:
1. Withdraw 50% ($50k) to external wallet/bank
2. Spread remaining $50k across platforms:
   - Polymarket: $30k (60%) — primary
   - Kalshi: $15k (30%) — regulated backup
   - Reserve: $5k (10%) — for new platform opportunities

3. Shift to lower-risk strategies:
   - Market making: consistent $200-400/day
   - NegRisk arbitrage: guaranteed small returns
   - Reduce insider allocation to 20% (legal risk)

4. Team scaling considerations:
   - If generating >$10k/month consistently → consider hiring
   - Developer ($2-3k/month part-time): maintain bot infrastructure
   - Analyst ($1-2k/month part-time): monitor edges and news
   - Or: keep solo, use AI ensemble as "virtual analyst"


### MULTI-PLATFORM MIGRATION PLAN

When Polymarket edge decays → migrate to next platform:

Step 1: Identify target platform (Kalshi, new DEX, etc.)
Step 2: Build API adapter (reuse 90% of existing code)
Step 3: Paper trade for 1 week on new platform
Step 4: Deploy 10% of bankroll as test
Step 5: Scale up if win rate > 55% over 30+ trades

Code portability:
- Signal detection: 90% reusable
- Risk management: 100% reusable
- Dashboard: 100% reusable
- Execution: Need new API adapter (~2-4 hours)
- Reference: multi-platform.md for platform comparison


### INCOME MILESTONES & ACTIONS

Milestone         | Action
$500              | Validate edge is real (not luck)
$1,000            | Deploy VPS, fully automate
$5,000            | Add market making + second platform
$10,000           | Withdraw $2k, add Valorant/FIFA parsers
$25,000           | Withdraw $10k, reduce risk allocation
$50,000           | Withdraw $25k, shift to sustainability mode
$100,000          | Withdraw $50k, consider team/product pivot
