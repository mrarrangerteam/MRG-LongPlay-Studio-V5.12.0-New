# LEGAL & COMPLIANCE — Prediction Market Regulatory Framework

## ⚠️ DISCLAIMER

```
เอกสารนี้เป็นข้อมูลเพื่อการศึกษาเท่านั้น ไม่ใช่คำแนะนำทางกฎหมาย
ปรึกษาทนายความก่อนดำเนินการใดๆ
```

## Platform Legal Status (มีนาคม 2026)

```
POLYMARKET:
- Type: Decentralized prediction market on Polygon
- Regulation: ไม่อยู่ภายใต้ CFTC โดยตรง
- CFTC Settlement: จ่ายค่าปรับ $1.4M (2022) และตกลงหยุด US operations
- Current: ใช้ VPN/non-US access เท่านั้น
- Thailand: BLOCKED (ต้อง VPN)
- Status: Gray area — ไม่ illegal แต่ไม่ regulated

KALSHI:
- Type: CFTC-regulated exchange (ใบอนุญาต DCM)
- Regulation: อยู่ภายใต้ CFTC เต็มรูปแบบ
- KYC: Required (US residents only)
- Thailand: ไม่เปิดให้ใช้
- Status: Legal ใน US, มีกรอบกฎหมายชัดเจน

MANIFOLD:
- Type: Play money (ไม่ใช่เงินจริง) + Mana currency
- Regulation: ไม่ regulated (play money)
- Thailand: เปิดให้ใช้ได้
- Status: Legal ทุกประเทศ (ไม่ใช่ gambling)

PREDICTIT:
- Type: CFTC no-action letter (limited)
- Regulation: กำลังถูก wind down
- Status: จำกัดมาก — ไม่แนะนำสำหรับ new traders
```

## Proposed Legislation Tracker

```
"PUBLIC INTEGRITY IN FINANCIAL PREDICTION MARKETS ACT"
Status: Proposed, not yet passed (as of March 2026)
Sponsor: Multiple senators
Target: Insider trading on prediction markets

Key provisions:
1. Criminalize trading on non-public information in prediction markets
2. Apply SEC-style insider trading rules to prediction markets
3. Require prediction markets to implement insider detection
4. Penalties: up to $1M fine + 10 years imprisonment

Timeline estimate:
- Q2 2026: Committee hearings
- Q3 2026: Possible floor vote
- Q4 2026 / Q1 2027: If passed, enforcement begins

Impact on strategies:
- Insider copy trading: DIRECT RISK (may become illegal)
- NegRisk arbitrage: NO IMPACT (math-based, not information)
- CS2 live parsing: LOW RISK (public information)
- Market making: NO IMPACT (legitimate activity)
- NO Arb: NO IMPACT (behavioral analysis)
```

## Thailand-Specific Considerations

```
Thailand Gambling Act (พ.ร.บ.การพนัน พ.ศ. 2478):
- Prediction markets could be classified as gambling
- Online gambling is illegal in Thailand
- Penalty: fine up to 5,000 THB + imprisonment up to 3 years

Computer Crime Act (พ.ร.บ.คอมพิวเตอร์ พ.ศ. 2560):
- Using VPN to access blocked services: gray area
- Platform blocks Thailand IPs: indicates regulatory concern

Practical considerations:
- VPN usage itself is NOT illegal in Thailand
- However, using VPN to access gambling platforms may violate gambling laws
- No known Thai prosecution for Polymarket usage (as of March 2026)
- Risk: account freeze, fund seizure, loss of deposits

RECOMMENDATION:
- Understand all legal risks before proceeding
- Consult with a Thai lawyer specializing in fintech/gambling law
- Consider Manifold (play money) for risk-free practice
- Consider Kalshi if you have US residency/access
```

## Tax Implications

```
Thailand:
- Gambling winnings: theoretically taxable as income
- No specific guidance for prediction markets
- Crypto gains: taxed at 15% (สรรพากร guidance 2024)
- Reporting: technically required for foreign income

US:
- Prediction market gains: taxed as ordinary income
- Short-term capital gains rate applies
- Form 1099 may not be issued (self-reporting required)
- State-specific rules may apply

General:
- Keep detailed trade logs for tax purposes
- Record: entry date, exit date, amount, profit/loss
- Consider professional tax advice for cross-border income
```

## Compliance Checklist (ก่อนเริ่มเทรด)

```
BEFORE GOING LIVE:

Legal:
□ Understand gambling laws in your jurisdiction
□ Understand tax obligations for trading gains
□ Know the risk of account freeze/fund seizure
□ Have legal counsel contact ready

Operational:
□ Use dedicated wallet (not linked to personal identity)
□ Use VPN with no-log policy (if required)
□ Don't share trading strategies publicly (competitive risk)
□ Keep trade logs for tax reporting

Financial:
□ Only trade with money you can afford to lose completely
□ Set absolute loss limit before starting
□ Have withdrawal plan (regular profit extraction)
□ Separate trading funds from personal finances

Technical:
□ Secure API keys (never commit to git)
□ Use 2FA on all exchange/platform accounts
□ Dedicated email for trading accounts
□ VPS in neutral jurisdiction for bots
```

## Risk Matrix

```
Risk                    | Probability | Impact  | Mitigation
------------------------|------------|---------|-----------------------------------
Platform ban            | Medium     | High    | Wallet rotation, VPN, multiple accounts
Fund seizure            | Low        | Critical| Regular withdrawals, small balances
Legal prosecution (TH)  | Very Low   | Critical| Legal counsel, compliance awareness
Insider law passes      | Medium     | High    | Shift to non-insider strategies
Tax audit               | Low        | Medium  | Keep detailed records, pay taxes
Smart contract exploit  | Very Low   | Critical| Limit funds on platform
API key compromise      | Low        | High    | Secure key management, IP whitelist
```

## Regulatory Monitoring

```python
# Sources to monitor for regulatory changes:

MONITORING_SOURCES = {
    "us_congress": {
        "url": "https://www.congress.gov/search?q=prediction+market",
        "check_frequency": "weekly",
        "alert_keywords": ["prediction market", "event contract", "binary option"]
    },
    "cftc": {
        "url": "https://www.cftc.gov/PressRoom/PressReleases",
        "check_frequency": "weekly",
        "alert_keywords": ["polymarket", "prediction market", "event contract"]
    },
    "thailand_sec": {
        "url": "https://www.sec.or.th/EN/Pages/Home.aspx",
        "check_frequency": "monthly",
        "alert_keywords": ["digital asset", "cryptocurrency", "online gambling"]
    },
    "twitter_alerts": {
        "accounts": ["@CFTC", "@PolymarketHQ", "@kalaborativecomm"],
        "check_frequency": "daily"
    }
}

# Action triggers:
# - Bill introduced → REVIEW strategy within 24h
# - Bill passes committee → PREPARE pivot plan
# - Law signed → EXECUTE pivot immediately
# - Platform announcement → ASSESS impact same day
```

## Exit Strategy (ถ้ากฎหมายเปลี่ยน)

```
SCENARIO 1: Insider trading law passes
Timeline: 30 days to comply
Action:
1. Stop all insider copy trading immediately
2. Close open insider-related positions
3. Shift capital to: NegRisk + NO Arb + Market Making
4. These strategies use public information only = legal

SCENARIO 2: Thailand cracks down on crypto/prediction markets
Timeline: Variable
Action:
1. Withdraw all funds from Polymarket within 48 hours
2. Move USDC to personal wallet (not exchange)
3. Convert to stablecoins on decentralized exchange
4. Consider Kalshi (US-based, regulated) if you have US access

SCENARIO 3: Polymarket shuts down or exits
Timeline: Platform would likely give 30-90 days notice
Action:
1. All open positions resolve or get refunded
2. Withdraw all funds
3. Migrate bots to Kalshi or next platform
4. Tool/scanner code is portable (API adapters only change)
```
