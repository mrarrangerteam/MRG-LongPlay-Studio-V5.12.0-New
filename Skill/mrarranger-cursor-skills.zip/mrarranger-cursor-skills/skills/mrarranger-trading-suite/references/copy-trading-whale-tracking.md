# COPY TRADING & WHALE TRACKING — Smart Money Monitor

## System Overview

```
┌──────────────────────────────────────────┐
│         WHALE TRACKING PIPELINE          │
│                                          │
│  Polygon WebSocket → Filter Large Txn    │
│        ↓                                 │
│  Wallet Scorer (age, win rate, focus)    │
│        ↓                                 │
│  Leaderboard Database (top 100 wallets) │
│        ↓                                 │
│  Copy Decision Engine (Kelly + delay)    │
│        ↓                                 │
│  Execute Copy → Telegram Alert           │
└──────────────────────────────────────────┘
```

## Whale Identification

```python
class WhaleScorer:
    """Score wallets to identify profitable traders worth copying"""

    SCORE_WEIGHTS = {
        "roi": 0.30,           # Historical ROI
        "win_rate": 0.25,      # % profitable trades
        "consistency": 0.20,   # Low variance in returns
        "volume": 0.15,        # Total trading volume
        "recency": 0.10        # Recent activity
    }

    def score_wallet(self, wallet_data):
        """
        wallet_data: {
            address, total_trades, wins, losses,
            total_profit, total_volume, avg_trade_size,
            active_days, markets_traded, last_active
        }
        """
        scores = {}

        # ROI score (0-10)
        roi = wallet_data["total_profit"] / max(wallet_data["total_volume"], 1)
        scores["roi"] = min(10, max(0, roi * 20))  # 50% ROI = 10

        # Win rate score
        total = wallet_data["total_trades"]
        if total < 10:
            return 0  # Not enough data
        wr = wallet_data["wins"] / total
        scores["win_rate"] = min(10, max(0, (wr - 0.50) * 40))  # 75% = 10

        # Consistency (low drawdown)
        scores["consistency"] = min(10, max(0,
            10 - wallet_data.get("max_drawdown_pct", 50) / 5))

        # Volume score
        vol = wallet_data["total_volume"]
        scores["volume"] = min(10, vol / 100000 * 10)  # $100k = 10

        # Recency
        days_since_active = wallet_data.get("days_since_active", 999)
        scores["recency"] = max(0, 10 - days_since_active)

        # Weighted total
        total_score = sum(
            scores[k] * self.SCORE_WEIGHTS[k]
            for k in self.SCORE_WEIGHTS
        )

        return {
            "address": wallet_data["address"],
            "score": round(total_score, 2),
            "tier": "S" if total_score > 8 else "A" if total_score > 6 else "B" if total_score > 4 else "C",
            "breakdown": scores,
            "copy_recommended": total_score > 5.0
        }
```

## Real-Time Monitoring

```python
import asyncio
import json
from web3 import Web3

# Polymarket CTF Exchange on Polygon
CTF_EXCHANGE = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E"
USDC_ADDRESS = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"

class WhaleMonitor:
    def __init__(self, tracked_wallets, min_size_usd=500):
        self.tracked = set(w.lower() for w in tracked_wallets)
        self.min_size = min_size_usd
        self.w3 = Web3(Web3.WebSocketProvider("wss://polygon-mainnet.g.alchemy.com/v2/YOUR_KEY"))

    async def monitor_transactions(self, callback):
        """Monitor Polygon for whale trades on Polymarket"""
        # Subscribe to Transfer events on CTF Exchange
        filter_params = {
            "address": CTF_EXCHANGE,
            "topics": [Web3.keccak(text="OrderFilled(bytes32,address,address,uint256,uint256,uint256,uint256)").hex()]
        }

        async for event in self.w3.eth.subscribe("logs", filter_params):
            trade = self._parse_trade(event)
            if trade and trade["trader"].lower() in self.tracked:
                if trade["size_usd"] >= self.min_size:
                    await callback(trade)

    def _parse_trade(self, event):
        """Parse OrderFilled event into readable trade"""
        try:
            return {
                "trader": event["topics"][1],
                "market_id": event["topics"][2],
                "side": "BUY" if event["data"][:2] == "0x01" else "SELL",
                "size_usd": int(event["data"][2:66], 16) / 1e6,
                "price": int(event["data"][66:130], 16) / 1e6,
                "timestamp": event["blockNumber"]
            }
        except Exception:
            return None
```

## Copy Execution

```python
class CopyTrader:
    def __init__(self, clob_client, bankroll_manager):
        self.clob = clob_client
        self.bankroll = bankroll_manager

    async def copy_trade(self, whale_trade, whale_score):
        """
        Copy a whale's trade with fractional sizing

        Sizing rules:
        - S-tier whale: copy 50% of their relative size
        - A-tier: copy 25%
        - B-tier: copy 10%
        """
        COPY_FRACTIONS = {"S": 0.50, "A": 0.25, "B": 0.10, "C": 0.0}

        fraction = COPY_FRACTIONS.get(whale_score["tier"], 0)
        if fraction == 0:
            return None

        # Calculate our size
        our_bankroll = self.bankroll.total
        whale_relative_size = whale_trade["size_usd"] / 10000  # Assume whale has ~$10k
        our_size = our_bankroll * whale_relative_size * fraction

        # Apply max limits
        our_size = min(our_size, our_bankroll * 0.15)  # Max 15% per copy
        our_size = max(our_size, 5.0)  # Min $5

        # Add random delay (anti-detection)
        import random
        delay = random.uniform(5, 30)  # 5-30 second random delay
        await asyncio.sleep(delay)

        # Execute
        result = await self.clob.place_order(
            market_id=whale_trade["market_id"],
            side=whale_trade["side"],
            price=whale_trade["price"],
            size=our_size
        )

        return {
            "whale": whale_trade["trader"][:10] + "...",
            "whale_size": whale_trade["size_usd"],
            "our_size": round(our_size, 2),
            "fraction": fraction,
            "delay_sec": round(delay, 1),
            "order_id": result
        }
```

## Leaderboard Tracking

```python
# Top Polymarket traders to track (update monthly)
WHALE_WATCHLIST = {
    "tier_s": [
        # Wallet addresses of top performers
        # Found via: Polymarket leaderboard + Polygonscan analysis
    ],
    "tier_insider": [
        # Wallets with suspected insider patterns
        # Fresh wallets + large single-market bets
    ],
    "tier_bot": [
        # Known profitable bot wallets
        # High frequency + consistent small wins
    ]
}

# Data sources for wallet discovery:
# 1. Polymarket leaderboard: polymarket.com/leaderboard
# 2. Polygonscan: search CTF Exchange interactions
# 3. Dune Analytics: custom queries on Polymarket trades
# 4. Community tracking: @PolymarketWhale on Twitter
```

## Anti-Detection Measures

```
เมื่อ copy trade ต้องระวังไม่ให้ whale รู้ว่าถูก copy:

1. Random delay: 5-30 วินาที (ไม่ copy ทันที)
2. Size variation: ±20% จากเป้า (ไม่ใช่เลขกลมๆ)
3. Wallet rotation: ใช้ 3-5 wallets สลับกัน
4. Time spread: แบ่ง order เป็น 2-3 ชิ้น ห่างกัน 1-5 นาที
5. Don't copy 100%: skip บาง trades สุ่ม 20%

ถ้า whale รู้ว่าถูก copy → อาจ:
- Fake trade เพื่อล่อ copier เข้า → แล้วขายกลับ
- เปลี่ยน wallet ใหม่ (ต้อง re-discover)
- ลดขนาด trade ลง
```

## Alert Format

```
🐋 WHALE ALERT [SCORE: 8.5/10 — Tier S]
Wallet: 0x1234...5678 (Win rate: 72%, ROI: +340%)
Action: BUY YES on "Will Bitcoin hit $200k by July 2026?"
Size: $12,500 @ 0.32 (implied prob: 32%)
Time: 2 minutes ago

Copy recommendation:
- Size: $187.50 (15% of bankroll × 50% fraction)
- Entry: 0.32–0.34 (account for slippage)
- Risk: Medium (whale has good track record but not perfect)

→ AUTO-COPIED: $187.50 @ 0.33 (order #12345)
```
