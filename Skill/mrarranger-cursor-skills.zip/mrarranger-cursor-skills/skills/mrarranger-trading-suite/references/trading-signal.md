# TRADING SIGNAL — Polymarket Signal System

## Signal Types & Priority

```
Priority 1 — INSIDER SIGNAL (ROI: 3–12x)
  Trigger: Fresh wallet + large bet + single market + cluster
  Window: 0–30 minutes from detection
  Action: Copy immediately with 40% of leg A bankroll

Priority 2 — NEGRISK GAP (ROI: 2–5% guaranteed)
  Trigger: Sum of all outcome prices < $0.97
  Window: Hours to days (slower opportunity)
  Action: Buy all outcomes via standard market

Priority 3 — CS2 ROUND (ROI: 80–120%/month)
  Trigger: PandaScore reports round result before Polymarket adjusts
  Window: 10–35 seconds
  Action: Buy winner with 4% bankroll per round

Priority 4 — NO ARB (ROI: 50–200%)
  Trigger: Sensational market YES > 20¢ for highly unlikely event
  Window: Days to weeks
  Action: Buy NO with 4–8% bankroll
```

## Signal 1: Insider Wallet (Detailed)

```python
# Signal definition
INSIDER_SIGNAL = {
    "id": "INSIDER_001",
    "name": "Suspicious Fresh Wallet",
    "criteria": {
        "wallet_age_days": {"max": 7},
        "markets_traded": {"max": 2},
        "position_size_usd": {"min": 500},
        "entry_price": {"max": 0.25},
        "time_window_min": 120,   # All activity within 2 hours
        "cluster_count": {"min": 2}  # At least 2 wallets doing same
    },
    "score_required": 4,  # Must match 4+ criteria
    "confidence": {
        5: "VERY HIGH — copy up to 40% of Leg A",
        4: "HIGH — copy up to 25% of Leg A",
        3: "MEDIUM — copy up to 10% of Leg A",
        2: "LOW — monitor only"
    }
}

# Score a wallet
def score_insider_signal(wallet_data, market_data, cluster_data):
    score = 0
    details = []

    if wallet_data["age_days"] < 7:
        score += 1
        details.append(f"Fresh wallet: {wallet_data['age_days']}d old")

    if wallet_data["markets_count"] <= 2:
        score += 1
        details.append(f"Focused: only {wallet_data['markets_count']} market(s)")

    if market_data["size_usd"] >= 500:
        score += 1
        details.append(f"Large bet: ${market_data['size_usd']:,.0f}")

    if market_data["entry_price"] <= 0.25:
        score += 1
        details.append(f"Low price entry: {market_data['entry_price']}¢ ({(1/market_data['entry_price']-1)*100:.0f}% upside)")

    if len(cluster_data) >= 2:
        score += 1
        details.append(f"Cluster: {len(cluster_data)} wallets coordinated")

    return score, details

# Historical insider cases (2026 data):
CASE_STUDIES = [
    {
        "event": "Venezuela Maduro removal (Jan 2026)",
        "score": 5,
        "entry": 0.08,
        "roi": "12.6x",
        "window_hours": 4
    },
    {
        "event": "Iran strike Feb 28 (Feb 2026)",
        "score": 5,
        "entry": 0.12,
        "roi": "6.3x",
        "wallets": 6,
        "window_hours": 24
    },
    {
        "event": "Axiom ZachXBT investigation (Feb 2026)",
        "score": 4,
        "entry": 0.14,
        "roi": "5.1x",
        "window_hours": 12
    }
]
```

## Signal 2: NegRisk Gap (Detailed)

```python
NEGRISK_SIGNAL = {
    "id": "NEGRISK_001",
    "name": "Multi-Outcome Sum Imbalance",
    "criteria": {
        "outcome_count": {"min": 3},
        "price_sum": {"max": 0.97},  # After 2% fee
        "min_liquidity_per_outcome": {"min": 100},
        "resolution_source": ["official", "hltv", "major_sports"]
    },
    "profit_formula": "gap_pct = (1.00 - price_sum) × 100",
    "action": "BUY ALL outcomes via STANDARD market (NOT NegRisk interface)"
}

# Alert format
def format_negrisk_alert(event_title, outcomes, total_sum):
    gap = round((1.0 - total_sum) * 100, 2)
    return {
        "type": "NEGRISK",
        "priority": "HIGH" if gap > 5 else "MEDIUM",
        "title": event_title[:60],
        "gap_pct": gap,
        "price_sum": round(total_sum, 4),
        "outcomes": len(outcomes),
        "action": f"BUY ALL {len(outcomes)} outcomes",
        "guaranteed_roi": f"+{gap:.1f}% (after fees)",
        "telegram_msg": f"🟢 NegRisk Gap: {gap:.1f}% on '{event_title[:40]}'"
    }
```

## Signal 3: CS2 Round Event

```python
CS2_SIGNAL = {
    "id": "CS2_ROUND_001",
    "name": "CS2 Stream Delay Arbitrage",
    "triggers": [
        {"event": "round_winner", "price_impact": 0.15, "window_sec": 35},
        {"event": "bomb_planted", "price_impact": 0.20, "window_sec": 35},
        {"event": "pistol_round", "price_impact": 0.25, "window_sec": 35},
        {"event": "ace_kill", "price_impact": 0.30, "window_sec": 35}
    ],
    "stream_delay_sec": 30,
    "api_latency_sec": 1,
    "execute_window_sec": 10  # Execute within 10s of detection
}

# Signal generation
def generate_cs2_signal(round_data, polymarket_price):
    """
    round_data: from PandaScore API
    polymarket_price: current Polymarket market price
    """
    winner = round_data.get("winner", {}).get("acronym")
    confidence = calculate_confidence(round_data)

    # After this round, what's the probability of CT winning overall?
    updated_prob = update_match_prob(
        current_score=round_data["score"],
        round_winner=winner,
        map_name=round_data["map"]
    )

    polymarket_lag = abs(updated_prob - polymarket_price)

    if polymarket_lag > 0.10:  # 10% lag = tradeable
        return {
            "type": "CS2_ROUND",
            "market": f"{round_data['match']} - Match Winner",
            "team": winner,
            "our_prob": updated_prob,
            "market_price": polymarket_price,
            "edge_pct": round(polymarket_lag * 100, 1),
            "action": f"BUY {winner} winner @ {polymarket_price:.2f}",
            "urgency": "IMMEDIATE — 30 second window"
        }
    return None
```

## Signal 4: NO Arbitrage

```python
NO_ARB_SIGNAL = {
    "id": "NOARB_001",
    "name": "Sensational Market YES Overpricing",
    "keywords": [
        "nuclear", "war", "collapse", "death", "coup", "impeach",
        "invasion", "explosion", "catastrophe", "crisis", "attack"
    ],
    "optimal_yes_range": (0.10, 0.40),
    "min_volume": 5000,
    "psychological_basis": "humans overestimate dramatic event probability"
}

# NO Arb scoring
def score_no_arb(market):
    score = 0
    yes = market["yes_price"]
    question = market["question"].lower()

    # Keyword check
    keyword_matches = sum(1 for kw in NO_ARB_SIGNAL["keywords"] if kw in question)
    if keyword_matches >= 1:
        score += 2
    if keyword_matches >= 2:
        score += 1

    # Price range check
    if 0.10 <= yes <= 0.40:
        score += 2

    # Volume check (active market = real opportunity)
    if market["volume"] > 50000:
        score += 2
    elif market["volume"] > 10000:
        score += 1

    # Time to resolution (need time for NO to pay off)
    if market["days_to_resolve"] > 14:
        score += 1

    return score  # 6-8 = strong, 4-5 = medium, <4 = weak

# Current active NO Arb candidates (template)
NO_ARB_WATCHLIST = [
    # Format: {question, yes_price, volume, days_to_resolve, score}
    # Updated by scanner in real-time
]
```

## Signal Aggregation

```python
class SignalAggregator:
    """Combine multiple signals and prioritize"""

    def __init__(self):
        self.pending = []
        self.executed = []

    def add_signal(self, signal):
        # Check for duplicates
        for existing in self.pending:
            if existing["market"] == signal["market"]:
                # Update if stronger signal
                if signal.get("score", 0) > existing.get("score", 0):
                    self.pending.remove(existing)
                    break
                else:
                    return  # Keep existing

        self.pending.append(signal)
        self.pending.sort(key=lambda x: x.get("priority_score", 0), reverse=True)

    def get_top_signals(self, n=3):
        """Get top N signals ready to execute"""
        return self.pending[:n]

    def format_daily_summary(self):
        """Daily signal report"""
        if not self.pending and not self.executed:
            return "📊 No signals today"

        msg = "📊 **Daily Signal Summary**\n\n"

        if self.pending:
            msg += f"🟡 **Pending ({len(self.pending)}):**\n"
            for s in self.pending[:5]:
                msg += f"  • {s['type']}: {s.get('title', s.get('market', ''))[:40]}\n"

        if self.executed:
            wins = [e for e in self.executed if e.get("won")]
            msg += f"\n✅ **Executed today:** {len(self.executed)} trades, {len(wins)} wins\n"

        return msg
```

## Alert Format Templates

```
🔴 INSIDER SIGNAL [SCORE: 5/5]
Market: Will [X] happen by [date]?
Entry: 0.12¢ | Upside: +733%
Size: $48 (16% of Leg A)
Window: ~30 minutes
Wallets: 4 coordinated (age: 2d, 1d, 3d, 1d)
→ COPY NOW via Polymarket

🟢 NEGRISK GAP [+4.2%]
Event: BLAST Rotterdam 2026 Winner
Sum: 0.958 (gap: 4.2% after fee)
Outcomes: 16 teams
Action: Buy ALL 16 outcomes standard
Guaranteed: +$0.042 per $1 invested

⚡ CS2 ROUND [10 SEC WINDOW]
Match: FaZe vs Vitality - Map 2
Event: FaZe won round 8 (bomb plant kill)
Polymarket lag: +14% (our prob 68% vs market 54%)
Action: BUY FaZe match winner @ 0.54
Size: $12 (4% bankroll)
⏰ EXECUTE IN 10 SECONDS

🔵 NO ARB [SCORE: 7/8]
Market: "Nuclear detonation before June 2026?"
YES price: 0.22 (22%)
Our estimate: ~3% real probability
Action: Buy NO @ 0.78
Size: $18 (6% bankroll)
```

---

## Signal 5: Valorant Round Event

```python
VALORANT_SIGNAL = {
    "id": "VAL_ROUND_001",
    "name": "Valorant Stream Delay Arbitrage",
    "triggers": [
        {"event": "round_winner", "price_impact": 0.12, "window_sec": 40},
        {"event": "spike_planted", "price_impact": 0.18, "window_sec": 40},
        {"event": "pistol_round", "price_impact": 0.22, "window_sec": 40},
        {"event": "ace_clutch", "price_impact": 0.30, "window_sec": 40},
        {"event": "eco_round_upset", "price_impact": 0.25, "window_sec": 40}
    ],
    "stream_delay_sec": 35,  # Valorant streams slightly more delayed
    "api_latency_sec": 2,    # Community API slightly slower
    "execute_window_sec": 10
}

def generate_valorant_signal(round_data, polymarket_price):
    """Generate signal from Valorant live match data"""
    winner = round_data.get("round_winner")
    current_score = round_data.get("score", {"team_a": 0, "team_b": 0})

    # Calculate updated match probability based on round result
    updated_prob = calculate_valorant_match_prob(
        score_a=current_score["team_a"],
        score_b=current_score["team_b"],
        round_winner=winner,
        map_name=round_data.get("map"),
        side=round_data.get("attacking_side")
    )

    lag = abs(updated_prob - polymarket_price)

    if lag > 0.08:  # 8% lag = tradeable (lower threshold than CS2 due to less liquidity)
        return {
            "type": "VALORANT_ROUND",
            "market": f"{round_data['match']} - Match Winner",
            "team": winner,
            "our_prob": updated_prob,
            "market_price": polymarket_price,
            "edge_pct": round(lag * 100, 1),
            "action": f"BUY {winner} winner @ {polymarket_price:.2f}",
            "urgency": "IMMEDIATE — 35 second window",
            "liquidity_warning": round_data.get("market_volume", 0) < 1000
        }
    return None

def calculate_valorant_match_prob(score_a, score_b, round_winner, map_name, side):
    """
    Calculate probability using Valorant-specific modeling.
    Valorant: first to 13 rounds, overtime at 12-12.
    """
    # Base probability from score
    rounds_to_win = 13
    remaining_a = rounds_to_win - score_a
    remaining_b = rounds_to_win - score_b

    if remaining_a <= 0:
        return 1.0
    if remaining_b <= 0:
        return 0.0

    # Simple binomial approximation
    round_win_rate = 0.52 if side == "attack" else 0.48  # Slight attack/defense bias

    # Adjust for round result
    if round_winner == "team_a":
        score_a += 1
        remaining_a -= 1

    # Probability using combination formula
    from math import comb
    prob_a = 0
    total_remaining = remaining_a + remaining_b - 1
    for wins in range(remaining_a - 1, total_remaining + 1):
        prob_a += comb(total_remaining, wins) * (round_win_rate ** wins) * ((1 - round_win_rate) ** (total_remaining - wins))

    return round(min(0.99, max(0.01, prob_a)), 4)
```

## Signal 6: FIFA / Sports Event

```python
FIFA_SIGNAL = {
    "id": "FIFA_001",
    "name": "FIFA World Cup Live Event Arbitrage",
    "triggers": [
        {"event": "goal_scored", "price_impact": 0.30, "window_sec": 45},
        {"event": "red_card", "price_impact": 0.20, "window_sec": 60},
        {"event": "penalty_awarded", "price_impact": 0.25, "window_sec": 30},
        {"event": "halftime", "price_impact": 0.05, "window_sec": 120},
        {"event": "substitution_key", "price_impact": 0.05, "window_sec": 90}
    ],
    "stream_delay_sec": 45,
    "api_latency_sec": 3,
    "execute_window_sec": 15,
    "active_period": "June-July 2026 (FIFA World Cup)"
}
```

## Signal 7: AI Ensemble Signal

```python
ENSEMBLE_SIGNAL = {
    "id": "ENSEMBLE_001",
    "name": "AI Ensemble Probability Disagreement",
    "description": "When AI ensemble disagrees with market price by >15%",
    "triggers": [
        {"condition": "ensemble_vs_market_gap > 0.15", "confidence": "high"},
        {"condition": "ensemble_vs_market_gap > 0.10 AND volume > 50000", "confidence": "medium"},
    ],
    "cost_per_forecast": 0.018,  # $0.018 per API call
    "max_forecasts_per_day": 50,
    "reference": "ai-ensemble-forecasting.md"
}

async def generate_ensemble_signals(active_markets, ensemble_forecaster):
    """
    Scan markets using AI ensemble for mispricing.
    Run 2x daily on top 50 highest-volume markets.
    """
    signals = []

    for market in active_markets[:50]:
        try:
            forecast = await ensemble_forecaster.forecast(
                question=market["question"],
                current_price=market["yes_price"],
                context={
                    "volume": market["volume"],
                    "age_days": market["age_days"],
                    "category": market.get("category", "unknown")
                }
            )

            gap = abs(forecast["blended_probability"] - market["yes_price"])

            if gap > 0.15:  # 15% disagreement
                direction = "YES" if forecast["blended_probability"] > market["yes_price"] else "NO"
                signals.append({
                    "type": "ENSEMBLE",
                    "market": market["question"][:60],
                    "market_price": market["yes_price"],
                    "ensemble_prob": forecast["blended_probability"],
                    "gap_pct": round(gap * 100, 1),
                    "direction": direction,
                    "confidence": forecast.get("agreement_score", 0),
                    "action": f"BUY {direction} @ {market['yes_price'] if direction == 'YES' else 1-market['yes_price']:.2f}"
                })

        except Exception:
            continue

    return sorted(signals, key=lambda x: x["gap_pct"], reverse=True)
```

## Enhanced Signal Aggregator

```python
class EnhancedSignalAggregator(SignalAggregator):
    """Extended aggregator with cross-signal confirmation and scoring"""

    SIGNAL_WEIGHTS = {
        "INSIDER": 10,
        "NEGRISK": 7,
        "CS2_ROUND": 6,
        "VALORANT_ROUND": 5,
        "FIFA_EVENT": 5,
        "ENSEMBLE": 4,
        "NOARB": 3,
    }

    def calculate_priority_score(self, signal):
        """Calculate overall priority combining type weight + signal strength"""
        type_weight = self.SIGNAL_WEIGHTS.get(signal["type"], 1)
        signal_score = signal.get("score", signal.get("gap_pct", 5)) / 10
        urgency_bonus = 5 if signal.get("urgency", "").startswith("IMMEDIATE") else 0
        confirmation_bonus = 3 if self._has_confirmation(signal) else 0

        return type_weight * signal_score + urgency_bonus + confirmation_bonus

    def _has_confirmation(self, signal):
        """Check if other signals confirm this one"""
        for existing in self.pending + self.executed:
            if (existing.get("market") == signal.get("market") and
                existing["type"] != signal["type"]):
                return True  # Different signal type, same market = confirmation
        return False

    def format_enhanced_summary(self):
        """Enhanced daily summary with cross-signal analysis"""
        msg = "📊 **Enhanced Signal Summary**\n\n"

        # Group by market
        markets = {}
        for s in self.pending:
            market = s.get("market", "unknown")
            markets.setdefault(market, []).append(s)

        # Multi-signal markets first
        confirmed = {m: sigs for m, sigs in markets.items() if len(sigs) > 1}
        if confirmed:
            msg += "🎯 **Multi-Signal Confirmed:**\n"
            for market, sigs in confirmed.items():
                types = ", ".join(s["type"] for s in sigs)
                msg += f"  • {market[:40]} ({types})\n"

        msg += f"\n📡 Total pending: {len(self.pending)} | "
        msg += f"Confirmed: {len(confirmed)} markets\n"

        return msg
```

## Alert Format Templates (Extended)

```
⚡ VALORANT ROUND [10 SEC WINDOW]
Match: Sentinels vs Fnatic - Map 1
Event: Sentinels won pistol round (Attack)
Polymarket lag: +12% (our prob 65% vs market 53%)
Action: BUY Sentinels match winner @ 0.53
Size: $10 (4% bankroll)
⏰ EXECUTE IN 10 SECONDS
⚠️ Low liquidity warning: $800 volume

⚽ FIFA GOAL [15 SEC WINDOW]
Match: Brazil vs Germany — 67th minute
Event: Goal scored by Brazil (now 2-1)
Market lag: +18% (our prob 78% vs market 60%)
Action: BUY Brazil match winner @ 0.60
Size: $25 (8% bankroll)
⏰ EXECUTE IN 15 SECONDS

🤖 AI ENSEMBLE DISAGREEMENT [MEDIUM PRIORITY]
Market: "Will Fed cut rates in June 2026?"
Market price: 0.42 (42%)
Ensemble estimate: 0.61 (61%)
Gap: 19%
Models: GPT-4o=0.58, Claude=0.65, Gemini=0.59
Action: BUY YES @ 0.42
Size: $30 (10% bankroll)
Confidence: HIGH (3/3 models agree direction)

🎯 MULTI-SIGNAL CONFIRMATION
Market: "Will [X] happen by [date]?"
Signals:
  1. INSIDER: Score 4/5, entry @ 0.15
  2. ENSEMBLE: 68% vs market 15%, gap 53%
Combined confidence: VERY HIGH
Action: BUY YES @ 0.15 (max 40% Leg A)
```
