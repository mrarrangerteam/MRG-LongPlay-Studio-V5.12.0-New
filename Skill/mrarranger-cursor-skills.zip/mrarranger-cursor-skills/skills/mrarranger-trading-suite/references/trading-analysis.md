# TRADING ANALYSIS — Polymarket Deep Dive

## Market Structure Analysis

### Polymarket as a Market System

```
Polymarket Structure:
├── Market Type: Binary (YES/NO) or Multi-Outcome (NegRisk)
├── Settlement: On-chain via UMA Oracle (Polygon)
├── Order Book: CLOB (Central Limit Order Book)
├── Fees: 2% winner fee, 0% maker rebate (except maker program)
├── Participants:
│   ├── Retail (80%) — emotional, slow, information-poor
│   ├── Smart Money (15%) — informed, fast, domain-expert
│   └── Bots/HFT (5%) — fastest, mechanical, exploit microstructure

Why inefficiencies exist:
1. Independent order books (YES and NO don't automatically balance)
2. Retail emotional trading (overprices dramatic events)
3. Information asymmetry (insiders know before public)
4. Stream delays (esports/sports live events lag)
5. Multi-outcome fragmentation (NegRisk underpricing niche outcomes)
```

### Market Efficiency Scale

```
MOST EFFICIENT (hardest to profit):
  ├── BTC/ETH 5-15min markets (HFT dominated)
  ├── Major US election binary markets
  └── Large volume sports markets ($500k+)

MEDIUM EFFICIENCY:
  ├── Breaking news political markets
  ├── CS2 match winner markets
  └── Macro economic markets

LEAST EFFICIENT (easiest to profit):
  ├── NegRisk niche outcome markets
  ├── New markets (first 30 min)
  ├── Sensational/emotional markets
  └── Small esports markets (<$50k volume)
  └── Markets with confirmed insider activity
```

## Edge Analysis Framework

### VRIO Analysis for Trading Edges

```
For each edge, ask:

V — Valuable? Does it generate positive EV consistently?
R — Rare? Do few competitors know/use it?
I — Inimitable? Hard to copy quickly?
O — Organized? Can you execute it systematically?

Scoring:
V + R + I + O = Sustainable Competitive Advantage
V + R + I = Temporary Advantage (6–18 months)
V + R = Short Window (1–6 months)
V only = No edge (everyone doing it)

Current edges:
Insider Copy: V✅ R✅ I✅ O✅ = Sustainable (until legal)
CS2 Parser: V✅ R✅ I✅ O✅ = Temporary (3–6 months)
NO Arb: V✅ R✅ I✗ O✅ = Short-term advantage
NegRisk: V✅ R✅ I✅ O✅ = Sustainable (math-based)
```

### Edge Decay Analysis

```python
def estimate_edge_decay(edge_name, discovery_date, current_date):
    """
    Estimate remaining edge based on decay model
    Based on observed patterns in 2024–2026 Polymarket data
    """
    days_since_discovery = (current_date - discovery_date).days

    DECAY_CURVES = {
        "insider_copy": {
            "half_life_days": 180,  # Edge halves every 6 months
            "floor_roi": 0.20       # Minimum ROI even when mature
        },
        "cs2_live_parse": {
            "half_life_days": 90,
            "floor_roi": 0.05
        },
        "negrisk_arb": {
            "half_life_days": 365,  # Very slow decay (math-based)
            "floor_roi": 0.01       # Near-zero but never dies
        },
        "no_arb_sensational": {
            "half_life_days": 730,  # Human psychology = permanent
            "floor_roi": 0.15
        }
    }

    params = DECAY_CURVES.get(edge_name, {"half_life_days": 90, "floor_roi": 0.05})

    # Exponential decay
    import math
    decay_factor = math.exp(-0.693 * days_since_discovery / params["half_life_days"])

    remaining_edge = max(params["floor_roi"], decay_factor)

    return {
        "edge": edge_name,
        "days_elapsed": days_since_discovery,
        "remaining_strength": f"{remaining_edge*100:.0f}%",
        "est_months_remaining": round(params["half_life_days"] * math.log(2) / 30, 1)
    }
```

## Competitive Analysis

### Who Else Is In This Game

```
Category 1: HFT Firms (Professional)
  - Entry: Sub-100ms latency
  - Focus: Binary arb, crypto latency
  - Threat level for us: VERY HIGH for those edges
  - Our response: Avoid those markets entirely

Category 2: Smart Copy Traders (Amateur Pro)
  - Entry: 5–60 second copy lag
  - Focus: Insider signals, whale copying
  - Threat level: MEDIUM (same space, similar tools)
  - Our response: Be faster, better filters

Category 3: Esports Bot Builders (Technical)
  - Entry: PandaScore API (public)
  - Focus: LoL/Dota2 (crowded), CS2 (growing)
  - Threat level: MEDIUM in CS2, HIGH in LoL
  - Our response: CS2 now, Valorant next

Category 4: Domain Specialists (Information Edge)
  - Entry: Domain knowledge (politics, crypto, biotech)
  - Focus: New market snipe, directional bets
  - Threat level: LOW (need specific knowledge)
  - Our response: Complement with our own domain areas

Category 5: Retail (Emotional Traders)
  - Entry: Anyone
  - Focus: Everything, driven by news/emotion
  - Threat level: NONE (they're our liquidity source!)
  - Our response: They ARE the edge — exploit their emotions
```

### Competition Monitor

```
Watch for these signals that competition is increasing:

🔴 Edge Crowding Signals:
  - Win rate drops > 10% over 2 weeks
  - Average entry price 20%+ worse than 2 weeks ago
  - New wallets with similar patterns appearing
  - Public posts about your specific edge on X/Twitter

🟡 Early Warning:
  - Thread about the edge appears (< 50 posts)
  - Win rate starts declining slowly
  - Execution getting harder (price moves before you)

🟢 Safe Zone:
  - Edge not mentioned publicly
  - Win rate stable or improving
  - Your execution fills at target price
```

## Timing Analysis

### Best Times to Trade Each Edge

```
Insider Signals:
  Best: Any time (can't predict)
  Frequency: 2–4 per month
  Response time: Within 30 minutes of detection

CS2 Live (BLAST Rotterdam):
  Match days: Mar 18–29 (all day)
  Best hours: 10:00–20:00 CET (European tournaments)
  ESL S23: April (schedule TBD)
  Worst: No tournaments = no edge

NO Arb:
  Best: During major geopolitical events (tension = overpricing)
  Entry: Gradually (scale in over 24–48h)
  Worst: Boring news cycles

NegRisk:
  Best: During major multi-outcome events (World Cup, elections)
  Any time: Always scan, gaps appear randomly
  Best hours: After major news hits (retail rushes in)

New Market Snipe:
  Best: Within 30 minutes of market creation
  Frequency: 50–100 new markets/day
  Monitor: Set up alert for new markets in your domain
```

## Investment Thesis

### Master Thesis Statement

```
THESIS: Polymarket is an information market where retail traders'
emotional biases, information lag, and irrational behavior create
systematic pricing inefficiencies that can be exploited by faster,
better-informed, mathematically-disciplined participants.

SUPPORTING EVIDENCE (2025–2026):
1. 41% of market conditions were mispriced at some point (IMDEA research)
2. $40M+ extracted via arbitrage in 12 months
3. Insider signals with 6–12x ROI documented (Iran, Maduro, Axiom)
4. Stream delay edge validated: $900 → $208k in 3 months (TeemuTeemuTeemu)
5. 80% of Polymarket traders lose money = our liquidity source

RISK FACTORS:
1. Edge decay (all edges have a lifespan)
2. Platform rule changes (Polymarket controls the game)
3. Legal uncertainty (insider trading law proposal)
4. Thailand geo-block (VPN risk)
5. Technical failures (bot crashes, API downtime)

EDGE PORTFOLIO THESIS:
By running 3 uncorrelated edges simultaneously, we:
- Reduce dependence on any single edge
- Provide income while building more complex systems
- Generate data to identify next edges early
- Survive edge decay through diversification
```

## Analysis Output Format

```
When analyzing a specific edge, output:

## [Edge Name] Analysis

### Market Opportunity
[Size, frequency, current state]

### Mechanism
[How the inefficiency exists and why it persists]

### Evidence
[Historical cases with numbers]

### Competitive Landscape
[Who else is doing this, how crowded]

### Edge Decay
[Phase, estimated window remaining, decay rate]

### Entry Requirements
[Capital, tools, time, skills needed]

### Risk Factors
[Top 3 ways this fails]

### Expected Returns
[Win rate, ROI range, monthly compound estimate]

### Verdict
[GO NOW / WAIT / SKIP] — [1 sentence reason]
```


---

## Multi-Platform Market Structure

Platform-specific inefficiencies:

POLYMARKET (Primary):
- Largest volume → most liquid → most efficient for major events
- Least efficient for: NegRisk niche outcomes, new markets, esports
- Edge source: on-chain transparency enables wallet tracking

KALSHI (Secondary):
- CFTC regulated → fewer bots → more retail inefficiency
- Least efficient for: political events, macro economics
- Edge source: less competition = wider spreads to capture

MANIFOLD (Practice):
- Play money → no financial incentive for accuracy
- Least efficient for: everything (play money attracts casual players)
- Edge source: calibration practice, strategy R&D


## On-Chain Analytics Integration

Enhanced analysis with on-chain data:

1. Wallet Cluster Analysis:
   - Identify coordinated wallets (same funder)
   - Track fund flow: CEX → Bridge → Polymarket
   - Reference: on-chain-analytics.md for implementation

2. Smart Money Flow:
   - Track top-performing wallets' positions
   - Aggregate their directional bias per market
   - Weight by historical accuracy

3. Volume Profile Analysis:
   - Time-weighted volume distribution
   - Identify accumulation vs distribution phases
   - Detect unusual volume spikes (potential insider activity)


## AI-Enhanced Market Analysis

Using AI Ensemble for deeper analysis (reference: ai-ensemble-forecasting.md):

1. Automated Market Structure Classification:
   - Input: market question + price + volume + age
   - Output: efficiency classification (High/Medium/Low)
   - Uses LLM to understand context and domain

2. Edge Discovery:
   - Scan 100+ markets daily with LLM analysis
   - Identify potential mispricings based on reasoning
   - Cross-reference with on-chain data for confirmation

3. Competitive Landscape Auto-Update:
   - Track new bot wallets entering your edge space
   - Measure execution quality degradation over time
   - Alert when competition reaches critical threshold
