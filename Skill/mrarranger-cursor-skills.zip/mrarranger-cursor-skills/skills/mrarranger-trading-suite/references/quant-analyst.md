# QUANT ANALYST — Prediction Market Mathematics

## Core Framework: 4-Step EV Analysis

```
Step 1: ESTIMATE true probability (p_true)
Step 2: COMPARE vs market price (p_market)
Step 3: CALCULATE edge = p_true - p_market
Step 4: SIZE position using Kelly if edge > 0
```

## 1. Probability Estimation Methods

### Method A: Base Rate + Adjustments
```python
def estimate_probability(base_rate, adjustments):
    """
    Start with historical base rate, adjust for specific factors

    Example: "Will CS2 team win this match?"
    base_rate = historical win rate (e.g., 0.55 for top team)
    adjustments:
      +0.05 if playing on home map
      -0.03 if key player injured
      +0.02 if opponent has travel fatigue
    """
    p = base_rate
    for adj in adjustments:
        p = p + adj  # Simple linear adjustment
        p = max(0.01, min(0.99, p))  # Clamp to valid range
    return p

# Insider signal adjustment example
def adjust_for_insider_signal(base_prob, signal_strength):
    """
    If fresh wallet bets large → market knows something
    signal_strength: 0.0 (weak) to 1.0 (very strong)
    """
    # Strong insider signal → push probability toward 1.0
    return base_prob + (1 - base_prob) * signal_strength * 0.7
```

### Method B: Bayesian Update
```python
def bayesian_update(prior, likelihood_ratio):
    """
    Update probability when new evidence arrives

    prior: your current probability estimate
    likelihood_ratio: P(evidence | true) / P(evidence | false)

    Example:
    Prior: Trump wins = 0.45
    New evidence: New poll shows +8% lead
    Likelihood ratio: 3.0 (3x more likely to see this if he's winning)

    posterior = (0.45 × 3.0) / (0.45 × 3.0 + 0.55 × 1.0) = 0.71
    """
    posterior_odds = (prior / (1 - prior)) * likelihood_ratio
    return posterior_odds / (1 + posterior_odds)

# Multiple evidence updates
def multi_bayesian(prior, evidence_list):
    """evidence_list: list of likelihood ratios"""
    p = prior
    for lr in evidence_list:
        p = bayesian_update(p, lr)
    return round(p, 4)
```

### Method C: Market Consensus + Own View
```python
def blend_estimates(market_price, own_estimate, confidence):
    """
    Blend market consensus with your own view
    confidence: 0.0 (no confidence in own view) to 1.0 (full confidence)

    If confidence = 0.3: mostly trust market
    If confidence = 0.8: mostly trust your own view
    """
    return (1 - confidence) * market_price + confidence * own_estimate
```

## 2. Expected Value (EV) Calculation

```python
def calculate_ev(entry_price, true_prob, fee_pct=0.02):
    """
    EV of buying YES at entry_price, given true probability

    Gross payout: $1.00 per share if correct
    Cost: entry_price per share
    Fee: 2% of winnings

    EV = p × (payout × (1-fee) - entry) - (1-p) × entry
    """
    payout = 1.0 * (1 - fee_pct)  # = $0.98

    ev = (true_prob * (payout - entry_price)) + ((1 - true_prob) * (-entry_price))
    return round(ev, 4)

def ev_percentage(entry_price, true_prob, fee_pct=0.02):
    """EV as % of investment"""
    ev = calculate_ev(entry_price, true_prob, fee_pct)
    return round((ev / entry_price) * 100, 2)

# Examples:
# Market: 25¢, True prob: 40% → EV = 0.40×0.73 - 0.60×0.25 = +$0.142 (+57%)
# Market: 25¢, True prob: 20% → EV = 0.20×0.73 - 0.80×0.25 = -$0.054 (-22%)

# Minimum edge to be profitable (accounting for uncertainty):
MIN_EDGE_PCT = 10  # At least 10% EV edge required
MIN_PROB_DIFF = 0.05  # Your estimate must be >5% higher than market
```

## 3. Kelly Criterion

```python
def kelly(win_prob, entry_price, fee_pct=0.02, fraction=1.0):
    """
    Optimal fraction of bankroll to bet

    b = net odds (payout per dollar bet, net of fee)
    p = win probability
    q = 1 - p

    f* = (p×b - q) / b
    """
    payout_net = (1 / entry_price - 1) * (1 - fee_pct)  # Net odds
    b = payout_net
    p = win_prob
    q = 1 - p

    if b <= 0:
        return 0

    full_kelly = (p * b - q) / b
    recommended = full_kelly * fraction

    return {
        "full_kelly": round(max(0, full_kelly), 4),
        "recommended": round(max(0, recommended), 4),
        "recommended_pct": round(max(0, recommended) * 100, 1),
        "positive_ev": full_kelly > 0
    }

# ALWAYS use Quarter Kelly (fraction=0.25) or less for prediction markets
# Full Kelly is theoretically optimal but causes too much variance
```

## 4. Performance Metrics

```python
def calculate_metrics(trades):
    """
    trades: list of {entry, exit_or_resolve, won, profit}
    """
    if not trades:
        return {}

    wins = [t for t in trades if t["won"]]
    losses = [t for t in trades if not t["won"]]

    win_rate = len(wins) / len(trades)
    avg_win = sum(t["profit"] for t in wins) / len(wins) if wins else 0
    avg_loss = abs(sum(t["profit"] for t in losses) / len(losses)) if losses else 0

    # Profit Factor
    gross_profit = sum(t["profit"] for t in wins)
    gross_loss = abs(sum(t["profit"] for t in losses))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float("inf")

    # Sharpe Ratio (simplified)
    all_returns = [t["profit"] / t.get("size", 1) for t in trades]
    avg_return = sum(all_returns) / len(all_returns)

    import math
    variance = sum((r - avg_return)**2 for r in all_returns) / len(all_returns)
    std_dev = math.sqrt(variance) if variance > 0 else 0.001
    sharpe = avg_return / std_dev if std_dev > 0 else 0

    # Max Drawdown
    cumulative = 0
    peak = 0
    max_dd = 0
    for t in trades:
        cumulative += t["profit"]
        peak = max(peak, cumulative)
        dd = (peak - cumulative) / peak if peak > 0 else 0
        max_dd = max(max_dd, dd)

    return {
        "total_trades": len(trades),
        "win_rate": round(win_rate * 100, 1),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "profit_factor": round(profit_factor, 2),
        "sharpe_ratio": round(sharpe, 2),
        "max_drawdown_pct": round(max_dd * 100, 1),
        "total_pnl": round(sum(t["profit"] for t in trades), 2),
        "expectancy": round(win_rate * avg_win - (1-win_rate) * avg_loss, 2)
    }
```

## 5. Market Efficiency Analysis

```python
def analyze_market_efficiency(market_data):
    """
    Test if a market is efficiently priced
    Returns efficiency score and mispricing direction
    """
    # For NegRisk markets: sum should = 1.00
    if market_data["type"] == "negrisk":
        total = sum(market_data["prices"])
        gap = 1.0 - total
        return {
            "efficient": abs(gap) < 0.01,
            "gap": round(gap, 4),
            "direction": "underpriced" if gap > 0 else "overpriced",
            "arb_opportunity": gap > 0.03  # > 3% gap = tradeable
        }

    # For binary YES/NO: YES + NO should ≈ 1.00
    yes = market_data.get("yes_price", 0.5)
    no = market_data.get("no_price", 0.5)
    total = yes + no

    return {
        "efficient": abs(total - 1.0) < 0.01,
        "sum": round(total, 4),
        "spread": round(abs(total - 1.0), 4),
        "direction": "arb" if total < 0.97 else "overpriced"
    }
```

## 6. Quick Analysis Commands

### /ev [market_price] [my_probability]
```
Calculates EV and sizing recommendation

Example: /ev 0.25 0.40
→ Entry: $0.25 | True prob: 40%
→ EV: +$0.142 per share (+57%)
→ Quarter Kelly: 14% of bankroll
→ RECOMMENDATION: TRADE ✅
```

### /kelly [probability] [price]
```
Calculates optimal position size

Example: /kelly 0.70 0.30
→ Full Kelly: 57.1% of bankroll
→ Quarter Kelly: 14.3%
→ For $300 bankroll: $42.90
```

### /sharpe [win_rate] [avg_win] [avg_loss]
```
Estimates Sharpe ratio from basic stats

Example: /sharpe 0.65 0.45 0.25
→ Expectancy: $0.205/trade
→ Estimated Sharpe: 2.8
→ Quality: GOOD (>2.0 is excellent)
```

## Red Flags (อย่าเทรด)

```
❌ EV < 5% after fee
❌ Win rate < 52% (not enough edge)
❌ Market resolving in < 10 minutes
❌ Liquidity < $500 (too thin)
❌ Can't identify WHY market is mispriced
❌ Based purely on gut feel / hope
```

## Green Flags (เทรดได้)

```
✅ EV > 10%
✅ Clear reason for mispricing (insider, recency bias, emotional)
✅ Liquidity > $2,000
✅ Can quantify edge (not just intuition)
✅ Historical pattern supports thesis
✅ Position size passes Kelly test
```


---

## AI Ensemble Integration

```python
def ensemble_probability(market_question, market_context):
    """
    Use AI Ensemble for probability estimation.
    Reference: ai-ensemble-forecasting.md for full implementation.

    Integration pattern:
    1. Get market question and context
    2. Query ensemble (GPT-4o + Claude + Gemini)
    3. Aggregate probabilities
    4. Compare with market price
    5. If edge > 10% → trade
    """
    # Simplified integration
    ensemble_prob = query_ensemble(market_question, market_context)

    # Blend with market price (market is usually somewhat efficient)
    market_price = market_context["current_price"]
    blended = blend_estimates(market_price, ensemble_prob, confidence=0.40)

    return {
        "ensemble_raw": ensemble_prob,
        "market_price": market_price,
        "blended_estimate": blended,
        "edge": blended - market_price,
        "tradeable": abs(blended - market_price) > 0.10
    }
```

## Calibration Tracking

```python
class CalibrationTracker:
    """
    Track prediction accuracy over time.
    Good calibration = when you say 70%, it happens 70% of the time.
    """

    def __init__(self):
        self.predictions = []  # (predicted_prob, actual_outcome)

    def add(self, predicted_prob, actual_outcome):
        """Record a prediction and its outcome (0 or 1)"""
        self.predictions.append((predicted_prob, actual_outcome))

    def brier_score(self):
        """
        Brier Score: mean squared error of probabilistic predictions.
        Lower = better. 0 = perfect. 0.25 = random (for 50/50).
        """
        if not self.predictions:
            return None
        return sum(
            (p - o) ** 2 for p, o in self.predictions
        ) / len(self.predictions)

    def calibration_curve(self, bins=10):
        """
        Group predictions into bins and check actual frequencies.
        Perfect calibration: predicted 30% → actually happens 30%.
        """
        bin_size = 1.0 / bins
        curve = []
        for i in range(bins):
            low = i * bin_size
            high = (i + 1) * bin_size
            bin_preds = [
                (p, o) for p, o in self.predictions
                if low <= p < high
            ]
            if bin_preds:
                avg_predicted = sum(p for p, _ in bin_preds) / len(bin_preds)
                avg_actual = sum(o for _, o in bin_preds) / len(bin_preds)
                curve.append({
                    "bin": f"{low:.1f}-{high:.1f}",
                    "count": len(bin_preds),
                    "avg_predicted": round(avg_predicted, 3),
                    "avg_actual": round(avg_actual, 3),
                    "calibration_error": round(abs(avg_predicted - avg_actual), 3)
                })
        return curve

    def summary(self):
        if len(self.predictions) < 10:
            return "Need at least 10 predictions for calibration analysis"

        brier = self.brier_score()
        curve = self.calibration_curve()
        avg_error = sum(b["calibration_error"] for b in curve) / len(curve)

        return {
            "total_predictions": len(self.predictions),
            "brier_score": round(brier, 4),
            "brier_quality": "Excellent" if brier < 0.10 else "Good" if brier < 0.20 else "Fair" if brier < 0.25 else "Poor",
            "avg_calibration_error": round(avg_error, 3),
            "well_calibrated": avg_error < 0.05
        }
```

## Log-Likelihood Scoring

```python
import math

def log_likelihood_score(predictions):
    """
    Log-likelihood score for prediction accuracy.
    Better for extreme probabilities than Brier score.

    predictions: list of (predicted_prob, actual_outcome)
    """
    total = 0
    for pred, actual in predictions:
        pred = max(0.001, min(0.999, pred))  # Clamp to avoid log(0)
        if actual == 1:
            total += math.log(pred)
        else:
            total += math.log(1 - pred)
    return total / len(predictions)  # Average log-likelihood

# Benchmark scores:
# -0.693 = always predicting 50% (uninformed)
# -0.356 = Polymarket average (market consensus)
# -0.200 = Good human forecaster
# -0.100 = Excellent (top 1% forecaster)
```

## Response Format: /quant [market]

```
## Quantitative Analysis: [Market Question]

### Probability Estimates
| Method | Estimate | Confidence |
|--------|----------|------------|
| Market price | XX% | (baseline) |
| Base rate + adj. | XX% | Medium |
| Bayesian update | XX% | Medium |
| AI Ensemble | XX% | High |
| **Blended** | **XX%** | **Weighted** |

### EV Calculation
Entry: $X.XX | True prob: XX% | EV: +X.X%
Kelly (quarter): X.X% of bankroll = $XX

### Calibration Note
Your recent Brier score: X.XXX ([quality])
Calibration error: X.X% ([well/poorly] calibrated)

### Verdict
[TRADE / SKIP] — [reason]
```
