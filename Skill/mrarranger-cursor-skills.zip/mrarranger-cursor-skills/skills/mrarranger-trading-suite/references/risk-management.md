# RISK MANAGEMENT — Polymarket Edition

## Core Philosophy

```
"Survive first. Profit second."

เป้าหมายของ risk management:
1. อย่าเสียหมด (risk of ruin → 0)
2. อยู่ในเกมนานพอที่ edge จะทำงาน
3. Scale up เมื่อ win rate พิสูจน์แล้ว
4. Scale down ทันทีเมื่อ edge เริ่มหาย

"The key to long-term trading success is not finding
the best strategy — it's surviving long enough to
compound your edge." — Ray Dalio (adapted)
```

## Bankroll Allocation Rules

### 3-Leg Split (Polymarket Multi-Edge)

```
Starting bankroll: $300

Leg A — Insider Signal:   40% = $120
Leg B — CS2 Live Parser:  40% = $120
Leg C — NO Arb Manual:    20% = $60

Hard limits per leg:
- Never exceed allocated % regardless of how good signal looks
- Rebalance every 2 weeks back to target allocation
- If one leg is losing → reduce allocation, don't go to 0
```

### Per-Trade Sizing (Kelly-Based)

```python
class BankrollManager:

    def __init__(self, total_bankroll):
        self.total = total_bankroll
        self.allocations = {
            "insider": 0.40,
            "cs2": 0.40,
            "no_arb": 0.20
        }
        self.trades = []
        self.peak = total_bankroll

    def get_max_size(self, leg, signal_strength="medium"):
        """Max position size for a given leg"""
        leg_bankroll = self.total * self.allocations[leg]

        limits = {
            "insider": {
                "strong": 0.40,   # 40% of leg = 16% of total
                "medium": 0.25,
                "weak": 0.10
            },
            "cs2": {
                "strong": 0.15,   # Per round, high frequency
                "medium": 0.10,
                "weak": 0.05
            },
            "no_arb": {
                "strong": 0.30,
                "medium": 0.20,
                "weak": 0.10
            }
        }

        fraction = limits.get(leg, {}).get(signal_strength, 0.10)
        return round(leg_bankroll * fraction, 2)

    def kelly_size(self, win_prob, entry_price, leg, fraction=0.25):
        """Calculate Kelly-sized position"""
        leg_bankroll = self.total * self.allocations[leg]
        b = (1 / entry_price - 1) * 0.98  # Net odds after 2% fee
        p = win_prob
        q = 1 - p

        if b <= 0 or p * b <= q:
            return 0  # Negative EV

        full_kelly = (p * b - q) / b
        size = leg_bankroll * full_kelly * fraction

        # Cap at max per-trade limit
        max_size = self.get_max_size(leg)
        return round(min(size, max_size), 2)

    def can_trade(self, leg):
        """Check if trading is allowed"""
        # Check drawdown
        if self.total < self.peak * 0.70:
            return False, "DRAWDOWN > 30% — TRADING SUSPENDED"

        # Check leg allocation
        leg_balance = self.get_leg_balance(leg)
        if leg_balance <= 0:
            return False, f"LEG {leg.upper()} BANKRUPT"

        return True, "OK"
```

## Kill Switch System

```python
KILL_SWITCHES = [
    {
        "name": "Global Drawdown",
        "trigger": "Total bankroll drops > 30% from peak",
        "action": "Stop ALL trading for 7 days",
        "auto": True,
        "check": lambda peak, current: current < peak * 0.70
    },
    {
        "name": "Win Rate Alert",
        "trigger": "Win rate drops below 50% over last 20 trades",
        "action": "Review strategy, reduce size 50%",
        "auto": False,  # Manual review required
        "check": lambda trades: sum(t["won"] for t in trades[-20:]) / 20 < 0.50
    },
    {
        "name": "CS2 Edge Death",
        "trigger": "CS2 leg win rate < 55% over 50 trades",
        "action": "Pause CS2 leg, shift capital to other legs",
        "auto": True,
        "check": lambda cs2_trades: (
            len(cs2_trades) >= 50 and
            sum(t["won"] for t in cs2_trades[-50:]) / 50 < 0.55
        )
    },
    {
        "name": "Platform Fee Change",
        "trigger": "Polymarket adds taker fee to CS2 markets",
        "action": "Stop CS2 leg immediately, recalculate EV",
        "auto": False,  # Monitor manually
        "check": None
    },
    {
        "name": "Milestone Withdrawal",
        "trigger": "Bankroll reaches $50,000",
        "action": "Withdraw 50% ($25,000) to external wallet",
        "auto": False,  # Manual execution
        "check": lambda total: total >= 50000
    },
    {
        "name": "Legal Risk",
        "trigger": "Congress passes insider trading law for prediction markets",
        "action": "Stop Insider leg immediately",
        "auto": False,
        "check": None  # News monitoring required
    }
]
```

## Risk of Ruin Calculator

```python
import math

def risk_of_ruin(win_rate, avg_win, avg_loss, bankroll, ruin_threshold=0.10):
    """
    Estimate probability of losing 90% of bankroll

    Uses simplified formula for binary bets
    """
    if win_rate <= 0 or avg_win <= 0:
        return 1.0

    edge = win_rate * avg_win - (1 - win_rate) * avg_loss
    if edge <= 0:
        return 1.0  # Negative edge = certain ruin eventually

    # Approximation for risk of ruin
    q = 1 - win_rate
    p = win_rate
    r = avg_loss / avg_win  # Loss to win ratio

    # Simplified: P(ruin) ≈ (q/p)^(bankroll/avg_loss) for fixed bets
    if q / p < 1:
        ror = (q / p) ** (bankroll / avg_loss)
    else:
        ror = 1.0

    return round(min(ror, 1.0), 4)

# Target: Risk of ruin < 5% before scaling up
# If RoR > 20% → reduce position sizes
# If RoR > 50% → stop and review

def sizing_for_ror_target(win_rate, avg_win_pct, bankroll, target_ror=0.05):
    """Find position size that gives target risk of ruin"""
    for pct in range(1, 50):
        size = bankroll * (pct / 100)
        avg_loss = size
        avg_win = size * avg_win_pct
        ror = risk_of_ruin(win_rate, avg_win, avg_loss, bankroll)
        if ror <= target_ror:
            return pct
    return 1  # 1% if nothing works
```

## Position Sizing Quick Reference

```
Signal Type          | Bankroll % | Max $ (on $300)
---------------------|-----------|----------------
Insider (Strong)     | 16%       | $48
Insider (Medium)     | 10%       | $30
Insider (Weak)       | 4%        | $12
CS2 per round        | 4%        | $12
CS2 per match        | 8%        | $24
NO Arb per position  | 4–8%      | $12–24
NegRisk per event    | 10%       | $30
New Market Snipe     | 5%        | $15
```

## Scale-Up Rules

```
NEVER scale up based on:
- 1–2 consecutive wins (luck)
- Feeling confident / FOMO
- Someone else's success story

ONLY scale up when:
- Win rate > 60% over 30+ trades ✓
- 2 consecutive profitable weeks ✓
- Drawdown < 10% from peak ✓
- All 3 legs positive EV ✓

Scale increment:
- Increase position sizes by 25% per scaling event
- Wait 2 weeks between scaling events
- Never exceed 10% of bankroll per single trade
```

## Correlation Guard

```python
def correlation_guard(open_positions, new_signal):
    """
    Prevent over-concentration in correlated bets

    Example: Don't bet on both CS2 round winner AND match winner
    if they're correlated — doubles risk without doubling edge
    """
    CORRELATED_PAIRS = [
        ("cs2_round", "cs2_match"),      # Round result affects match
        ("btc_up", "eth_up"),            # Crypto correlation
        ("trump_win", "republican_senate"),  # Political correlation
    ]

    for pos in open_positions:
        for pair in CORRELATED_PAIRS:
            if pos["type"] in pair and new_signal["type"] in pair:
                return False, f"Correlated with open position: {pos['type']}"

    return True, "No correlation detected"
```

## Emergency Protocols

```
🔴 EMERGENCY STOP (Everything halted):
  - Bankroll drops 30% in single day
  - Bot has bug causing rapid trading
  - Platform announces policy change

  Action: docker stop polymarket-bot immediately
  Recovery: Manual review, paper trade 3 days, restart

🟡 WARNING STATE (Reduced trading):
  - Win rate 50–55% over last 20 trades
  - Single leg down > 20%
  - Unusual market behavior

  Action: Reduce all position sizes 50%, alert Telegram

🟢 NORMAL OPERATION:
  - Win rate > 60%
  - Drawdown < 10% from peak
  - All edges showing positive EV
```


---

## Production Correlation Guard

```python
import numpy as np
from typing import List, Dict, Tuple

class ProductionCorrelationGuard:
    """
    Advanced correlation detection for prediction market positions.
    Prevents over-concentration in correlated bets across all strategies.
    """

    # Static correlation matrix (known relationships)
    KNOWN_CORRELATIONS = {
        # Esports
        ("cs2_round", "cs2_match"): 0.85,
        ("cs2_map", "cs2_match"): 0.70,
        ("valorant_round", "valorant_match"): 0.85,

        # Political
        ("trump_win", "republican_senate"): 0.65,
        ("biden_approval", "democrat_house"): 0.55,
        ("midterm_turnout", "democrat_house"): 0.40,

        # Crypto
        ("btc_above_X", "eth_above_Y"): 0.80,
        ("btc_above_X", "crypto_total_mcap"): 0.90,

        # Geopolitical
        ("iran_strike", "oil_above_X"): 0.60,
        ("russia_ukraine", "nato_expansion"): 0.50,

        # Cross-category
        ("fed_rate_cut", "btc_above_X"): 0.35,
        ("us_recession", "sp500_below_X"): 0.70,
    }

    def __init__(self, max_correlated_exposure_pct=0.30):
        self.max_correlated = max_correlated_exposure_pct
        self.dynamic_correlations = {}

    def check_new_position(
        self, new_signal: Dict, open_positions: List[Dict], bankroll: float
    ) -> Tuple[bool, str, float]:
        """
        Check if new position would create dangerous correlation.
        Returns: (allowed, reason, suggested_size_multiplier)
        """
        total_correlated_exposure = 0

        for pos in open_positions:
            corr = self._get_correlation(new_signal["type"], pos["type"])
            if corr > 0.30:  # Meaningful correlation threshold
                correlated_value = pos["size"] * corr
                total_correlated_exposure += correlated_value

        # Check against limit
        max_exposure = bankroll * self.max_correlated
        remaining = max_exposure - total_correlated_exposure

        if remaining <= 0:
            return False, f"Correlated exposure limit reached ({total_correlated_exposure:.0f}/{max_exposure:.0f})", 0

        # Suggest reduced size
        suggested_multiplier = min(1.0, remaining / new_signal.get("size", bankroll * 0.10))
        if suggested_multiplier < 0.25:
            return False, f"Would exceed correlated limit (multiplier: {suggested_multiplier:.2f})", suggested_multiplier

        return True, "OK", suggested_multiplier

    def _get_correlation(self, type_a: str, type_b: str) -> float:
        """Look up correlation between two position types"""
        key = tuple(sorted([type_a, type_b]))
        # Check static
        if key in self.KNOWN_CORRELATIONS:
            return self.KNOWN_CORRELATIONS[key]
        # Check dynamic (learned from data)
        if key in self.dynamic_correlations:
            return self.dynamic_correlations[key]
        # Same category default
        if type_a.split("_")[0] == type_b.split("_")[0]:
            return 0.40
        return 0.0

    def update_dynamic_correlation(self, type_a: str, type_b: str, observed_corr: float):
        """Update correlation based on observed co-movement"""
        key = tuple(sorted([type_a, type_b]))
        alpha = 0.3  # Learning rate
        current = self.dynamic_correlations.get(key, 0.0)
        self.dynamic_correlations[key] = current * (1 - alpha) + observed_corr * alpha
```

## Value at Risk (VaR) Calculator

```python
import math
from typing import List

class VaRCalculator:
    """
    Calculate Value at Risk for prediction market portfolio.
    Adapted for binary outcome markets.
    """

    @staticmethod
    def parametric_var(positions: List[Dict], confidence=0.95) -> float:
        """
        Parametric VaR assuming normal distribution of returns.

        positions: list of {size, win_prob, entry_price}
        confidence: VaR confidence level (0.95 = 95%)
        """
        z_scores = {0.90: 1.282, 0.95: 1.645, 0.99: 2.326}
        z = z_scores.get(confidence, 1.645)

        portfolio_variance = 0
        for pos in positions:
            p = pos["win_prob"]
            size = pos["size"]
            # Binary outcome variance = p * (1-p) * size^2
            pos_variance = p * (1 - p) * size ** 2
            portfolio_variance += pos_variance

        portfolio_std = math.sqrt(portfolio_variance)
        var = z * portfolio_std

        return round(var, 2)

    @staticmethod
    def historical_var(trade_history: List[float], confidence=0.95) -> float:
        """
        Historical VaR from actual trade P&L data.

        trade_history: list of daily P&L values
        """
        if len(trade_history) < 20:
            return 0  # Not enough data

        sorted_pnl = sorted(trade_history)
        index = int(len(sorted_pnl) * (1 - confidence))
        return abs(sorted_pnl[index])

    @staticmethod
    def monte_carlo_var(positions, num_sims=10000, confidence=0.95):
        """Monte Carlo VaR simulation"""
        import random

        portfolio_pnls = []
        for _ in range(num_sims):
            sim_pnl = 0
            for pos in positions:
                won = random.random() < pos["win_prob"]
                if won:
                    sim_pnl += pos["size"] * (1 / pos["entry_price"] - 1) * 0.98
                else:
                    sim_pnl -= pos["size"]
            portfolio_pnls.append(sim_pnl)

        portfolio_pnls.sort()
        index = int(num_sims * (1 - confidence))
        return abs(portfolio_pnls[index])
```

## Stress Testing

```python
class StressTest:
    """
    Stress test portfolio against extreme scenarios.
    Essential before scaling to >$10k bankroll.
    """

    SCENARIOS = {
        "black_swan_loss": {
            "description": "All positions lose simultaneously",
            "multiplier": -1.0,  # 100% loss on all positions
        },
        "platform_exit_scam": {
            "description": "Platform freezes all funds",
            "multiplier": -1.0,
            "note": "Mitigate by regular withdrawals"
        },
        "half_positions_lose": {
            "description": "50% of positions lose (bad luck streak)",
            "multiplier": -0.50,
        },
        "edge_death_gradual": {
            "description": "Win rate drops from 70% to 50% over 30 days",
            "daily_decay": 0.0067,  # ~20% reduction over 30 days
        },
        "liquidity_crisis": {
            "description": "Can't exit positions — stuck at bad prices",
            "slippage_pct": 0.20,  # 20% worse exit than expected
        },
        "api_outage_24h": {
            "description": "Can't trade for 24 hours during live event",
            "missed_trades": 50,
            "avg_profit_per_trade": 2.0,
        }
    }

    @staticmethod
    def run_stress_test(bankroll, positions, scenario_name):
        """Run a specific stress scenario"""
        scenario = StressTest.SCENARIOS[scenario_name]

        if "multiplier" in scenario:
            total_exposure = sum(p["size"] for p in positions)
            loss = total_exposure * abs(scenario["multiplier"])
            surviving_bankroll = bankroll - loss
        elif "daily_decay" in scenario:
            surviving_bankroll = bankroll
            for day in range(30):
                daily_pnl = surviving_bankroll * 0.03 * (1 - day * scenario["daily_decay"])
                surviving_bankroll += daily_pnl
            loss = bankroll - surviving_bankroll
        elif "slippage_pct" in scenario:
            total_exposure = sum(p["size"] for p in positions)
            loss = total_exposure * scenario["slippage_pct"]
            surviving_bankroll = bankroll - loss
        else:
            loss = scenario.get("missed_trades", 0) * scenario.get("avg_profit_per_trade", 0)
            surviving_bankroll = bankroll  # No loss, just missed profit

        return {
            "scenario": scenario_name,
            "description": scenario["description"],
            "estimated_loss": round(loss, 2),
            "surviving_bankroll": round(max(0, surviving_bankroll), 2),
            "ruin": surviving_bankroll <= bankroll * 0.10,
            "action_needed": surviving_bankroll < bankroll * 0.50
        }

    @staticmethod
    def run_all(bankroll, positions):
        """Run all stress scenarios"""
        results = {}
        for name in StressTest.SCENARIOS:
            results[name] = StressTest.run_stress_test(bankroll, positions, name)
        return results
```

## Multi-Platform Risk Aggregation

```python
class MultiPlatformRiskManager:
    """
    Aggregate risk across Polymarket, Kalshi, Manifold.
    Reference: multi-platform.md for API details.
    """

    def __init__(self, total_bankroll):
        self.total = total_bankroll
        self.platform_limits = {
            "polymarket": 0.60,  # Max 60% on Polymarket
            "kalshi": 0.30,     # Max 30% on Kalshi
            "manifold": 0.10,   # Max 10% on Manifold (play money, practice)
        }

    def get_platform_budget(self, platform):
        return self.total * self.platform_limits.get(platform, 0)

    def check_cross_platform_exposure(self, positions_by_platform):
        """Check for same event traded on multiple platforms"""
        events = {}
        for platform, positions in positions_by_platform.items():
            for pos in positions:
                event_key = pos.get("event_key", pos["title"][:30].lower())
                events.setdefault(event_key, []).append({
                    "platform": platform,
                    "size": pos["size"],
                    "side": pos["side"]
                })

        warnings = []
        for event, platforms in events.items():
            if len(platforms) > 1:
                total_exposure = sum(p["size"] for p in platforms)
                # Check if it's hedged (opposite sides) or concentrated (same side)
                sides = set(p["side"] for p in platforms)
                if len(sides) == 1:
                    warnings.append({
                        "event": event,
                        "type": "CONCENTRATED",
                        "total_exposure": total_exposure,
                        "platforms": [p["platform"] for p in platforms],
                        "action": "REDUCE — same direction on multiple platforms"
                    })
                else:
                    warnings.append({
                        "event": event,
                        "type": "HEDGED",
                        "total_exposure": total_exposure,
                        "platforms": [p["platform"] for p in platforms],
                        "action": "OK — cross-platform hedge (check for arb profit)"
                    })

        return warnings

    def rebalance_recommendation(self, current_allocations):
        """Suggest rebalancing across platforms"""
        recommendations = []
        for platform, limit in self.platform_limits.items():
            current = current_allocations.get(platform, 0)
            target = self.total * limit
            diff = current - target
            if abs(diff) > self.total * 0.05:  # >5% off target
                action = "WITHDRAW" if diff > 0 else "DEPOSIT"
                recommendations.append({
                    "platform": platform,
                    "current": round(current, 2),
                    "target": round(target, 2),
                    "action": f"{action} ${abs(diff):.2f}"
                })
        return recommendations
```
