# AI ENSEMBLE FORECASTING — Multi-LLM Probability Engine

## Architecture Overview

```
┌──────────────────────────────────────────┐
│           ENSEMBLE FORECASTER            │
│                                          │
│  ┌─────────┐ ┌─────────┐ ┌──────────┐  │
│  │ GPT-4o  │ │ Claude  │ │ Gemini   │  │
│  │ (40%)   │ │ (35%)   │ │ (25%)    │  │
│  └────┬────┘ └────┬────┘ └────┬─────┘  │
│       │           │           │         │
│       ▼           ▼           ▼         │
│  ┌──────────────────────────────────┐   │
│  │     AGGREGATION ENGINE           │   │
│  │  Trimmed Mean / Median / WEMA    │   │
│  └──────────────┬───────────────────┘   │
│                 ▼                        │
│  ┌──────────────────────────────────┐   │
│  │     CALIBRATION CHECK            │   │
│  │  Historical accuracy → weight    │   │
│  └──────────────┬───────────────────┘   │
│                 ▼                        │
│         FINAL PROBABILITY               │
└──────────────────────────────────────────┘
```

## Model Weights & Rationale

```python
MODEL_CONFIG = {
    "gpt-4o": {
        "weight": 0.40,
        "strengths": ["breaking news", "US politics", "crypto"],
        "weaknesses": ["overconfident on low-prob events"],
        "api": "openai",
        "cost_per_call": 0.01
    },
    "claude-sonnet": {
        "weight": 0.35,
        "strengths": ["nuanced reasoning", "calibration", "geopolitics"],
        "weaknesses": ["slightly conservative estimates"],
        "api": "anthropic",
        "cost_per_call": 0.003
    },
    "gemini-pro": {
        "weight": 0.25,
        "strengths": ["data-heavy analysis", "sports/esports"],
        "weaknesses": ["less reliable on niche markets"],
        "api": "google",
        "cost_per_call": 0.005
    }
}
```

## Prompt Template (ใช้กับทุก Model)

```python
FORECAST_PROMPT = """
You are a prediction market analyst. Estimate the probability of the following event.

EVENT: {event_title}
CURRENT MARKET PRICE: {market_price} (YES price on Polymarket)
RESOLUTION DATE: {resolution_date}
RESOLUTION CRITERIA: {resolution_criteria}

CONTEXT:
{news_context}

Instructions:
1. State your probability estimate as a decimal (0.00 to 1.00)
2. List your top 3 reasons for this estimate
3. Rate your confidence: LOW / MEDIUM / HIGH
4. Identify what would change your estimate significantly

Output format (JSON):
{{
    "probability": 0.XX,
    "confidence": "MEDIUM",
    "reasons": ["reason1", "reason2", "reason3"],
    "would_change_if": "description"
}}
"""
```

## Ensemble Forecaster Class

```python
import json
import statistics
from datetime import datetime

class EnsembleForecaster:
    def __init__(self, models=None):
        self.models = models or MODEL_CONFIG
        self.history = []  # Track accuracy over time

    async def forecast(self, event, market_price, context=""):
        """Get probability from all models and aggregate"""
        predictions = {}

        for model_name, config in self.models.items():
            prompt = FORECAST_PROMPT.format(
                event_title=event["title"],
                market_price=market_price,
                resolution_date=event.get("resolution_date", "Unknown"),
                resolution_criteria=event.get("criteria", "Standard"),
                news_context=context
            )

            response = await self._call_model(model_name, prompt)
            predictions[model_name] = self._parse_response(response)

        return self._aggregate(predictions, market_price)

    def _aggregate(self, predictions, market_price):
        """Combine predictions using multiple methods"""
        probs = []
        weights = []

        for model_name, pred in predictions.items():
            if pred and "probability" in pred:
                probs.append(pred["probability"])
                # Adjust weight by historical accuracy
                base_weight = self.models[model_name]["weight"]
                accuracy_adj = self._get_accuracy_adjustment(model_name)
                weights.append(base_weight * accuracy_adj)

        if not probs:
            return None

        # Normalize weights
        total_w = sum(weights)
        weights = [w / total_w for w in weights]

        # Method 1: Weighted Average
        weighted_avg = sum(p * w for p, w in zip(probs, weights))

        # Method 2: Trimmed Mean (remove highest and lowest if 3+ models)
        trimmed = statistics.mean(sorted(probs)[1:-1]) if len(probs) >= 3 else statistics.mean(probs)

        # Method 3: Median
        median = statistics.median(probs)

        # Final: blend of methods
        final = 0.50 * weighted_avg + 0.30 * trimmed + 0.20 * median

        # Disagreement score
        spread = max(probs) - min(probs)
        agreement = "HIGH" if spread < 0.10 else "MEDIUM" if spread < 0.20 else "LOW"

        # Edge vs market
        edge = final - market_price

        return {
            "final_probability": round(final, 4),
            "weighted_average": round(weighted_avg, 4),
            "trimmed_mean": round(trimmed, 4),
            "median": round(median, 4),
            "model_predictions": predictions,
            "agreement": agreement,
            "spread": round(spread, 4),
            "edge_vs_market": round(edge, 4),
            "edge_pct": round(edge * 100, 2),
            "tradeable": abs(edge) > 0.05 and agreement != "LOW",
            "direction": "BUY YES" if edge > 0.05 else "BUY NO" if edge < -0.05 else "NO TRADE"
        }

    def _get_accuracy_adjustment(self, model_name):
        """Adjust weight based on historical accuracy"""
        relevant = [h for h in self.history if h["model"] == model_name]
        if len(relevant) < 10:
            return 1.0  # Not enough data

        errors = [abs(h["predicted"] - h["actual"]) for h in relevant[-50:]]
        avg_error = sum(errors) / len(errors)

        # Lower error = higher multiplier
        return max(0.5, min(1.5, 1.0 - (avg_error - 0.15) * 2))

    def track_result(self, event_id, model_name, predicted, actual):
        """Record actual outcome for calibration"""
        self.history.append({
            "event_id": event_id,
            "model": model_name,
            "predicted": predicted,
            "actual": actual,
            "error": abs(predicted - actual),
            "date": datetime.now().isoformat()
        })
```

## Calibration Tracking

```python
def calibration_report(history, bins=10):
    """
    Check if models are well-calibrated:
    When model says 70%, does it happen 70% of the time?
    """
    bin_size = 1.0 / bins
    report = []

    for i in range(bins):
        low = i * bin_size
        high = (i + 1) * bin_size
        mid = (low + high) / 2

        in_bin = [h for h in history if low <= h["predicted"] < high]
        if not in_bin:
            continue

        actual_rate = sum(h["actual"] for h in in_bin) / len(in_bin)
        report.append({
            "bin": f"{low:.1f}–{high:.1f}",
            "predicted_avg": round(mid, 2),
            "actual_rate": round(actual_rate, 2),
            "calibration_error": round(abs(mid - actual_rate), 3),
            "n": len(in_bin)
        })

    return report
```

## When to Trust Ensemble vs Single Model

```
USE ENSEMBLE WHEN:
✅ High-stakes trade (>10% of bankroll)
✅ Market is in "uncertain zone" (30–70% price)
✅ Event has multiple information dimensions
✅ Models AGREE (spread < 10%)

USE SINGLE MODEL WHEN:
✅ Speed matters (CS2 live — no time for 3 API calls)
✅ Domain-specific event (sports → Gemini, politics → GPT-4o)
✅ Cost optimization (low-value trades)
✅ Models strongly DISAGREE (trust domain expert model)

NEVER TRADE WHEN:
❌ All models uncertain (spread > 20%)
❌ No recent news context available
❌ Market resolving within 1 hour (too volatile)
```

## Response Format: /forecast

```
## AI Ensemble Forecast — [Event Title]

Market Price: 0.35 (YES) | Resolution: [date]

### Model Predictions
| Model | Probability | Confidence | Key Reason |
|-------|------------|------------|------------|
| GPT-4o (40%) | 0.42 | HIGH | [reason] |
| Claude (35%) | 0.38 | MEDIUM | [reason] |
| Gemini (25%) | 0.45 | HIGH | [reason] |

### Ensemble Result
Final Probability: **0.41** (weighted avg: 0.41, trimmed: 0.42, median: 0.42)
Agreement: **HIGH** (spread: 0.07)

### Trade Signal
Edge: +6.0% vs market | Direction: **BUY YES**
Quarter Kelly: 8.2% of bankroll ($24.60 on $300)

### Caveats
[What would change this forecast]
```

## News Context Enrichment

```python
async def enrich_context(event_title, max_articles=5):
    """Gather recent news for better forecasting"""
    sources = [
        f"https://newsapi.org/v2/everything?q={event_title}&sortBy=publishedAt",
        f"https://api.twitter.com/2/tweets/search/recent?query={event_title}",
    ]

    context_parts = []

    for source_url in sources:
        try:
            articles = await fetch_news(source_url)
            for article in articles[:max_articles]:
                context_parts.append(
                    f"- [{article['source']}] {article['title']} ({article['date']})"
                )
        except Exception:
            continue

    return "\n".join(context_parts) if context_parts else "No recent news found."
```

## Cost Management

```
Per forecast (3 models):
- GPT-4o: ~$0.01
- Claude: ~$0.003
- Gemini: ~$0.005
Total: ~$0.018 per forecast

Budget strategy:
- High-value trades (>$50): Full ensemble ($0.018)
- Medium trades ($10-50): Claude only ($0.003)
- Low trades (<$10): No AI, use quant model only ($0)
- Daily budget: $1.00 (55 full ensembles)
```
