# ON-CHAIN ANALYTICS — Wallet Forensics & Cluster Analysis

## Data Architecture

```
┌─────────────────────────────────────────────┐
│           ON-CHAIN DATA PIPELINE            │
│                                             │
│  Polygon RPC ──→ Raw Transactions           │
│       ↓                                     │
│  Filter: CTF Exchange + USDC transfers      │
│       ↓                                     │
│  Wallet Profile Builder                     │
│       ↓                                     │
│  Cluster Detector (共通 funder)              │
│       ↓                                     │
│  Fund Flow Tracker                          │
│       ↓                                     │
│  Insider Signal Scorer (enhanced)           │
└─────────────────────────────────────────────┘
```

## Wallet Profiling

```python
from web3 import Web3
from datetime import datetime, timedelta
import requests

POLYGON_RPC = "https://polygon-mainnet.g.alchemy.com/v2/YOUR_KEY"
CTF_EXCHANGE = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E"

class OnChainAnalyzer:
    def __init__(self, rpc_url=POLYGON_RPC):
        self.w3 = Web3(Web3.HTTPProvider(rpc_url))

    def wallet_profile(self, address):
        """Build comprehensive wallet profile"""
        address = Web3.to_checksum_address(address)

        # Basic info
        balance_wei = self.w3.eth.get_balance(address)
        balance_matic = balance_wei / 1e18
        tx_count = self.w3.eth.get_transaction_count(address)

        # Estimate wallet age
        first_tx = self._get_first_transaction(address)
        age_days = (datetime.now() - first_tx).days if first_tx else 0

        # USDC balance
        usdc_balance = self._get_usdc_balance(address)

        # Trading history on Polymarket
        trades = self._get_polymarket_trades(address)

        return {
            "address": address,
            "balance_matic": round(balance_matic, 4),
            "usdc_balance": round(usdc_balance, 2),
            "tx_count": tx_count,
            "age_days": age_days,
            "total_trades": len(trades),
            "unique_markets": len(set(t["market"] for t in trades)),
            "total_volume": sum(t["size"] for t in trades),
            "win_rate": self._calculate_win_rate(trades),
            "avg_trade_size": sum(t["size"] for t in trades) / max(len(trades), 1),
            "risk_flags": self._check_risk_flags(address, age_days, trades),
            "classification": self._classify_wallet(age_days, trades)
        }

    def _classify_wallet(self, age_days, trades):
        """Classify wallet type"""
        if age_days < 7 and len(trades) <= 3:
            return "FRESH_SUSPICIOUS"  # Possible insider
        elif len(trades) > 500:
            return "BOT"  # Automated trader
        elif len(trades) > 50 and self._calculate_win_rate(trades) > 0.65:
            return "SMART_MONEY"  # Profitable trader
        elif age_days > 180:
            return "VETERAN"  # Long-term user
        else:
            return "RETAIL"  # Regular trader

    def _check_risk_flags(self, address, age_days, trades):
        """Flag suspicious patterns"""
        flags = []

        if age_days < 7:
            flags.append("FRESH_WALLET")

        unique_markets = len(set(t["market"] for t in trades))
        if unique_markets <= 2 and len(trades) > 0:
            flags.append("SINGLE_MARKET_FOCUS")

        total_volume = sum(t["size"] for t in trades)
        if total_volume > 1000 and age_days < 3:
            flags.append("HIGH_VOLUME_NEW_WALLET")

        if len(trades) > 100 and age_days < 7:
            flags.append("BOT_PATTERN")

        return flags
```

## Cluster Analysis (เปิดโปงกลุ่ม Insider)

```python
class ClusterDetector:
    """Detect coordinated wallets (same funder = same person/group)"""

    def __init__(self, analyzer):
        self.analyzer = analyzer

    def detect_clusters(self, wallets, market_id=None):
        """
        Find groups of wallets that:
        1. Were funded by the same source
        2. Traded the same market within a short time window
        3. Have similar behavior patterns
        """
        clusters = []
        funding_map = {}  # funder → [funded wallets]

        for wallet in wallets:
            funder = self._trace_funding_source(wallet)
            if funder:
                funding_map.setdefault(funder, []).append(wallet)

        # Filter: clusters of 2+ wallets from same funder
        for funder, funded_wallets in funding_map.items():
            if len(funded_wallets) >= 2:
                cluster = {
                    "funder": funder,
                    "wallets": funded_wallets,
                    "count": len(funded_wallets),
                    "total_volume": sum(
                        self._get_wallet_volume(w, market_id) for w in funded_wallets
                    ),
                    "timing": self._analyze_timing(funded_wallets, market_id),
                    "insider_score": self._score_cluster(funded_wallets, market_id)
                }
                clusters.append(cluster)

        return sorted(clusters, key=lambda c: c["insider_score"], reverse=True)

    def _trace_funding_source(self, wallet):
        """Find the wallet that first funded this address"""
        # Look at first incoming USDC/MATIC transfer
        # This is typically the "parent" wallet
        transfers = self.analyzer._get_incoming_transfers(wallet, limit=5)
        if transfers:
            return transfers[0]["from"]  # First funder
        return None

    def _analyze_timing(self, wallets, market_id):
        """Check if wallets traded within a short time window"""
        trade_times = []
        for w in wallets:
            trades = self.analyzer._get_polymarket_trades(w)
            if market_id:
                trades = [t for t in trades if t["market"] == market_id]
            for t in trades:
                trade_times.append(t["timestamp"])

        if len(trade_times) < 2:
            return {"window_minutes": None, "coordinated": False}

        trade_times.sort()
        window = (trade_times[-1] - trade_times[0]).total_seconds() / 60

        return {
            "window_minutes": round(window, 1),
            "coordinated": window < 120,  # All trades within 2 hours
            "first_trade": trade_times[0].isoformat(),
            "last_trade": trade_times[-1].isoformat()
        }

    def _score_cluster(self, wallets, market_id):
        """Score how likely this cluster represents insider activity"""
        score = 0

        # Fresh wallets (all < 7 days old)
        ages = [self.analyzer.wallet_profile(w)["age_days"] for w in wallets[:5]]
        if all(a < 7 for a in ages):
            score += 3

        # Coordinated timing
        timing = self._analyze_timing(wallets, market_id)
        if timing["coordinated"]:
            score += 2

        # Large total volume
        total_vol = sum(self.analyzer._get_wallet_volume(w, market_id) for w in wallets)
        if total_vol > 5000:
            score += 2
        if total_vol > 50000:
            score += 1

        # Single market focus
        for w in wallets[:5]:
            profile = self.analyzer.wallet_profile(w)
            if profile["unique_markets"] <= 2:
                score += 0.5

        return min(10, round(score, 1))
```

## Fund Flow Tracking

```python
def trace_fund_flow(address, depth=3):
    """
    Trace money path: Exchange → Bridge → Wallet → Polymarket

    Common insider pattern:
    Centralized Exchange (Binance/Coinbase)
    → Polygon Bridge
    → Fresh Wallet
    → USDC deposit to Polymarket
    → Large bet on single market
    """
    flow = []

    current = address
    for level in range(depth):
        incoming = get_incoming_transfers(current, limit=3)
        if not incoming:
            break

        source = incoming[0]
        flow.append({
            "level": level,
            "from": source["from"],
            "to": current,
            "amount": source["amount"],
            "token": source["token"],
            "timestamp": source["timestamp"],
            "source_type": classify_address(source["from"])
        })

        current = source["from"]

    return flow

def classify_address(address):
    """Classify an address as exchange, bridge, contract, or EOA"""
    KNOWN_ADDRESSES = {
        "0x...binance": "EXCHANGE_BINANCE",
        "0x...coinbase": "EXCHANGE_COINBASE",
        "0x...bridge": "POLYGON_BRIDGE",
        "0x...ctf": "POLYMARKET_CTF",
    }

    if address in KNOWN_ADDRESSES:
        return KNOWN_ADDRESSES[address]

    # Check if contract
    code = w3.eth.get_code(address)
    if code and code != b'':
        return "CONTRACT"

    return "EOA"  # Externally Owned Account (person)
```

## Enhanced Insider Signal (เสริมจาก Module 3 เดิม)

```python
def enhanced_insider_score(wallet, market, cluster_data):
    """
    Enhanced scoring ที่รวม on-chain data เข้าด้วย

    เดิม: 5 criteria (age, focus, size, price, cluster)
    ใหม่: + fund flow + timing pattern + historical accuracy
    """
    score = 0
    details = []

    # Original criteria
    profile = wallet_profile(wallet)

    if profile["age_days"] < 7:
        score += 1; details.append(f"Fresh: {profile['age_days']}d")
    if profile["unique_markets"] <= 2:
        score += 1; details.append("Single market focus")
    if market["size_usd"] >= 500:
        score += 1; details.append(f"Large: ${market['size_usd']:,.0f}")
    if market["entry_price"] <= 0.25:
        score += 1; details.append(f"Low entry: {market['entry_price']}")

    # NEW: Cluster analysis
    if cluster_data and cluster_data["count"] >= 2:
        score += 1; details.append(f"Cluster: {cluster_data['count']} wallets")
    if cluster_data and cluster_data["count"] >= 5:
        score += 1; details.append(f"Large cluster: {cluster_data['count']}")

    # NEW: Fund flow analysis
    flow = trace_fund_flow(wallet)
    if flow and flow[-1].get("source_type", "").startswith("EXCHANGE"):
        score += 1; details.append("Funded from exchange (fresh)")

    # NEW: Timing relative to event
    hours_to_event = market.get("hours_to_resolution", 999)
    if hours_to_event < 48:
        score += 1; details.append(f"Close to event: {hours_to_event}h")

    return {
        "score": min(10, score),
        "max_score": 10,
        "details": details,
        "confidence": "VERY HIGH" if score >= 7 else "HIGH" if score >= 5 else "MEDIUM" if score >= 3 else "LOW"
    }
```

## Response Format: /onchain [wallet]

```
## On-Chain Analysis — 0x1234...5678

### Wallet Profile
- Age: 3 days | Tx count: 12 | Classification: FRESH_SUSPICIOUS
- USDC balance: $4,200 | MATIC: 2.5
- Trades: 4 total | 2 markets | Volume: $8,500
- Win rate: N/A (no resolutions yet)

### Risk Flags
🔴 FRESH_WALLET (3 days old)
🔴 HIGH_VOLUME_NEW_WALLET ($8,500 in 3 days)
🟡 SINGLE_MARKET_FOCUS (2 markets only)

### Fund Flow
Binance → Polygon Bridge → 0x1234...5678 → Polymarket CTF
Timeline: All within 6 hours

### Cluster Analysis
Found 4 wallets funded by same source (0xABCD...)
Total cluster volume: $34,000 on "Will X happen?"
Coordinated: YES (all traded within 45 minutes)

### Insider Score: 8/10 (VERY HIGH)
→ RECOMMEND: Copy with 25% of Leg A bankroll
```
