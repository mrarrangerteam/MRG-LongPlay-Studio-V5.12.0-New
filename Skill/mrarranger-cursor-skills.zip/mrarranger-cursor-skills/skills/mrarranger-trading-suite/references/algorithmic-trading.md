# ALGORITHMIC TRADING — Polymarket Bot System

## Bot Architecture (5 Layers)

```
Layer 1: DATA FEED
├── Polymarket WebSocket (ws://clob.polymarket.com/ws)
├── Binance WebSocket (crypto price feed)
├── PandaScore REST/WS (CS2/esports live data)
└── Polygon RPC (on-chain wallet monitoring)

Layer 2: SIGNAL ENGINE
├── NegRisk Scanner (sum < $0.97)
├── Insider Detector (fresh wallet + large bet)
├── CS2 Parser (stream delay arbitrage)
└── NO Arb Screener (sensational markets)

Layer 3: DECISION ENGINE
├── Kelly Calculator (position sizing)
├── EV Filter (only trade if EV > 0)
├── Correlation Guard (don't double exposure)
└── Edge Validator (verify signal strength)

Layer 4: EXECUTION
├── CLOB Order Placement (py-clob-client)
├── Retry Logic (3 attempts, exponential backoff)
├── Slippage Guard (cancel if price moved > 5%)
└── Gas Management (Polygon MATIC buffer)

Layer 5: MONITORING
├── Telegram Alerts (real-time)
├── SQLite Trade Log (all trades)
├── Performance Dashboard (win rate, PnL)
└── Kill Switch (auto-stop on drawdown)
```

## Tech Stack

```yaml
Language: Python 3.11+
Core libs:
  - py-clob-client: Polymarket CLOB API
  - web3: Polygon blockchain interaction
  - websockets: Real-time data streaming
  - aiohttp: Async HTTP requests
  - sqlite3: Trade logging
  - python-telegram-bot: Alerts

Infrastructure:
  - Hetzner CX22: €3.79/month (Amsterdam)
  - Docker: containerization
  - systemd: auto-restart on crash

APIs:
  - Polymarket CLOB: clob.polymarket.com
  - Polymarket Gamma: gamma-api.polymarket.com
  - PandaScore: api.pandascore.co (CS2/esports)
  - Polygon RPC: via Alchemy (free tier)
```

## Project Structure

```
polymarket-bot/
├── config.py           # API keys, constants
├── main.py             # Entry point
├── data/
│   ├── clob_feed.py    # WebSocket price stream
│   ├── gamma_feed.py   # Market metadata
│   ├── cs2_feed.py     # PandaScore esports
│   └── chain_feed.py   # Polygon wallet monitor
├── signals/
│   ├── negrisk.py      # NegRisk arbitrage
│   ├── insider.py      # Wallet pattern detection
│   ├── cs2_parser.py   # Stream delay arb
│   └── no_arb.py       # Sensational market screen
├── engine/
│   ├── kelly.py        # Position sizing
│   ├── ev_calc.py      # Expected value
│   └── risk_guard.py   # Risk limits
├── execution/
│   ├── executor.py     # Order placement
│   └── order_mgr.py    # Track open positions
├── monitoring/
│   ├── telegram.py     # Alert system
│   ├── logger.py       # Trade database
│   └── dashboard.py    # Performance metrics
└── tests/
    └── paper_trade.py  # Paper trading mode
```

## Core Bot Loop

```python
import asyncio
from signals import negrisk, insider, cs2_parser, no_arb
from engine import kelly, risk_guard
from execution import executor
from monitoring import telegram, logger

PAPER_MODE = True  # Set False when ready for live

async def main_loop():
    """Main trading loop — runs all strategies concurrently"""

    print("🚀 Bot starting...")
    await telegram.send("🟢 Bot Online | Paper Mode: " + str(PAPER_MODE))

    while True:
        try:
            # Run all signal scanners concurrently
            signals = await asyncio.gather(
                negrisk.scan(),
                insider.scan(),
                cs2_parser.scan(),
                no_arb.scan(),
                return_exceptions=True
            )

            for signal_list in signals:
                if isinstance(signal_list, Exception):
                    continue
                for signal in (signal_list or []):
                    await process_signal(signal)

            await asyncio.sleep(30)  # Scan every 30 seconds

        except Exception as e:
            await telegram.send(f"⚠️ Bot error: {e}")
            await asyncio.sleep(60)

async def process_signal(signal):
    """Validate and execute a trading signal"""

    # 1. Check risk limits
    if not risk_guard.can_trade(signal):
        return

    # 2. Calculate position size
    size = kelly.calculate(
        bankroll=risk_guard.get_bankroll(),
        win_prob=signal["estimated_prob"],
        entry_price=signal["price"],
        fraction=0.25  # Quarter Kelly
    )

    if size < 1.0:  # Min $1 trade
        return

    # 3. Execute or paper log
    if PAPER_MODE:
        logger.log_paper(signal, size)
        await telegram.send_signal(signal, size, paper=True)
    else:
        result = await executor.place_order(signal, size)
        logger.log_trade(signal, size, result)
        await telegram.send_signal(signal, size, result=result)

if __name__ == "__main__":
    asyncio.run(main_loop())
```

## Deployment (Hetzner VPS)

```bash
# 1. Setup VPS
ssh root@your-vps-ip
apt update && apt install -y python3.11 python3-pip docker.io

# 2. Clone and configure
git clone your-repo
cd polymarket-bot
cp config.example.py config.py
# Edit config.py with your API keys

# 3. Run with Docker
docker build -t polymarket-bot .
docker run -d --name bot --restart=always polymarket-bot

# 4. Monitor
docker logs -f bot

# 5. systemd alternative (no Docker)
cat > /etc/systemd/system/polymarket-bot.service << EOF
[Unit]
Description=Polymarket Trading Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/polymarket-bot
ExecStart=/usr/bin/python3 main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl enable polymarket-bot
systemctl start polymarket-bot
```

## Paper Trading Mode

```
ก่อน live trading ต้องผ่านทั้งหมดนี้:

Gate 1: 3 วัน paper trade ผ่าน
Gate 2: Win rate > 55% ใน 20+ trades
Gate 3: EV positive (avg win > avg loss)
Gate 4: Max simulated drawdown < 20%
Gate 5: Bot ไม่ crash ใน 24h

ถ้าผ่านหมด → เปิด PAPER_MODE = False
เริ่มด้วยทุน 20% ของ budget จริง
Scale up ทีละ 20% ทุก 3 วัน ถ้า win rate ยังดี
```

## Rate Limits & Constraints

```
Polymarket CLOB:
- Public endpoints: 60 req/min
- Authenticated: Higher limit
- WebSocket: No limit (recommended)

Polymarket Gamma:
- 100 req/min
- Use caching (TTL 60s for market data)

PandaScore:
- Free tier: 1,000 req/hour
- Use for match data, cache aggressively

Polygon RPC (Alchemy free):
- 300M compute units/month
- Use WebSocket for wallet monitoring
```


---

## Multi-Strategy Concurrent Execution

```python
import asyncio
from typing import Dict, Any

class StrategyOrchestrator:
    """Run multiple strategies concurrently with resource management"""

    def __init__(self, bankroll_manager, executor):
        self.strategies: Dict[str, Any] = {}
        self.bankroll = bankroll_manager
        self.executor = executor
        self.active = True

    def register_strategy(self, name, strategy, allocation_pct):
        """Register a strategy with its bankroll allocation"""
        self.strategies[name] = {
            "instance": strategy,
            "allocation": allocation_pct,
            "enabled": True,
            "stats": {"trades": 0, "wins": 0, "pnl": 0}
        }

    async def run_all(self):
        """Run all registered strategies concurrently"""
        tasks = []
        for name, config in self.strategies.items():
            if config["enabled"]:
                task = asyncio.create_task(
                    self._run_strategy(name, config),
                    name=f"strategy-{name}"
                )
                tasks.append(task)

        await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_strategy(self, name, config):
        """Run single strategy with error isolation"""
        strategy = config["instance"]
        while self.active:
            try:
                signals = await strategy.scan()
                for signal in (signals or []):
                    signal["strategy"] = name
                    await self._process_with_limits(name, signal)
                await asyncio.sleep(strategy.scan_interval)
            except Exception as e:
                print(f"[{name}] Error: {e}")
                await asyncio.sleep(60)

    async def _process_with_limits(self, strategy_name, signal):
        """Apply cross-strategy risk limits before execution"""
        config = self.strategies[strategy_name]

        # Check strategy-specific allocation
        leg_bankroll = self.bankroll.total * config["allocation"]
        current_exposure = self.bankroll.get_leg_exposure(strategy_name)

        if current_exposure >= leg_bankroll * 0.80:
            return  # 80% of leg allocation used

        # Check global limits
        can_trade, reason = self.bankroll.can_trade(strategy_name)
        if not can_trade:
            return

        # Execute
        result = await self.executor.execute(signal)
        config["stats"]["trades"] += 1
        if result.get("won"):
            config["stats"]["wins"] += 1
        config["stats"]["pnl"] += result.get("profit", 0)

    def hot_swap(self, old_name, new_name, new_strategy, allocation):
        """Replace a strategy without stopping others"""
        if old_name in self.strategies:
            self.strategies[old_name]["enabled"] = False
        self.register_strategy(new_name, new_strategy, allocation)

    def get_dashboard(self):
        """Get real-time strategy performance"""
        return {
            name: {
                "enabled": config["enabled"],
                "trades": config["stats"]["trades"],
                "win_rate": (
                    config["stats"]["wins"] / max(config["stats"]["trades"], 1) * 100
                ),
                "pnl": round(config["stats"]["pnl"], 2),
                "allocation": f"{config['allocation']*100:.0f}%"
            }
            for name, config in self.strategies.items()
        }
```

## Strategy Hot-Swap Mechanism

```python
class StrategySwapper:
    """Hot-swap strategies based on performance or edge decay"""

    def __init__(self, orchestrator, min_trades=20):
        self.orch = orchestrator
        self.min_trades = min_trades

    async def evaluate_and_swap(self):
        """Check if any strategy should be swapped"""
        for name, config in self.orch.strategies.items():
            stats = config["stats"]
            if stats["trades"] < self.min_trades:
                continue

            win_rate = stats["wins"] / stats["trades"]

            # Edge death detection
            if win_rate < 0.50:
                await self._handle_edge_death(name, win_rate)
            elif win_rate < 0.55:
                await self._handle_edge_decay(name, win_rate)

    async def _handle_edge_death(self, name, win_rate):
        """Strategy win rate below 50% — likely edge is dead"""
        print(f"⚠️ Edge death detected: {name} (win rate: {win_rate:.1%})")

        FALLBACK_MAP = {
            "cs2": "valorant",      # CS2 → Valorant
            "insider": "no_arb",    # Insider → NO Arb (if legal risk)
            "valorant": "fifa",     # Valorant → FIFA
        }

        fallback = FALLBACK_MAP.get(name)
        if fallback:
            # Import and initialize fallback strategy
            from strategies import STRATEGY_REGISTRY
            new_strategy = STRATEGY_REGISTRY[fallback]()
            old_alloc = self.orch.strategies[name]["allocation"]
            self.orch.hot_swap(name, fallback, new_strategy, old_alloc)

    async def _handle_edge_decay(self, name, win_rate):
        """Strategy between 50-55% — reduce allocation"""
        current_alloc = self.orch.strategies[name]["allocation"]
        new_alloc = current_alloc * 0.50  # Cut in half
        self.orch.strategies[name]["allocation"] = new_alloc
        print(f"📉 Edge decay: {name} allocation reduced to {new_alloc:.0%}")
```

## Health Monitoring Integration

```python
import time
import json
from pathlib import Path

class BotHealthMonitor:
    """Production health monitoring for the trading bot"""

    def __init__(self, heartbeat_path="data/heartbeat.json"):
        self.heartbeat_path = Path(heartbeat_path)
        self.start_time = time.time()
        self.errors = []
        self.metrics = {
            "orders_placed": 0,
            "orders_failed": 0,
            "api_calls": 0,
            "ws_reconnects": 0
        }

    def heartbeat(self):
        """Write heartbeat — called every 60s by main loop"""
        data = {
            "timestamp": time.time(),
            "uptime_hours": round((time.time() - self.start_time) / 3600, 2),
            "metrics": self.metrics,
            "recent_errors": self.errors[-5:],
            "status": "healthy" if not self.errors else "degraded"
        }
        self.heartbeat_path.write_text(json.dumps(data))

    def record_error(self, component, message):
        self.errors.append({
            "time": time.time(),
            "component": component,
            "message": str(message)[:200]
        })
        # Keep only last 100 errors
        self.errors = self.errors[-100:]

    def record_metric(self, name, increment=1):
        if name in self.metrics:
            self.metrics[name] += increment

    def get_status(self):
        """Get current bot status for dashboard"""
        uptime = time.time() - self.start_time
        return {
            "status": "healthy" if len(self.errors) < 5 else "degraded",
            "uptime": f"{uptime/3600:.1f}h",
            "orders_placed": self.metrics["orders_placed"],
            "error_rate": (
                self.metrics["orders_failed"] /
                max(self.metrics["orders_placed"], 1) * 100
            ),
            "ws_reconnects": self.metrics["ws_reconnects"]
        }
```

## Advanced Order Management

```python
from enum import Enum
from dataclasses import dataclass
from typing import Optional
import asyncio

class OrderStatus(Enum):
    PENDING = "pending"
    OPEN = "open"
    PARTIAL = "partial"
    FILLED = "filled"
    CANCELLED = "cancelled"
    FAILED = "failed"

@dataclass
class ManagedOrder:
    order_id: str
    market_id: str
    strategy: str
    side: str
    price: float
    size: float
    status: OrderStatus = OrderStatus.PENDING
    filled_size: float = 0
    avg_fill_price: float = 0
    created_at: float = 0
    ttl_seconds: int = 300  # Auto-cancel after 5 min

class OrderManager:
    """Track and manage all open orders across strategies"""

    def __init__(self, clob_client, telegram):
        self.client = clob_client
        self.telegram = telegram
        self.orders: dict = {}

    async def submit(self, order: ManagedOrder) -> str:
        """Submit order with retry logic"""
        for attempt in range(3):
            try:
                result = await self.client.place_limit_order(
                    token_id=order.market_id,
                    side=order.side,
                    price=order.price,
                    size=order.size
                )
                order.order_id = result["orderID"]
                order.status = OrderStatus.OPEN
                order.created_at = asyncio.get_event_loop().time()
                self.orders[order.order_id] = order
                return order.order_id
            except Exception as e:
                if attempt == 2:
                    order.status = OrderStatus.FAILED
                    raise
                await asyncio.sleep(2 ** attempt)

    async def monitor_orders(self):
        """Background task: monitor fills, handle TTL expiry"""
        while True:
            now = asyncio.get_event_loop().time()
            for oid, order in list(self.orders.items()):
                if order.status == OrderStatus.OPEN:
                    # Check TTL
                    if now - order.created_at > order.ttl_seconds:
                        await self.cancel(oid)
                        await self.telegram.send(
                            f"⏰ Order expired: {order.strategy} {order.side} @ {order.price}"
                        )
            await asyncio.sleep(10)

    async def cancel(self, order_id):
        """Cancel an open order"""
        try:
            await self.client.cancel_order(order_id)
            if order_id in self.orders:
                self.orders[order_id].status = OrderStatus.CANCELLED
        except Exception:
            pass

    async def cancel_all_strategy(self, strategy_name):
        """Cancel all orders for a specific strategy (used by kill switch)"""
        for oid, order in self.orders.items():
            if order.strategy == strategy_name and order.status == OrderStatus.OPEN:
                await self.cancel(oid)

    def get_open_exposure(self, strategy=None):
        """Get total open order exposure"""
        return sum(
            o.size for o in self.orders.values()
            if o.status in (OrderStatus.OPEN, OrderStatus.PARTIAL)
            and (strategy is None or o.strategy == strategy)
        )
```

## Production Main Entry Point

```python
#!/usr/bin/env python3
"""
Polymarket Trading Bot — Production Entry Point
Runs all strategies concurrently with full monitoring
"""

import asyncio
import signal
import sys

from config import Config
from engine.orchestrator import StrategyOrchestrator
from engine.risk_guard import BankrollManager
from execution.executor import Executor
from execution.order_mgr import OrderManager
from monitoring.health import BotHealthMonitor
from monitoring.telegram import TelegramBot
from monitoring.logger import TradeLogger
from strategies.insider import InsiderStrategy
from strategies.cs2 import CS2Strategy
from strategies.negrisk import NegRiskStrategy
from strategies.no_arb import NoArbStrategy

async def main():
    config = Config.load()

    # Initialize core components
    bankroll = BankrollManager(config.starting_bankroll)
    telegram = TelegramBot(config.telegram_token, config.telegram_chat_id)
    logger = TradeLogger("data/trades.db")
    health = BotHealthMonitor()
    executor = Executor(config, logger, telegram)
    order_mgr = OrderManager(executor.clob_client, telegram)

    # Initialize orchestrator
    orch = StrategyOrchestrator(bankroll, executor)

    # Register strategies
    orch.register_strategy("insider", InsiderStrategy(config), 0.40)
    orch.register_strategy("cs2", CS2Strategy(config), 0.30)
    orch.register_strategy("negrisk", NegRiskStrategy(config), 0.15)
    orch.register_strategy("no_arb", NoArbStrategy(config), 0.15)

    # Graceful shutdown handler
    def shutdown(sig, frame):
        print("\\n🛑 Shutting down gracefully...")
        orch.active = False
        asyncio.get_event_loop().call_soon_threadsafe(
            asyncio.get_event_loop().stop
        )

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # Start
    await telegram.send("🟢 Bot Online | Mode: " + ("PAPER" if config.paper_mode else "LIVE"))

    await asyncio.gather(
        orch.run_all(),
        order_mgr.monitor_orders(),
        health_loop(health),
        return_exceptions=True
    )

async def health_loop(health):
    while True:
        health.heartbeat()
        await asyncio.sleep(60)

if __name__ == "__main__":
    asyncio.run(main())
```
