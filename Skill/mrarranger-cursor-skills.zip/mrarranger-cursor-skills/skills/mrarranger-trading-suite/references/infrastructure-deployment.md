# INFRASTRUCTURE & DEPLOYMENT — Production Trading Bot

## Infrastructure Stack

```
┌─────────────────────────────────────────┐
│          PRODUCTION STACK               │
│                                         │
│  Hetzner VPS (CX22, €3.79/mo)         │
│  ├── Docker + docker-compose           │
│  ├── Trading Bot Container             │
│  ├── SQLite Database (trades.db)       │
│  ├── Prometheus (metrics)              │
│  ├── Grafana (dashboard)               │
│  ├── Nginx (reverse proxy)             │
│  └── Telegram Bot (alerts)             │
│                                         │
│  GitHub Actions (CI/CD)                │
│  ├── Lint + Test on push               │
│  └── Auto-deploy to VPS                │
└─────────────────────────────────────────┘
```

## Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# System deps
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc libffi-dev && rm -rf /var/lib/apt/lists/*

# Python deps
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# App code
COPY . .

# Environment
ENV PYTHONUNBUFFERED=1
ENV TZ=UTC

# Health check
HEALTHCHECK --interval=60s --timeout=10s --retries=3 \
    CMD python health_check.py || exit 1

CMD ["python", "main.py"]
```

## docker-compose.yml

```yaml
version: "3.8"

services:
  bot:
    build: .
    container_name: polymarket-bot
    restart: always
    env_file: .env
    volumes:
      - ./data:/app/data        # Persist trade database
      - ./logs:/app/logs        # Persist logs
    logging:
      driver: json-file
      options:
        max-size: "10m"
        max-file: "3"

  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD}
    volumes:
      - grafana-data:/var/lib/grafana

volumes:
  grafana-data:
```

## VPS Setup Script

```bash
#!/bin/bash
# deploy.sh — Setup Hetzner VPS from scratch

set -e

echo "=== Polymarket Bot VPS Setup ==="

# 1. System updates
apt update && apt upgrade -y
apt install -y docker.io docker-compose git ufw

# 2. Firewall
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp    # SSH
ufw allow 3000/tcp  # Grafana (optional)
ufw --force enable

# 3. Create bot user
useradd -m -s /bin/bash botuser
usermod -aG docker botuser

# 4. Clone and setup
su - botuser << 'EOF'
git clone https://github.com/YOUR_REPO/polymarket-bot.git
cd polymarket-bot
cp .env.example .env
echo "Edit .env with your API keys!"
EOF

# 5. Start
cd /home/botuser/polymarket-bot
docker-compose up -d

echo "=== Setup Complete ==="
echo "Bot running. Check: docker-compose logs -f"
```

## systemd Service (Alternative to Docker)

```ini
# /etc/systemd/system/polymarket-bot.service
[Unit]
Description=Polymarket Trading Bot
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/home/botuser/polymarket-bot
ExecStart=/usr/bin/python3 main.py
Restart=always
RestartSec=30
StartLimitBurst=5
StartLimitIntervalSec=300

# Environment
EnvironmentFile=/home/botuser/polymarket-bot/.env

# Logging
StandardOutput=append:/home/botuser/polymarket-bot/logs/bot.log
StandardError=append:/home/botuser/polymarket-bot/logs/bot-error.log

[Install]
WantedBy=multi-user.target
```

## Health Monitoring

```python
# health_check.py
import sys
import json
import time
from pathlib import Path

def check_health():
    """Bot health check — used by Docker HEALTHCHECK"""
    checks = {}

    # 1. Heartbeat file (bot writes every 60s)
    heartbeat_file = Path("data/heartbeat.json")
    if heartbeat_file.exists():
        data = json.loads(heartbeat_file.read_text())
        age = time.time() - data.get("timestamp", 0)
        checks["heartbeat"] = age < 120  # Max 2 min old
    else:
        checks["heartbeat"] = False

    # 2. Trade database accessible
    try:
        import sqlite3
        conn = sqlite3.connect("data/trades.db")
        conn.execute("SELECT 1")
        conn.close()
        checks["database"] = True
    except Exception:
        checks["database"] = False

    # 3. API connectivity
    try:
        import requests
        r = requests.get("https://gamma-api.polymarket.com/events?limit=1", timeout=5)
        checks["api"] = r.status_code == 200
    except Exception:
        checks["api"] = False

    # Result
    all_healthy = all(checks.values())
    print(json.dumps({"healthy": all_healthy, "checks": checks}))

    sys.exit(0 if all_healthy else 1)

if __name__ == "__main__":
    check_health()
```

## Structured Logging

```python
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "module": record.module,
            "message": record.getMessage(),
        }
        if hasattr(record, "trade"):
            log_entry["trade"] = record.trade
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)

def setup_logging():
    logger = logging.getLogger("bot")
    logger.setLevel(logging.INFO)

    # File handler (JSON)
    fh = logging.FileHandler("logs/bot.jsonl")
    fh.setFormatter(JSONFormatter())
    logger.addHandler(fh)

    # Console handler (readable)
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s"
    ))
    logger.addHandler(ch)

    return logger
```

## CI/CD Pipeline (GitHub Actions)

```yaml
# .github/workflows/deploy.yml
name: Deploy Trading Bot

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install -r requirements.txt
      - run: python -m pytest tests/ -v

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to VPS
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.VPS_HOST }}
          username: botuser
          key: ${{ secrets.VPS_SSH_KEY }}
          script: |
            cd polymarket-bot
            git pull origin main
            docker-compose build
            docker-compose up -d
            docker-compose logs --tail=20
```

## Security: .env Management

```bash
# .env (NEVER commit to git)
POLYMARKET_API_KEY=your_api_key
POLYMARKET_API_SECRET=your_api_secret
POLYMARKET_PRIVATE_KEY=your_wallet_private_key
TELEGRAM_BOT_TOKEN=your_telegram_token
TELEGRAM_CHAT_ID=your_chat_id
ALCHEMY_API_KEY=your_alchemy_key
PANDASCORE_API_KEY=your_pandascore_key
GRAFANA_PASSWORD=secure_password_here

# .env.example (commit this instead)
POLYMARKET_API_KEY=
POLYMARKET_API_SECRET=
POLYMARKET_PRIVATE_KEY=
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
ALCHEMY_API_KEY=
PANDASCORE_API_KEY=
GRAFANA_PASSWORD=
```

## Backup Strategy

```bash
#!/bin/bash
# backup.sh — Run daily via cron
BACKUP_DIR="/home/botuser/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup trade database
cp data/trades.db "$BACKUP_DIR/trades_$DATE.db"

# Backup configs
tar czf "$BACKUP_DIR/config_$DATE.tar.gz" .env prometheus.yml docker-compose.yml

# Keep only last 30 days
find $BACKUP_DIR -mtime +30 -delete

echo "Backup complete: $DATE"
```
