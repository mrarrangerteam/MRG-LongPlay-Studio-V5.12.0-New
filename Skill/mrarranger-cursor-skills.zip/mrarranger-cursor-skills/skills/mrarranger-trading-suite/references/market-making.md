# MARKET MAKING — Polymarket Spread Capture

## Market Making คืออะไร

```
Market Maker = ผู้ให้สภาพคล่อง (Liquidity Provider)
วาง order ทั้งฝั่ง BID (ซื้อ) และ ASK (ขาย) พร้อมกัน
กำไร = spread ระหว่าง bid-ask

ตัวอย่าง:
BID: ซื้อ YES @ $0.48
ASK: ขาย YES @ $0.52
Spread: $0.04 per round-trip

ถ้า volume $100k/day, capture 10% flow:
Daily revenue ≈ $100k × 10% × $0.04 = $400/day
```

## Polymarket Spread Data (2026)

```
Average spreads by market type:
- High volume (>$1M): 1-2¢ spread (tight, competitive)
- Medium volume ($100k-$1M): 2-5¢ spread (sweet spot)
- Low volume (<$100k): 5-15¢ spread (wide, but low fill rate)

Maker rebate: Polymarket offers 0% fee for makers (limit orders)
Taker fee: 2% on winnings for takers (market orders)

Revenue target:
- 10 markets × $0.02 spread × $5k daily capture = $1,000/day
- After inventory risk: realistic $200-400/day with $10k bankroll
```

## Core Architecture

```python
import asyncio
from dataclasses import dataclass

@dataclass
class Quote:
    market_id: str
    side: str  # "BUY" or "SELL"
    price: float
    size: float
    order_id: str = None

class MarketMaker:
    def __init__(self, clob_client, config):
        self.clob = clob_client
        self.config = config
        self.inventory = {}  # market_id → net position
        self.active_orders = {}  # order_id → Quote
        self.pnl = 0.0

    async def run(self, market_id):
        """Main market making loop"""
        while True:
            try:
                orderbook = await self.clob.get_orderbook(market_id)
                mid_price = self._calculate_mid(orderbook)
                inventory = self.inventory.get(market_id, 0)

                # Calculate skewed quotes
                bid, ask = self._calculate_quotes(mid_price, inventory)

                # Cancel stale orders and place new ones
                await self._cancel_replace(market_id, bid, ask)

                # Check inventory limits
                await self._check_inventory_limits(market_id)

                await asyncio.sleep(self.config["quote_interval_sec"])

            except Exception as e:
                print(f"MM error: {e}")
                await asyncio.sleep(5)

    def _calculate_mid(self, orderbook):
        """Best bid + best ask / 2"""
        best_bid = orderbook["bids"][0]["price"] if orderbook["bids"] else 0.40
        best_ask = orderbook["asks"][0]["price"] if orderbook["asks"] else 0.60
        return (best_bid + best_ask) / 2

    def _calculate_quotes(self, mid_price, inventory):
        """
        Avellaneda-Stoikov adapted for prediction markets

        Key idea: skew quotes based on inventory
        - ถ้าถือ YES มาก → ลด bid price, เพิ่ม ask price (want to sell)
        - ถ้าถือ NO มาก → เพิ่ม bid price, ลด ask price (want to buy)
        """
        half_spread = self.config["min_spread"] / 2

        # Inventory skew: push prices to reduce inventory
        skew = inventory * self.config["skew_factor"]

        bid_price = round(mid_price - half_spread - skew, 2)
        ask_price = round(mid_price + half_spread - skew, 2)

        # Clamp to valid range
        bid_price = max(0.01, min(0.99, bid_price))
        ask_price = max(0.01, min(0.99, ask_price))

        # Ensure spread is positive
        if ask_price <= bid_price:
            ask_price = bid_price + 0.01

        bid = Quote(market_id="", side="BUY", price=bid_price,
                    size=self.config["order_size"])
        ask = Quote(market_id="", side="SELL", price=ask_price,
                    size=self.config["order_size"])

        return bid, ask

    async def _cancel_replace(self, market_id, new_bid, new_ask):
        """Cancel existing orders and place new ones atomically"""
        # Cancel all active orders for this market
        for oid, quote in list(self.active_orders.items()):
            if quote.market_id == market_id:
                await self.clob.cancel_order(oid)
                del self.active_orders[oid]

        # Place new orders
        bid_id = await self.clob.place_order(
            market_id, "BUY", new_bid.price, new_bid.size
        )
        ask_id = await self.clob.place_order(
            market_id, "SELL", new_ask.price, new_ask.size
        )

        new_bid.order_id = bid_id
        new_ask.order_id = ask_id
        new_bid.market_id = market_id
        new_ask.market_id = market_id

        self.active_orders[bid_id] = new_bid
        self.active_orders[ask_id] = new_ask

    async def _check_inventory_limits(self, market_id):
        """Hard limits on inventory to prevent resolution blowup"""
        inv = self.inventory.get(market_id, 0)
        max_inv = self.config["max_inventory"]

        if abs(inv) > max_inv:
            # Emergency: market sell excess inventory
            if inv > 0:
                await self.clob.market_sell(market_id, abs(inv) - max_inv)
            else:
                await self.clob.market_buy(market_id, abs(inv) - max_inv)
```

## Configuration

```python
MM_CONFIG = {
    "min_spread": 0.03,        # Minimum 3¢ spread
    "order_size": 50,          # $50 per side
    "max_inventory": 500,      # Max $500 net position
    "skew_factor": 0.001,      # Price skew per $1 inventory
    "quote_interval_sec": 10,  # Update quotes every 10s
    "max_markets": 5,          # MM on 5 markets simultaneously
    "min_volume_24h": 10000,   # Only MM markets with >$10k volume
    "time_to_resolution_min_days": 3,  # Don't MM markets resolving soon
}
```

## Inventory Risk (สำคัญที่สุด)

```
⚠️ CRITICAL: Prediction market contracts resolve to $0 or $1
ต่างจากหุ้นที่ราคาจะเคลื่อนที่ช้าๆ — ที่นี่ถ้าถืออยู่ฝั่งผิดตอน resolve = เสียหมด

Risk mitigation:
1. Hard inventory limit ($500 per market)
2. Time-to-resolution cutoff (stop MM 3 days before resolve)
3. Directional bias check (ถ้า AI forecast > 80% → only quote one side)
4. Stop-loss: if inventory mark-to-market loss > 20% → exit all
5. Diversify across 5+ markets (different categories)

Resolution risk formula:
Max loss = inventory × probability_of_wrong_side
Example: $500 inventory × 30% wrong = $150 expected loss
Breakeven: need $150 spread revenue before resolution
```

## Market Selection Criteria

```
GOOD markets for MM:
✅ Volume: $50k–$500k daily (not too crowded, enough flow)
✅ Spread: 3–8¢ (wide enough to profit)
✅ Resolution: >7 days away
✅ Category: politics, sports (stable flow)
✅ Balanced YES/NO demand

BAD markets for MM:
❌ Volume: <$10k (no flow) or >$1M (HFT dominated)
❌ Spread: <2¢ (too tight) or >20¢ (no one trading)
❌ Resolution: <3 days (inventory risk too high)
❌ Breaking news markets (adverse selection risk)
❌ Insider-heavy markets (they know, you don't)
```

## Adverse Selection Protection

```python
def detect_adverse_selection(recent_fills, threshold=0.70):
    """
    ถ้า fills ส่วนใหญ่อยู่ฝั่งเดียว → someone knows something
    = adverse selection risk

    Example: 10 fills, 8 are buying YES → informed trader thinks YES
    """
    if not recent_fills:
        return False

    buy_count = sum(1 for f in recent_fills if f["side"] == "BUY")
    buy_ratio = buy_count / len(recent_fills)

    if buy_ratio > threshold or buy_ratio < (1 - threshold):
        return True  # Likely adverse selection → widen spread or exit

    return False
```

## Revenue Model

```
Monthly revenue estimate ($10k bankroll, 5 markets):

Spread revenue: 5 markets × $0.03 spread × $3k capture/day = $450/day
× 30 days = $13,500/month gross

Minus:
- Inventory losses (avg 20%): -$2,700
- Resolution losses (avg 10%): -$1,350
- Gas fees: -$50

Net: ~$9,400/month (~94% ROI)

Conservative: assume 50% of above = ~$4,700/month (47% ROI)

IMPORTANT: These are estimates. Actual results depend on market conditions,
competition, and execution quality.
```
