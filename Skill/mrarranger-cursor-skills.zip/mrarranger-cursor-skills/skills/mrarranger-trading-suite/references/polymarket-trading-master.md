# POLYMARKET TRADING MASTER SKILL
> Unified skill สำหรับ Prediction Market Trading — รวม 7 modules จาก conversation จริง

---

## QUICK COMMANDS

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/edge [name]` | วิเคราะห์ edge เฉพาะ | Edge analysis + window estimate |
| `/backtest [edge] [capital]` | จำลอง ROI | Backtest table + chart |
| `/signal` | scan markets ตอนนี้ | Live market opportunities |
| `/risk [bankroll]` | คำนวณ position size | Kelly + risk limits |
| `/phase [target $]` | วางแผน phase | Sprint plan พร้อม milestones |
| `/scan negrisk` | scan NegRisk arb | Markets ที่ sum < $0.97 |
| `/scan noarb` | scan sensational markets | Markets ที่ YES overpriced |
| `/insider` | analyze wallet pattern | Suspicious wallet signals |
| `/cs2 [event]` | CS2 live edge | Round markets + stream delay |
| `/pivot` | edge หมดแล้ว ทำอะไรต่อ | Next edge recommendations |

---

## MODULE 1: EDGE LIBRARY (ข้อมูล 2026)

### Edge Tier System

```
TIER S+ (ROI ชันสุด, window ยังกว้าง):
├── Insider Wallet Copy — follow fresh wallet + large bet + single market
│   ROI: 3–12x per event | Freq: 2–4/month | Window: 6–12 months
│   Source: Iran strike ($1.2M), Maduro ($442k), Axiom ($266k) — Feb–Mar 2026
│
└── NO Arbitrage (Sensational Markets) — human overestimates dramatic events
    ROI: 50–200% per position | Freq: 5–15/month | Window: permanent
    Source: $360k profit case, nuclear market $850k volume — 2026

TIER S (High freq, window 2–5 months):
├── CS2 Live Parser — stream delay 30–40s, BLAST Rotterdam live Mar 18
│   ROI: 80–120%/month | Freq: 50–200 trades/match day | Window: 3–6 months
│   Source: TeemuTeemuTeemu $208k LoL → CS2 equivalent
│
└── NegRisk Arbitrage — multi-outcome sum < $1.00
    ROI: 1.8–5%/trade guaranteed | Freq: 3–8/day | Window: wide
    Source: IMDEA research $29M extracted, 41% conditions mispriced

TIER A (Good, needs domain knowledge):
├── New Market Snipe — ตลาดใหม่เปิด 50/50 แต่ real prob ≠ 50%
│   ROI: 20–80% per position | Window: permanent
│
└── Dependent Market LLM — semantic relationship between markets
    ROI: variable | Requires Claude API

TIER DEAD (Skip ในปี 2026):
├── Binary YES+NO Arb — 2.7s average window, HFT ครอง
├── Crypto 15-min Latency — taker fee 3.15% kill edge (Jan 2026)
└── Simple arbitrage simple — ตายสมบูรณ์
```

---

## MODULE 2: EDGE DECAY MODEL

```
ทุก edge มีวงจรชีวิต 4 phases:

Phase 1 (Month 0–1): Innovator เห็น → ROI max, competition = 0
Phase 2 (Month 1–3): Early adopters ก็อป → competition เพิ่ม
Phase 3 (Month 3–6): กระจายบน X/Twitter → แออัด, ROI ลด 50–70%
Phase 4 (Month 6+): Platform patch / fee เพิ่ม → edge ตาย

RULE: ต้องออกก่อน Phase 3 เสมอ
COROLLARY: ถ้าเห็นบน YouTube/TikTok แล้ว = Phase 3–4 แล้ว
```

**สถานะ edge มีนาคม 2026:**

| Edge | Phase | Window เหลือ | Action |
|------|-------|-------------|--------|
| Insider Copy | 1 | 6–12 เดือน | BUILD NOW |
| NO Arbitrage | 1–2 | Permanent | BUILD NOW |
| CS2 Parser | 2 | 2–4 เดือน | THIS WEEK |
| Valorant Parser | 1 | 6–12 เดือน | Month 2 |
| LoL/Dota2 | 3 | แออัดแล้ว | TOO LATE |
| Crypto Latency | 4 | ตาย | SKIP |

---

## MODULE 3: INSIDER WALLET TRACKER

### Signal Detection Rules

```python
# Suspicious wallet criteria (ทั้งหมดต้องตรงพร้อมกัน)
SUSPICIOUS = {
    "wallet_age_days": < 7,          # Fresh wallet
    "market_count": <= 2,            # Single/double market focus
    "position_size_usd": > 1000,     # Large relative to wallet age
    "entry_price": < 0.25,           # Low price (high upside)
    "coordinated_wallets": >= 3,     # Multiple wallets same time
    "time_before_event_hours": < 48  # Close to event
}

# Copy window
OPTIMAL_COPY: 0–30 minutes after detection
STILL_PROFITABLE: 30–120 minutes
TOO_LATE: > 2 hours (price already moved)
```

### Case Studies (2026 ยืนยัน)

```
Jan 2026 — Venezuela Maduro:
  Entry: ~$0.10 | Profit: $442k from $35k | ROI: 12.6x
  Signal: New wallet, $30k bet, single market

Feb 2026 — Iran Strike:
  Entry: $0.10–0.18 | Profit: $1.2M (6 wallets) | ROI: ~6x
  Signal: 6 new wallets, all fund + bet within 24h

Feb 2026 — Axiom ZachXBT:
  Entry: ~14¢ | Profit: $266k–$411k | ROI: 5–7x
  Signal: 12 wallets entered before publication

Pattern: Fresh wallet + Single market + Low price + Cluster = HIGH signal
```

### Build Instructions

```python
# Tools needed:
# - Polygon RPC (Alchemy free tier หรือ QuickNode)
# - Polymarket CLOB API (public)
# - Telegram Bot API

# Detection loop (รัน ทุก 2 นาที)
def detect_suspicious_wallets():
    # 1. Scan new wallets ที่ place order ใหญ่
    # 2. Check wallet age via Polygon explorer
    # 3. Check market concentration (1–2 markets เท่านั้น)
    # 4. Check entry price (< 25¢ = interesting)
    # 5. Check cluster (หลาย wallets เข้าพร้อมกัน)
    # 6. Alert Telegram ถ้า match >= 3 criteria

# Copy logic
def copy_trade(wallet, market, size_fraction=0.25):
    # Quarter Kelly on bankroll
    # Max 40% per single insider event
    # Stop if market void/dispute
```

### Legal Considerations

```
ตอนนี้ (2026): ยังไม่มีกฎหมายห้ามใน US
กำลังเกิด: "Public Integrity in Financial Prediction Markets Act"
Timeline กฎหมาย: อาจอีก 6–12 เดือน
Risk: ถ้า market void → ได้ทุนคืน ไม่ขาดทุน
Gray area: Copy trade ไม่ใช่ insider ตัวเอง
```

---

## MODULE 4: CS2 LIVE PARSER

### Architecture

```
Data Flow:
PandaScore API → Parse round result → Compare with Polymarket price →
If lag > threshold → Place order → Exit when price corrects

Timing:
- Stream delay (Twitch/YouTube): 30–40 seconds
- PandaScore API latency: < 1 second
- Polymarket CLOB execute: ~1 second
- Total edge window: ~28–38 seconds
```

### Markets to Target

```
High-value in-play markets:
1. Round winner (CT vs T) — resolves every ~90 seconds
2. Bomb planted — binary, fast resolve
3. Pistol round winner — high variance = high misprice
4. Ace/clutch markets — rare but massive edge

Entry rules:
- Enter within 10s of event detection
- Only when market liquidity > $500
- Max size: 10% of bankroll per round
- Exit: when price reaches fair value OR before round ends
```

### Tournament Calendar 2026

```
March 18–29: BLAST Open Rotterdam (ACTIVE NOW)
April: ESL Pro League Season 23
May: IEM Dallas
June: BLAST Premier Spring Finals + FIFA World Cup (adjacent volume)
September: IEM Cologne
November: CS2 Major + US Midterm Elections (massive volume)
```

### API Setup

```python
# PandaScore (free tier: 1000 req/hour)
import requests

PANDASCORE_API = "https://api.pandascore.co"
API_KEY = "your_key"

def get_live_cs2_match():
    r = requests.get(
        f"{PANDASCORE_API}/csgo/matches/running",
        headers={"Authorization": f"Bearer {API_KEY}"}
    )
    return r.json()

def get_match_rounds(match_id):
    r = requests.get(
        f"{PANDASCORE_API}/csgo/matches/{match_id}/rounds",
        headers={"Authorization": f"Bearer {API_KEY}"}
    )
    return r.json()
```

---

## MODULE 5: NEGRISK SCANNER

### Math

```
NegRisk Arbitrage condition:
Σ(prices of all outcomes) < 1.00

Example (BLAST Rotterdam Winner, 16 teams):
Vitality: 0.56
FaZe: 0.18
NaVi: 0.12
G2: 0.06
Others (12 teams): 0.05 each = 0.60 total
SUM = 0.56 + 0.18 + 0.12 + 0.06 + 0.60 = 1.52 (overpriced → no arb)

Wait for: SUM < 0.97 (leaves 3% after 2% fee + gas)
When found: BUY all outcomes via STANDARD market (NOT NegRisk interface)
Result: Guaranteed profit = ($1.00 - SUM) × shares
```

### Critical Rule

```
⚠️ IMPORTANT:
- Sum < $1.00 → Use STANDARD market → True arbitrage profit
- Sum > $1.00 → Use NEGRISK interface → Only capital efficiency
- Never use NegRisk interface for underpriced markets (no profit!)
```

### Scanner Code

```python
import requests

GAMMA_API = "https://gamma-api.polymarket.com"

def scan_negrisk_opportunities(min_gap=0.03):
    """Scan for NegRisk markets where sum < 1.0"""
    events = requests.get(
        f"{GAMMA_API}/events",
        params={"neg_risk": "true", "active": "true", "limit": 100}
    ).json()

    opportunities = []

    for event in events:
        markets = event.get("markets", [])
        if len(markets) < 3:
            continue

        total = sum(float(m.get("bestAsk", 1)) for m in markets)
        gap = 1.0 - total

        if gap > min_gap:  # After fee
            liquidity = min(float(m.get("liquidity", 0)) for m in markets)
            opportunities.append({
                "event": event["title"],
                "sum": round(total, 4),
                "gap": round(gap, 4),
                "profit_pct": round(gap * 100, 2),
                "markets": len(markets),
                "min_liquidity": round(liquidity, 0)
            })

    return sorted(opportunities, key=lambda x: x["gap"], reverse=True)
```

---

## MODULE 6: NO ARBITRAGE (SENSATIONAL MARKETS)

### Psychology Basis

```
Human bias: People OVERESTIMATE probability of dramatic events
- Nuclear war: Market says 15% → Real probability: 2–3%
- Major country collapse: Market says 25% → Real: 3–5%
- Celebrity scandal: Market says 40% → Real: 15–20%

Edge: Buy NO when YES is emotionally inflated
Result: YES holders pay emotional premium → NO holders collect it
```

### Identification Criteria

```python
# Screen for sensational markets
SENSATIONAL_SIGNALS = {
    "keywords": [
        "nuclear", "war", "collapse", "death", "arrest", "impeach",
        "invasion", "explosion", "crash", "default", "crisis"
    ],
    "volume_spike": True,        # High volume = emotional flow
    "yes_price": "> 0.15",       # Not too cheap (needs liquidity)
    "yes_price": "< 0.45",       # Not too expensive (needs gap)
    "resolution_date": "> 7 days", # Needs time for NO to pay off
    "liquidity": "> $5000"       # Enough to enter/exit
}

# Optimal NO buy range: 60–85¢ (YES at 15–40¢)
# If YES is 15¢, NO is 85¢ — still worth if real prob is < 5%
```

### Sizing Rules

```
NO Arb position sizing:
- Start: 5% of bankroll per market
- Max: 20% of bankroll total in NO positions
- Stop: if YES spikes to > 60¢ (re-evaluate thesis)
- Target: hold until resolve or YES drops below 10¢

Example: $300 bankroll
- $60 max per NO position (20% of $300)
- $15 per position (5% of $300)
- Can hold 3–4 positions simultaneously
```

---

## MODULE 7: RISK MANAGEMENT

### Position Sizing (Prediction Market Version)

```
KELLY CRITERION for Prediction Markets:
f* = (p × b - q) / b

Where:
f* = fraction of bankroll to bet
p = estimated win probability
b = odds (payout - 1, i.e., if entry 0.25, b = 3)
q = 1 - p

Example:
Entry: $0.25 (you think real prob is 70%)
p = 0.70, q = 0.30, b = 3
f* = (0.70 × 3 - 0.30) / 3 = (2.1 - 0.3) / 3 = 0.60 → 60% full Kelly

Quarter Kelly (safer): 0.60 × 0.25 = 15% of bankroll
```

### Bankroll Rules

```
HARD RULES (never break):
1. Max 40% per single insider event
2. Max 40% in CS2 leg simultaneously
3. Max 20% in NO arb positions total
4. Stop all trading after 30% drawdown from peak
5. Withdraw 50% when hitting $50k milestone
6. Never trade with money needed in next 6 months

SOFT RULES (guidelines):
- Paper trade 3+ days before going live on new edge
- Validate win rate > 55% before increasing size
- Rotate wallets when any single wallet gets noticed
```

### Kill Switches

```
Trigger                          → Action
DrawDown > 30% in 7 days         → STOP 1 week, review
Win rate drops < 50% (20 trades) → REVIEW STRATEGY
Polymarket adds CS2 taker fees   → SHIFT TO LEG A+C
Congress passes insider law      → STOP INSIDER LEG
Market void/dispute              → ACCEPT, continue (get capital back)
Edge appears on X/YouTube         → START PIVOTING
Bankroll hits $50k               → WITHDRAW 50%
All 3 edges fade simultaneously  → PIVOT or EXIT
```

---

## MODULE 8: PHASE PLAN TO $100K

### Overview

```
Starting capital: $300 (ยอมเสียได้หมด)
Target: $100,000
Timeline: 5–8 months (Base case)
Strategy: Scenario B — Multi-Edge Stack
```

### Phase 0: Setup (Day 1–3)
```
□ MetaMask wallet (dedicated, anonymous)
□ VPN (Mullvad/ProtonVPN — Thai location blocked)
□ Polymarket account setup + USDC bridge
□ Python installed + py-clob-client tested
□ Telegram bot setup for alerts
□ Spreadsheet for tracking all trades
```

### Phase 1: First Money (Week 1–2) — Target $300 → $600+
```
Day 1: Manual NO Arb — identify 3 sensational markets, $30–50 each
Day 2–3: Build insider wallet scanner (Python, paper test)
Day 3–4: Build NegRisk scanner (Python, find opportunities)
Day 5: BLAST Rotterdam Mar 18 — CS2 parser paper trade
Week 2: If paper win rate > 60% → go live with real $50–100

GATE: Must prove win rate > 55% in paper before increasing
```

### Phase 2: Scale to $1k–3k (Month 1–2)
```
- Reinvest 80% profit, keep 20% cash reserve
- CS2: scale size proportionally to bankroll (max 40%)
- Insider: monitor every 2h, copy within 15 min of detection
- NO Arb: 3–5 positions open simultaneously
- Deploy Hetzner VPS €3.79/month for 24/7 uptime

Catalyst: ESL Pro League S23 (April) → CS2 volume spike
```

### Phase 3: Scale to $10k (Month 2–4)
```
- Add Valorant parser (new tournament announcements)
- Add NegRisk auto-scanner running 24/7
- Build 2026 US Midterm tracker (November = biggest event)
- Polygon RPC direct node → lower latency for insider copy
- Milestone: When hitting $10k → withdraw $2k as emergency fund
```

### Phase 4: $100k (Month 4–8)
```
- FIFA World Cup June 2026 → massive CS2/sports volume
- US Midterm elections Nov 2026 → insider pattern will repeat
- At $50k bankroll → insider event allocation = $20k per event
- 1–2 insider events at $10–50k each → $100k achievable

Path options:
A) Compound CS2 ($300 → $1k → $5k → $20k → $100k via 100%/mo)
B) Insider event hits ($5k in → $40k out → scale → $100k)
C) Hybrid: compound to $10k then insider push to $100k
```

---

## MODULE 9: BACKTEST TEMPLATES

### Quick Backtest Format

```
Edge: [name]
Period: [date range]
Capital: $[amount]
Strategy: [description]

Results:
- Total trades:
- Win rate: %
- Avg win: $
- Avg loss: $
- Max drawdown: %
- Net profit: $
- ROI: %

Assessment:
- Edge still valid? Y/N
- Competition level: Low/Medium/High
- Estimated window remaining:
- Recommend: Build / Monitor / Skip
```

### Compound Calculator

```python
def compound_roi(capital, monthly_roi, months, withdraw_pct=0):
    """
    capital: starting amount
    monthly_roi: e.g., 1.0 = 100% monthly
    months: number of months
    withdraw_pct: % to withdraw each month (0 = full compound)
    """
    results = [capital]
    bal = capital
    for m in range(months):
        gain = bal * monthly_roi
        withdraw = gain * withdraw_pct
        bal = bal + gain - withdraw
        results.append(round(bal, 2))
    return results

# Example: $300, 100%/month, 8 months, no withdrawal
# result: [300, 600, 1200, 2400, 4800, 9600, 19200, 38400, 76800]
```

---

## MODULE 10: PIVOT FRAMEWORK

### When to Pivot

```
Signal: Edge อายุ > 4 เดือน + Win rate ลด > 20%
Signal: บทความ/thread เกี่ยวกับ edge นั้นบน X > 50 posts
Signal: Platform เพิ่ม fee/rules targeting your edge

Pivot options:
CS2 dies → Valorant / R6 Siege / FIFA markets
Insider tracking illegal → NO Arb full + Midterm NegRisk
All Polymarket edges gone → Kalshi (CFTC regulated, different market)
Kalshi blocked too → Manifold (play money testing) → wait for next platform
```

### Next Edges on Horizon (Q2–Q4 2026)

```
April–May: ESL Pro League S23 → CS2 volume
June: FIFA World Cup → massive prediction market activity
September: IEM Cologne CS2 Major
November: US Midterm Elections → insider patterns WILL repeat
          → Volume could hit $500M+ (bigger than 2024 election)
2027: New prediction market platforms launching
```

---

## RESPONSE FORMATS

### When user asks for edge analysis (/edge)
```
## [Edge Name] — Analysis

**Status:** [Phase 1/2/3/4] | **Window:** [time estimate]
**ROI/trade:** [range] | **Win Rate:** [%] | **Frequency:** [per day/week]

### How it works
[2–3 sentences mechanism]

### Evidence (2026 data)
[Specific cases with numbers]

### Build requirements
- Code: [difficulty + tools]
- Time: [days to build]
- Capital min: $[amount]

### Risk factors
[Top 3 risks]

### Verdict
[GO / WAIT / SKIP] — [reason in 1 sentence]
```

### When user asks for signal scan (/signal)
```
## Live Signals — [date]

### 🔴 HIGH PRIORITY
[Market] | [Edge type] | Entry: [price] | Edge: [%] | Window: [time]

### 🟡 WATCH LIST
[Market] | [Edge type] | Waiting for: [condition]

### ✅ ACTIVE POSITIONS
[Market] | Entry: [price] | Current: [price] | P&L: [+/-$]
```

### When user asks for phase plan (/phase $X)
```
## Phase Plan → $[target]

Starting: $[amount] | Strategy: [scenario]

### Phase 0: Setup [Day 1–3]
[checklist]

### Phase 1: First Proof [Week 1–2] → $[target]
[actions]

### Phase 2: Scale [Month 1–2] → $[target]
[actions]

### Kill Switches
[trigger → action pairs]
```

---

## MODULE 11: VALORANT LIVE PARSER

### Architecture

```
Data Flow:
Riot Games Valorant API → Parse round/spike data → Compare with Polymarket →
If lag > threshold → Place order → Exit on correction

API: https://valorant-api.henrikdev.xyz/v3 (free, unofficial but reliable)
Alternative: Riot Games official Esports API

Timing:
- Stream delay (Twitch): 30–45 seconds
- API latency: 1–3 seconds
- Polymarket CLOB: ~1 second
- Edge window: ~26–41 seconds
```

### Markets to Target

```
Valorant in-play markets:
1. Round winner — resolves every ~100 seconds
2. Spike planted (equivalent to bomb plant) — binary, fast
3. Pistol round winner — high variance = misprice
4. Map winner — longer duration, less edge per trade but safer
5. First blood — high-impact, correlates with round winner

Entry rules:
- Enter within 10s of event detection
- Only when market liquidity > $300 (lower than CS2 — newer markets)
- Max size: 8% of bankroll per round
- Exit: when price reaches fair value
```

### Tournament Calendar 2026

```
Q2 2026: VCT Masters Shanghai
Q3 2026: VCT Champions (World Championship)
Q4 2026: VCT Game Changers Championship
Year-round: VCT regional leagues (Americas, EMEA, Pacific)
Third-party: Red Bull Home Ground, VALORANT Challengers

Note: Valorant esports markets on Polymarket growing rapidly
Competition: Much LOWER than CS2 (Phase 1 for Valorant)
```

### API Setup

```python
import requests

# Using henrikdev unofficial API (free, no auth needed)
VALORANT_API = "https://api.henrikdev.xyz/valorant/v3"

def get_live_valorant_match():
    """Get currently live Valorant esports matches"""
    r = requests.get(
        f"{VALORANT_API}/esports/schedule",
        params={"region": "international"}
    )
    matches = r.json().get("data", [])
    return [m for m in matches if m.get("state") == "running"]

def get_match_details(match_id):
    """Get detailed match data including round results"""
    r = requests.get(f"{VALORANT_API}/esports/matches/{match_id}")
    return r.json().get("data", {})

# Riot Games Official API (needs API key)
RIOT_ESPORTS = "https://esports-api.lolesports.com/persisted/gw"

def get_live_events_riot(api_key):
    """Official Riot API for live events"""
    r = requests.get(
        f"{RIOT_ESPORTS}/getLive",
        headers={"x-api-key": api_key},
        params={"hl": "en-US"}
    )
    return r.json()
```

---

## MODULE 12: FIFA / SPORTS PARSER

### Architecture

```
FIFA World Cup 2026 (June–July) → MASSIVE prediction market volume
Sports-API → Parse goal/event → Compare with Polymarket → Trade lag

APIs:
1. Football-Data.org (free tier: 10 req/min)
2. API-Football (rapidapi.com, free 100 req/day)
3. Sportmonks API (premium, real-time)

Edge concept:
- Goal scored → Match probability shifts dramatically
- Polymarket lag: 30–60 seconds (longer than esports due to less automation)
- Red card → even bigger probability shift
- Penalty awarded → high-impact, fast resolution
```

### Markets to Target (FIFA World Cup 2026)

```
High-value markets:
1. Match winner (3-way: Team A, Draw, Team B)
2. Both teams to score (Yes/No)
3. Total goals over/under
4. Group stage: "Will [country] advance?"
5. Tournament winner (NegRisk multi-outcome)

Volume estimates:
- Group stage: $5M–$20M per match
- Knockout: $20M–$100M per match
- Final: $200M+ (massive retail inflow → massive inefficiency)
```

### R6 Siege / Other Esports

```
Rainbow Six Siege:
- Growing esports market on Polymarket
- Similar stream delay edge as CS2
- API: Ubisoft Esports API (limited) + community APIs
- Competition: Very LOW (Phase 0–1)

FIFA Esports (EA FC):
- Electronic arts competitive scene
- Smaller markets but near-zero competition
- API: Community-driven, less reliable

General rule: Any esport with stream delay + Polymarket markets = potential edge
```

---

## MODULE 13: MARKET MAKING INTEGRATION

### When to Add Market Making

```
Add market making when:
1. Bankroll > $5,000 (need capital for both sides)
2. Other edges generating consistent income
3. Understand bid-ask dynamics on CLOB

Market making on Polymarket:
- Quote both BUY and SELL (provide liquidity)
- Profit from spread between bid and ask
- Risk: adverse selection (informed traders pick you off)
- Mitigation: wide spreads on volatile events, tight on stable

Integration with other edges:
- Use insider signals to WIDEN spreads (protect from smart money)
- Use CS2 parser to PULL quotes during live events
- Use NegRisk scanner to find MM opportunities in multi-outcome markets
```

---

## MODULE 14: ENSEMBLE FORECASTING INTEGRATION

### Using AI for Probability Estimation

```
Multi-LLM Ensemble (reference: ai-ensemble-forecasting.md)

Integration with edges:
1. Insider signal → Use ensemble to estimate true probability
2. NO Arb → Use ensemble to validate "YES is overpriced" thesis
3. NegRisk → Use ensemble to identify which outcome is most underpriced
4. New market snipe → Use ensemble to estimate fair price immediately

Cost management:
- Only use ensemble for trades > $50 (ROI on API cost)
- Cache ensemble results for 1 hour
- Use simplified model for small trades
```

---

## MODULE 15: ON-CHAIN ENHANCED SIGNALS

### Cluster Analysis Integration

```
Enhanced insider scoring (10-point scale):
1. Wallet age < 7 days (+2)
2. Single market focus (+1)
3. Position > $1,000 (+1)
4. Entry price < 25¢ (+1)
5. Cluster ≥ 3 wallets (+2)
6. Common funding source detected (+2) ← NEW: on-chain analytics
7. Bridge from CEX within 48h (+1) ← NEW: fund flow tracking

Score 8-10: MAXIMUM CONFIDENCE → 40% of Leg A
Score 6-7: HIGH → 25% of Leg A
Score 4-5: MEDIUM → 10% of Leg A
Score < 4: MONITOR ONLY

Reference: on-chain-analytics.md for full implementation
```

---

## DISCLAIMER

```
⚠️ สำหรับการศึกษาและ research เท่านั้น
- Polymarket บล็อก Thailand — ต้องใช้ VPN (ผิด ToS, มีความเสี่ยงถูกแบน)
- Insider trading อาจมีกฎหมายในอนาคต
- การเทรดทุกประเภทมีความเสี่ยง รวมถึงการเสียเงินทั้งหมด
- ตัวเลข ROI ในเอกสารนี้มาจาก cases ที่ดีที่สุด ไม่ใช่ average
- 92% ของ Polymarket traders ขาดทุน
- บทความนี้ไม่ใช่คำแนะนำทางการเงิน
```
