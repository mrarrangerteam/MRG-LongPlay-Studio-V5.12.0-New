# PERFORMANCE DASHBOARD — 9-Tab Monitoring System

## Dashboard Architecture

```
┌─────────────────────────────────────────────────────┐
│              TRADING DASHBOARD                       │
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐         │
│  │Port │ │Strat│ │Trade│ │Curve│ │Risk │         │
│  │folio│ │ egy │ │ Log │ │     │ │     │         │
│  └──┬──┘ └──┬──┘ └──┬──┘ └──┬──┘ └──┬──┘         │
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐                  │
│  │Signa│ │Whale│ │Scann│ │Syste│                  │
│  │l    │ │     │ │er   │ │m    │                  │
│  └─────┘ └─────┘ └─────┘ └─────┘                  │
│           SQLite ←── Bot ──→ Telegram              │
└─────────────────────────────────────────────────────┘
```

## SQLite Database Schema

```sql
-- trades.db schema

CREATE TABLE trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    strategy TEXT NOT NULL,         -- 'insider', 'cs2', 'no_arb', 'negrisk', 'mm'
    market_id TEXT NOT NULL,
    market_title TEXT,
    side TEXT NOT NULL,             -- 'BUY' or 'SELL'
    entry_price REAL NOT NULL,
    exit_price REAL,
    size_usd REAL NOT NULL,
    profit REAL,
    won BOOLEAN,
    status TEXT DEFAULT 'open',     -- 'open', 'closed', 'cancelled'
    notes TEXT,
    signal_score REAL,
    closed_at DATETIME
);

CREATE TABLE positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT UNIQUE NOT NULL,
    market_title TEXT,
    strategy TEXT,
    side TEXT,
    entry_price REAL,
    current_price REAL,
    size_usd REAL,
    unrealized_pnl REAL,
    opened_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE daily_pnl (
    date DATE PRIMARY KEY,
    starting_bankroll REAL,
    ending_bankroll REAL,
    realized_pnl REAL,
    unrealized_pnl REAL,
    trades_count INTEGER,
    wins INTEGER,
    losses INTEGER
);

CREATE TABLE signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    type TEXT NOT NULL,            -- 'INSIDER', 'NEGRISK', 'CS2', 'NOARB'
    market_title TEXT,
    score REAL,
    executed BOOLEAN DEFAULT FALSE,
    trade_id INTEGER REFERENCES trades(id)
);

CREATE TABLE whale_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    wallet TEXT NOT NULL,
    market_id TEXT,
    side TEXT,
    size_usd REAL,
    price REAL,
    copied BOOLEAN DEFAULT FALSE
);

CREATE TABLE system_health (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    component TEXT,               -- 'bot', 'api', 'ws', 'db'
    status TEXT,                  -- 'healthy', 'degraded', 'down'
    latency_ms REAL,
    error_message TEXT
);

-- Indexes
CREATE INDEX idx_trades_strategy ON trades(strategy);
CREATE INDEX idx_trades_status ON trades(status);
CREATE INDEX idx_trades_timestamp ON trades(timestamp);
CREATE INDEX idx_signals_type ON signals(type);
CREATE INDEX idx_whale_wallet ON whale_activity(wallet);
```

## Tab 1: Portfolio Overview

```python
def portfolio_overview(db):
    """Tab 1: Current state of everything"""
    cursor = db.cursor()

    # Total bankroll
    bankroll = cursor.execute(
        "SELECT ending_bankroll FROM daily_pnl ORDER BY date DESC LIMIT 1"
    ).fetchone()

    # Open positions
    positions = cursor.execute(
        "SELECT * FROM positions ORDER BY unrealized_pnl DESC"
    ).fetchall()

    # Today's P&L
    today_pnl = cursor.execute(
        "SELECT SUM(profit) FROM trades WHERE date(timestamp) = date('now')"
    ).fetchone()

    # All-time stats
    all_time = cursor.execute("""
        SELECT COUNT(*), SUM(CASE WHEN won THEN 1 ELSE 0 END),
               SUM(profit), MAX(profit), MIN(profit)
        FROM trades WHERE status = 'closed'
    """).fetchone()

    return {
        "bankroll": bankroll[0] if bankroll else 300,
        "open_positions": len(positions),
        "unrealized_pnl": sum(p[6] for p in positions),
        "today_pnl": today_pnl[0] or 0,
        "total_trades": all_time[0],
        "total_wins": all_time[1],
        "total_pnl": all_time[2],
        "best_trade": all_time[3],
        "worst_trade": all_time[4]
    }
```

## Tab 2: Strategy Performance

```python
def strategy_breakdown(db):
    """Tab 2: Performance per strategy/edge"""
    strategies = ['insider', 'cs2', 'no_arb', 'negrisk', 'mm', 'copy', 'ensemble']
    results = {}

    for strat in strategies:
        data = db.execute("""
            SELECT COUNT(*) as trades,
                   SUM(CASE WHEN won THEN 1 ELSE 0 END) as wins,
                   SUM(profit) as total_pnl,
                   AVG(CASE WHEN won THEN profit END) as avg_win,
                   AVG(CASE WHEN NOT won THEN profit END) as avg_loss
            FROM trades
            WHERE strategy = ? AND status = 'closed'
        """, (strat,)).fetchone()

        if data[0] > 0:
            win_rate = data[1] / data[0]
            avg_win = data[3] or 0
            avg_loss = abs(data[4] or 0)
            profit_factor = (data[1] * avg_win) / max((data[0]-data[1]) * avg_loss, 1)

            results[strat] = {
                "trades": data[0],
                "win_rate": round(win_rate * 100, 1),
                "total_pnl": round(data[2], 2),
                "avg_win": round(avg_win, 2),
                "avg_loss": round(avg_loss, 2),
                "profit_factor": round(profit_factor, 2),
                "status": "ACTIVE" if win_rate > 0.55 else "WARNING" if win_rate > 0.45 else "REVIEW"
            }

    return results
```

## Tab 4: Equity Curve

```python
def equity_curve(db):
    """Tab 4: Compound growth chart data"""
    rows = db.execute("""
        SELECT date, ending_bankroll, realized_pnl
        FROM daily_pnl ORDER BY date
    """).fetchall()

    # Calculate drawdown
    peak = 0
    curve = []
    for date, bankroll, pnl in rows:
        peak = max(peak, bankroll)
        drawdown = (peak - bankroll) / peak if peak > 0 else 0
        curve.append({
            "date": date,
            "bankroll": bankroll,
            "daily_pnl": pnl,
            "peak": peak,
            "drawdown_pct": round(drawdown * 100, 2)
        })

    return curve
```

## Tab 5: Risk Monitor

```python
def risk_monitor(db, bankroll_manager):
    """Tab 5: Current risk exposure"""
    return {
        "total_exposure": bankroll_manager.get_total_exposure(),
        "exposure_by_leg": {
            "insider": bankroll_manager.get_leg_exposure("insider"),
            "cs2": bankroll_manager.get_leg_exposure("cs2"),
            "no_arb": bankroll_manager.get_leg_exposure("no_arb"),
            "mm": bankroll_manager.get_leg_exposure("mm")
        },
        "current_drawdown": bankroll_manager.current_drawdown_pct(),
        "kill_switch_status": {
            "global_drawdown": bankroll_manager.total < bankroll_manager.peak * 0.70,
            "win_rate_alert": check_recent_win_rate(db) < 0.50,
            "daily_loss_limit": check_daily_loss(db) > bankroll_manager.total * 0.10
        },
        "correlation_map": check_position_correlation(db)
    }
```

## KPI Formulas

```python
def calculate_kpis(trades):
    """All key performance indicators"""
    if not trades:
        return {}

    wins = [t for t in trades if t["won"]]
    losses = [t for t in trades if not t["won"]]

    return {
        "win_rate": len(wins) / len(trades),
        "profit_factor": (
            sum(t["profit"] for t in wins) /
            max(abs(sum(t["profit"] for t in losses)), 0.01)
        ),
        "expectancy": (
            (len(wins)/len(trades)) * avg([t["profit"] for t in wins]) +
            (len(losses)/len(trades)) * avg([t["profit"] for t in losses])
        ),
        "sharpe_ratio": calculate_sharpe(trades),
        "max_drawdown": calculate_max_drawdown(trades),
        "avg_trade_duration": avg_duration(trades),
        "trades_per_day": len(trades) / max(trading_days(trades), 1),
        "roi_total": sum(t["profit"] for t in trades) / initial_bankroll,
        "roi_monthly": annualize_roi(trades)
    }
```

## Streamlit Dashboard (Quick Setup)

```python
# dashboard.py — run with: streamlit run dashboard.py
import streamlit as st
import sqlite3
import pandas as pd

st.set_page_config(page_title="Trading Dashboard", layout="wide")

db = sqlite3.connect("data/trades.db")

# Sidebar: navigation
tab = st.sidebar.radio("Tab", [
    "Portfolio", "Strategy", "Trade Log", "Equity Curve",
    "Risk Monitor", "Signals", "Whales", "Scanner", "System"
])

if tab == "Portfolio":
    st.title("Portfolio Overview")
    data = portfolio_overview(db)
    col1, col2, col3 = st.columns(3)
    col1.metric("Bankroll", f"${data['bankroll']:,.2f}")
    col2.metric("Today P&L", f"${data['today_pnl']:,.2f}")
    col3.metric("All-Time P&L", f"${data['total_pnl']:,.2f}")

elif tab == "Equity Curve":
    st.title("Equity Curve")
    curve = equity_curve(db)
    df = pd.DataFrame(curve)
    st.line_chart(df.set_index("date")["bankroll"])
    st.area_chart(df.set_index("date")["drawdown_pct"])

elif tab == "Trade Log":
    st.title("Trade Log")
    df = pd.read_sql("SELECT * FROM trades ORDER BY timestamp DESC LIMIT 100", db)
    st.dataframe(df)

# ... additional tabs
```

## Daily/Weekly Report Template

```
📊 DAILY REPORT — [DATE]

💰 P&L: +$XX.XX (Today) | $X,XXX.XX (Total Bankroll)
📈 Win Rate: XX% (last 20 trades)
📉 Drawdown: X.X% from peak

Strategy Performance:
- Insider: X trades, XX% win rate, +$XX
- CS2: X trades, XX% win rate, +$XX
- NO Arb: X positions, $XX unrealized
- Market Making: $XX spread capture

Signals: X generated, X executed, X missed
Whales: X movements tracked, X copied

System: ✅ All healthy | Uptime: XX hours
```

## Alert Thresholds

```python
ALERT_RULES = {
    "daily_loss_5pct": {
        "condition": "daily_loss > bankroll * 0.05",
        "severity": "WARNING",
        "action": "Reduce position sizes 50%"
    },
    "daily_loss_10pct": {
        "condition": "daily_loss > bankroll * 0.10",
        "severity": "CRITICAL",
        "action": "Stop trading, review immediately"
    },
    "win_rate_drop": {
        "condition": "win_rate_20trades < 0.50",
        "severity": "WARNING",
        "action": "Review strategy, check edge decay"
    },
    "api_down": {
        "condition": "api_latency > 5000ms or api_errors > 5",
        "severity": "CRITICAL",
        "action": "Cancel all open orders, wait for recovery"
    },
    "new_high": {
        "condition": "bankroll > previous_peak",
        "severity": "INFO",
        "action": "Update peak, consider partial withdrawal"
    }
}
```
