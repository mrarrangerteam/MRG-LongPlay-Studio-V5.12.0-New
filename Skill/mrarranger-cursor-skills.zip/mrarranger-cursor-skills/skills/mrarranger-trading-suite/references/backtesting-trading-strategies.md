# BACKTESTING — Prediction Market Strategy Tester

## Backtesting Framework

```python
import json
import random
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class Trade:
    date: str
    strategy: str
    market: str
    entry_price: float
    size_usd: float
    won: bool
    exit_price: float
    profit: float
    edge_type: str  # "insider", "cs2", "negrisk", "no_arb"

@dataclass
class BacktestResult:
    strategy: str
    start_capital: float
    end_capital: float
    trades: List[Trade] = field(default_factory=list)

    @property
    def total_trades(self): return len(self.trades)

    @property
    def wins(self): return [t for t in self.trades if t.won]

    @property
    def losses(self): return [t for t in self.trades if not t.won]

    @property
    def win_rate(self):
        return len(self.wins) / self.total_trades if self.total_trades > 0 else 0

    @property
    def total_profit(self): return sum(t.profit for t in self.trades)

    @property
    def roi_pct(self): return (self.end_capital / self.start_capital - 1) * 100

    @property
    def max_drawdown(self):
        peak = self.start_capital
        current = self.start_capital
        max_dd = 0
        for t in self.trades:
            current += t.profit
            peak = max(peak, current)
            dd = (peak - current) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)
        return max_dd

    @property
    def sharpe_ratio(self):
        if not self.trades:
            return 0
        returns = [t.profit / t.size_usd for t in self.trades]
        avg = sum(returns) / len(returns)
        variance = sum((r - avg)**2 for r in returns) / len(returns)
        std = variance**0.5
        return avg / std if std > 0 else 0

    def summary(self):
        return {
            "strategy": self.strategy,
            "trades": self.total_trades,
            "win_rate": f"{self.win_rate*100:.1f}%",
            "roi": f"{self.roi_pct:.1f}%",
            "max_drawdown": f"{self.max_drawdown*100:.1f}%",
            "sharpe": f"{self.sharpe_ratio:.2f}",
            "total_profit": f"${self.total_profit:.2f}",
            "end_capital": f"${self.end_capital:.2f}"
        }
```

## Historical Data Sets (Known Cases 2025–2026)

```python
# Verified historical data for backtesting
HISTORICAL_DATA = {

    "insider_signals_2026": [
        # Q1 2026 confirmed insider cases
        {"date": "2026-01-15", "event": "Venezuela Maduro removal",
         "entry": 0.08, "resolved": 1.0, "won": True, "roi": 11.25},
        {"date": "2026-02-28", "event": "Iran strike Feb 28",
         "entry": 0.12, "resolved": 1.0, "won": True, "roi": 7.33},
        {"date": "2026-02-27", "event": "Axiom ZachXBT reveal",
         "entry": 0.14, "resolved": 1.0, "won": True, "roi": 6.14},
        # Note: Not all insider signals work - some are false positives
        # Estimated false positive rate: 30-40%
    ],

    "no_arb_2025_2026": [
        # Sensational markets that resolved NO (YES was overpriced)
        {"event": "Nuclear detonation 2025", "yes_at_buy": 0.18,
         "resolved": 0.0, "won": True, "no_profit_pct": 28.2},
        {"event": "Major country collapsed 2025", "yes_at_buy": 0.22,
         "resolved": 0.0, "won": True, "no_profit_pct": 22.4},
        {"event": "US-China direct military clash 2026", "yes_at_buy": 0.25,
         "resolved": 0.0, "won": True, "no_profit_pct": 19.6},
        # Losses
        {"event": "Iran nuclear test", "yes_at_buy": 0.30,
         "resolved": 1.0, "won": False, "no_profit_pct": -100},
    ],

    "cs2_teemu_style": {
        # Based on TeemuTeemuTeemu's LoL/Dota2 results (extrapolated to CS2)
        "start_capital": 900,
        "end_capital": 208521,
        "period_months": 3,
        "approx_win_rate": 0.75,
        "approx_trades_per_day": 150,
        "avg_profit_per_trade": 4.60
    }
}
```

## Simulation Engine

```python
import random

def simulate_strategy(
    strategy_name: str,
    start_capital: float,
    win_rate: float,
    avg_roi_win: float,
    avg_loss_pct: float,
    trades_per_day: int,
    days: int,
    kelly_fraction: float = 0.25,
    bankroll_pct_per_trade: float = 0.10
):
    """
    Monte Carlo simulation for a trading strategy

    Returns: BacktestResult with simulated trades
    """
    result = BacktestResult(strategy=strategy_name, start_capital=start_capital,
                            end_capital=start_capital)
    bankroll = start_capital

    for day in range(days):
        date = (datetime.now() + timedelta(days=day)).strftime("%Y-%m-%d")

        for _ in range(trades_per_day):
            if bankroll <= start_capital * 0.10:
                break  # Ruin threshold

            # Position size (Kelly-based)
            size = bankroll * bankroll_pct_per_trade

            # Simulate trade outcome
            won = random.random() < win_rate

            if won:
                profit = size * avg_roi_win
            else:
                profit = -size * avg_loss_pct

            bankroll += profit

            trade = Trade(
                date=date,
                strategy=strategy_name,
                market=f"Market_{day}_{_}",
                entry_price=0.25,
                size_usd=size,
                won=won,
                exit_price=1.0 if won else 0.0,
                profit=profit,
                edge_type=strategy_name.lower()
            )
            result.trades.append(trade)

    result.end_capital = bankroll
    return result

def monte_carlo(strategy_params, num_simulations=1000):
    """Run multiple simulations, get distribution of outcomes"""
    outcomes = []

    for _ in range(num_simulations):
        result = simulate_strategy(**strategy_params)
        outcomes.append(result.end_capital)

    outcomes.sort()

    return {
        "median": outcomes[len(outcomes)//2],
        "p10": outcomes[int(len(outcomes)*0.10)],  # 10th percentile (bad luck)
        "p90": outcomes[int(len(outcomes)*0.90)],  # 90th percentile (good luck)
        "p_ruin": sum(1 for o in outcomes if o < strategy_params["start_capital"]*0.10) / num_simulations,
        "p_reach_10k": sum(1 for o in outcomes if o >= 10000) / num_simulations,
        "p_reach_100k": sum(1 for o in outcomes if o >= 100000) / num_simulations,
    }
```

## Standard Backtest Configs (Pre-built)

```python
# Ready-to-run backtest configurations based on 2026 data

BACKTEST_CONFIGS = {

    "scenario_b_multi_edge": {
        # Recommended strategy from our analysis
        "strategies": {
            "insider": {
                "win_rate": 0.60,      # 40% false positives
                "avg_roi_win": 5.0,    # 5x average on true insiders
                "avg_loss_pct": 1.0,   # Lose full position
                "trades_per_month": 3,
                "allocation": 0.40
            },
            "cs2": {
                "win_rate": 0.73,
                "avg_roi_win": 0.40,   # 40% per round
                "avg_loss_pct": 1.0,
                "trades_per_day": 80,
                "allocation": 0.40
            },
            "no_arb": {
                "win_rate": 0.80,
                "avg_roi_win": 0.25,   # Average NO position gains 25%
                "avg_loss_pct": 1.0,
                "trades_per_month": 8,
                "allocation": 0.20
            }
        },
        "start_capital": 300,
        "target": 100000,
        "months": 8
    },

    "insider_only_aggressive": {
        "win_rate": 0.60,
        "avg_roi_win": 6.0,
        "avg_loss_pct": 1.0,
        "bankroll_pct_per_trade": 0.40,
        "trades_per_month": 3,
        "start_capital": 300,
    },

    "cs2_grind": {
        "win_rate": 0.73,
        "avg_roi_win": 0.35,
        "avg_loss_pct": 1.0,
        "bankroll_pct_per_trade": 0.04,
        "trades_per_day": 100,
        "start_capital": 300
    }
}
```

## Backtest Output Format

```
=== BACKTEST RESULTS: Scenario B Multi-Edge ===
Period: 8 months | Start: $300

Strategy Performance:
┌──────────────┬────────┬──────────┬──────────┬──────────┐
│ Strategy     │ Trades │ Win Rate │ Max DD   │ Sharpe   │
├──────────────┼────────┼──────────┼──────────┼──────────┤
│ Insider      │ 24     │ 58.3%    │ -18.5%   │ 3.2      │
│ CS2          │ 18,240 │ 73.1%    │ -6.2%    │ 2.8      │
│ NO Arb       │ 64     │ 81.3%    │ -4.1%    │ 4.1      │
│ COMBINED     │ 18,328 │ 73.0%    │ -14.8%   │ 3.1      │
└──────────────┴────────┴──────────┴──────────┴──────────┘

Capital Growth:
  Month 0: $300 (base)
  Month 1: $750   (+150%)
  Month 2: $1,950 (+160%)
  Month 3: $5,070 (+160%)
  Month 4: $13,182 (+160%)
  Month 5: $34,273 (+160%)
  Month 6: $89,110 (+160%)
  Month 7: $100,000 (TARGET HIT ✅)

Monte Carlo (1,000 simulations):
  P(reach $100k): 34%
  P(reach $10k): 78%
  P(ruin): 18%
  Median outcome: $24,600
  P10 (bad luck): $800
  P90 (good luck): $215,000
```

## Validation Checklist

```
Before going live, backtest must show:

□ Win rate > 55% over 50+ simulated trades
□ Profit factor > 1.5 (gross wins / gross losses)
□ Sharpe ratio > 1.5
□ Max drawdown < 30%
□ Risk of ruin < 20%
□ Strategy makes logical sense (not just curve-fitted)
□ Tested on different time periods (not just best period)
□ Paper traded for 3+ real days with similar results

IMPORTANT: Backtesting on historical Polymarket data shows BEST case.
Real performance will be WORSE due to:
- Slippage (can't always get best price)
- Missed opportunities (bot/human delay)
- Edge decay (competition enters over time)
- Unexpected events (platform changes, bugs)

Conservative estimate: expect 40–60% of backtest results in live trading
```


---

## Walk-Forward Analysis

```python
def walk_forward_test(strategy_params, data, train_window=60, test_window=14):
    """
    Walk-forward analysis: train on window, test on next period, slide forward.
    More realistic than single backtest — detects overfitting.

    train_window: days of training data
    test_window: days of out-of-sample testing
    """
    results = []
    total_days = len(data)

    for start in range(0, total_days - train_window - test_window, test_window):
        train_data = data[start:start + train_window]
        test_data = data[start + train_window:start + train_window + test_window]

        # Optimize on training data
        best_params = optimize_strategy(strategy_params, train_data)

        # Test on unseen data
        test_result = simulate_strategy(
            **{**best_params, "data": test_data}
        )

        results.append({
            "period": f"Day {start+train_window}-{start+train_window+test_window}",
            "train_win_rate": best_params.get("optimized_wr", 0),
            "test_win_rate": test_result.win_rate,
            "test_pnl": test_result.total_profit,
            "overfitting_ratio": (
                best_params.get("optimized_wr", 0) / max(test_result.win_rate, 0.01)
            )
        })

    # Aggregate
    avg_test_wr = sum(r["test_win_rate"] for r in results) / len(results)
    avg_overfit = sum(r["overfitting_ratio"] for r in results) / len(results)

    return {
        "periods": len(results),
        "avg_test_win_rate": round(avg_test_wr * 100, 1),
        "avg_overfitting_ratio": round(avg_overfit, 2),
        "consistent": avg_overfit < 1.20,  # <20% overfit = good
        "details": results
    }
```

## Slippage Modeling

```python
def apply_slippage(backtest_result, slippage_model="realistic"):
    """
    Apply slippage to backtest results for more realistic estimates.

    Polymarket slippage factors:
    - Market order: 0.5-2% depending on liquidity
    - Limit order: 0% but may not fill
    - During live events: 2-5% (fast-moving prices)
    """
    SLIPPAGE_MODELS = {
        "optimistic": {"market": 0.005, "limit_fill_rate": 0.90, "live_event": 0.02},
        "realistic": {"market": 0.015, "limit_fill_rate": 0.70, "live_event": 0.035},
        "pessimistic": {"market": 0.03, "limit_fill_rate": 0.50, "live_event": 0.05},
    }

    model = SLIPPAGE_MODELS[slippage_model]
    adjusted_trades = []

    for trade in backtest_result.trades:
        slippage = model["market"]
        if "cs2" in trade.edge_type or "valorant" in trade.edge_type:
            slippage = model["live_event"]

        # Apply slippage to entry price
        adjusted_entry = trade.entry_price * (1 + slippage)

        # Recalculate profit
        if trade.won:
            adjusted_profit = (trade.exit_price * 0.98 - adjusted_entry) * (trade.size_usd / trade.entry_price)
        else:
            adjusted_profit = -trade.size_usd

        # Apply fill rate (some trades don't execute)
        import random
        if random.random() > model["limit_fill_rate"]:
            continue  # Trade didn't fill

        adjusted_trades.append(Trade(
            date=trade.date,
            strategy=trade.strategy,
            market=trade.market,
            entry_price=adjusted_entry,
            size_usd=trade.size_usd,
            won=trade.won,
            exit_price=trade.exit_price,
            profit=adjusted_profit,
            edge_type=trade.edge_type
        ))

    return BacktestResult(
        strategy=backtest_result.strategy + "_slippage_adjusted",
        start_capital=backtest_result.start_capital,
        end_capital=backtest_result.start_capital + sum(t.profit for t in adjusted_trades),
        trades=adjusted_trades
    )
```

## Market Regime Detection

```python
def detect_market_regime(price_history, volume_history):
    """
    Detect current market regime to adjust strategy parameters.

    Regimes:
    1. TRENDING — strong directional movement
    2. MEAN_REVERTING — oscillating around fair value
    3. VOLATILE — large random swings
    4. LOW_ACTIVITY — thin volume, wide spreads
    """
    if len(price_history) < 20:
        return "UNKNOWN"

    # Calculate metrics
    returns = [price_history[i]/price_history[i-1]-1 for i in range(1, len(price_history))]
    avg_volume = sum(volume_history[-10:]) / 10
    volatility = (sum(r**2 for r in returns[-10:]) / 10) ** 0.5

    # Trend strength (simplified)
    price_change = (price_history[-1] - price_history[-10]) / price_history[-10]

    if abs(price_change) > 0.15 and volatility < 0.10:
        return "TRENDING"
    elif volatility > 0.15:
        return "VOLATILE"
    elif avg_volume < sum(volume_history) / len(volume_history) * 0.30:
        return "LOW_ACTIVITY"
    else:
        return "MEAN_REVERTING"

REGIME_ADJUSTMENTS = {
    "TRENDING": {"kelly_mult": 1.2, "entry_aggression": "high"},
    "MEAN_REVERTING": {"kelly_mult": 1.0, "entry_aggression": "normal"},
    "VOLATILE": {"kelly_mult": 0.5, "entry_aggression": "cautious"},
    "LOW_ACTIVITY": {"kelly_mult": 0.3, "entry_aggression": "avoid"},
    "UNKNOWN": {"kelly_mult": 0.5, "entry_aggression": "cautious"},
}
```
