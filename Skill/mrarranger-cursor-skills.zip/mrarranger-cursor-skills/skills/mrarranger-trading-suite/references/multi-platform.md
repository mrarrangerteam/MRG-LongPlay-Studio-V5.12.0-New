# MULTI-PLATFORM — Polymarket + Kalshi + Manifold + PredictIt

## Platform Comparison

```
┌──────────────┬─────────────┬─────────────┬──────────────┬──────────────┐
│ Feature      │ Polymarket  │ Kalshi      │ Manifold     │ PredictIt    │
├──────────────┼─────────────┼─────────────┼──────────────┼──────────────┤
│ Type         │ Crypto-nativ│ CFTC regula.│ Play money   │ CFTC no-actn │
│ Currency     │ USDC (Poly) │ USD         │ Mana (M$)    │ USD          │
│ Chain        │ Polygon     │ None (centr)│ None         │ None         │
│ Min trade    │ $1          │ $1          │ Free         │ $1           │
│ Max position │ No limit    │ $25k/market │ No limit     │ $850/market  │
│ Maker fee    │ 0%          │ 0%          │ 0%           │ 0%           │
│ Taker fee    │ 2% on win   │ Variable    │ 0%           │ 10% on win   │
│ KYC          │ None        │ Full KYC    │ None         │ Full KYC     │
│ US access    │ Blocked     │ Yes         │ Yes          │ Yes (limited)│
│ Thai access  │ VPN needed  │ No          │ Yes          │ No           │
│ API          │ REST+WS+RPC │ REST        │ REST         │ Limited      │
│ Volume/day   │ $50M+       │ $30M+       │ $500k (mana) │ $100k        │
│ Markets      │ Unlimited   │ 500+        │ Unlimited    │ 25           │
│ Speed        │ ~1s (CLOB)  │ Instant     │ AMM (instant)│ AMM          │
└──────────────┴─────────────┴─────────────┴──────────────┴──────────────┘
```

## Cross-Platform Arbitrage

```python
class MultiPlatformScanner:
    """Scan for same events priced differently across platforms"""

    def __init__(self, polymarket_api, kalshi_api, manifold_api):
        self.poly = polymarket_api
        self.kalshi = kalshi_api
        self.manifold = manifold_api

    async def scan_cross_platform_arb(self, min_gap_pct=3.0):
        """Find same events with different prices"""
        opportunities = []

        # Get events from all platforms
        poly_markets = await self.poly.get_active_markets()
        kalshi_markets = await self.kalshi.get_active_markets()
        manifold_markets = await self.manifold.get_active_markets()

        # Match events across platforms (by title similarity)
        for pm in poly_markets:
            for km in kalshi_markets:
                similarity = self._title_similarity(pm["title"], km["title"])
                if similarity > 0.80:  # 80% title match
                    gap = abs(pm["yes_price"] - km["yes_price"])
                    gap_pct = gap * 100

                    if gap_pct >= min_gap_pct:
                        opportunities.append({
                            "event": pm["title"][:60],
                            "polymarket_yes": pm["yes_price"],
                            "kalshi_yes": km["yes_price"],
                            "gap_pct": round(gap_pct, 2),
                            "action": self._recommend_action(pm, km),
                            "liquidity_ok": pm.get("volume", 0) > 5000 and km.get("volume", 0) > 1000,
                            "fee_adjusted_profit": round(gap_pct - 2.0, 2)  # After Poly 2% fee
                        })

        return sorted(opportunities, key=lambda x: x["gap_pct"], reverse=True)

    def _title_similarity(self, a, b):
        """Simple word overlap similarity"""
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0
        overlap = words_a & words_b
        return len(overlap) / max(len(words_a), len(words_b))

    def _recommend_action(self, poly, kalshi):
        """Determine trade direction"""
        if poly["yes_price"] > kalshi["yes_price"]:
            return f"Buy YES on Kalshi @ {kalshi['yes_price']:.2f}, Sell YES on Polymarket @ {poly['yes_price']:.2f}"
        else:
            return f"Buy YES on Polymarket @ {poly['yes_price']:.2f}, Sell YES on Kalshi @ {kalshi['yes_price']:.2f}"
```

## Kalshi API

```python
import requests

KALSHI_URL = "https://trading-api.kalshi.com/trade-api/v2"

class KalshiAPI:
    def __init__(self, email, password):
        self.session = requests.Session()
        self._login(email, password)

    def _login(self, email, password):
        """Authenticate with Kalshi"""
        r = self.session.post(f"{KALSHI_URL}/login", json={
            "email": email,
            "password": password
        })
        token = r.json()["token"]
        self.session.headers["Authorization"] = f"Bearer {token}"

    def get_events(self, status="open", limit=100):
        """List events"""
        r = self.session.get(f"{KALSHI_URL}/events", params={
            "status": status, "limit": limit
        })
        return r.json()["events"]

    def get_markets(self, event_ticker):
        """Get markets for an event"""
        r = self.session.get(f"{KALSHI_URL}/events/{event_ticker}/markets")
        return r.json()["markets"]

    def get_orderbook(self, ticker):
        """Get order book"""
        r = self.session.get(f"{KALSHI_URL}/markets/{ticker}/orderbook")
        return r.json()["orderbook"]

    def place_order(self, ticker, side, price_cents, count):
        """Place an order on Kalshi
        price_cents: price in cents (1-99)
        count: number of contracts
        """
        r = self.session.post(f"{KALSHI_URL}/portfolio/orders", json={
            "ticker": ticker,
            "action": "buy" if side == "BUY" else "sell",
            "type": "limit",
            "yes_price": price_cents if side == "BUY" else None,
            "no_price": price_cents if side == "SELL" else None,
            "count": count
        })
        return r.json()

    def get_positions(self):
        """Get current positions"""
        r = self.session.get(f"{KALSHI_URL}/portfolio/positions")
        return r.json()["market_positions"]
```

## Manifold API

```python
MANIFOLD_URL = "https://api.manifold.markets/v0"

class ManifoldAPI:
    def __init__(self, api_key=None):
        self.headers = {}
        if api_key:
            self.headers["Authorization"] = f"Key {api_key}"

    def search_markets(self, query, limit=10):
        """Search Manifold markets"""
        r = requests.get(f"{MANIFOLD_URL}/search-markets", params={
            "term": query, "limit": limit
        })
        return r.json()

    def get_market(self, market_id):
        """Get single market"""
        r = requests.get(f"{MANIFOLD_URL}/market/{market_id}")
        return r.json()

    def place_bet(self, market_id, amount, outcome):
        """Place a bet (Mana currency)"""
        r = requests.post(f"{MANIFOLD_URL}/bet", json={
            "contractId": market_id,
            "amount": amount,
            "outcome": outcome  # "YES" or "NO"
        }, headers=self.headers)
        return r.json()

    def get_positions(self):
        """Get user's positions"""
        r = requests.get(f"{MANIFOLD_URL}/me", headers=self.headers)
        return r.json()
```

## Price Normalization

```python
def normalize_prices(poly_price, kalshi_price_cents, manifold_prob):
    """
    Normalize prices across platforms to comparable format

    Polymarket: 0.00 - 1.00 (decimal)
    Kalshi: 1 - 99 (cents)
    Manifold: 0 - 100 (percentage/probability)
    """
    return {
        "polymarket": poly_price,
        "kalshi": kalshi_price_cents / 100,
        "manifold": manifold_prob / 100,
    }

def fee_adjusted_price(platform, price, side="BUY"):
    """Adjust price for platform-specific fees"""
    FEES = {
        "polymarket": {"winner_fee": 0.02, "maker_rebate": 0.00},
        "kalshi": {"winner_fee": 0.01, "maker_rebate": 0.00},
        "manifold": {"winner_fee": 0.00, "maker_rebate": 0.00},
        "predictit": {"winner_fee": 0.10, "withdrawal_fee": 0.05}
    }

    fee = FEES.get(platform, {"winner_fee": 0.02})

    if side == "BUY":
        # Effective cost = price + (expected fee on winning)
        effective = price + (1 - price) * fee["winner_fee"]
    else:
        effective = price - price * fee["winner_fee"]

    return round(effective, 4)
```

## Migration Strategy

```
WHEN TO MIGRATE:

Polymarket edge dies → Move to:
1. Kalshi (if you have US access)
   - More regulated = fewer bots = more edge for humans
   - Market making viable (less competition)
   - Political events overlap with Polymarket

2. Manifold (for practice/R&D)
   - Free (play money)
   - Test new strategies risk-free
   - Good for calibration practice

3. New platforms (watch for):
   - Hedgehog Markets (Solana-based)
   - Azuro (sports prediction, decentralized)
   - Overtime Markets (sports, Optimism)

Code portability:
- Signal detection: 90% reusable (just change API adapter)
- Risk management: 100% reusable (platform-agnostic)
- Dashboard: 100% reusable
- Execution: Need new API adapter per platform (~2 hours work)
```

## Combined Portfolio View

```python
class MultiPlatformPortfolio:
    """Unified portfolio across all platforms"""

    def __init__(self, poly_client, kalshi_client, manifold_client):
        self.clients = {
            "polymarket": poly_client,
            "kalshi": kalshi_client,
            "manifold": manifold_client
        }

    async def get_total_portfolio(self):
        """Aggregate positions across all platforms"""
        total = {"value": 0, "positions": [], "platforms": {}}

        for platform, client in self.clients.items():
            try:
                positions = await client.get_positions()
                platform_value = sum(p.get("value", 0) for p in positions)

                total["platforms"][platform] = {
                    "positions": len(positions),
                    "value": platform_value
                }
                total["value"] += platform_value

                for p in positions:
                    p["platform"] = platform
                    total["positions"].append(p)
            except Exception as e:
                total["platforms"][platform] = {"error": str(e)}

        return total

    async def check_cross_platform_exposure(self):
        """Detect if same event is traded on multiple platforms"""
        portfolio = await self.get_total_portfolio()
        events = {}

        for pos in portfolio["positions"]:
            title = pos.get("title", "").lower()
            key = title[:30]  # Group by first 30 chars
            events.setdefault(key, []).append(pos)

        duplicates = {k: v for k, v in events.items() if len(v) > 1}
        return duplicates
```

## Response Format: /kalshi or /manifold

```
## Multi-Platform Overview

### Portfolio Summary
| Platform | Positions | Value | Status |
|----------|-----------|-------|--------|
| Polymarket | 8 | $1,240 | ✅ Active |
| Kalshi | 3 | $450 | ✅ Active |
| Manifold | 12 | M$2,500 | ✅ Practice |

### Cross-Platform Arbitrage (Live)
| Event | Poly YES | Kalshi YES | Gap | Action |
|-------|----------|------------|-----|--------|
| "Fed cuts March" | 0.62 | 0.58 | 4.0% | Buy Kalshi, Sell Poly |
| "BTC >$200k" | 0.18 | 0.22 | 4.0% | Buy Poly, Sell Kalshi |

### Recommendations
- 2 arbitrage opportunities found (>3% gap)
- Total estimated profit: $XX if both resolve
```
