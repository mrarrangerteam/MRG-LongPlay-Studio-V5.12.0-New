# POLYMARKET APIs — Complete Reference

## API Ecosystem Overview

```
Polymarket has 3 main APIs:

1. GAMMA API (Market Discovery)
   URL: https://gamma-api.polymarket.com
   Auth: None required
   Use: Search markets, get metadata, events, pricing

2. CLOB API (Trading)
   URL: https://clob.polymarket.com
   Auth: API Key + Secret + EIP-712 signing
   Use: Place orders, cancel orders, get orderbook

3. CTF Exchange (On-Chain)
   Contract: 0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E
   Network: Polygon
   Use: Direct on-chain trading, position management
```

## 1. Gamma API (Market Data)

```python
import requests

GAMMA_URL = "https://gamma-api.polymarket.com"

class GammaAPI:
    """Polymarket market discovery and metadata"""

    def search_markets(self, query, limit=10):
        """Search for markets by keyword"""
        r = requests.get(f"{GAMMA_URL}/markets", params={
            "search": query, "limit": limit, "active": "true"
        })
        return r.json()

    def get_events(self, limit=50, category=None):
        """List events (groups of related markets)"""
        params = {"limit": limit, "active": "true"}
        if category:
            params["tag"] = category
        r = requests.get(f"{GAMMA_URL}/events", params=params)
        return r.json()

    def get_market(self, condition_id):
        """Get single market details"""
        r = requests.get(f"{GAMMA_URL}/markets/{condition_id}")
        return r.json()

    def get_negrisk_events(self, limit=100):
        """Get multi-outcome NegRisk events"""
        r = requests.get(f"{GAMMA_URL}/events", params={
            "neg_risk": "true", "active": "true", "limit": limit
        })
        return r.json()

    def get_market_history(self, condition_id, interval="1h"):
        """Get price history"""
        r = requests.get(f"{GAMMA_URL}/markets/{condition_id}/history",
                         params={"interval": interval})
        return r.json()
```

## 2. CLOB API (Trading)

```python
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import OrderArgs, OrderType

class PolymarketTrader:
    """Polymarket CLOB trading operations"""

    def __init__(self, api_key, api_secret, private_key):
        self.client = ClobClient(
            host="https://clob.polymarket.com",
            key=api_key,
            chain_id=137,  # Polygon
            funder=private_key
        )
        self.client.set_api_creds(
            self.client.create_or_derive_api_creds()
        )

    def get_orderbook(self, token_id):
        """Get current order book"""
        return self.client.get_order_book(token_id)

    def get_midpoint(self, token_id):
        """Get mid-price"""
        return self.client.get_midpoint(token_id)

    def place_limit_order(self, token_id, side, price, size):
        """Place a limit order"""
        order_args = OrderArgs(
            token_id=token_id,
            price=price,
            size=size,
            side=side  # "BUY" or "SELL"
        )
        signed = self.client.create_order(order_args)
        return self.client.post_order(signed, OrderType.GTC)

    def place_market_order(self, token_id, side, size):
        """Place a market order (immediate fill)"""
        order_args = OrderArgs(
            token_id=token_id,
            price=0.99 if side == "BUY" else 0.01,
            size=size,
            side=side
        )
        signed = self.client.create_order(order_args)
        return self.client.post_order(signed, OrderType.FOK)

    def cancel_order(self, order_id):
        """Cancel an open order"""
        return self.client.cancel(order_id)

    def cancel_all(self):
        """Cancel all open orders"""
        return self.client.cancel_all()

    def get_open_orders(self):
        """List all open orders"""
        return self.client.get_orders()

    def get_positions(self):
        """Get current positions"""
        return self.client.get_positions()

    def get_trades(self, limit=100):
        """Get recent trade history"""
        return self.client.get_trades(limit=limit)
```

## 3. WebSocket (Real-Time Data)

```python
import asyncio
import json
import websockets

WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

class PolymarketWebSocket:
    """Real-time market data streaming"""

    def __init__(self):
        self.ws = None
        self.callbacks = {}

    async def connect(self):
        self.ws = await websockets.connect(WS_URL)

    async def subscribe(self, market_ids, callback):
        """Subscribe to real-time updates for markets"""
        for mid in market_ids:
            self.callbacks[mid] = callback
            await self.ws.send(json.dumps({
                "type": "subscribe",
                "channel": "market",
                "market": mid
            }))

    async def listen(self):
        """Main listening loop"""
        async for message in self.ws:
            data = json.loads(message)
            market_id = data.get("market")

            if market_id and market_id in self.callbacks:
                await self.callbacks[market_id](data)

    async def run(self, market_ids, callback):
        """Connect, subscribe, and listen"""
        await self.connect()
        await self.subscribe(market_ids, callback)
        await self.listen()

# Usage
async def on_price_update(data):
    print(f"Market: {data['market']} | Price: {data.get('price')} | "
          f"Side: {data.get('side')} | Size: {data.get('size')}")

# asyncio.run(ws.run(["0xmarket1", "0xmarket2"], on_price_update))
```

## Order Types

```
GTC (Good Till Cancelled):
- Stays on book until filled or cancelled
- Best for: Limit orders, market making

FOK (Fill or Kill):
- Must fill entirely or cancel immediately
- Best for: Market orders, urgent execution

IOC (Immediate or Cancel):
- Fill what you can, cancel the rest
- Best for: Partial fills acceptable

GTD (Good Till Date):
- Expires at specific time
- Best for: Time-sensitive trades
```

## Rate Limits

```
Public endpoints (no auth):
- 60 requests/minute
- Orderbook, midpoint, market data

Authenticated endpoints:
- 100 requests/minute (standard)
- 300 requests/minute (market maker program)

WebSocket:
- No explicit rate limit
- Recommended: 1 connection per strategy

Gamma API:
- 100 requests/minute
- Cache aggressively (TTL 60s for market data)

Best practices:
1. Use WebSocket for real-time data (no rate limit)
2. Cache Gamma API responses (60s TTL)
3. Batch cancel orders when possible
4. Use exponential backoff on 429 errors
```

## EIP-712 Order Signing

```python
# Polymarket uses EIP-712 typed data for order signing
# py-clob-client handles this automatically, but here's the structure:

EIP712_DOMAIN = {
    "name": "Polymarket CTF Exchange",
    "version": "1",
    "chainId": 137,  # Polygon
    "verifyingContract": "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E"
}

ORDER_TYPE = {
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "taker", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "expiration", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "feeRateBps", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
    ]
}
```

## Error Handling

```python
import time
from functools import wraps

def retry_on_error(max_retries=3, backoff_factor=2):
    """Retry decorator with exponential backoff"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    wait = backoff_factor ** attempt
                    print(f"Retry {attempt+1}/{max_retries} in {wait}s: {e}")
                    await asyncio.sleep(wait)
        return wrapper
    return decorator

# Common error codes:
# 400: Bad request (invalid parameters)
# 401: Unauthorized (bad API key)
# 429: Rate limited (wait and retry)
# 500: Server error (retry with backoff)
```

## Quick Start: First Trade

```python
# Complete example: search market → place order

from py_clob_client.client import ClobClient
import requests

# 1. Find a market
gamma = requests.get("https://gamma-api.polymarket.com/markets",
    params={"search": "Bitcoin", "active": "true", "limit": 5}
).json()

market = gamma[0]
token_id = market["clobTokenIds"][0]  # YES token
print(f"Market: {market['question']}")
print(f"YES price: {market['outcomePrices'][0]}")

# 2. Setup trader
trader = ClobClient(
    host="https://clob.polymarket.com",
    key="YOUR_API_KEY",
    chain_id=137,
    funder="YOUR_PRIVATE_KEY"
)

# 3. Place order
order = trader.create_order(OrderArgs(
    token_id=token_id,
    price=0.25,  # Buy YES at 25¢
    size=10,     # $10 worth
    side="BUY"
))
result = trader.post_order(order)
print(f"Order placed: {result}")
```
