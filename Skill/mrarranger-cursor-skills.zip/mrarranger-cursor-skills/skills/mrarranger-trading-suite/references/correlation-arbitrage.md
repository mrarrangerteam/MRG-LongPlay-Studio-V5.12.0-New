# CORRELATION ARBITRAGE — Cross-Market Logic

## Types of Correlation

```
TYPE 1: LOGICAL (Subset/Superset)
"Trump wins 2028" → MUST be ≤ "Republican wins 2028"
ถ้า Trump YES = 0.40, Republican YES = 0.35 → ARBITRAGE
Action: Buy Republican YES, Sell Trump YES

TYPE 2: TEMPORAL (Sequential Events)
"Fed cuts rates in March" → increases prob of "S&P hits 6000 by June"
ถ้า Fed cut happens but S&P market hasn't adjusted → TRADE

TYPE 3: CAUSAL (Cause → Effect)
"Russia-Ukraine ceasefire" → increases "EU lifts sanctions" prob
ถ้า ceasefire market moves but sanctions market doesn't → TRADE

TYPE 4: NEGRISK INTERNAL (Multi-Outcome Relationships)
"BLAST Rotterdam Winner" — if Vitality eliminated, all their shares go to 0
→ remaining teams' probabilities must increase proportionally
```

## Logical Arbitrage Scanner

```python
class CorrelationScanner:
    """Detect mispriced correlated markets on Polymarket"""

    # Known logical relationships (maintain this list)
    LOGICAL_PAIRS = [
        {
            "parent": "Republican wins 2028 election",
            "child": "Trump wins 2028 election",
            "relationship": "child ≤ parent",
            "min_gap_pct": 3  # Trade when gap > 3%
        },
        {
            "parent": "Bitcoin above $150k EOY 2026",
            "child": "Bitcoin above $200k EOY 2026",
            "relationship": "child ≤ parent",
            "min_gap_pct": 2
        },
        {
            "parent": "Fed cuts rates 2026",
            "child": "Fed cuts rates in Q1 2026",
            "relationship": "child ≤ parent",
            "min_gap_pct": 2
        }
    ]

    def __init__(self, gamma_api):
        self.api = gamma_api

    async def scan_logical_arb(self):
        """Find logical arbitrage opportunities"""
        opportunities = []

        for pair in self.LOGICAL_PAIRS:
            parent_market = await self.api.search_market(pair["parent"])
            child_market = await self.api.search_market(pair["child"])

            if not parent_market or not child_market:
                continue

            parent_price = float(parent_market["yes_price"])
            child_price = float(child_market["yes_price"])

            # Check violation: child should NEVER be more than parent
            if child_price > parent_price:
                gap = child_price - parent_price
                gap_pct = gap * 100

                if gap_pct >= pair["min_gap_pct"]:
                    opportunities.append({
                        "type": "LOGICAL_ARB",
                        "parent": pair["parent"],
                        "child": pair["child"],
                        "parent_price": parent_price,
                        "child_price": child_price,
                        "gap": round(gap, 4),
                        "gap_pct": round(gap_pct, 2),
                        "action": f"BUY '{pair['parent']}' YES @ {parent_price:.2f}, "
                                  f"SELL '{pair['child']}' YES @ {child_price:.2f}",
                        "guaranteed_profit": True
                    })

        return opportunities
```

## LLM-Based Correlation Discovery

```python
CORRELATION_PROMPT = """
Analyze these two Polymarket markets for correlation:

Market A: "{market_a_title}" — YES price: {price_a}
Market B: "{market_b_title}" — YES price: {price_b}

Questions:
1. Are these markets logically correlated? (subset, causal, temporal)
2. If A resolves YES, what happens to B's probability? (increase/decrease/unchanged)
3. If A resolves NO, what happens to B's probability?
4. Is there a mispricing based on the correlation?
5. What's the confidence level of this correlation? (LOW/MEDIUM/HIGH)

Output JSON:
{{
    "correlated": true/false,
    "type": "logical/causal/temporal/none",
    "a_yes_impact_on_b": "+0.15",
    "a_no_impact_on_b": "-0.10",
    "mispriced": true/false,
    "direction": "B too low/B too high/fair",
    "confidence": "MEDIUM",
    "reasoning": "explanation"
}}
"""

async def discover_correlations(markets, llm_client):
    """Use LLM to find non-obvious correlations between markets"""
    pairs_to_check = []

    # Generate pairs from similar categories
    categories = {}
    for m in markets:
        cat = m.get("category", "other")
        categories.setdefault(cat, []).append(m)

    for cat, cat_markets in categories.items():
        for i, a in enumerate(cat_markets):
            for b in cat_markets[i+1:]:
                pairs_to_check.append((a, b))

    results = []
    for market_a, market_b in pairs_to_check[:50]:  # Limit API calls
        prompt = CORRELATION_PROMPT.format(
            market_a_title=market_a["question"],
            price_a=market_a["yes_price"],
            market_b_title=market_b["question"],
            price_b=market_b["yes_price"]
        )

        response = await llm_client.complete(prompt)
        parsed = json.loads(response)

        if parsed.get("mispriced") and parsed.get("confidence") != "LOW":
            results.append({
                "market_a": market_a["question"][:60],
                "market_b": market_b["question"][:60],
                **parsed
            })

    return results
```

## NegRisk Internal Correlation

```python
def check_negrisk_rebalance(event, eliminated_outcome):
    """
    When one NegRisk outcome is eliminated (goes to 0),
    the remaining outcomes must absorb that probability.

    If market doesn't adjust fast enough → trade opportunity
    """
    remaining = [m for m in event["markets"] if m["id"] != eliminated_outcome["id"]]

    # Pre-elimination: all outcomes summed
    old_sum = sum(float(m["yes_price"]) for m in event["markets"])

    # Post-elimination: remaining should sum to ~1.0
    new_sum = sum(float(m["yes_price"]) for m in remaining)

    # Gap = probability that hasn't been redistributed yet
    gap = 1.0 - new_sum

    if gap > 0.03:  # >3% not redistributed
        # Find which outcomes should gain the most
        # Proportional to their current probability
        recommendations = []
        for m in remaining:
            current = float(m["yes_price"])
            expected_gain = gap * (current / new_sum) if new_sum > 0 else gap / len(remaining)
            recommendations.append({
                "market": m["question"][:40],
                "current": current,
                "expected": round(current + expected_gain, 4),
                "edge": round(expected_gain * 100, 2)
            })

        return {
            "type": "NEGRISK_REBALANCE",
            "eliminated": eliminated_outcome["question"][:40],
            "gap": round(gap, 4),
            "gap_pct": round(gap * 100, 2),
            "recommendations": sorted(recommendations, key=lambda x: x["edge"], reverse=True)
        }

    return None
```

## Response Format: /corr

```
## Correlation Arbitrage Scan — [date]

### 🔴 LOGICAL ARB (Guaranteed)
Parent: "Republican wins 2028" @ 0.42
Child: "Trump wins 2028" @ 0.45
Gap: 3.0% — Child > Parent = VIOLATION
Action: Buy Parent YES, Sell Child YES
→ Guaranteed profit: $0.03 per share

### 🟡 CAUSAL CORRELATION (High Confidence)
Market A: "Fed cuts March" @ 0.65
Market B: "S&P above 6000 by June" @ 0.30
If A → YES: B should be ~0.40 (currently 0.30)
Edge: 10% underpriced
Action: If A resolves YES → immediately buy B

### 🟢 NEGRISK REBALANCE
Event: "BLAST Rotterdam Winner"
Eliminated: Team X (went 0-3)
Remaining gap: 5.2% not redistributed
Top plays:
- Vitality: 0.52 → expected 0.55 (+3.0%)
- FaZe: 0.20 → expected 0.22 (+2.2%)
```

## Risks

```
1. Resolution edge cases: markets may not resolve as logically expected
2. Illiquidity: correlated market may have thin order book
3. Timing: correlation may take days/weeks to correct
4. LLM errors: AI may identify false correlations
5. Transaction costs: need gap > fee to profit

Rule: Only trade correlations with gap > 3% AND liquidity > $5,000 both sides
```
