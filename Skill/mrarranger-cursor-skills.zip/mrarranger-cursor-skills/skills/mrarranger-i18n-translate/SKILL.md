---
name: mrarranger-i18n-translate
description: "MRARRANGER Internationalization and Translation - Multi-language Translation, Localization Strategy, i18n Implementation (React-intl, next-intl, i18next), RTL Support, Date/Time/Currency Formatting, Locale Management, Translation Memory, Glossary Management, Cultural Adaptation, SEO Multilingual (hreflang), App Store Localization, String Extraction, Machine Translation Post-editing, Quality Assurance (LQA). Commands: /translate /localize /i18n /rtl /locale /glossary /hreflang /l10n /lqa. Triggers: translation, localize, i18n, multilingual, RTL, hreflang, localization"
---

# Internationalization & Localization Skill

## Overview

This skill provides comprehensive guidance on making products available globally through internationalization (i18n) and localization (l10n). It covers technical implementation, translation management, cultural adaptation, and quality assurance to ensure consistent, high-quality experiences across all languages and regions.

## Core Competencies

### 1. Multi-Language Translation Strategy

**Translation Overview**

**Terminology**:
- **Internationalization (i18n)**: Making product structure language-agnostic
- **Localization (l10n)**: Adapting content, design, and functionality to specific locale
- **Locale**: Language + region (e.g., en-US, fr-FR, pt-BR)
- **Source Language**: Original language (usually English)
- **Target Language**: Language being translated to

**Translation Approaches**

**Human Translation**:
- **Professional Translators**: High quality, expensive, slow
- **Native Speakers**: Good quality, affordable, variable speed
- **Community Translation**: Crowdsourced, free, variable quality (Crowdin, Weblate)
- **Cost**: $0.05-0.30 per word depending on quality

**Machine Translation**:
- **Google Translate**: Free, fast, decent quality for common language pairs
- **DeepL**: Higher quality, paid API
- **Microsoft Translator**: Quality varies, API available
- **OpenAI/Claude**: Excellent for context, expensive, slow
- **Post-editing**: Human review of machine output (faster/cheaper than full translation)

**Hybrid Approach** (Recommended):
- Machine translate for speed/cost
- Professional review for quality-critical content
- Crowdsource for large volumes and community languages
- Community feedback for continuous improvement

**Language Prioritization**

**Selection Criteria**:
- **Market Size**: How many speakers in target regions?
- **Revenue Potential**: Expected revenue from language group
- **Competitive Presence**: Are competitors in market?
- **Technical Difficulty**: Languages like Arabic (RTL) need extra work
- **User Requests**: Direct feedback from users

**Phased Rollout**:
1. **Phase 1**: Top 3-5 languages (80% of potential users)
   - Major languages by speakers (English, Mandarin, Spanish, Hindi, Portuguese)
   - Business-critical regions (major markets)
   - Languages with high revenue potential

2. **Phase 2**: Next 10-15 languages
   - Secondary markets
   - Emerging regions
   - User-requested languages

3. **Phase 3**: Long-tail and regional languages
   - Community-contributed
   - Crowdfunded
   - Lower priority

**Translation Quality Levels**

**Quality Tiers**:
- **T1 - Full Professional**: Native translator + reviewer + proofreader
  - Cost: $0.15-0.30 per word
  - Use for: UI critical path, marketing, legal
  - Timeline: 2-3 weeks for typical project

- **T2 - Professional Review**: Machine or native translator + professional reviewer
  - Cost: $0.08-0.15 per word
  - Use for: Core features, support docs
  - Timeline: 1-2 weeks

- **T3 - Native + Machine**: Professional native translator, no review
  - Cost: $0.05-0.10 per word
  - Use for: Secondary features, help text
  - Timeline: 1 week

- **T4 - Machine Assisted**: Machine translation + light review
  - Cost: $0.01-0.05 per word
  - Use for: Community forums, user-generated content
  - Timeline: 1-2 days

**Language-Specific Considerations**

**Right-to-Left (RTL) Languages**:
- Arabic, Hebrew, Farsi, Urdu
- Require design and layout changes
- Significant additional development effort
- See RTL Support section below

**Languages with Complex Scripts**:
- Chinese: Simplified vs Traditional, different character sets
- Japanese: Kanji, Hiragana, Katakana mixing
- Korean: Hangul (phonetic)
- Thai: No spaces between words, challenging hyphenation
- Require expertise in language and rendering

**Pluralization Rules**:
- English: singular/plural (1 item vs 2 items)
- French: Different rules for 0/1/>1
- Russian: Complex rules for different numbers
- Polish: Multiple plural forms
- Require conditional logic based on number and language

**String Length Variations**:
- English to German: Often 30% longer
- English to Chinese: Often 30% shorter
- Impacts UI design and layout
- Allow 30% extra space for growth

### 2. Localization Strategy & Cultural Adaptation

**Localization Beyond Translation**

**Dimensions of Localization**:
1. **Language**: Correct translation, grammar, tone
2. **Cultural**: Symbols, colors, images, holidays
3. **Format**: Date/time/number/currency formats
4. **Design**: Layout, whitespace, imagery
5. **Legal**: Privacy, terms, compliance by country
6. **Business**: Pricing, payment methods, shipping
7. **Regulatory**: Age ratings, content restrictions

**Cultural Considerations**

**Symbols & Colors**:
- Red: Luck in China, danger in West
- White: Purity in West, death in many Asian cultures
- Numbers: 4 is unlucky in Chinese (sounds like death)
- Thumbs up: Offensive in many cultures

**Imagery & Representation**:
- Use culturally appropriate images
- Represent diversity in team/customer photos
- Avoid stereotypes
- Respect cultural norms and dress
- Consider religious sensitivity

**Dates & Numbers**:
- UK: 31/12/2024 (DD/MM/YYYY)
- US: 12/31/2024 (MM/DD/YYYY)
- ISO: 2024-12-31 (YYYY-MM-DD) - preferred for code
- Numbers: 1.000,00 (comma as decimal in many European countries)

**Holidays & Celebrations**:
- Launch features for local holidays
- Be aware of major holidays (vary by culture)
- Customize messaging and promotions
- Respect religious observances

**Local Preferences**:
- Payment methods vary (not all accept credit cards)
- Currency and pricing strategies
- Shipping and delivery options
- Customer service hours and language support
- Legal age requirements (alcohol, gambling, etc.)

**Localization Audit** (before launch):

- [ ] All strings translated
- [ ] Date/time format correct for locale
- [ ] Currency display correct
- [ ] Number formatting correct (decimal separator)
- [ ] RTL layout (if applicable)
- [ ] Images culturally appropriate
- [ ] No hardcoded text in code
- [ ] Links point to localized pages
- [ ] Legal compliance verified
- [ ] Professional proofreading done

### 3. Internationalization Implementation

**i18n Architecture Principles**

**Core Concepts**:
- **Separation of Concerns**: Content separate from code
- **Single Source of Truth**: One set of translations per language
- **Dynamic Loading**: Load only needed language
- **Fallback**: Default language if translation missing
- **Scalability**: Easy to add new languages

**String Externalization**

**Hardcoded (Bad)**:
```javascript
const message = "Welcome to our app";
<h1>Hello User</h1>
```

**Externalized (Good)**:
```javascript
// en.json
{ "greeting": "Welcome to our app" }
// Component
<h1>{t('greeting')}</h1>
```

**Benefits**:
- Can be translated without code changes
- Single string used everywhere (consistency)
- Easy to find all strings needing translation
- Reuse strings across features

**i18n Library Comparison**

**React-intl** (Facebook/Meta):
- Powerful and feature-rich
- Components and hooks for formatting
- Date/time/number/relative-time formatting built-in
- Pluralization support
- Message formatting with variables
- Learning curve but comprehensive

**Example**:
```javascript
import { FormattedMessage, FormattedNumber } from 'react-intl';

<FormattedMessage
  id="greeting"
  defaultMessage="Hello {name}, you have {count} messages"
  values={{ name: 'John', count: 5 }}
/>

<FormattedNumber value={1000} style="currency" currency="USD" />
```

**next-intl** (Next.js):
- Purpose-built for Next.js
- Server-side rendering support
- Static generation with localized paths
- Middleware for locale detection
- Type-safe translations
- Simpler API than react-intl

**Example**:
```javascript
import {useTranslations} from 'next-intl';

export default function Page() {
  const t = useTranslations();
  return <h1>{t('greeting')}</h1>;
}
```

**i18next** (Flexible):
- Language-agnostic (works with React, Vue, vanilla JS)
- Namespace support (organize strings)
- Lazy loading
- Backend integration (dynamically fetch translations)
- Rich plugin ecosystem
- Growing popularity

**Example**:
```javascript
import { useTranslation } from 'react-i18next';

export default function Component() {
  const { t } = useTranslation('common');
  return <h1>{t('greeting')}</h1>;
}
```

**i18n Implementation Process**

**1. Choose Library**:
- Evaluate team expertise
- Framework compatibility
- Feature requirements
- Community support

**2. Set Up Infrastructure**:
- Install and configure library
- Create language files (JSON/YAML/etc)
- Configure available locales
- Set up fallback language

**3. Externalize Strings**:
- Identify all user-facing strings
- Create translation keys
- Replace hardcoded strings with i18n calls
- Test with fallback language

**4. Add Locale Switching**:
- Language selector in UI
- Store preference (localStorage, user account)
- Reload page or context update
- Persist across sessions

**5. Integration with Build Process**:
- Extract strings for translation (tooling)
- Validate translations (keys exist)
- Tree-shake unused translations
- Optimize bundle size

**Implementation Example** (React with i18next):

```javascript
// i18n/config.js
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n.use(initReactI18next).init({
  resources: {
    en: { translation: require('./locales/en.json') },
    es: { translation: require('./locales/es.json') },
    fr: { translation: require('./locales/fr.json') },
  },
  lng: 'en',
  fallbackLng: 'en',
  interpolation: { escapeValue: false },
});

// locales/en.json
{
  "greeting": "Hello {{name}}",
  "itemCount": {
    "one": "{{count}} item",
    "other": "{{count}} items"
  }
}

// Component
import { useTranslation } from 'react-i18next';

export default function Greeting() {
  const { t, i18n } = useTranslation();

  const changeLang = (lang) => i18n.changeLanguage(lang);

  return (
    <div>
      <h1>{t('greeting', { name: 'John' })}</h1>
      <button onClick={() => changeLang('es')}>Español</button>
      <button onClick={() => changeLang('fr')}>Français</button>
    </div>
  );
}
```

### 4. Right-to-Left (RTL) Support

**RTL Basics**

**Affected Languages**:
- Arabic (Arabic, Egyptian Arabic, Gulf Arabic, Moroccan Arabic)
- Hebrew
- Farsi (Persian)
- Urdu
- Pashto
- Sindhi

**User Base**: ~300+ million people globally

**Layout Considerations**

**CSS Approach** (Logical Properties):
- Use logical properties instead of physical (left/right)
- `margin-inline-start` instead of `margin-left`
- `padding-inline-end` instead of `padding-right`
- `inset-inline-start` instead of `left`

**Benefits**:
- Single CSS file works for LTR and RTL
- Automatic direction switching
- Future-proof

**Example**:
```css
/* LTR and RTL compatible */
.sidebar {
  margin-inline-start: 20px; /* left for LTR, right for RTL */
  border-inline-start: 2px solid blue; /* left for LTR, right for RTL */
}

.button {
  padding-inline: 12px; /* left+right padding */
}
```

**Legacy CSS Approach** (CSS-in-JS or Tooling):
```css
/* LTR */
.sidebar {
  margin-left: 20px;
  border-left: 2px solid blue;
}

/* RTL */
[dir="rtl"] .sidebar {
  margin-right: 20px;
  margin-left: 0;
  border-right: 2px solid blue;
  border-left: none;
}
```

**HTML Setup**:
```html
<!-- Automatic detection -->
<html dir="auto" lang="ar">

<!-- Explicit RTL -->
<html dir="rtl" lang="ar">

<!-- Explicit LTR -->
<html dir="ltr" lang="en">
```

**Flexbox & Grid** (Easier for RTL):
```css
.row {
  display: flex;
  justify-content: flex-end; /* Semantic: end = right in LTR, left in RTL */
}

.grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  /* Direction adjusts automatically */
}
```

**Design Considerations for RTL**

**Mirrored vs Unmirrored Elements**:
- **Mirrored**: Text, layout, navigation (flows right-to-left)
- **Unmirrored**: Logos, icons, images (fixed orientation)
- **Careful Mirroring**: Some icons mean different things reversed (e.g., undo/redo arrows)

**Navigation**:
- Menu items flow right-to-left
- Hamburger menu usually on right (not left)
- Breadcrumbs reverse order
- Pagination "next" on left (not right)

**Forms & Inputs**:
- Form labels on right
- Input fields text right-aligned
- Radio buttons/checkboxes on right
- Error messages on left side

**Text Direction**:
- Headings right-aligned
- Body text right-aligned
- Lists flow from right-to-left

**RTL Implementation in Code**

**Next.js Example**:
```javascript
// next.config.js
module.exports = {
  i18n: {
    locales: ['en', 'ar', 'fr'],
    defaultLocale: 'en',
  },
};

// pages/[locale]/index.js
export default function Page() {
  const { locale } = useRouter();
  const isRTL = locale === 'ar';

  return (
    <html dir={isRTL ? 'rtl' : 'ltr'} lang={locale}>
      {/* Content */}
    </html>
  );
}
```

**CSS-in-JS (Styled Components)**:
```javascript
const StyledDiv = styled.div`
  margin-inline-start: 20px;
  padding: 10px;
  border-inline-start: 2px solid blue;
`;
```

**Testing RTL**:
- Use browser DevTools to test direction
- Test with actual RTL content (not just direction change)
- Verify scrollbars, focus order
- Test with screen readers (announce direction properly)
- User testing with native speakers

### 5. Date, Time, Currency & Number Formatting

**Date Formatting**

**Locale-Specific Formats**:
- US: "12/31/2024"
- UK: "31/12/2024"
- ISO: "2024-12-31" (preferred for storage/code)
- France: "31/12/2024" or "31 décembre 2024"

**Implementation** (React-intl):
```javascript
import { FormattedDate, FormattedTime } from 'react-intl';

<FormattedDate value={new Date()} />
// Output (en-US): 12/31/2024

<FormattedDate
  value={new Date()}
  dateStyle="full"
/>
// Output (en-US): Wednesday, December 31, 2024

<FormattedTime value={new Date()} />
// Output (en-US): 3:45:30 PM
```

**Implementation** (JavaScript API - Intl):
```javascript
const date = new Date('2024-12-31');

const enUS = new Intl.DateTimeFormat('en-US');
console.log(enUS.format(date)); // 12/31/2024

const fr = new Intl.DateTimeFormat('fr-FR');
console.log(fr.format(date)); // 31/12/2024

const de = new Intl.DateTimeFormat('de-DE', {
  year: 'numeric',
  month: 'long',
  day: 'numeric'
});
console.log(de.format(date)); // 31. Dezember 2024
```

**Time Zone Handling**:
- Store times in UTC
- Display in user's time zone
- Allow time zone selection
- Be explicit about time zone in UI

```javascript
const date = new Date('2024-12-31T15:00:00Z'); // UTC

const formatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'America/New_York',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit'
});
console.log(formatter.format(date)); // 12/31/2024, 10:00 AM
```

**Relative Time**:
```javascript
import { FormattedRelativeTime } from 'react-intl';

<FormattedRelativeTime
  value={-5}
  unit="day"
/>
// Output: 5 days ago (en-US)
// Output: hace 5 días (es-ES)
```

**Number Formatting**

**Integer Numbers**:
- US: 1,000,000 (comma separator)
- France: 1 000 000 (space separator)
- Germany: 1.000.000 (period separator)
- India: 10,00,000 (different grouping)

```javascript
const formatter = new Intl.NumberFormat('en-US');
console.log(formatter.format(1000)); // 1,000

const formatterDE = new Intl.NumberFormat('de-DE');
console.log(formatterDE.format(1000)); // 1.000
```

**Decimal Numbers**:
- US: 3.14 (period as decimal)
- France: 3,14 (comma as decimal)
- Germany: 3,14 (comma as decimal)

```javascript
const formatter = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
console.log(formatter.format(3.1)); // 3.10

const formatterFR = new Intl.NumberFormat('fr-FR', {
  minimumFractionDigits: 2
});
console.log(formatterFR.format(3.1)); // 3,10
```

**Currency Formatting**

**Essential for E-commerce & Financial Apps**

```javascript
const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD'
});
console.log(formatter.format(1234.56)); // $1,234.56

const formatterEU = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR'
});
console.log(formatterEU.format(1234.56)); // 1.234,56 €

const formatterJP = new Intl.NumberFormat('ja-JP', {
  style: 'currency',
  currency: 'JPY'
});
console.log(formatterJP.format(1234.56)); // ¥1,235 (no decimals)
```

**Currency Conversion**:
- Use API for real-time rates (XE, Fixer.io, OpenExchangeRates)
- Cache rates (update daily)
- Display "as of" timestamp
- Allow user to change currency preference

### 6. Locale Management & Preferences

**Locale Detection**

**Sources** (in order of preference):
1. **User Selection**: Explicit choice (language selector)
2. **User Account**: Stored preference (if logged in)
3. **Browser Settings**: Accept-Language header
4. **Device Settings**: OS locale
5. **IP Geolocation**: Derive from user's IP
6. **Default**: Fallback locale (usually English)

**Implementation**:
```javascript
function detectLocale(req) {
  // 1. Check URL parameter
  if (req.query.lang) return req.query.lang;

  // 2. Check user account
  if (req.user?.preferredLocale) return req.user.preferredLocale;

  // 3. Check cookie
  if (req.cookies.locale) return req.cookies.locale;

  // 4. Parse Accept-Language header
  const acceptLanguage = req.headers['accept-language'];
  if (acceptLanguage) {
    const preferred = acceptLanguage.split(',')[0].trim();
    // "en-US" → validate and return
    return validateLocale(preferred);
  }

  // 5. Return default
  return 'en';
}
```

**Accept-Language Header**:
- Browser sends preferred languages
- Format: "en-US,en;q=0.9,es;q=0.8"
- Quality factor (q) indicates preference
- Server should respect order

**Storing Preferences**

**Options**:
- **Cookie**: Simple, persists across sessions, available on server
  - Set-Cookie: lang=es; Path=/; Max-Age=31536000
  - Read easily in code

- **localStorage**: Client-side, persists across sessions
  - localStorage.setItem('locale', 'es')
  - Must be set after page load

- **Database**: For authenticated users
  - User table with locale column
  - Sync across devices
  - Can be overridden by temporary selection

- **URL Query**: For anonymous/testing
  - ?lang=es or /es/ path structure
  - Session-based (no persistence)

**Best Practice**: Combine cookie + database for authenticated users

### 7. Translation Memory & Glossary Management

**Translation Memory (TM)**

**Purpose**:
- Store previously translated segments
- Reuse translations (consistency)
- Speed up future translations
- Leverage context from previous work

**Benefits**:
- Consistency across product
- Faster translation (avoid retranslating)
- Lower translation costs (fewer unique segments)
- Historical context (who translated, when)

**TM Structure**:
- Source segment (English)
- Target segment (translated)
- Metadata (translator, timestamp, context, domain)

**TM Tools**:
- **Crowdin**: Integrated TM with translation platform
- **Weblate**: Open-source with TM
- **Phrase (formerly Memsource)**: Enterprise TM
- **memoQ**: Specialized TM tool
- **Trados**: Industry standard

**TM Best Practices**:
- Clean TM (remove bad translations)
- Regular maintenance (remove outdated)
- Domain-specific TMs (separate tech from legal)
- Quality control (review before adding)
- Version control (track TM changes)

**Glossary Management**

**Purpose**:
- Maintain terminology consistency
- Define domain-specific terms
- Provide context for translators
- Prevent mistranslation of technical terms

**Glossary Contents**:
- Term (English)
- Translation (in each language)
- Definition
- Part of speech
- Context/usage example
- Category (technical, marketing, legal)
- Approved/forbidden alternates

**Example Glossary Entry**:
```
Term: Dashboard
Part of Speech: Noun
Definition: Main page showing overview of key metrics
Spanish: Panel de control
French: Tableau de bord
German: Instrumententafel
Chinese (Simplified): 仪表板
Context: "Welcome to your dashboard"
Forbidden: Substitute "Board" or "Control panel"
Category: UI/UX
Created: 2023-01-15
```

**Glossary Tools**:
- **Crowdin Glossary**: Integrated with Crowdin
- **Phrase Glossary**: Part of Phrase platform
- **Sheet2TM**: Convert spreadsheet to TM
- **Excel/Google Sheets**: DIY (spreadsheet-based)
- **Terminology Software**: memoQ, Trados

**Managing Glossary Across Teams**:
- Single source of truth
- Regular updates (quarterly review)
- Translator access
- Marketing approval for branding terms
- Technical validation for technical terms
- Version control and change history

### 8. Cultural Adaptation & Localization Strategy

**Content Adaptation**

**Legal & Compliance**:
- Privacy policies (GDPR for EU, CCPA for CA)
- Terms of service (region-specific variations)
- Data residency requirements (where data stored)
- Age restrictions and ratings (PEGI, ESRB, etc.)
- Currency and tax requirements

**Examples**:
- GDPR (EU): Explicit consent for data collection
- China: Specific content restrictions and censorship
- Saudi Arabia: Cultural and religious considerations
- Brazil: Portuguese (not Spanish)
- Singapore: Simplified Chinese or English

**Marketing & Messaging**:
- Adapt value propositions to local needs
- Use local references and examples
- Respect local holidays and events
- Avoid direct translation of idioms
- Consider local sense of humor
- Highlight local team/community

**User Interface Adaptation**:
- Color schemes (cultural color meanings)
- Icons and symbols (may have different meanings)
- Images (use culturally relevant photos)
- Layout (accommodate RTL, different text lengths)
- Forms (local address formats, phone numbers)

**Customer Service Adaptation**:
- Local support hours (not 9-5 ET)
- Local language support (not just English)
- Cultural communication styles (formal vs informal)
- Payment methods (cards not universal)
- Local holidays (support availability)

**Testing Localized Content**

**Before Launch**:
- [ ] Professional proofreading by native speaker
- [ ] Cultural review (avoid offensive content)
- [ ] Functional testing (all features work in locale)
- [ ] Visual testing (text length, layout, images)
- [ ] Link testing (point to localized pages)
- [ ] Date/time/currency formatting correct
- [ ] Compliance review (legal, privacy, regulatory)
- [ ] User acceptance testing (native speakers)

### 9. SEO for Multilingual Sites

**hreflang Implementation**

**Purpose**:
- Tell search engines which language version to show
- Prevent duplicate content penalties
- Help users find right language version
- Improve rankings in each language

**hreflang Syntax**:
```html
<!-- English (US) page -->
<link rel="alternate" hreflang="en-US"
      href="https://example.com/en-us/page" />
<link rel="alternate" hreflang="es"
      href="https://example.com/es/page" />
<link rel="alternate" hreflang="fr"
      href="https://example.com/fr/page" />

<!-- Self-reference (required) -->
<link rel="alternate" hreflang="en-US"
      href="https://example.com/en-us/page" />
```

**Alternative Languages**:
- Subdomain: en.example.com, es.example.com
- Subdirectory: example.com/en/, example.com/es/
- Query parameter: example.com/?lang=es (not recommended)
- Different domain: example.com, example.es, example.fr

**hreflang Placement Options**:
1. **HTML Head** (simplest, recommended for <100 languages)
2. **XML Sitemap** (scale to many languages)
3. **HTTP Headers** (for non-HTML content)

**XML Sitemap Example**:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xhtml="http://www.w3.org/1999/xhtml">
  <url>
    <loc>https://example.com/en/page</loc>
    <xhtml:link rel="alternate" hreflang="en"
      href="https://example.com/en/page" />
    <xhtml:link rel="alternate" hreflang="es"
      href="https://example.com/es/page" />
    <xhtml:link rel="alternate" hreflang="fr"
      href="https://example.com/fr/page" />
  </url>
</urlset>
```

**Multilingual SEO Best Practices**

**URL Structure**:
- Use language/region in URL (clear to search engines)
- Subdirectory: example.com/es/ (recommended)
- Subdomain: es.example.com (also works)
- Consistent structure across languages

**Content Localization for SEO**:
- Translate page titles and meta descriptions
- Localize keywords (different search behavior by language)
- Use local content and examples
- Link between language versions (internal links)
- Translate image alt text

**Keyword Research by Language**:
- Different keywords in different languages
- Search volume varies (some regions search less)
- Use local SEO tools (Google Trends, Ahrefs in local language)
- Avoid direct keyword translation (search behavior differs)

**Technical SEO**:
- Set Content-Language HTTP header
- Use lang attribute in HTML tag
- Proper character encoding (UTF-8)
- Mobile optimization for all languages
- Fast loading in all regions (CDN)

### 10. App Store Localization

**Importance**:
- Apple App Store and Google Play support 40+ languages
- Localization correlates with downloads
- Required for some countries (China, Japan)

**App Store Metadata to Localize**

**App Name**:
- Often kept same across languages (brand consistency)
- Sometimes adapted (marketing advantage)
- May be shortened due to character limits

**Subtitle** (iOS):
- Highlight key feature
- Localize for relevance
- 30 character limit

**Description**:
- Sell the app (why should they download)
- Highlight key benefits
- Keep concise (most users skim)
- Include keywords
- 4000 character limit (iOS)

**Keywords**:
- Most important for discoverability
- Research local search terms
- 10 keywords per language
- Separate with commas

**Screenshot Text & Images**:
- Translating screenshots (hard to do post-release)
- Consider generic/language-free screenshots
- Or overlay text in multiple languages
- Images should be culturally relevant

**Release Notes**:
- What's new in this version
- Localize changes/fixes
- Keep brief and exciting
- Use bullet points

**Example Localization** (iOS):

EN:
- Name: "Photo Editor Pro"
- Subtitle: "Professional photo editing tools"
- Keywords: photo, editor, filter, effect, image

ES:
- Name: "Photo Editor Pro" (or "Editor de Fotos Pro")
- Subtitle: "Herramientas profesionales de edición de fotos"
- Keywords: fotos, editor, filtro, efecto, imagen

**Rating & Age Gates**:
- Different age requirements by country
- Content description (violence, language, etc.)
- Localize rating descriptions
- Affects distribution in some countries

### 11. String Extraction & Management

**Identifying Strings to Translate**

**What to Extract**:
- All user-facing text (UI labels, buttons, messages)
- Error messages
- Help text and tooltips
- Placeholders and form labels
- Email subject lines and templates
- Dynamic content (with variables)

**What NOT to Extract**:
- Code comments (not visible to users)
- Debug messages
- Development/test content
- Variable names (internal)
- Constants (internal use only)

**Manual String Extraction**

**Process**:
1. Review all user-facing content
2. Create unique keys for each string
3. Write to translation file (JSON, YAML, CSV)
4. Replace hardcoded strings with key references
5. Test with fallback language
6. Validate all keys used

**Example** (before and after):

Before:
```javascript
export function LoginForm() {
  return (
    <form>
      <label>Email Address</label>
      <input placeholder="Enter your email" />
      <button>Sign In</button>
      <p>Don't have an account? <a href="/signup">Create one</a></p>
    </form>
  );
}
```

After:
```javascript
// en.json
{
  "form.email.label": "Email Address",
  "form.email.placeholder": "Enter your email",
  "form.submit": "Sign In",
  "form.signup.prompt": "Don't have an account?",
  "form.signup.link": "Create one"
}

// Component
export function LoginForm() {
  const { t } = useTranslation();
  return (
    <form>
      <label>{t('form.email.label')}</label>
      <input placeholder={t('form.email.placeholder')} />
      <button>{t('form.submit')}</button>
      <p>{t('form.signup.prompt')} <a href="/signup">{t('form.signup.link')}</a></p>
    </form>
  );
}
```

**Automated String Extraction**

**Tools**:
- **i18next-scanner**: Finds i18next calls in code, generates translation keys
- **Babel Plugins**: Extract from React components
- **ESLint Plugins**: Warn about missing translations
- **Build Tool Plugins**: Webpack, Vite, Next.js

**i18next-scanner Example**:
```bash
i18next-scanner --config i18next-scanner.config.js
```

This scans code and generates/updates translation files automatically.

**Translation File Management**:
- Store in version control
- One file per language
- Consistent format (JSON, YAML)
- Clear structure/keys
- Complete coverage (all keys in all languages)

### 12. Machine Translation & Post-Editing

**Machine Translation Workflow**

**Typical Process**:
1. Content ready (strings extracted, glossary prepared)
2. Machine translate (Google Translate, DeepL, etc.)
3. Post-edit (human review and correction)
4. QA (proof reading, testing)
5. Publish

**Cost Savings**:
- Machine + post-edit: 40-60% cheaper than human
- Faster turnaround (hours vs weeks)
- Good for high-volume content
- Trade-off: Quality may be lower

**When to Use Machine Translation**:
- High volume, lower stakes content
- Community forums and user-generated
- Support documents and FAQs
- Marketing with review
- Content that updates frequently

**When NOT to Use**:
- Brand voice and marketing copy
- Legal documents
- Safety-critical content
- Content needing cultural adaptation
- Customer-facing critical paths

**Popular MT Services**:
- **Google Translate**: Free, decent quality
- **DeepL**: Better quality, paid API
- **Microsoft Translator**: Enterprise integration
- **OpenAI/Claude**: Excellent quality, expensive

**Post-Editing Best Practices**

**Reviewer Qualifications**:
- Native speaker of target language
- Understands domain/subject matter
- Familiar with product and brand voice
- Not necessarily professional translator (cheaper)

**Review Checklist**:
- [ ] Accuracy (correct meaning)
- [ ] Terminology (uses glossary terms)
- [ ] Grammar and spelling
- [ ] Brand voice (tone and style)
- [ ] Cultural appropriateness
- [ ] Formatting preserved
- [ ] Variables/placeholders intact
- [ ] No missing or extra content

**Turnaround Time**:
- Machine translation: 1-5 minutes
- Post-edit review: 1-2 hours per 1000 words
- Total: 2-4 hours for typical feature

### 13. Quality Assurance & Testing (LQA)

**Linguistic Quality Assurance (LQA)**

**Purpose**: Ensure translation quality before launch

**LQA Testing Areas**:
- Translation accuracy and completeness
- Terminology consistency
- Grammar and punctuation
- Formatting and layout
- Cultural appropriateness
- Functional testing in-app
- Links and navigation

**LQA Process** (In-country review):

1. **Functional Testing**:
   - Install app/run site with language active
   - Navigate all features
   - Test all content paths
   - Check date/time/currency formatting
   - Verify special characters and accents

2. **Translation Validation**:
   - Read all text naturally (not just keys)
   - Check for consistency (same term used same way)
   - Verify terminology against glossary
   - Test variable substitution (names, numbers)

3. **Cultural & Context Review**:
   - Check for culturally inappropriate content
   - Verify currency and measurement units
   - Confirm date/time formats
   - Review imagery (culturally appropriate)
   - Check icons (correct meaning)

4. **Documentation**:
   - Issues logged with severity
   - Screenshots or videos of issues
   - Suggested corrections
   - Context and location info

**Common QA Issues**

**Translation Issues**:
- Mistranslated terms (especially homonyms)
- Inconsistent terminology
- Awkward phrasing
- Over-translated (too literal)
- Missing context (needs clarification)

**Technical Issues**:
- Text overflow (UI layout breaks)
- Truncated text
- Variables not substituted
- Encoding issues (special characters broken)
- RTL layout issues

**Contextual Issues**:
- Outdated content (old references)
- Wrong context applied
- Cultural insensitivity
- Inappropriate tone
- Formatting lost (bold, italics, etc.)

**QA Metrics**

**Tracking Quality**:
- Issues per 1000 words
- Defect severity (critical, major, minor)
- Time to fix
- Repeat issues (indicate process problem)
- Reviewer agreement (multiple reviewers?)

**Quality Standards**:
- Critical issues: 0 (must fix)
- Major issues: <2 per 1000 words
- Minor issues: <5 per 1000 words
- Overall: 95%+ accuracy target

**Continuous Improvement**:
- Review common issues
- Update glossary/TM
- Retrain translators
- Improve process
- Measure improvement

## Quick Reference

### Common Commands & Triggers
- `/translate` - Multi-language translation strategy
- `/localize` - Localization and cultural adaptation
- `/i18n` - Internationalization implementation
- `/rtl` - Right-to-left language support
- `/locale` - Locale detection and management
- `/glossary` - Glossary and terminology management
- `/hreflang` - SEO for multilingual sites
- `/l10n` - Localization and app store
- `/lqa` - Quality assurance and testing

## Conclusion

Successful internationalization requires both technical implementation and strategic planning around translation, localization, and quality. By adopting systematic approaches to string management, translation workflows, and cultural adaptation, products can serve global audiences with consistent, high-quality experiences across languages and regions.
