# mrarranger-content

**Source:** `/mnt/skills/user/mrarranger-content/SKILL.md`
**Size:** 3980 bytes

---

---
name: mrarranger-content
description: MRARRANGER Content Writer - ระบบสร้าง Content ทุกรูปแบบ (Blog, Article, Newsletter, Email). ใช้เมื่อ (1) เขียนบทความ/Blog (2) สร้าง Newsletter (3) เขียน Email Marketing (4) สร้าง Landing Page Copy (5) เขียน Script YouTube/Podcast. Commands /blog /email /newsletter /landing /script
---

# MRARRANGER Content Writer

## Quick Commands

| Command | ใช้งาน | Output |
|---------|--------|--------|
| `/blog [หัวข้อ]` | เขียนบทความ | Blog post พร้อม SEO |
| `/email [วัตถุประสงค์]` | Email Marketing | Email sequence 3-5 ฉบับ |
| `/newsletter [หัวข้อ]` | Newsletter | Newsletter พร้อม CTA |
| `/landing [สินค้า/บริการ]` | Landing Page | Copy ครบทุก section |
| `/script [หัวข้อ]` | Script Video/Podcast | Script พร้อม timestamps |

## Content Frameworks

### Blog Post Structure
```
1. Hook (จับใจภายใน 3 วินาที)
2. Problem (ปัญหาที่ผู้อ่านมี)
3. Agitation (ขยายปัญหา)
4. Solution (วิธีแก้)
5. Proof (หลักฐาน/ตัวอย่าง)
6. CTA (สิ่งที่ต้องทำต่อ)
```

### Email Sequence (5 Emails)
```
Email 1: Welcome + Value
Email 2: Story + Problem
Email 3: Solution + Social Proof
Email 4: Objection Handling
Email 5: Offer + Urgency
```

### Newsletter Format
```
📌 Subject Line (ต้อง < 50 ตัวอักษร, สร้างความอยากรู้)
👋 Personal Opening (1-2 ประโยค)
🎯 Main Value (เนื้อหาหลัก 80%)
💡 Quick Tips/Insights
🔗 Resources/Links
✅ Single CTA
```

### Landing Page Sections
```
1. Hero (Headline + Subheadline + CTA)
2. Problem Section
3. Solution/Features
4. Social Proof (Testimonials)
5. How It Works
6. Pricing/Offer
7. FAQ
8. Final CTA
```

### Script Structure (YouTube/Podcast)
```
[0:00-0:30] Hook - จับความสนใจ
[0:30-1:00] Intro - แนะนำตัว/หัวข้อ
[1:00-X:00] Main Content - เนื้อหาหลัก
[X:00-X:30] Recap - สรุป
[X:30-END] CTA - Subscribe/Like/Comment
```

## Writing Style Options

เมื่อสร้าง content ให้ถามหรือตรวจจับ style ที่ต้องการ:

| Style | ลักษณะ | เหมาะกับ |
|-------|--------|---------|
| Professional | ทางการ, มีข้อมูล | B2B, Corporate |
| Casual | เป็นกันเอง, สนุก | B2C, Lifestyle |
| Educational | สอน, อธิบาย | Course, Tutorial |
| Storytelling | เล่าเรื่อง, อารมณ์ | Brand, Personal |
| Persuasive | โน้มน้าว, ขาย | Sales, Marketing |

## SEO Integration

ทุก Blog/Article ต้องมี:
- **Title**: มี keyword หลัก, < 60 ตัวอักษร
- **Meta Description**: 150-160 ตัวอักษร, มี CTA
- **Headers**: H1 (1), H2 (3-5), H3 (ตามความเหมาะสม)
- **Keywords**: หลัก 1, รอง 3-5
- **Internal Links**: 2-3 links
- **Image Alt Text**: descriptive, มี keyword

## Output Format

ทุก content ต้อง output เป็น:
1. **Markdown file** (.md) - สำหรับใช้งานทั่วไป
2. **Plain text** - สำหรับ copy/paste
3. **Metadata** - SEO info, word count, reading time

## Chain Integration

Content skill เชื่อมต่อกับ skills อื่น:
```
/blog → mrarranger-social (แปลงเป็น social posts)
/script → mrarranger-visual (สร้าง storyboard)
/newsletter → mrarranger-seo (optimize)
```