# mrarranger-mass-production

**Source:** `/mnt/skills/user/mrarranger-mass-production/SKILL.md`
**Size:** 11864 bytes

---

---
name: mrarranger-mass-production
description: "MRARRANGER Universal Mass Production - สร้าง Content จำนวนมาก (10-1000+) สำหรับทุก AI Platform. รองรับ Music (Suno Udio Soundraw) Image (Midjourney Leonardo Flux DALL-E Ideogram Stable Diffusion) Video (Sora Veo3 Kling Runway Pika Luma Haiper Minimax) และ AI ใหม่ๆ ทุกตัว. Export เป็น .md .json .txt .csv. ใช้เมื่อต้องการ batch สร้าง content จำนวนมากในครั้งเดียว"
---

# 🚀 MRARRANGER Universal Mass Production

สร้าง Content จำนวนมากสำหรับ **ทุก AI Platform** | Auto-Learn New Platforms

## Core Philosophy

```yaml
principle_1: "UNIVERSAL SUPPORT"
  - รองรับทุก AI Platform ที่มีอยู่
  - เรียนรู้ Platform ใหม่อัตโนมัติ

principle_2: "ONE COMMAND, MASS OUTPUT"
  - สั่งครั้งเดียว ได้ 10-1000+ items
  - Export พร้อมใช้กับ Automation

principle_3: "FLEXIBLE FORMAT"
  - รองรับทุก output format
  - ปรับตาม platform ที่ใช้
```

## Quick Start

```
/mass [จำนวน] [ประเภท] [platform] "[style]"
```

### Examples
```
/mass 100 music suno "Soft Pop Rock"
/mass 50 image midjourney "Cyberpunk City"
/mass 30 video sora "Cinematic Nature"
/mass 200 image flux "Anime Portrait"
```

---

## 📋 SUPPORTED PLATFORMS (ทั้งหมด)

### 🎵 MUSIC PLATFORMS

| Platform | Type | Output | Status |
|----------|------|--------|--------|
| **Suno** | Music Gen | .md, .json | ✅ Full Support |
| **Udio** | Music Gen | .md, .json | ✅ Full Support |
| **Soundraw** | Music Gen | .json | ✅ Supported |
| **AIVA** | Music Gen | .json | ✅ Supported |
| **Mubert** | Music Gen | .json | ✅ Supported |
| **Boomy** | Music Gen | .md | ✅ Supported |
| **Loudly** | Music Gen | .json | ✅ Supported |
| **[New Platform]** | Auto | Auto | 🔄 Auto-Learn |

### 🖼️ IMAGE PLATFORMS

| Platform | Type | Output | Status |
|----------|------|--------|--------|
| **Midjourney** | Image Gen | .md, .txt | ✅ Full Support |
| **DALL-E 3** | Image Gen | .json, .md | ✅ Full Support |
| **Stable Diffusion** | Image Gen | .json | ✅ Full Support |
| **Leonardo AI** | Image Gen | .json, .md | ✅ Full Support |
| **Flux** | Image Gen | .md, .txt | ✅ Full Support |
| **Ideogram** | Image Gen | .md, .txt | ✅ Full Support |
| **Nano Banana** | Image Gen | .md, .txt | ✅ Full Support |
| **Adobe Firefly** | Image Gen | .md | ✅ Supported |
| **Playground AI** | Image Gen | .md | ✅ Supported |
| **Canva AI** | Image Gen | .md | ✅ Supported |
| **Microsoft Designer** | Image Gen | .md | ✅ Supported |
| **Grok (xAI)** | Image Gen | .md, .json | ✅ Supported |
| **Meta AI** | Image Gen | .md | ✅ Supported |
| **Google Imagen** | Image Gen | .json | ✅ Supported |
| **[New Platform]** | Auto | Auto | 🔄 Auto-Learn |

### 🎬 VIDEO PLATFORMS

| Platform | Type | Output | Status |
|----------|------|--------|--------|
| **Sora (OpenAI)** | Video Gen | .md, .json | ✅ Full Support |
| **Veo 3 (Google)** | Video Gen | .md, .json | ✅ Full Support |
| **Kling AI** | Video Gen | .md, .json | ✅ Full Support |
| **Runway Gen-3** | Video Gen | .md, .json | ✅ Full Support |
| **Pika Labs** | Video Gen | .md, .txt | ✅ Full Support |
| **Luma Dream Machine** | Video Gen | .md, .json | ✅ Full Support |
| **Haiper** | Video Gen | .md, .txt | ✅ Supported |
| **Minimax (Hailuo)** | Video Gen | .md, .json | ✅ Supported |
| **Invideo AI** | Video Gen | .md | ✅ Supported |
| **Synthesia** | Avatar Video | .json | ✅ Supported |
| **HeyGen** | Avatar Video | .json | ✅ Supported |
| **D-ID** | Avatar Video | .json | ✅ Supported |
| **Pixverse** | Video Gen | .md | ✅ Supported |
| **Genmo** | Video Gen | .md | ✅ Supported |
| **[New Platform]** | Auto | Auto | 🔄 Auto-Learn |

### 🗣️ VOICE/AUDIO PLATFORMS

| Platform | Type | Output | Status |
|----------|------|--------|--------|
| **ElevenLabs** | Voice Gen | .json, .txt | ✅ Full Support |
| **PlayHT** | Voice Gen | .json | ✅ Supported |
| **Murf AI** | Voice Gen | .json | ✅ Supported |
| **Speechify** | Voice Gen | .txt | ✅ Supported |
| **Resemble AI** | Voice Clone | .json | ✅ Supported |
| **[New Platform]** | Auto | Auto | 🔄 Auto-Learn |

### 🤖 MULTI-MODAL / OTHER

| Platform | Type | Output | Status |
|----------|------|--------|--------|
| **ChatGPT** | Text/Image | .md, .json | ✅ Supported |
| **Claude** | Text | .md | ✅ Supported |
| **Gemini** | Multi | .md, .json | ✅ Supported |
| **Grok** | Text/Image | .md, .json | ✅ Supported |
| **Perplexity** | Research | .md | ✅ Supported |
| **[New Platform]** | Auto | Auto | 🔄 Auto-Learn |

---

## 📁 OUTPUT FORMATS

### .md (Markdown) - Default
```markdown
## Item 001

**Prompt:**
Cyberpunk city at night, neon lights, rain-soaked streets, 
flying cars, holographic advertisements, cinematic lighting

**Parameters:**
- Aspect: 16:9
- Style: Cinematic
- Quality: HD

---

## Item 002
...
```

### .json (API Ready)
```json
{
  "platform": "midjourney",
  "total": 100,
  "items": [
    {
      "id": 1,
      "prompt": "Cyberpunk city...",
      "params": {
        "aspect": "16:9",
        "style": "raw",
        "version": "6"
      }
    }
  ]
}
```

### .txt (Simple List)
```
001 | Cyberpunk city at night, neon lights --ar 16:9 --v 6
002 | Futuristic Tokyo street, rain --ar 16:9 --v 6
003 | Neon marketplace, crowds --ar 16:9 --v 6
```

### .csv (Spreadsheet)
```csv
id,prompt,aspect,style,notes
1,"Cyberpunk city...","16:9","cinematic","hero image"
2,"Future Tokyo...","16:9","cinematic","scene 2"
```

---

## 🎯 COMMANDS

### Main Commands
```yaml
/mass [n] [type] [platform] "[style]":
  สร้าง n items สำหรับ platform
  
  Examples:
  /mass 50 music suno "Lo-Fi Chill"
  /mass 100 image midjourney "Fantasy Landscape"
  /mass 30 video sora "Product Demo"
  /mass 200 image flux "Anime Character"
```

### Control Commands
```yaml
/continue [from]:        ทำต่อจาก item ที่ from
/export [format]:        Export เป็น .md/.json/.txt/.csv
/batch [n] per file:     แบ่งไฟล์ละ n items
/variation [base]:       สร้าง variations จาก base prompt
```

### Info Commands
```yaml
/platforms:              แสดง platforms ทั้งหมด
/template [platform]:    แสดง template ของ platform
/formats:                แสดง output formats
/styles [platform]:      แสดง styles ที่แนะนำ
```

### Advanced Commands
```yaml
/sequence [n] [story]:   สร้าง sequential content (MV, Story)
/ab-test [base] [vars]:  สร้าง A/B test variations
/mix [platforms]:        ผสมหลาย platforms ในชุดเดียว
```

---

## 🔧 PRODUCTION MODES

### Mode 1: Single Style
```yaml
description: "ทุก item ใช้ style เดียวกัน"
use_case: "Album, Playlist, Consistent series"
example: "/mass 50 music suno 'Soft Pop Rock' --mode single"
```

### Mode 2: Variations
```yaml
description: "Base เดียวกัน ปรับ parameters เล็กน้อย"
use_case: "A/B Testing, Exploration"
variation_params:
  - tempo: "±10 BPM"
  - mood: "rotate through list"
  - color: "shift palette"
```

### Mode 3: Multi-Style
```yaml
description: "ผสมหลาย styles"
use_case: "Diverse portfolio, Mixed playlist"
example: |
  /mass 100 image midjourney --mix
  - 40% Cyberpunk
  - 30% Fantasy
  - 30% Anime
```

### Mode 4: Sequential
```yaml
description: "Items เชื่อมต่อกันเป็นเรื่อง"
use_case: "MV Storyboard, Story series, Tutorial steps"
example: "/mass 20 video kling 'Product Launch' --sequential"
```

### Mode 5: Loop/Seamless
```yaml
description: "สำหรับ loop content"
use_case: "Background video, Ambient music, Seamless animation"
example: "/mass 10 video veo3 'Abstract Loop' --loop"
```

---

## 📝 PLATFORM TEMPLATES

### Suno Music Template
```markdown
## เพลงที่ [X]

**ชื่อเพลง:** [Number].[Title in English]

**Style:**
[Genre], [Instruments], [BPM], [Key], [Vocal Type], [Mood], [Production Style]

**Lyrics:**
[Verse 1]
(4 lines)

[Pre-Chorus]
(2 lines)

[Chorus]
(4 lines)

[Verse 2]
(4 lines)

[Bridge]
(4 lines)

[Outro]
(1-2 lines)

**Concept:** [Brief description]

---
```

### Midjourney Image Template
```markdown
## Image [X]

**Prompt:**
[Subject], [Style], [Lighting], [Mood], [Details], [Quality tags]

**Parameters:**
--ar [aspect] --v [version] --style [style] --q [quality]

---
```

### Sora/Veo Video Template
```markdown
## Video [X]

**Scene:** [Scene description]

**Prompt:**
[Action], [Subject], [Environment], [Camera movement], [Lighting], [Style], [Duration hint]

**Technical:**
- Duration: [X seconds]
- Aspect: [16:9 / 9:16 / 1:1]
- Motion: [Low / Medium / High]
- Camera: [Static / Pan / Tracking / Drone]

---
```

### Kling Video Template
```markdown
## Video [X]

**Type:** [Text-to-Video / Image-to-Video]

**Prompt:**
[Subject], [Action], [Environment], [Camera], [Style]

**Settings:**
- Mode: [Standard / Pro]
- Duration: [5s / 10s]
- Motion: [1-10]

**Reference Image:** [If I2V - description of source image]

---
```

### ElevenLabs Voice Template
```markdown
## Audio [X]

**Text:**
[Script to speak]

**Voice Settings:**
- Voice: [Voice name/ID]
- Stability: [0.0-1.0]
- Clarity: [0.0-1.0]
- Style: [0.0-1.0]

---
```

---

## 🔄 AUTO-LEARN NEW PLATFORMS

เมื่อเจอ Platform ใหม่ที่ไม่รู้จัก:

```yaml
auto_learn_process:
  step_1: "Research platform capabilities"
  step_2: "Identify input format required"
  step_3: "Determine optimal output format"
  step_4: "Generate appropriate template"
  step_5: "Apply to mass production"

example:
  user: "/mass 50 image newplatform 'style'"
  system: |
    🔍 ไม่รู้จัก "newplatform"
    → Research วิธีใช้งาน...
    → พบว่ารับ prompt format แบบ X
    → สร้าง template ให้อัตโนมัติ
    → ดำเนินการสร้าง 50 items
```

---

## ⚠️ IMPORTANT RULES

1. **ห้ามใส่ชื่อศิลปิน/แบรนด์ใน Prompt** - ใช้เป็น inspiration เท่านั้น
2. **แต่ละ Item คั่นด้วย `---`** - สำหรับ parsing
3. **ใช้ภาษาอังกฤษใน Prompt** - AI เข้าใจดีกว่า
4. **Export ตาม format ที่ platform รองรับ**
5. **ตรวจสอบ platform limits** - บาง platform จำกัดจำนวน/วัน

---

## 📊 BATCH PLANNING

| Batch Size | Recommended Split | Use Case |
|------------|------------------|----------|
| 10-50 | Single file | Quick test |
| 51-100 | 2 files (50 each) | Medium batch |
| 101-500 | 5-10 files | Large production |
| 500+ | 10-20 files | Mass production |

---

## 🔗 INTEGRATION

Skill นี้ทำงานร่วมกับ:
- **mrarranger-bridge** → Auto-execute บน Chrome
- **mrarranger-music** → ใช้ Music DNA
- **mrarranger-visual** → ใช้ Visual DNA
- **mrarranger-seo** → สร้าง SEO พร้อมกัน

---

## References

- `references/platform-templates.md` - Templates ทุก platform
- `references/style-guides.md` - Style guides แต่ละประเภท
- `assets/batch-template.md` - Batch template ตัวอย่าง