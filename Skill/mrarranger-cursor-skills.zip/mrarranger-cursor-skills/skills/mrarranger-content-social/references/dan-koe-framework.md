# dan-koe-framework

**Source:** `/mnt/skills/user/dan-koe-framework/SKILL.md`
**Size:** 6353 bytes

---

---
name: dan-koe-framework
description: |
  Framework สร้างและวิเคราะห์ Content ที่มี Taste ไม่เป็น Slop - ใช้หลัก Dan Koe
  ใช้เมื่อ: (1) สร้าง Content ที่มีตัวตน ไม่ซ้ำใคร (2) วิเคราะห์ว่า Content เป็น Slop หรือ Signal
  (3) พัฒนา Taste และ Original Perspective (4) เปลี่ยนจาก Topic-based เป็น Mission-based content
  (5) สร้าง Idea Museum / Context Library (6) เขียนแบบ Content Director ไม่ใช่แค่ Creator
  Commands: /analyze [content], /create [topic], /taste [niche], /mission [goal], /museum [ideas]
  Supports: Thai, English
---

# Dan Koe Framework - Anti-Slop Content System

## Core Philosophy

**"Value ไม่ได้ตาย - ของที่ตายคือ Content ที่ไม่เคยมีตัวตน"**

AI ไม่ได้ฆ่า Creator - มันแค่เปิดโปงว่าใครคิดเป็น ใครคิดไม่เป็น

### The Signal-Slop Spectrum

```
SLOP ←――――――――――――――――――→ SIGNAL
(ใครเขียนก็ได้)          (เฉพาะคุณเท่านั้น)

- How-to ซ้ำๆ            - Original Perspective
- Tips รีไซเคิล          - ประสบการณ์จริง
- Framework ลอก          - Taste + Opinion
- ไม่มีตัวตน             - มีลายเซ็นชัด
```

## Commands

### /analyze [content]
วิเคราะห์ว่า Content เป็น Slop หรือ Signal
→ See [references/signal-vs-slop.md](references/signal-vs-slop.md)

### /create [topic]
สร้าง Content ที่มี Taste ไม่เหมือนใคร
→ See [references/content-templates.md](references/content-templates.md)

### /taste [niche]
พัฒนา Taste และ Original Voice ในหัวข้อนั้น
→ See [references/taste-development.md](references/taste-development.md)

### /mission [goal]
เปลี่ยนจาก Topic-based → Mission-based Content

### /museum [ideas]
สร้าง Idea Museum / Context Library

## Core Workflow

### 1. ก่อนสร้าง Content - ถาม 3 คำถาม

1. **Replaceability Test**: "ใครก็เขียนแบบนี้ได้ไหม?"
   - ถ้าใช่ = Slop territory
   - ถ้าไม่ = Signal potential

2. **Taste Test**: "มีความกล้าตัดสินอะไรออกไปไหม?"
   - ไม่มี opinion = ค่าเฉลี่ย = ลืมง่าย
   - มี opinion = มีตัวตน = จำได้

3. **Mission Test**: "Content นี้พาคนไปถึงไหน?"
   - Topic-based = ข้อมูล (ลอกได้)
   - Mission-based = การเปลี่ยนแปลง (ลอกไม่ได้)

### 2. The Content Director Mindset

```
Content Creator (เก่า)     Content Director (ใหม่)
-------------------------  -------------------------
ผูกตัวตนกับแรงงาน          ผูกตัวตนกับทิศทาง
"ต้องพิมพ์เอง"             "ต้องคิดเอง"
Volume = Value             Direction = Value
ยิ่งโพสต์ ยิ่งดี           ยิ่งคิด ยิ่งโดน
```

### 3. Mission-Based Framework

**เลิกคิดแบบนี้:**
> "ฉันสอนเรื่อง [Topic]"

**เริ่มคิดแบบนี้:**
> "ฉันพาคนจาก [สถานะ A] ไปสู่ [สถานะ B]"

**ตัวอย่าง:**
- ❌ "ฉันสอน Marketing"
- ✅ "ฉันพาคนจากไม่มีคนรู้จัก → มีแฟนคลับที่รอซื้อ"

- ❌ "ฉันสอน Productivity"
- ✅ "ฉันพาคนจากยุ่งทั้งวันไม่ได้อะไร → ทำน้อยแต่ได้มาก"

### 4. Idea Museum Building

สร้าง Context Library ของตัวเอง:

**ถ้าเคยเขียนแล้ว:**
- ประโยคที่คน Share/Save
- Framework ที่คนเอาไปใช้
- ความคิดที่คนพูดถึง

**ถ้ายังไม่เคยเขียน:**
- Save สิ่งที่หยุด Scroll
- จด "ทำไมถึงชอบ"
- สะสม Pattern ที่โดนใจ

### 5. The L.A.S. Formula (เบ้น's Addition)

**"Learn deeper, Act harder, Share better"**

```
LEARN → ACT → SHARE → (repeat)
เรียนลึก → ลงมือทำ → เล่าส่งต่อ
```

สิ่งที่ได้:
- มีประสบการณ์จริง (ไม่ใช่แค่ข้อมูล)
- มีมุมมองเฉพาะตัว (ไม่ใช่แค่ summary)
- มี Value ที่ลอกไม่ได้ (เพราะมาจากการลงมือทำ)

## Reference Files

- **[signal-vs-slop.md](references/signal-vs-slop.md)** - เกณฑ์วิเคราะห์ Content แบบละเอียด
- **[taste-development.md](references/taste-development.md)** - วิธีพัฒนา Taste และ Original Voice
- **[content-templates.md](references/content-templates.md)** - Templates สำหรับสร้าง Signal Content

## Quick Quality Check

Before posting, verify:

| Check | Slop | Signal |
|-------|------|--------|
| ใครเขียน? | ใครก็ได้ | เฉพาะคุณ |
| มี Opinion? | กลางๆ ปลอดภัย | ตัดสินชัด |
| มี Story? | แค่ข้อมูล | ประสบการณ์ |
| พาไปไหน? | อยู่กับที่ | เปลี่ยนสถานะ |
| จำได้ไหม? | ลืมง่าย | ติดหัว |

**ถ้าตอบ "Slop" ≥3 ข้อ → Rewrite**