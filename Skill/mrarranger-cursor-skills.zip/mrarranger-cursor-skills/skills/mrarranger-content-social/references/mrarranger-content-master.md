# mrarranger-content-master

**Source:** `/mnt/skills/user/mrarranger-content-master/SKILL.md`
**Size:** 6827 bytes

---

---
name: "mrarranger-content-master"
description: "ระบบสร้าง Content Marketing และ Sales ครบวงจรสำหรับ AI Music Course และธุรกิจดิจิทัล รองรับ 5 Writing Styles, 24 Conversion Content Techniques, 24 Selling Techniques, 12 Sales Page Structures, Thai Rewriting System (Russell Brunson style), และ Income Automation ใช้เมื่อ: (1) สร้าง Content Marketing ทุกรูปแบบ (2) เขียน Sales Page/Copy (3) สร้าง Conversion Content (4) เขียน Content ภาษาไทยแบบขายได้ (5) วางแผน Product/Monetization (6) ต้องการปรับ Style การเขียน Commands: /content [style] [platform] [topic], /sales [product], /convert [technique], /rewrite [text]"
---
  รองรับ 5 Writing Styles, 24 Conversion Content Techniques, 24 Selling Techniques, 
  12 Sales Page Structures, Thai Rewriting System (Russell Brunson style), และ Income Automation
  
  ใช้เมื่อ: (1) สร้าง Content Marketing ทุกรูปแบบ (2) เขียน Sales Page/Copy (3) สร้าง Conversion Content 
  (4) เขียน Content ภาษาไทยแบบขายได้ (5) วางแผน Product/Monetization (6) ต้องการปรับ Style การเขียน
  
  Commands: /content [style] [platform] [topic], /sales [product], /convert [technique], /rewrite [text]
---

# MRARRANGER Content Master

ระบบสร้าง Content Marketing และ Sales ครบวงจร by Mrarranger

## Core Components

### 1. Five Writing Styles
เลือก Style ตาม Platform และ Audience - ดู `references/styles.md`

| Style | Tone | Best For |
|-------|------|----------|
| **บอ.บู๋** | Casual, Data+Emotion | Facebook, Blog, Email |
| **Dan Koe** | Philosophy+Business | LinkedIn, Twitter, Course |
| **อาจารย์อดัม** | Friendly Teacher | YouTube, Workshop |
| **Gary Vee TH** | High Energy, Action | TikTok, Reels |
| **พี่โอ๋** | Minimalist, Zen | Instagram, Infographic |

### 2. AI Conversion Content (24 เทคนิค)
เทคนิคสร้าง Content ที่กระตุ้นการซื้อ - ดู `references/conversion-content.md`

### 3. AI Selling Techniques (24 เทคนิค)
AWARE → ACCEPT → ASPIRE → ACTION Framework - ดู `references/selling-techniques.md`

### 4. Sales Page Structure (12 ส่วน)
โครงสร้าง High Converting Sales Page - ดู `references/sales-page.md`

### 5. Thai Rewriting System
เขียนภาษาไทยแบบ Russell Brunson, Jim Edwards, Peng Joon - ดู `references/thai-rewriting.md`

### 6. Income Automation & Product Matrix
8 ประเภทสินค้าดิจิทัล และกลยุทธ์ Monetization - ดู `references/monetization.md`

## Quick Start

### Command: /content [style] [platform] [topic]
```
/content บอ.บู๋ facebook "AI Music สร้างเพลงได้จริง"
/content dan-koe linkedin "Future of Music Industry"
/content อาจารย์อดัม youtube "สอนใช้ Suno AI ฉบับมือใหม่"
```

### Command: /sales [product]
สร้าง Sales Page ครบ 12 ส่วน
```
/sales "คอร์ส AI Music Mastery"
```

### Command: /convert [technique-number] [topic]
ใช้เทคนิค Conversion Content เฉพาะ
```
/convert 1 "AI Music" → ใช้เทคนิค Relatable Situation
/convert 8 "Suno AI" → ใช้เทคนิค Signature Method
```

### Command: /rewrite [text]
แปลง/เขียนใหม่เป็นภาษาไทยแบบ Conversion Copy

## Workflow

1. **รับ Request** → ระบุ Topic, Platform, Audience Level
2. **เลือก Style** → Auto-select จาก Platform หรือตามที่ระบุ
3. **เลือก Framework** → Conversion Content, Selling Technique, หรือ Sales Page
4. **สร้าง Content** → ใช้ Thai Rewriting System ถ้าเป็นภาษาไทย
5. **Output** → ตาม Format ของ Platform

## Platform Matrix (Auto Style Selection)

| Platform | Primary Style | Format |
|----------|--------------|--------|
| Facebook | บอ.บู๋ | 300-800 words, storytelling |
| Instagram | พี่โอ๋ | Carousel 5-10 slides |
| TikTok | Gary Vee TH | Script 15-60s |
| YouTube | อาจารย์อดัม | Script 8-20 min |
| LinkedIn | Dan Koe | 600-1500 words |
| Email | บอ.บู๋ + Dan Koe | 500-1000 words |
| Sales Page | Mixed | 12 sections framework |

## Rules

1. **Author**: ชื่อผู้เขียนคือ "Mrarranger" เสมอ ไม่ว่าใช้ Style ใด
2. **Topic Focus**: AI Music Tools (Suno AI, AIVA, Soundraw) และ Monetization
3. **Language**: ภาษาไทยใช้ Thai Rewriting System, อังกฤษใช้ Dan Koe style
4. **CTA**: ทุก Content ต้องมี Call-to-Action ที่ชัดเจน

## Reference Files

| File | Content |
|------|---------|
| `references/styles.md` | 5 Writing Styles + Voice Parameters |
| `references/hook-openers.md` | 🆕 Hook Library 50+ แบบ (Original) |
| `references/brand-cortex.md` | 🆕 Brand House 5 Components |
| `references/72-topics.md` | 🆕 72 Content Topics |
| `references/conversion-content.md` | 24 Conversion Content Techniques |
| `references/selling-techniques.md` | 24 AI Selling Techniques |
| `references/sales-page.md` | 12 Sales Page Structure |
| `references/thai-rewriting.md` | Thai Rewriting System |
| `references/monetization.md` | Income Automation Matrix |
| `references/prompts.md` | AI Prompt Templates |

## New Commands

### Command: /brand [component]
สร้าง Brand Cortex - ดู `references/brand-cortex.md`
```
/brand company → Company Brand elements
/brand personal → Personal Brand elements
/brand product → Product Positioning
```

### Command: /topic [number]
สร้าง Content จาก 72 Topics - ดู `references/72-topics.md`
```
/topic 1 → Topic: ทำไมต้องสร้าง Digital Asset
/topic 25 → Topic: Lead Magnet ที่ดี
/topic 72 → Topic: นอนนับเงิน
```

### Command: /hook [category] [topic]
สร้าง Hook เปิดหัว - ดู `references/hook-openers.md`
```
/hook question "AI Music" → Question-based hooks
/hook story "การเริ่มต้น" → Story hooks
/hook contrarian "การทำเพลง" → Contrarian hooks
```