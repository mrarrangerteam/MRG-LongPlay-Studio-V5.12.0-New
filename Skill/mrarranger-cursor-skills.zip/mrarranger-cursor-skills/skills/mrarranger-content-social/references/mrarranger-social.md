# mrarranger-social

**Source:** `/mnt/skills/user/mrarranger-social/SKILL.md`
**Size:** 4053 bytes

---

---
name: "mrarranger-social"
description: "MRARRANGER Social Media - สร้าง Social Content ทุก Platform (Twitter/X, Instagram, TikTok, LinkedIn, Facebook). ใช้เมื่อ (1) สร้าง Twitter Thread (2) เขียน IG Caption (3) Script TikTok (4) LinkedIn Post (5) แปลง content เป็น social posts. Commands /thread /ig /tiktok /linkedin /fb /convert"
---

# MRARRANGER Social Media

## Quick Commands

| Command | Platform | Output |
|---------|----------|--------|
| `/thread [หัวข้อ]` | Twitter/X | Thread 5-15 tweets |
| `/ig [หัวข้อ]` | Instagram | Caption + Hashtags + CTA |
| `/tiktok [หัวข้อ]` | TikTok | Script + Hook + Trend |
| `/linkedin [หัวข้อ]` | LinkedIn | Professional post |
| `/fb [หัวข้อ]` | Facebook | Engaging post |
| `/convert [content]` | All | แปลง content เป็นทุก platform |

## Platform Specs

### Twitter/X Thread
```
Tweet 1: HOOK (ต้องหยุด scroll)
Tweet 2-X: VALUE (1 idea = 1 tweet)
Tweet Final: CTA + Retweet request

Rules:
- แต่ละ tweet < 280 ตัวอักษร
- ใช้ line breaks เพื่อ readability
- Emoji sparingly (1-2 per tweet)
- End with engagement question
```

### Instagram Caption
```
Line 1: HOOK (ปรากฏก่อน "more")
Line 2-5: VALUE/STORY
Line 6: CTA
Line 7: .
Line 8: .
Line 9: .
Line 10: Hashtags (20-30)

Rules:
- < 2,200 ตัวอักษร
- Hashtags: Mix popular + niche
- Use emojis strategically
```

### TikTok Script
```
[0-1s] HOOK: "POV:" / "Wait for it" / "สิ่งที่คนไม่รู้คือ..."
[1-3s] SETUP: Context
[3-45s] CONTENT: Value/Entertainment
[45-60s] PAYOFF: Resolution + CTA

Hooks ที่ใช้ได้:
- "3 สิ่งที่ฉันหวังว่าจะรู้ก่อน..."
- "ทำไมไม่มีใครพูดถึง..."
- "นี่คือความลับที่..."
- "หยุด scroll ถ้าคุณ..."
```

### LinkedIn Post
```
Line 1: HOOK (Bold statement)
[blank line]
Line 2-3: CONTEXT
[blank line]
Line 4-8: VALUE (Bullet points OK)
[blank line]
Line 9: INSIGHT/LESSON
[blank line]
Line 10: CTA + Question

Rules:
- Professional but personal
- Stories perform well
- Data/stats add credibility
- End with engaging question
```

### Facebook Post
```
Hook → Story → Value → CTA

Rules:
- Longer form OK (up to 500 words)
- Personal stories work best
- Ask questions for engagement
- Use native video when possible
```

## Hashtag Strategy

### Instagram Hashtag Mix (30 total)
```
Popular (1M+): 5 hashtags
Mid-range (100K-1M): 15 hashtags
Niche (<100K): 10 hashtags
```

### Twitter Hashtags
```
Maximum: 2-3 per tweet
Place: End of tweet or inline
```

### TikTok Hashtags
```
Maximum: 3-5
Include: 1 trending + 2-3 niche + 1 branded
```

## Content Conversion

เมื่อได้รับ content จาก skill อื่น (เช่น /blog):

```
Blog Post (1000 words)
    ↓
├── Twitter Thread (10 tweets)
├── Instagram Carousel (7 slides concept)
├── TikTok Script (60s)
├── LinkedIn Post (300 words)
└── Facebook Post (200 words)
```

## Posting Schedule Templates

### Daily Posting
```
Twitter: 3-5x/day
Instagram: 1-2x/day
TikTok: 1-3x/day
LinkedIn: 1x/day
Facebook: 1-2x/day
```

### Best Times (Thailand)
```
Twitter: 8AM, 12PM, 6PM, 9PM
Instagram: 11AM, 2PM, 7PM
TikTok: 7PM-10PM
LinkedIn: 8AM, 12PM, 5PM
Facebook: 1PM, 4PM, 8PM
```

## Output Format

ทุก social content ต้อง output:
1. **Ready-to-post text** - Copy/paste ได้เลย
2. **Hashtags** - แยกชุด
3. **Image/Video prompt** - สำหรับสร้าง visual
4. **Best posting time** - แนะนำเวลา

## Chain Integration

```
mrarranger-content → /convert → Social posts ทุก platform
mrarranger-social → mrarranger-visual → Image prompts
mrarranger-social → mrarranger-seo → Optimize reach
```