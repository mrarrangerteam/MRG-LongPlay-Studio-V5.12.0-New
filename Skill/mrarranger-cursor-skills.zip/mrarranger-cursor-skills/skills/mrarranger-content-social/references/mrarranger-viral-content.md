# mrarranger-viral-content

**Source:** `/mnt/skills/user/mrarranger-viral-content/SKILL.md`
**Size:** 5185 bytes

---

---
name: "mrarranger-viral-content"
description: "ระบบสร้าง Viral Content ครบวงจร - 8 Viral Formulas, 50+ Hooks, 20+ Ready-to-Use Templates รวม Case Studies จาก Viral จริง, Platform-Specific Scripts, และ Niche Templates ใช้เมื่อ: (1) สร้าง Viral Content ทุก Platform (2) เขียน Hook หยุด Scroll (3) สร้าง Short Video Script (4) วิเคราะห์ทำไม Content Viral (5) Trend Riding (6) Content Series (7) Viral Challenge Commands: /viral /hook /trend /series /challenge /analyze /remix"
---
  Commands: /viral /hook /trend /series /challenge /analyze /remix
---

# MRARRANGER Viral Content Creator V2.0

## Quick Commands

| Command | Output |
|---------|--------|
| `/viral [platform] [topic]` | Complete viral script + visuals |
| `/hook [type]` | 5 hooks: shock/curiosity/story/value/contrarian |
| `/trend [niche]` | Trending angles + adaptation |
| `/series [concept]` | 5-7 part series plan |
| `/challenge [idea]` | Viral challenge campaign |
| `/analyze [url/description]` | ทำไม content นี้ viral |
| `/remix [content]` | 5 variations ต่าง platform |

## V.I.R.A.L Framework

```
V = VALUE      → คนได้อะไรจาก content นี้?
I = IDENTITY   → คนอยาก share เพราะมันบอกอะไรเกี่ยวกับตัวเขา?
R = RELATABLE  → คน "เข้าใจ" หรือ "เคยเจอ" ไหม?
A = ACTION     → มี CTA ที่ชัดเจนไหม?
L = LOOP       → ดูจบแล้วอยากดูอีกไหม?
```

## 8 Viral Formulas (Quick Reference)

| # | Formula | Structure | Best For |
|---|---------|-----------|----------|
| 1 | **SEP** | Shock→Explain→Proof | Tutorial, Before/After |
| 2 | **DRA** | Disagree→Reason→Alternative | Hot takes, Opinion |
| 3 | **PAS** | Problem→Agitate→Solve | How-to, Tips |
| 4 | **SLC** | Story→Lesson→Challenge | Transformation |
| 5 | **LOOP** | Loop→Value→Loop | Satisfying, Process |
| 6 | **QTR** | Question→Tease→Reveal | Secrets, Behind scenes |
| 7 | **T+N** | Trend + Niche | Trend riding |
| 8 | **SERIES** | Hook→Develop→Cliffhanger | Building followers |

## Platform Quick Specs

| Platform | Duration | Key Metric | First 3s |
|----------|----------|------------|----------|
| TikTok | 21-34s | Watch Time | Pattern interrupt |
| IG Reels | 7-15s | Saves | Visual hook |
| YT Shorts | 30-60s | CTR | Title + thumbnail |
| LinkedIn | Text post | Engagement | First line = hook |
| Twitter/X | Thread | Retweets | Tweet 1 = everything |

## Output Format

```
🔥 VIRAL CONTENT: [Title]
📌 Platform: [X] | Formula: [X] | Duration: [X]

🎣 HOOK (เลือก 1):
1. [Hook option 1]
2. [Hook option 2]
3. [Hook option 3]

📝 SCRIPT:
[0-3s] HOOK: ...
[3-15s] CONTENT: ...
[15-25s] VALUE: ...
[25-30s] CTA: ...

🎬 VISUAL NOTES:
- Scene 1: ...
- Scene 2: ...

📋 COPY-PASTE CAPTION:
[Ready-to-use caption with hashtags]

✅ VIRAL CHECKLIST:
☐ Hook ใน 0.5s | ☐ Loop potential | ☐ Share value | ☐ Clear CTA
```

## Reference Files

| File | เมื่อไหร่ต้องอ่าน |
|------|-----------------|
| `references/examples.md` | ต้องการตัวอย่าง script พร้อมใช้ |
| `references/case-studies.md` | ต้องการวิเคราะห์ viral จริง |
| `references/viral-hooks.md` | ต้องการ hook หลากหลาย |
| `references/viral-formulas.md` | ต้องการ formula เชิงลึก |
| `references/platform-specs.md` | ต้องการ specs ละเอียด |
| `references/niche-templates.md` | ต้องการ templates เฉพาะ niche |
| `references/viral-psychology.md` | ต้องการเข้าใจ psychology |
| `references/trend-series.md` | ต้องการ trend riding + series |
| `references/quick-cheatsheet.md` | 1-page quick reference ทุกอย่าง |
| `references/ai-video-templates.md` | 40+ Templates สำหรับ AI Video (Veo3/Runway/Kling) |

## Workflow

```
1. รับ Request → ระบุ Platform + Topic + Goal
2. เลือก Formula → ดู Quick Reference ด้านบน
3. สร้าง Hooks → อ่าน references/viral-hooks.md
4. เขียน Script → ใช้ Output Format
5. Optimize → ตรวจ Viral Checklist
6. Output → พร้อม Copy-Paste
```

## Rules

1. **Hook First** - ทุก content เริ่มด้วย hook ที่หยุด scroll ใน 0.5s
2. **Platform Native** - ปรับ format ตาม platform ไม่ใช่ one-size-fits-all
3. **Copy-Ready** - Output ต้อง copy-paste ได้เลย ไม่ต้องแก้
4. **Value > Viral** - มีคุณค่าจริง ไม่ใช่แค่ clickbait
5. **Test Hooks** - เสนอ 3-5 hooks ให้เลือก

| `references/social-platform-specs.md` | Platform specs + templates ทุก social |