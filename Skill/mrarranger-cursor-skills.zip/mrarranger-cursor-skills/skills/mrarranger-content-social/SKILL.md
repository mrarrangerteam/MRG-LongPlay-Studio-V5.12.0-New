---
name: mrarranger-content-social
description: "MRARRANGER Content & Social Media - รวม 8 Skills: Viral Content (Hooks, Trends, Series, Challenge), Social Media (IG, TikTok, LinkedIn, FB, Twitter, Thread), Content Creation (Blog, Email, Newsletter, Landing Page, Script), Content Master (Content Marketing Engine, Sales Content), Dan Koe Framework (Signal vs Slop, Taste-Based Content), Content Strategy (Traffic, Authority, Customer Research), Mass Production (Batch Content for All AI Platforms), Thai Master (Thai Copywriting, Prosody, Cultural Context). Commands: /viral /hook /trend /social /ig /tiktok /linkedin /content /blog /email /newsletter /mass /thai. Triggers: content creation, social media, viral, hooks, blog post, email marketing, Thai copywriting, batch content, content strategy"
---

# MRARRANGER Content & Social Media — 8 Skills Combined

> Routing table for content and social media skills

## SKILL ROUTING TABLE

| Trigger | Reference File | Use When |
|---------|---------------|----------|
| `/viral` `/hook` `/trend` `/series` | `references/mrarranger-viral-content.md` | Viral content, hooks |
| `/social` `/ig` `/tiktok` `/linkedin` `/fb` | `references/mrarranger-social.md` | Social media posts |
| `/blog` `/email` `/newsletter` `/landing` | `references/mrarranger-content.md` | Blog, email, newsletter |
| `/content-master` `/content-engine` | `references/mrarranger-content-master.md` | Content marketing engine |
| `/dankoe` `/signal` `/slop` | `references/dan-koe-framework.md` | Dan Koe style content |
| `/strategy` `/traffic` `/authority` | `references/content-strategy.md` | Content strategy |
| `/mass` `/batch` `/bulk` | `references/mrarranger-mass-production.md` | Batch content production |
| `/thai` `/prosody` `/thai-copy` | `references/mrarranger-thai-master.md` | Thai language copywriting |
